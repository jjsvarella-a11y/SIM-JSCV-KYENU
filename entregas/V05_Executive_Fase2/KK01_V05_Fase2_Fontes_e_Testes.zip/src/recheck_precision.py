from pathlib import Path
import sys,json,concurrent.futures
sys.path.insert(0,str(Path(__file__).parent));from run_sensitivities import CASES
from check_recalc import check
R=Path(__file__).resolve().parents[1]
def worker(case):
 name,params,_=case;folder=R/'validacao'/('Teste_'+name);prior=json.loads((folder/'Resultado.json').read_text());res=check(folder/'out'/(name+'.xlsx'),params,full_errors=False)
 for k in ['case','seconds','params','input_sha256','canonical_input_sha256']:res[k]=prior.get(k,name if k=='case' else None)
 res['error_count']=prior['error_count'];res['errors']=prior['errors'];res['ok']=res['ok'] and prior['error_count']==0;res['formula_error_scan_performed_on_recalculated_file']=True;res['strict_precision_rechecked']=True
 if 'auxiliary_risks_ok' in prior:res['auxiliary_risks_ok']=prior['auxiliary_risks_ok'];res['ok']=res['ok'] and prior['auxiliary_risks_ok']
 (folder/'Resultado.json').write_text(json.dumps(res,ensure_ascii=False,indent=2));print(name,res['ok'],res['failures'][:2],flush=True);return res
if __name__=='__main__':
 cases=[x for x in CASES if x[0]!='Base']
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:results=list(pool.map(worker,cases))
 (R/'entrega/Testes_Precisao_Fase2.json').write_text(json.dumps(results,ensure_ascii=False,indent=2));raise SystemExit(not all(x['ok'] for x in results))
