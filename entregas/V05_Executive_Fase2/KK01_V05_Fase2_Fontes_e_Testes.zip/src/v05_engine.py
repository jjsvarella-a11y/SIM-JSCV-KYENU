"""V05: inherited 180-month bank engine; explicit dividend policy and proportional exit.
The original V04 module is imported read-only; no edits to its files.
"""
from pathlib import Path
import sys,inspect,json,copy
BASESRC=Path(__file__).resolve().parents[1]/'reference/src'
sys.path.insert(0,str(BASESRC))
import engine as v4
from selected_policy import selected as v4_selected
COUNTS=[3,2,10];TICKETS=[1e7,5e6,1e6];RATES=[[.07,.05,.04],[.085,.0575,.045],[.10,.065,.05]]
LEGCATS=['Platinum']+['Gold']*6+['Silver']*5
LEGCODES=['P01','G01']+['G02']*5+['S01','S02','S03','S04','S05']
OLDPIPE=v4.pipeline;OLDHOTEL=v4.hotel

def config(**u):
 p=v4.config(**u);p.update({'v05':True,'coverage':1.2,'div_basis':'Geração 12M','div_tier':'Automático','partial':1,'exit_mult':12,'exit_enabled':1,'benefit_v05':True,'block_v05':True,'div_v05':True,'exit_proportional':True,'extra_reserves':{},'document_caps':{},'approvals':{},'actual_payments':{}})
 p.update(u);p['n_gold']=u.get('n_gold',2);p['n_silver']=u.get('n_silver',5);return p

def pipeline(p):
 plans=OLDPIPE(p)
 if not p.get('block_v05'):return plans
 for i,x in enumerate(plans):
  x.update(code=LEGCODES[i],category=LEGCATS[i]);x['block_ticket']=1e7 if i==0 else 5e6 if i<7 else 1e6
  if p['equity_mode']=='Combinação tickets':
   n=1 if i<2 else 2 if i<7 else i-6;selected=p['n_platinum']>=n if i==0 else p['n_gold']>=n if i<7 else p['n_silver']>=n
   x['selected']=selected;x['planned_received']=x['ticket']*p['received_ratio']*p['capital_fraction'] if selected and x['commit_month']<=p['capital_stop'] else 0;x['transfer']=x['planned_received']*p['treasury_ratio']
  # Preserve the twelve original payment legs and all aggregate monthly funding.
  # G02 pays five 1M tranches, not five Gold blocks.
 return plans

def hotel(p):
 if not p.get('benefit_v05'):return OLDHOTEL(p)
 p=p.copy();old=2*p['benefit_platinum']+3*p['benefit_gold']+15*p['benefit_silver'];new=3*p['benefit_platinum']+2*p['benefit_gold']+10*p['benefit_silver']
 # Inject the same total into the inherited cost formula without changing operating logic.
 p['benefit_platinum']=(new-3*p['benefit_gold']-15*p['benefit_silver'])/2
 return OLDHOTEL(p)

def dividend_decision(p,previous,loc):
 m=loc['m'];start=max(0,m-12)
 def generated(x):return x['hotel_cf']+x['res_cf']-x['service']-sum(x[k] for k in ['construction','supervision','contingency','hotpay','transfer','marketing','kyenu','openingfee','broker','mobil'])
 gen=sum(generated(x) for x in previous[start:])+loc['h'][m-1]['cf']+loc['res'][m-1]['kk']-loc['principal']-loc['interest']-loc['loan_interest']-loc['loan_principal']-loc['commitment']-loc['cap'][m-1]['total']-loc['hotpay']-loc['re']['tax'][m-1]-loc['re']['marketing'][m-1]-loc['re']['kyenu'][m-1]-loc['fees']
 free=max(0,loc['post']-loc['sweep']-loc['reserve']-loc['forward']-p['extra_reserves'].get(m,0));profit=max(0,loc['profits']-loc['distributed'])
 legal=max(0,(p['legal_dividend_cap'] or 0)-loc['distributed']) if p['payout_basis']=='Documentado' else profit
 independent=min(free,legal);covcap=max(0,gen)/p['coverage']
 capacity=min(independent,covcap) if p['div_basis']=='Geração 12M' else independent
 objectives=[sum(n*t*r for n,t,r in zip(COUNTS,TICKETS,rates)) for rates in RATES]
 targetindex={'Mínimo':0,'Intermédio':1,'Máximo':2}.get(p['div_tier'],2)
 while targetindex>0 and capacity<objectives[targetindex]:targetindex-=1
 target=objectives[targetindex]
 eligible=m>=54 and m>=p['open']+23 and (m-54)%12==0 and loc['debt']<.005 and loc['shareloan']<.005 and loc['fundgap_ever']<.005
 fullcapital=sum(x['planned_received'] for x in pipeline(p) if x['pay_month']<=m)>=p['equity']-p['conversion']-.005
 eligible=eligible and fullcapital and p['div_tier']!='Suspenso'
 div=min(capacity,target) if eligible and (p['partial'] or capacity>=target) else 0
 achieved=2 if div>=objectives[2]-.005 else 1 if div>=objectives[1]-.005 else 0
 weights=[n*t*rate/objectives[achieved] for n,t,rate in zip(COUNTS,TICKETS,RATES[achieved])]
 approved=min(div,max(0,p['document_caps'].get(m,0))) if p['approvals'].get(m)==1 else 0
 return div,{'generation12':gen,'free':free,'independent':independent,'covcapacity':covcap,'capacity':capacity,'target':target,'tier':achieved,'weights':weights,'coverage_ratio':gen/div if div else None,'financial_dividend':div,'approved_documented':approved,'actual_documented':p['actual_payments'].get(m),'eligible':eligible}

# Reuse the original run body and override ONLY the dividend decision line.
source=inspect.getsource(v4.run).replace('def run(p=None):','def run(p=None):')
old="  dividend=min(ceiling,max(0,post-sweep-reserve)*p['payout']) if m>=p['open'] and m%int(p['dividend_frequency'])==0 and debt<.005 and shareloan<.005 and fundgap_ever<.005 else 0"
assert old in source
source=source.replace(old,old+"\n  if p.get('div_v05'):dividend,_dm=dividend_decision(p,out,locals())")
source=source.replace(" return dict(p=p,re=re,cap=cap,hotel=h,res=res,flow=out)","  if p.get('div_v05'):out[-1]['div_metrics']=_dm\n return dict(p=p,re=re,cap=cap,hotel=h,res=res,flow=out)")
ns=dict(vars(v4));ns.update(pipeline=pipeline,hotel=hotel,dividend_decision=dividend_decision,config=config)
def investor_outlay(p,m):return sum(x['planned_received'] for x in pipeline(p) if x['pay_month']==m) if p['capital_schedule']!='V03' else v4.investor_outlay(p,m)
ns['investor_outlay']=investor_outlay
exec(source,ns);run=ns['run']

def results(r):
 p=r['p'];f=r['flow'];end=f[-1];ebitda=sum(x['ebitda'] for x in r['hotel'][168:180]);ev=ebitda*p['exit_mult'];exitvalue=max(0,ev*(1-p['exit_cost'])-end['debt']-end['shareloan']+end['cash']-end['hothold']-end['conthold']-p['extra_reserves'].get(180,0))*p.get('exit_enabled',1)
 received=[];outlays=[];catdiv=[0.,0.,0.];catout=[0.,0.,0.];block_cf={code:[0.] for code in dict.fromkeys(LEGCODES)};pay=[]
 for row in f:
  m=row['m'];d=row['dividend'];cap=investor_outlay(p,m)
  if p.get('div_v05'):weights=row['div_metrics']['weights']
  else:weights=[.6,.2,.2] # diagnostic only; actual V04 allocation selected separately below
  dc=[d*x for x in weights];ec=[exitvalue*s if m==180 else 0 for s in [.6,.2,.2]]
  new=dc[0]/3+dc[1]+dc[2]/2+(exitvalue*.5 if m==180 else 0)
  received.append(new);outlays.append(cap);catdiv=[a+b for a,b in zip(catdiv,dc)];pay.append(dc)
  for code in block_cf:
   j=0 if code[0]=='P' else 1 if code[0]=='G' else 2
   spent=sum(x['planned_received'] for x in pipeline(p) if x['code']==code and x['pay_month']==m)
   block_cf[code].append((dc[j]+ec[j])/COUNTS[j]-spent)
 totalout=sum(outlays);cf=[0]+[a-b for a,b in zip(received,outlays)]
 terminal_project=(ev*(1-p['exit_cost'])-end['hothold']-end['conthold']-p['extra_reserves'].get(180,0))*p.get('exit_enabled',1);pc=[0]+[x['project_cf'] for x in f];pc[-1]+=terminal_project
 project_irr=eirr=v4.irr(pc);project_npv=sum(x/(1+p['discount'])**(i/12) for i,x in enumerate(pc))
 return {'project_irr_exit':project_irr,'project_npv_exit':project_npv,'cash30':f[29]['cash'],'cash42':f[41]['cash'],'cash54':f[53]['cash'],'div54':f[53]['dividend'],'reserve54':f[53]['reserve'],'generation54':f[53].get('div_metrics',{}).get('generation12'),'free54':f[53].get('div_metrics',{}).get('free'),'cash_end':end['cash'],'dividends':sum(x['dividend'] for x in f),'new_dividends':sum(received)-exitvalue*.5,'ebitda15':ebitda,'ev':ev,'exit_equity':exitvalue,'new_irr':v4.irr(cf),'new_moic':sum(received)/totalout if totalout else None,'new_npv':sum(x/(1+p['equity_discount'])**(i/12) for i,x in enumerate(cf)),'peak':max(x['debt_open']+x['draw'] for x in f),'used':end['cumulative'],'reserve_gap':max(x['reservegap'] for x in f),'funding_gap':max(x['gap'] for x in f),'category_dividends':catdiv,'block_cf':block_cf,'new_cf':cf}
if __name__=='__main__':
 r=run(config());print(json.dumps(results(r),ensure_ascii=False,indent=2))
