from pathlib import Path
import zipfile,xml.etree.ElementTree as E,json,re,hashlib,html
R=Path(__file__).resolve().parents[1];P=R/'entrega/KK01_Modelo_Integrado_V05_Executive.xlsx';S=R/'original/KK01_Modelo_Integrado_V04_Excel_Fix.xlsx';N='{http://schemas.openxmlformats.org/spreadsheetml/2006/main}';RID='{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id';checks=[]
def test(name,ok,detail=None):checks.append({'test':name,'ok':bool(ok),'detail':detail})
with zipfile.ZipFile(S) as a,zipfile.ZipFile(P) as b:
 test('ZIP íntegro',b.testzip() is None)
 wa=E.fromstring(a.read('xl/workbook.xml'));wb=E.fromstring(b.read('xl/workbook.xml'));sa=[(s.attrib['name'],s.attrib.get('state','visible')) for s in wa.find(N+'sheets')];sb=[(s.attrib['name'],s.attrib.get('state','visible')) for s in wb.find(N+'sheets')];test('313folhas originais e estados preservados',all(x in sb for x in sa));test('6folhas financeiras novas',len(sb)==len(sa)+6)
 na=[E.tostring(x) for x in wa.find(N+'definedNames')];nb=[E.tostring(x) for x in wb.find(N+'definedNames')];test('347nomes definidos preservados',na==nb)
 for label,prefix in [('gráficos','xl/charts/'),('imagens','xl/media/'),('notas','xl/comments'),('estilos','xl/styles.xml')]:
  files=[x for x in a.namelist() if x.startswith(prefix)];normalize=lambda raw:re.sub(rb'<c:(?:numCache|strCache)>.*?</c:(?:numCache|strCache)>',b'',raw,flags=re.S)
  if label=='gráficos':test('Desenho e referências dos gráficos preservados',all(x in b.namelist() and normalize(a.read(x))==normalize(b.read(x)) for x in files),len(files))
  else:test(label+' preservados byte a byte',all(x in b.namelist() and a.read(x)==b.read(x) for x in files),len(files))
 allnames={n for n,_ in sb};invalid=[];longf=[];total=0;allerr=[];formula_counts={};dup=[]
 for fn in b.namelist():
  if not fn.startswith('xl/worksheets/') or not fn.endswith('.xml'):continue
  txt=b.read(fn).decode();addrs=re.findall(r'<c\b[^>]*\br="([A-Z]+\d+)"',txt)
  if len(addrs)!=len(set(addrs)):dup.append(fn)
  for m in re.finditer(r'<f(?:\s[^>]*)?>(.*?)</f>',txt,re.S):
   total+=1
   if len(html.unescape(m[1]))>8192:longf.append(fn)
  if re.search(r'<c\b[^>]*t="e"',txt):allerr.append(fn)
 test('Sem células duplicadas',not dup,dup[:5]);test('Fórmulas dentro do limite Excel',not longf,longf[:5]);test('Fórmulas dinâmicas preservadas e ampliadas',total>=1485103,total);test('Sem erros armazenados no ficheiro final',not allerr,allerr[:8]);test('Sem ligações externas',not any(x.startswith('xl/externalLinks/') for x in b.namelist()));test('Sem VBA',not any('vbaProject' in x for x in b.namelist()))
 cp=wb.find(N+'calcPr');test('Recálculo automático integral',cp.get('calcMode')=='auto' and cp.get('fullCalcOnLoad')=='1' and cp.get('forceFullCalc')=='1');test('Iteração desativada',cp.get('iterate')=='false')
report={'ok':all(x['ok'] for x in checks),'checks':len(checks),'failures':[x for x in checks if not x['ok']],'results':checks};(R/'entrega/Testes_Estruturais_Fase2.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='results'},ensure_ascii=False));raise SystemExit(not report['ok'])
