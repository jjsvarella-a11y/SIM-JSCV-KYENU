from pathlib import Path
import openpyxl,sys,json,zipfile,re,xml.etree.ElementTree as E
sys.path.insert(0,str(Path(__file__).parent));import v05_engine as e
META=json.load(open(Path(__file__).resolve().parents[1]/'reference/src/build_metadata.json'))
def check(path,params=None,full_errors=True):
 r=e.run(e.config(**(params or {})));expected=e.results(r);w=openpyxl.load_workbook(path,read_only=True,data_only=True);fails=[];count=0
 def equal(label,a,b):
  nonlocal count
  count+=1
  if b is None:
   if isinstance(a,(int,float)):fails.append([label,a,b])
  else:
   ratio=(label in ['V04 Retornos!B27','V04 Retornos!B28','KPI!B29'] or label.endswith(' dscr') or label.startswith('V05 Blocos!I') or label.startswith('V05 Blocos!H'))
   tol=max(1e-7,abs(b)*1e-8) if ratio else 1e-10 if label=='V05 Retornos!B25' else max(.01,abs(b)*1e-9)
   if not isinstance(a,(int,float)) or abs(a-b)>tol:fails.append([label,a,b])
 for row,x in zip(w['Fluxo 180M'].iter_rows(min_row=5,max_row=184,values_only=True),r['flow']):
  for k,c in META['flow_columns'].items():
   if isinstance(x.get(k),(int,float)):equal('M'+str(x['m'])+' '+k,row[c],x[k])
  if x.get('div_metrics'):
   for k,c in [('generation12',56),('free',57),('independent',58),('covcapacity',59),('capacity',60),('target',62),('financial_dividend',64)]:equal('M'+str(x['m'])+' '+k,row[c],x['div_metrics'][k])
 for a,k in [('B27','new_irr'),('B28','new_moic'),('B29','new_npv'),('B36','exit_equity')]:equal('V04 Retornos!'+a,w['V04 Retornos'][a].value,expected[k]*(.5 if a=='B36' else 1))
 equal('KPI!B27',w['KPI']['B27'].value,expected['project_npv_exit'])
 equal('KPI!B29',w['KPI']['B29'].value,expected['project_irr_exit'])
 for i,code in enumerate(['P01','G01','G02','S01','S02','S03','S04','S05']):
  for m,row in enumerate(w['V05 Fluxos Blocos'].iter_rows(min_row=5,max_row=185,min_col=i+2,max_col=i+2,values_only=True)):equal(code+' '+str(m),row[0],expected['block_cf'][code][m])
 for a in ['B25','B26','B27']:equal('V05 Retornos!'+a,w['V05 Retornos'][a].value,0)
 for i,code in enumerate(['P01','G01','G02','S01','S02','S03','S04','S05']):
  br=i+12;k=0 if i==0 else 1 if i<3 else 2;paid=sum(x['planned_received'] for x in e.pipeline(r['p']) if x['code']==code);div=expected['category_dividends'][k]/e.COUNTS[k];exitv=expected['exit_equity']*e.TICKETS[k]/50e6
  for cc,val in [('E',paid),('F',div),('G',exitv),('H',(div+exitv)/paid if paid else None),('I',e.v4.irr(expected['block_cf'][code]))]:equal('V05 Blocos!'+cc+str(br),w['V05 Blocos'][cc+str(br)].value,val)
 for m in range(1,181):
  row=m+4;dm=r['flow'][m-1]['div_metrics'];docs=w['V05 Dividendos']
  if (params or {}).get('approvals',{}).get(m)==1:equal('Aprovação M'+str(m),docs['O'+str(row)].value,dm['approved_documented'])
  if m in (params or {}).get('actual_payments',{}):equal('Pagamento M'+str(m),docs['P'+str(row)].value,dm['actual_documented'])

 w.close();errors=[]
 if full_errors:
  with zipfile.ZipFile(path) as z:
   for inf in z.infolist():
    if inf.filename.startswith('xl/worksheets/') and inf.filename.endswith('.xml'):
     txt=z.read(inf.filename).decode()
     for m in re.finditer(r'<(?:\w+:)?c\b[^>]*\bt="e"[^>]*>.*?</(?:\w+:)?c>',txt,re.S):errors.append([inf.filename,m[0][:200]])
 return {'file':str(path),'ok':not fails and not errors,'comparisons':count,'failures':fails[:30],'error_count':len(errors),'errors':errors[:15],'metrics':{k:v for k,v in expected.items() if k not in ['block_cf','new_cf']}}
if __name__=='__main__':
 path=Path(sys.argv[1]);params=json.loads(sys.argv[2]) if len(sys.argv)>2 else {};res=check(path,params);dest=path.parent/'Resultado_Conferencia.json';dest.write_text(json.dumps(res,ensure_ascii=False,indent=2));print(json.dumps({k:v for k,v in res.items() if k!='metrics'},ensure_ascii=False,indent=2));raise SystemExit(not res['ok'])
