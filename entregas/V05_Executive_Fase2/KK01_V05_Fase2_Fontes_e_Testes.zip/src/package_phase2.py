from pathlib import Path
import json,zipfile,hashlib,shutil,sys
R=Path(__file__).resolve().parents[1];O=R/'entrega'
# Keep historical failures distinguishable from final results.
H=O/'historico';H.mkdir(exist_ok=True)
for name in ['Testes_Sensibilidade_Primeira_Passagem.json','Testes_Controlados_Antes_Controlo15.json']:
 p=O/name
 if p.exists():shutil.move(p,H/name)
# Consolidate the final audit-only maintenance in the change registry.
p=O/'Registo_Alteracoes_Fase2.json';records=json.loads(p.read_text())
for addr,old,new in [('A53','V04:20blocos','V05:15 blocos'),('B53',"IF(SUM('Matriz Societaria V03'!B9:D9)=20,0,1)","IF(SUM('Matriz Societaria V03'!B9:D9)=15,0,1)"),('C53',"IF(SUM('Matriz Societaria V03'!B9:D9)=20,\"Conforme\",\"Alerta\")","IF(SUM('Matriz Societaria V03'!B9:D9)=15,\"Conforme\",\"Alerta\")"),('A58','V04:preferências aprovadas','V05:política formalizada externamente')]:
 if not any(x.get('sheet')=='AUDITORIA' and x.get('cell')==addr and x.get('reason')=='final_cardinality15' for x in records):records.append({'sheet':'AUDITORIA','cell':addr,'old':old,'new':new,'reason':'final_cardinality15','kind':'formula' if addr[0] in 'BC' else 'text'})
p.write_text(json.dumps(records,ensure_ascii=False,indent=2))
(H/'README.md').write_text('Resultados de desenvolvimento anteriores às correções. Não constituem o estado final. As falhas foram identificadas, corrigidas e reexecutadas; consultar os relatórios finais e os JSONs na pasta entrega.\n')
# Source/test package: no duplicate original workbook, no huge recalculated variant files.
sources=O/'KK01_V05_Fase2_Fontes_e_Testes.zip'
with zipfile.ZipFile(sources,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for folder in ['src','reference']:
  for f in (R/folder).rglob('*'):
   if f.is_file() and '__pycache__' not in f.parts:z.write(f,f.relative_to(R))
 z.write(R/'requirements.txt','requirements.txt');z.write(O/'README.md','README.md')
 z.writestr('original/README.md','Colocar aqui KK01_Modelo_Integrado_V04_Excel_Fix.xlsx. SHA-256:be8288ced2494ef31c2dbe1d31d77b8277a0753a1209a8df0a83c3a5d86dcdc0. O original encontra-se na pastaV04_Excel_Fix do repositório.\n')
 for f in O.rglob('*'):
  if f.is_file() and f.suffix in ['.json','.csv','.md']:z.write(f,Path('entrega')/f.relative_to(O))
 for f in (R/'validacao').glob('Falha_MTC_*.log'):z.write(f,Path('historico_runtime')/f.name)
full=O/'KK01_V05_Executive_Fase2_Pacote_Completo.zip'
with zipfile.ZipFile(full,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for f in O.iterdir():
  if f.is_file() and f!=full and f.suffix in ['.xlsx','.pdf','.md','.csv','.json','.zip']:z.write(f,Path('entrega')/f.name)
for f in [sources,full,O/'KK01_Modelo_Integrado_V05_Executive.xlsx']:
 assert f.stat().st_size<40000000,(f.name,f.stat().st_size)
 print(f.name, f.stat().st_size,'bytes')
files=[f for f in O.iterdir() if f.is_file() and f.name!='Manifesto_SHA256_Fase2.json']
manifest={'source_original_fixed_sha256':'be8288ced2494ef31c2dbe1d31d77b8277a0753a1209a8df0a83c3a5d86dcdc0','phase':'2 — financial only','excel_desktop_certified':False,'files':[{'name':f.name,'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in sorted(files)]}
(O/'Manifesto_SHA256_Fase2.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
