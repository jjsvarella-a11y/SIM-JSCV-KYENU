from pathlib import Path
import json,zipfile,xml.etree.ElementTree as E,concurrent.futures,subprocess,time,sys,shutil,re
sys.path.insert(0,str(Path(__file__).parent));from check_recalc import check
R=Path(__file__).resolve().parents[1];P=R/'entrega/KK01_Modelo_Integrado_V05_Executive.xlsx';META=json.load(open(Path(__file__).resolve().parents[1]/'reference/src/build_metadata.json'));PR=META['param_rows'];N='{http://schemas.openxmlformats.org/spreadsheetml/2006/main}';RID='{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id'
CASES=[
 ('Base',{},{}),
 ('Acumulados_Maximo',{'div_basis':'Acumulados','div_tier':'Máximo'},{'V05 Config':{'B5':'Acumulados','B6':'Máximo'}}),
 ('Acumulados_Minimo',{'div_basis':'Acumulados','div_tier':'Mínimo'},{'V05 Config':{'B5':'Acumulados','B6':'Mínimo'}}),
 ('Acumulados_Intermedio',{'div_basis':'Acumulados','div_tier':'Intermédio'},{'V05 Config':{'B5':'Acumulados','B6':'Intermédio'}}),
 ('Operador_4_3_10',{'fee_mode':'Proposta simulada'},{'Pressupostos':{'B'+str(PR['fee_mode']):'Proposta simulada'}}),
 ('Exit_Prudente',{'exit_mult':10},{'V05 Config':{'B9':'Prudente'}}),
 ('Exit_Favoravel',{'exit_mult':15},{'V05 Config':{'B9':'Favorável'}}),
 ('Continuidade',{'exit_enabled':0},{'V05 Config':{'B10':0}}),
 ('Sem_Parcial',{'partial':0},{'V05 Config':{'B8':0}}),
 ('Suspenso',{'div_tier':'Suspenso'},{'V05 Config':{'B6':'Suspenso'}}),
 ('Documentado_Sem_Teto',{'payout_basis':'Documentado'},{'Pressupostos':{'B'+str(PR['payout_basis']):'Documentado'}}),
 ('Reserva_Extra_M54',{'extra_reserves':{54:20000000}},{'V05 Controlo':{'B58':20000000}}),
 ('Hotel_Conservador',{'hotel':'Conservador'},{'Pressupostos':{'B'+str(PR['hotel']):'Conservador'}}),
 ('Capital_Vendas_Atraso',{'capital_delay':12,'commercial_delay':6},{'Pressupostos':{'B'+str(PR['capital_delay']):12,'B'+str(PR['commercial_delay']):6}}),
]
CASES += [
 ('Documentos_M54',{'document_caps':{54:1000000},'approvals':{54:1},'actual_payments':{54:500000}},{'V05 Controlo':{'C58':1000000,'D58':1,'E58':500000}}),
 ('Capital_75pct',{'capital_fraction':.75},{'Pressupostos':{'B'+str(PR['capital_fraction']):.75}}),
 ('Acumulados_Max_Fallback',{'div_basis':'Acumulados','div_tier':'Máximo','extra_reserves':{54:8000000}},{'V05 Config':{'B5':'Acumulados','B6':'Máximo'},'V05 Controlo':{'B58':8000000}}),
 ('Exit_Reserva_Futura',{'extra_reserves':{180:5000000}},{'V05 Controlo':{'B184':5000000}}),
 ('Atraso_Obra_Abertura',{'construction_delay':6,'opening_delay':3},{'Pressupostos':{'B'+str(PR['construction_delay']):6,'B'+str(PR['opening_delay']):3}}),
 ('Beneficios_NaoZero',{'benefit_platinum':12000,'benefit_gold':8000,'benefit_silver':4000},{'Pressupostos':{'B'+str(PR['benefit_platinum']):12000,'B'+str(PR['benefit_gold']):8000,'B'+str(PR['benefit_silver']):4000}}),
]

def mutate(dest,changes):
 with zipfile.ZipFile(P) as zi:
  wb=E.fromstring(zi.read('xl/workbook.xml'));rels={x.attrib['Id']:x.attrib['Target'] for x in E.fromstring(zi.read('xl/_rels/workbook.xml.rels'))};paths={s.attrib['name']:(rels[s.attrib[RID]].lstrip('/') if rels[s.attrib[RID]].startswith('/') else 'xl/'+rels[s.attrib[RID]]) for s in wb.find(N+'sheets')};patches={paths[n]:v for n,v in changes.items()}
  with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED) as zo:
   for it in zi.infolist():
    data=zi.read(it.filename)
    if it.filename in patches:
     x=E.fromstring(data);cells={c.attrib['r']:c for c in x.iter(N+'c')}
     for a,v in patches[it.filename].items():
      c=cells[a]
      for child in list(c):c.remove(child)
      c.attrib.pop('t',None)
      if isinstance(v,str):c.set('t','inlineStr');E.SubElement(E.SubElement(c,N+'is'),N+'t').text=v
      else:E.SubElement(c,N+'v').text=str(v)
     data=E.tostring(x,encoding='utf-8',xml_declaration=True)
    if it.filename.startswith('xl/worksheets/') and it.filename.endswith('.xml'):
     def invalidate(m):
      text=m[0]
      if re.search(r'<(?:\w+:)?f(?:\s|>)',text):text=re.sub(r'<(?:\w+:)?v(?:\s[^>]*)?>.*?</(?:\w+:)?v>|<(?:\w+:)?v\s*/>','',text,flags=re.S)
      return text
     data=re.sub(r'<((?:\w+:)?)c\b[^>]*(?<!/)>.*?</\1c>',invalidate,data.decode(),flags=re.S).encode()
    zo.writestr(it,data)

def worker(case):
 name,params,changes=case;folder=R/'validacao'/('Teste_'+name);folder.mkdir(exist_ok=True);(folder/'out').mkdir(exist_ok=True);shutil.rmtree(folder/'profile',ignore_errors=True);(folder/'profile/user').mkdir(parents=True,exist_ok=True)
 (folder/'profile/user/registrymodifications.xcu').write_text('<?xml version="1.0"?><oor:items xmlns:oor="http://openoffice.org/2001/registry"><item oor:path="/org.openoffice.Office.Calc/Formula/Load"><prop oor:name="OOXMLRecalcMode" oor:op="fuse"><value>0</value></prop></item><item oor:path="/org.openoffice.Office.Calc/Formula/Calculation"><prop oor:name="UseThreadedCalculationForFormulaGroups" oor:op="fuse"><value>false</value></prop><prop oor:name="UseOpenCL" oor:op="fuse"><value>false</value></prop></item></oor:items>')
 dest=folder/(name+'.xlsx');mutate(dest,changes);out=folder/'out'/dest.name
 if out.exists():out.unlink()
 start=time.time();proc=subprocess.run(['soffice','-env:UserInstallation='+str((folder/'profile').as_uri()),'--headless','--convert-to','xlsx','--outdir',str(folder/'out'),str(dest)],capture_output=True,text=True,timeout=1200)
 (folder/'Recalculo.log').write_text(proc.stdout+proc.stderr);out=folder/'out'/dest.name
 if proc.returncode or not out.exists():res={'case':name,'ok':False,'error':proc.stdout+proc.stderr}
 else:
  res=check(out,params);res['case']=name;res['seconds']=round(time.time()-start,2);res['params']=params;res['input_sha256']=__import__('hashlib').sha256(dest.read_bytes()).hexdigest();res['canonical_input_sha256']=__import__('hashlib').sha256(P.read_bytes()).hexdigest()
 if name=='Base' and out.exists():
  from check_risks import audit
  risks=audit(out);(R/'entrega/Testes_Riscos_Auxiliares_Fase2.json').write_text(json.dumps(risks,ensure_ascii=False,indent=2));res['auxiliary_risks_ok']=risks['ok'];res['ok']=res['ok'] and risks['ok']
 (folder/'Resultado.json').write_text(json.dumps(res,ensure_ascii=False,indent=2));print(name,res['ok'],res.get('comparisons'),res.get('failures',[])[:2],flush=True);return res
if __name__=='__main__':
 wanted=set(sys.argv[1:]);cases=[x for x in CASES if not wanted or x[0] in wanted]
 with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:res=list(pool.map(worker,cases))
 (R/'entrega/Testes_Sensibilidade_Fase2.json').write_text(json.dumps(res,ensure_ascii=False,indent=2));raise SystemExit(not all(x['ok'] for x in res))
