from pathlib import Path
import zipfile,re,html,json,xml.etree.ElementTree as E,hashlib,collections,os
from openpyxl.utils import get_column_letter as CL
R=Path(__file__).resolve().parents[1];SRC=R/'original/KK01_Modelo_Integrado_V04_Excel_Fix.xlsx';OUT=Path(os.environ.get('KK01_BUILD_OUTPUT',str(R/'entrega/KK01_Modelo_Integrado_V05_Executive.xlsx')));N='http://schemas.openxmlformats.org/spreadsheetml/2006/main';T=lambda n:'{'+N+'}'+n;RID='{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id'
META=json.load(open(Path(__file__).resolve().parents[1]/'reference/src/build_metadata.json'));PR=META['param_rows'];PV=lambda k:f'Pressupostos!$B${PR[k]}';C=lambda r:f"'V05 Config'!$B${r}"
changes=[];extrasheets={};newraw={};sheetrels={};config='V05 Config';flows={};wfmeta={};opening_expr={};counts=[f"'V05 Config'!$B${r}" for r in [20,21,22]];tickets=[1e7,5e6,1e6];cats=['Platinum','Gold','Silver'];legcats=['Platinum']+['Gold']*6+['Silver']*5;codes=['P01','G01']+['G02']*5+['S01','S02','S03','S04','S05']

def cell(addr,val,formula=False,style=0):
 a=f'<c r="{addr}" s="{style}"'
 if formula:return a+'><f>'+html.escape(val,quote=False)+'</f></c>'
 if val is None:return a+'/>'
 if isinstance(val,(int,float)):return a+'><v>'+str(val)+'</v></c>'
 return a+' t="inlineStr"><is><t xml:space="preserve">'+html.escape(str(val),quote=False)+'</t></is></c>'

def display_style(name,a,r):
 col=re.match('[A-Z]+',a)[0]
 if r in [1,4]:return HSTYLE
 if name=='V05 Config':
  if 20<=r<=22 and col in 'DEFG':return IPCT
  if a=='B7':return NSTYLE
  if col=='B' and r in [8,10,11,12,14,16]:return INTSTYLE
  if col in 'EFG' and r==24:return EURSTYLE
  if col=='C' and 20<=r<=22:return EURSTYLE
 if name=='V05 Blocos':
  if col in ['D','I','L']:return PCTSTYLE
  if col=='H':return MULTSTYLE
  if col in ['E','F','G','J','K']:return EURSTYLE
 if name=='V05 Retornos':
  if a=='B20':return PCTSTYLE
  if a=='B21':return MULTSTYLE
  if col=='B':return EURSTYLE
 if name in ['V05 Dividendos','V05 Controlo'] and col!='A':return EURSTYLE if col not in ['I','Q','J','D'] else NSTYLE
 return ISTYLE if a in INPUTS.get(name,set()) else NSTYLE

def sheet(name,rows,width=22,validations='',links=''):
 nav=[('Executivo','EXEC KK01'),('Configuração','V05 Config'),('Dividendos','V05 Dividendos'),('Retornos','V05 Retornos'),('Blocos','V05 Blocos')]
 links='<hyperlinks>'+''.join('<hyperlink ref="'+CL(i+1)+'3" location="&apos;'+target+'&apos;!A1" display="'+html.escape(label)+'"/>' for i,(label,target) in enumerate(nav))+'</hyperlinks>'
 for i,(label,target) in enumerate(nav):rows[CL(i+1)+'3']=label
 byrow=collections.defaultdict(list)
 for addr,val in rows.items():
  m=re.fullmatch(r'([A-Z]+)(\d+)',addr);byrow[int(m[2])].append((addr,val))
 def key(a):
  s=re.match('[A-Z]+',a[0])[0];v=0
  for c in s:v=v*26+ord(c)-64
  return v
 data=''.join('<row r="'+str(r)+'">'+''.join(cell(a,v[1:] if isinstance(v,str) and v.startswith('=') else v,isinstance(v,str) and v.startswith('='),HSTYLE if r in [1,4] else display_style(name,a,r)) for a,v in sorted(vs,key=key))+'</row>' for r,vs in sorted(byrow.items()))
 dim=max(byrow) if byrow else 1
 text=f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="{N}"><dimension ref="A1:AZ{dim}"/><sheetViews><sheetView workbookViewId="0"><pane ySplit="4" topLeftCell="A5" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><sheetFormatPr defaultRowHeight="17"/><cols><col min="1" max="1" width="37" customWidth="1"/><col min="2" max="52" width="{width}" customWidth="1"/></cols><sheetData>{data}</sheetData>{validations}{links}<pageMargins left="0.3" right="0.3" top="0.4" bottom="0.4" header="0.2" footer="0.2"/><pageSetup orientation="landscape" paperSize="9" fitToWidth="1" fitToHeight="0"/></worksheet>'
 extrasheets[name]=text.encode()

INPUTS={}
with zipfile.ZipFile(SRC) as z:
 wb=E.fromstring(z.read('xl/workbook.xml'));rel=E.fromstring(z.read('xl/_rels/workbook.xml.rels'));targets={a.attrib['Id']:a.attrib['Target'] for a in rel}
 paths={s.attrib['name']:(targets[s.attrib[RID]].lstrip('/') if targets[s.attrib[RID]].startswith('/') else 'xl/'+targets[s.attrib[RID]]) for s in wb.find(T('sheets'))}
 sample=E.fromstring(z.read(paths['Pressupostos']));smap={c.attrib['r']:c for c in sample.iter(T('c'))};NSTYLE=int(smap['B8'].attrib.get('s',0));ISTYLE=int(smap['B9'].attrib.get('s',0));HSTYLE=int(smap['A4'].attrib.get('s',0));IPCT=int(smap['B10'].attrib.get('s',0));INTSTYLE=int(smap['B22'].attrib.get('s',0));kp=E.fromstring(z.read(paths['KPI']));km={c.attrib['r']:c for c in kp.iter(T('c'))};EURSTYLE=int(km['B10'].attrib.get('s',0));PCTSTYLE=int(km['B13'].attrib.get('s',0));rp=E.fromstring(z.read(paths['Retornos']));rm={c.attrib['r']:c for c in rp.iter(T('c'))};MULTSTYLE=int(rm['C18'].attrib.get('s',0))
 # Identify all monthly bank sheets and associated waterfall/policy sheets from their formulas.
 for sn,path in paths.items():
  raw=z.read(path).decode()
  if re.search(r'<c\b[^>]*\br="AD5"[^>]*>.*?<f',raw) and 'Reserva protegida' not in sn:
   x=E.fromstring(raw);cells={c.attrib['r']:c for c in x.iter(T('c'))};f=cells.get('AD5');f=f.find(T('f')).text if f is not None and f.find(T('f')) is not None else ''
   if 'MOD(' in f and 'Q5' in f and 'AA5' in f:flows[sn]=True
  if sn=='V04 Waterfall180' or re.fullmatch(r'V04 R\d+WF',sn):
   x=E.fromstring(raw);cs={c.attrib['r']:c for c in x.iter(T('c'))}
   ff=cs['B5'].find(T('f')).text;fs=re.search(r"'([^']+)'!AD5",ff)[1];pl=re.search(r"'([^']+)'!B11",cs['C5'].find(T('f')).text)[1];ps=re.search(r"'([^']+)'!J5",cs['Q5'].find(T('f')).text)[1];q=cs['Q5'].find(T('f')).text;delay=re.search(r'<=1-(\d+)',q);delay=int(delay[1]) if delay else 0
   wfmeta[sn]=(fs,pl,ps,delay)
 print('Monthly engines:',len(flows),'waterfalls:',len(wfmeta),flush=True)
 assert 'Fluxo 180M' in flows and len(flows)>=60
 for fs in flows:
  fx=E.fromstring(z.read(paths[fs]));fc={c.attrib['r']:c for c in fx.iter(T('c'))};af=fc['AO5'].find(T('f')).text;ma=re.fullmatch(r"(?:'([^']+)'|([A-Za-z0-9_]+))!K5",af);assert ma,(fs,af);hs=ma[1] or ma[2];hx=E.fromstring(z.read(paths[hs]));hc={c.attrib['r']:c for c in hx.iter(T('c'))};bf=hc['B5'].find(T('f')).text;mo=re.search(r'IF\(A5<(.*?),0,INT',bf);assert mo,(fs,bf);opening_expr[fs]=mo[1]

 for sn,path in paths.items():
  raw=z.read(path).decode();extra={};updates={};values={}
  if sn in flows:
   for r in range(5,185):
    lo=max(5,r-11);rr=f'\'V05 Controlo\'!B{r}';cap=f'{PV("equity")}-{PV("conversion")}'
    gen=f'SUM(L{lo}:M{r})-SUM(AH{lo}:AH{r})-SUM(H{lo}:K{r})-SUM(E{lo}:G{r})-SUM(T{lo}:V{r})'
    extra['BE'+str(r)]=gen
    extra['BF'+str(r)]=f'MAX(0,Z{r}-AA{r}-Q{r}-AR{r}-{rr})'
    extra['BG'+str(r)]=f'MIN(BF{r},BA{r})'
    extra['BH'+str(r)]=f'MAX(0,BE{r})/{C(7)}'
    extra['BI'+str(r)]=f'IF({C(5)}="Geração 12M",MIN(BG{r},BH{r}),BG{r})'
    # Objectives include all promoter and new blocks. Selection does not create seniority.
    obj=[f"SUMPRODUCT('V05 Config'!$B$20:$B$22,'V05 Config'!$C$20:$C$22,'V05 Config'!${cl}$20:${cl}$22)" for cl in ['E','F','G']]
    extra['BJ'+str(r)]=f'IF(AND(BI{r}>={obj[2]},OR({C(6)}="Automático",{C(6)}="Máximo")),3,IF(AND(BI{r}>={obj[1]},{C(6)}<>"Mínimo"),2,1))'
    extra['BK'+str(r)]=f'CHOOSE(BJ{r},{",".join(obj)})'
    extra['BL'+str(r)]=f'AND(A{r}>={C(14)},A{r}>=({opening_expr[sn]})+23,MOD(A{r}-{C(14)},12)=0,AB{r}<0.005,AX{r}<0.005,SUM(AF$5:AF{r})<0.005,{C(6)}<>"Suspenso",OR({C(16)}=0,SUM(C$5:C{r})>=({cap})*{PV("treasury_ratio")}-0.005))'
    extra['BM'+str(r)]=f'IF(AND(BL{r},OR({C(8)}=1,BI{r}>=BK{r})),MIN(BI{r},BK{r}),0)'
    for k,cc in enumerate(['BN','BO','BP']):
     cr=20+k;extra[cc+str(r)]=f"{counts[k]}*'V05 Config'!C{cr}*IF(BM{r}>={obj[2]}-0.005,'V05 Config'!G{cr},IF(BM{r}>={obj[1]}-0.005,'V05 Config'!F{cr},'V05 Config'!E{cr}))/IF(BM{r}>={obj[2]}-0.005,{obj[2]},IF(BM{r}>={obj[1]}-0.005,{obj[1]},{obj[0]}))"
    extra['BQ'+str(r)]=f'IF(AND(\'V05 Controlo\'!D{r}=1,ISNUMBER(\'V05 Controlo\'!C{r})),MIN(BM{r},MAX(0,\'V05 Controlo\'!C{r})),0)'
    extra['BR'+str(r)]=f'IF(BM{r}=0,"Distribuição não suportada",IF(BM{r}<{obj[0]}-0.005,"Distribuição parcial possível",IF(BM{r}>={obj[2]}-0.005,"Máximo suportado",IF(BM{r}>={obj[1]}-0.005,"Intermédio suportado","Mínimo suportado"))))'
    extra['BS'+str(r)]=f'IF(BM{r}>0,BE{r}/BM{r},"")'
   for i,label in enumerate(['Geração12M líquida','Caixa livre após proteção','Capacidade independente','Capacidade cobertura','Capacidade selecionada','Patamar escolhido','Objetivo selecionado','Calendário elegível','Dividendo simulado','Peso dividendos P','Peso dividendos G','Peso dividendos S','Elegível documentação','Estado financeiro','Cobertura geração'],57):values[CL(i)+'4']=label
  # All payment pipelines preserve the same amounts/dates as V04, but identify G02 tranches correctly.
  if sn=='V04 Pipeline' or re.fullmatch(r'V04 R\d+Pipeline',sn):
   values['A2']='V05: 12 parcelas de pagamento de 8 blocos novos; G02 tem 5 parcelas de 1M€. Não confundir parcelas com blocos. Documentação permanece independente.'
   for i,r in enumerate(range(5,17)):
    values['A'+str(r)]=codes[i];values['B'+str(r)]=legcats[i];values['C'+str(r)]='Origem da transmissão / instrumento a validar'
    # selected quantities: G02 five payment legs refer to the second Gold, not five blocks.
    updates['H'+str(r)]=f'IF({PV("equity_mode")}="Combinação tickets",IF({PV("n_platinum") if i==0 else PV("n_gold") if i<7 else PV("n_silver")} >= {1 if i<2 else 2 if i<7 else i-6},1,0),1)'
    updates['W'+str(r)]=f'IF(F{r}>0,MIN(1,T{r}/F{r}),0)'
   values['A20']='Potencial oferta — parcelas';values['A21']='Proposto no plano — parcelas'
  if sn=='V04 Calendarios':
   values['A2']='V05: 12 parcelas de8blocos novos. G02 tem5parcelas. Calendário agregadoV04preservado; datas são hipóteses.'
   for i,r in enumerate(range(5,17)):values['A'+str(r)]=codes[i]+('-'+str(i-1) if 2<=i<=6 else '')
  if sn=='V04 Pipeline':values['F4']='Parcela referência €';values['G4']='Parcela proposta — plano';values['W4']='Parcela recebida / referência'
  if sn=='Pressupostos':
   values['B'+str(PR['n_gold'])]=2;values['B'+str(PR['n_silver'])]=5
   updates['B'+str(PR['exit_mult'])]=C(30)
   values['D'+str(PR['capital_scenario'])]='V05: KK-E25, 25M€ por 50%; 8 blocos novos, 15 globais.'
   values['D'+str(PR['equity'])]='25M€ previstos, segundo calendário faseado de parcelas. Não é capital documentadamente realizado.'
   values['D'+str(PR['waterfall_mode'])]='Seletor legado não governa a V05. Dividendos por objetivos de categoria; saída proporcional. Ver V05 Config.'
   values['D'+str(PR['dividend_frequency'])]='V05: primeira elegibilidade M54, depois cada12meses. Este seletor legado só se aplica com política V05 desligada.'
   for k in ['target_platinum','target_gold','target_silver']:values['D'+str(PR[k])]='Meta TIR histórica V04 preservada como benchmark; não governa dividendos nem saída da V05.'
  if sn=='Matriz Societaria V03':
   for r,nums in [(5,[2,0,0]),(6,[0,0,5]),(7,[1,2,5])]:
    for col,n in zip('BCD',nums):values[col+str(r)]=n
   values['A14']='Blocos totais = 15';updates['B14']='IF(SUM(B9:D9)=15,"Conforme","Alerta")';values['A20']='V05: JSCV2P; JALS5S; novos1P2G5S';values['A21']='Dividendos e saída: simulações; formalização societária pendente'
  if sn=='Beneficios V03':
   for r,n in zip([5,6,7],counts):updates['C'+str(r)]=n
  if sn=='Societario':values['D5']='V05: JSCV2Platinum=40%; sem inferir controlo jurídico automático.'
  if sn=='AUDITORIA':
   values['A53']='V05:15 blocos';updates['B53']="IF(SUM('Matriz Societaria V03'!B9:D9)=15,0,1)";updates['C53']="IF(SUM('Matriz Societaria V03'!B9:D9)=15,\"Conforme\",\"Alerta\")"
   values['A58']='V05:política formalizada externamente'

  if sn=='Blocos V03':
   values['H5']=1;values['H6']=2;values['H7']=5;values['A2']='V05: 8 blocos novos, captação-alvo25M€. Contagens de cenário não constituem capital contratado.'
   values['E4']='Capital previsto';values['F4']='Quota prevista'
  if sn=='Ronda Investidores':values['A7']='Silver';values['C4']='Participação por bloco V05'
  if sn=='EXEC KK01':values['A2']='V05 Executive — Fase2 financeira sobre V04 Excel Fix. Ver V05 Retornos e V05 Config. Interface ainda não reformulada; números são simulações.'
  if sn in ['DASH Acionistas','DASH Investimento','Retorno Socios','Retorno Categorias V03','Investidores']:
   values['A2']='V05: painel legado preservado. Referência atual por categoria/bloco em V05 Blocos, V05 Retornos e V04 Retornos; não usar benchmarks proporcionais antigos como política selecionada.'
  if sn=='V04 Decisoes Board':
   values['B5']='Estrutura15blocos';values['C5']='JSCV2P / JALS5S / novos1P2G5S';values['B6']='Dividendos progressivos e saída proporcional';values['C6']='M54+12meses; saída40/10/50; sem waterfall antiga';values['D6']='Mínimo3M; intermédio3,575M; máximo4,15M; coberturaref1,20x'
  if sn=='V04 Impactos':
   for r in range(5,18):
    sr=r+1;updates['G'+str(r)]=f'IF(AND(ISNUMBER(\'V04 Riscos\'!K{sr}),ISNUMBER(\'V04 Riscos\'!K5)),\'V04 Riscos\'!K{sr}-\'V04 Riscos\'!K5,"Não comparável — TIR não definida")'
  if sn=='V04 Riscos':
   values['O4']='Regra de distribuição V05'
   for r in range(5,19):values['O'+str(r)]='Dividendos progressivos; saída proporcional'
  if sn=='Retornos':
   values['A2']='V05: resultados selecionados; dividendos por categoria e saída proporcional. Valores10A são saída alternativa hipotética.'
   for cc in 'BC':updates[cc+'11']=f'MAX(0,{cc}6-{cc}7-{cc}8+{cc}9-{cc}10-\'V05 Controlo\'!B{124 if cc=="B" else 184})*{C(10)}'
   for dest,source in [('C14','B36'),('C15','B37'),('C18','B28'),('C19','B27'),('C21','B34'),('C23','B32'),('B14','M140'),('B15','B60'),('B18','B56'),('B19','B55'),('B21','B58'),('B23','B59')]:updates[dest]="'V04 Retornos'!"+source
   values['A12']='Dividendos totais simulados'
  if sn=='Fluxos Retorno':
   for m in range(1,181):
    r=m+5;fr=m+4;updates['C'+str(r)]=f"'V04 Waterfall180'!V{fr}";updates['E'+str(r)]=f"'V04 Waterfall180'!Y{fr}"
    if m<=120:
     updates['B'+str(r)]=f"'V04 Waterfall180'!V{fr}"+("+'V04 Retornos'!M140" if m==120 else '')
     updates['D'+str(r)]=f"'V04 Waterfall180'!Y{fr}"+("+'V04 Retornos'!M141" if m==120 else '')
   updates['G185']=f'F185+(Retornos!$C$6-Retornos!$C$7-Retornos!$C$10-\'V05 Controlo\'!B184)*{C(10)}'

  if sn in [v[1] for v in wfmeta.values()]:
   for r,n,k in zip([5,6,7],counts,range(3)):
    updates['B'+str(r)]=n;updates['K'+str(r)]=f'{n}*{tickets[k]:.0f}/50000000';updates['J'+str(r)]=f"{n}*{tickets[k]:.0f}*'V05 Config'!E{20+k}/'V05 Config'!E24"
   values['A2']='V05: saída proporcional; preferências/metas otimizadas V04 inativas. Fórmulas analíticas antigas preservadas para rastreabilidade, não direitos acumulativos.'
   updates['B30']='FALSE';updates['B31']='0';values['A34']='Análise antiga não governa a V05';values['B34']='Consultar V05 Dividendos e V05 Retornos.'
   # Exit continuity applies to actual exit cash, not the separate EV estimate.
   # B11 captured in the formula callback below.
  if sn in wfmeta:
   fs,pl,ps,delay=wfmeta[sn]
   values['A2']='V05: dividendos por categoria; saída proporcional. Sem prioridade acumulativa. Novos blocos integralmente pagos antes da distribuição; dados financeiros simulados.'
   for r in range(5,185):
    for cc in ['D','E','F','M','N','O','AC','AD','AE','AF','AG','AH','AI','AJ']:updates[cc+str(r)]='0'
    for k,cc in enumerate(['G','H','I']):updates[cc+str(r)]=f"B{r}*'{fs}'!{['BN','BO','BP'][k]}{r}"
    for k,cc in enumerate(['J','K','L']):updates[cc+str(r)]=f'C{r}*{counts[k]}*{tickets[k]:.0f}/50000000'
    for k,cc in enumerate(['Q','R','S']):
     blockticket=tickets[k];updates[cc+str(r)]=f'SUMIFS(\'{ps}\'!$T$5:$T$16,\'{ps}\'!$B$5:$B$16,"{cats[k]}",\'{ps}\'!$J$5:$J$16,"<="&(A{r}-{delay}))/{blockticket:.0f}'
    updates['T'+str(r)]=f'(G{r}+J{r})/{counts[0]}+(H{r}+K{r})/{counts[1]}*2+(I{r}+L{r})/{counts[2]}*5'
    updates['W'+str(r)]=f'(G{r}+J{r})/{counts[0]}*2'
    updates['X'+str(r)]=f'(I{r}+L{r})/{counts[2]}*5'
  if sn=='V04 Vet Retorno':
   for m in range(181):
    r=m+5;fr=m+4
    for k,cc in enumerate('BCD'):updates[cc+str(r)]='0' if m==0 else f"('V04 Waterfall180'!{CL(7+k)}{fr}+'V04 Waterfall180'!{CL(10+k)}{fr})/{counts[k]}"+(f'-{tickets[k]:.0f}' if m==1 else '')
    # Former twelve vectors now represent the eight blocks followed by four inactive zero vectors.
    for i,cc in enumerate([CL(x) for x in range(9,21)]):
     if i>=8:updates[cc+str(r)]='0';continue
     updates[cc+str(r)]=f"'V05 Fluxos Blocos'!{CL(i+2)}{r}"
  if sn=='V04 Retornos':
   values['A2']='V05: dividendos progressivos e saída proporcional. TIR mede fluxos efetivos de cenário; não confundir com dividend yield. Blocos promotores têm bases convencionais.'
   for k,r in enumerate([5,6,7]):
    values['C'+str(r)]=None;values['E'+str(r)]=None
    for cc,srccl in [('F','GHI'[k]),('G','JKL'[k])]:updates[cc+str(r)]=f"SUM('V04 Waterfall180'!{srccl}5:{srccl}184)/{counts[k]}"
   values['C4']='Meta TIR V04 inativa';values['E4']='Não aplicável'
   for i in range(12):
    r=i+12
    if i<8:
     code=['P01','G01','G02','S01','S02','S03','S04','S05'][i];cat='Platinum' if i==0 else 'Gold' if i<3 else 'Silver';values['A'+str(r)]=code;values['B'+str(r)]=cat;updates['C'+str(r)]=f"'V05 Blocos'!E{i+12}";updates['D'+str(r)]=f"'V05 Blocos'!I{i+12}"
    else:
     for cc in 'ABCD':values[cc+str(r)]=None
   for r,ran in [(5,'D12'),(6,'D13:D14'),(7,'D15:D19')]:updates['J'+str(r)]=f'IF(COUNT({ran})>0,MIN({ran}),"")';updates['K'+str(r)]=f'IF(COUNT({ran})>0,MAX({ran}),"")'
   updates['B36']="'V04 Politica'!B11*50%"
   for k,rr in enumerate([137,138,139]):updates['M'+str(rr)]=f'M131*{counts[k]}*{tickets[k]:.0f}/50000000'
   updates['M140']='M131*50%'
   # Replace legacy hard-coded denominators only in expressions tied to class distributions.
   for m in range(1,121):
    r=m+5;fr=m+4
    for k,cc in enumerate('NOP'):updates[cc+str(r)]=f"'V04 Waterfall180'!{'GHI'[k]}{fr}/{counts[k]}"+(f'-{tickets[k]:.0f}' if m==1 else '')+(f'+M{137+k}/{counts[k]}' if m==120 else '')
   for k,r in enumerate([47,48,49]):updates['C'+str(r)]=f"SUM('V04 Waterfall180'!{'GHI'[k]}5:{'GHI'[k]}124)/{counts[k]}";updates['D'+str(r)]=f'M{137+k}/{counts[k]}'
   updates['M131']=f'MAX(0,M130-\'Fluxo 180M\'!AX124-\'V05 Controlo\'!B124)*{C(10)}'
  # Adapt new counts in every hotel benefits formula; these feed CFADS and all debt cases.
  def cb(match):
   full=match.group();addr=match[1];fm=re.search(r'<f(?:\s[^>]*)?>(.*?)</f>',full,re.S);old=html.unescape(fm[1]) if fm else None;new=old
   if old is not None:
    new=new.replace(f'2*{PV("benefit_platinum")}+3*{PV("benefit_gold")}+15*{PV("benefit_silver")}',f'{counts[0]}*{PV("benefit_platinum")}+{counts[1]}*{PV("benefit_gold")}+{counts[2]}*{PV("benefit_silver")}')
    if sn in flows and re.fullmatch(r'AD(\d+)',addr) and 5<=int(addr[2:])<=184:new=f'IF({C(11)}=1,BM{addr[2:]},{new})'
    if sn in [v[1] for v in wfmeta.values()] and addr=='B11':new=f'MAX(0,({old})-\'V05 Controlo\'!B184)*{C(10)}'
    if sn in [v[1] for v in wfmeta.values()] and addr=='B16':new=f'MAX(0,({old})-\'V05 Controlo\'!B184)'
    if sn in [v[1] for v in wfmeta.values()] and addr=='B17':new=f'({old})*{C(10)}'
   if addr in updates:new=updates.pop(addr)
   if addr in values:
    val=values.pop(addr);changes.append({'sheet':sn,'cell':addr,'old':old,'new':val,'kind':'value_or_text'});style=int(re.search(r'\bs="(\d+)"',full)[1]) if re.search(r'\bs="(\d+)"',full) else 0;return cell(addr,val,False,style)
   if new is not None and new!=old:
    changes.append({'sheet':sn,'cell':addr,'old':old,'new':new,'kind':'formula'});style=int(re.search(r'\bs="(\d+)"',full)[1]) if re.search(r'\bs="(\d+)"',full) else 0;return cell(addr,new,True,style)
   # Clear every formula cache for actual full recalculation.
   if fm:full=re.sub(r'<v(?:\s[^>]*)?>.*?</v>|<v\s*/>','',full,flags=re.S)
   return full
  raw=re.sub(r'<c\b[^>]*\br="([A-Z]+\d+)"[^>]*(?<!/)>.*?</c>',cb,raw,flags=re.S)
  # Handle explicit empty/self-closing cells that carry planned updates.
  def cbempty(m):
   addr=m[1];style=int(re.search(r'\bs="(\d+)"',m[0])[1]) if re.search(r'\bs="(\d+)"',m[0]) else 0
   if addr in updates:return cell(addr,updates.pop(addr),True,style)
   if addr in values:return cell(addr,values.pop(addr),False,style)
   return m[0]
  raw=re.sub(r'<c\b[^>]*\br="([A-Z]+\d+)"[^>]*/>',cbempty,raw)
  extra.update(updates)
  byrow=collections.defaultdict(list)
  for a,f in extra.items():byrow[int(re.search(r'\d+',a)[0])].append(cell(a,f,True,NSTYLE))
  for a,v in values.items():byrow[int(re.search(r'\d+',a)[0])].append(cell(a,v,False,HSTYLE if a.endswith('4') else NSTYLE))
  if byrow:
   def insert(m):return m[0][:-6]+''.join(byrow.pop(int(m[1]),[]))+'</row>'
   raw=re.sub(r'<row\b[^>]*\br="(\d+)"[^>]*>.*?</row>',insert,raw,flags=re.S)
   if byrow:raw=raw.replace('</sheetData>',''.join(f'<row r="{rr}">'+''.join(cc)+'</row>' for rr,cc in sorted(byrow.items()))+'</sheetData>')
   # New helpers lie to the right of the existing BD column.
   if sn in flows:raw=re.sub(r'<dimension ref="[^"]+"\s*/>','<dimension ref="A1:BS184"/>',raw)
  newraw[path]=raw.encode()
 # New functional sheets, without dashboard redesign.
 rows={'A1':'KK-01 V05 | Configuração financeira — Fase 2','A2':'Projeções financeiras; dividendos não são juridicamente aprovados nem pagos. Base V04 Excel Fix preservada.','A4':'Parâmetro','B4':'Selecionado','C4':'Critério'}
 for rr,label,val,note in [(5,'Base de capacidade','Geração 12M','Geração 12M ou Acumulados: este último dispensa apenas cobertura; não lucros/caixa/reservas.'),(6,'Patamar solicitado','Automático','Automático / Mínimo / Intermédio / Máximo / Suspenso'),(7,'Cobertura geração12M',1.2,'Caixa operacional líquida últimos12meses / dividendo; independente de caixa acumulada.'),(8,'Permitir parcial',1,'Rateio proporcional aos mínimos; sem prioridade.'),(9,'Cenário de saída','Base','Prudente10x / Base12x / Favorável15x.'),(10,'Realizar saída hipotética',1,'0: continuidade sem recebimento terminal; EV continua estimativa.'),(11,'Política dividendos V05',1,'0 apenas para testes comparativos com política legada.'),(12,'Composição V05',1,'Usado nos custos/contagens; estrutura societária V05 é15blocos.'),(14,'Primeiro mês elegível',54,'Depois cada12meses; requer pelo menos24meses de operação.'),(16,'Exigir capital planeado integral',1,'Conservador: suspende dividendos enquanto capital-alvo não estiver recebido no cenário.')]:rows['A'+str(rr)]=label;rows['B'+str(rr)]=val;rows['C'+str(rr)]=note
 for k,r in enumerate([20,21,22]):
  rows['A'+str(r)]=cats[k];rows['B'+str(r)]=f'=IF(B12=1,{[3,2,10][k]},{[2,3,15][k]})';rows['C'+str(r)]=tickets[k];rows['D'+str(r)]=tickets[k]/50e6
  for j,cc in enumerate('EFG'):rows[cc+str(r)]=[[.07,.05,.04],[.085,.0575,.045],[.10,.065,.05]][j][k]
 for c,l in zip('ABCDEFG',['Categoria','Blocos totais','Base por bloco €','Participação','Mínimo','Intermédio','Máximo']):rows[c+'19']=l
 rows['A24']='Objetivo anual global'
 for cc in 'EFG':rows[cc+'24']=f'=SUMPRODUCT(B20:B22,C20:C22,{cc}20:{cc}22)'
 rows['A30']='Múltiplo selecionado';rows['B30']='=IF(B9="Prudente",10,IF(B9="Favorável",15,12))'
 rows['A32']='Distribuição de saída';rows['B32']='Proporcional: JSCV40%; JALS10%; novos50%'
 INPUTS[config]={'B'+str(r) for r in [5,6,7,8,9,10,11,12,14,16]}|{cc+str(r) for cc in 'EFG' for r in [20,21,22]}
 dv='<dataValidations count="3">'+''.join(f'<dataValidation type="list" sqref="B{r}"><formula1>"{s}"</formula1></dataValidation>' for r,s in [(5,'Geração 12M,Acumulados'),(6,'Automático,Mínimo,Intermédio,Máximo,Suspenso'),(9,'Prudente,Base,Favorável')])+'</dataValidations>'
 dv=dv.replace('count="3"','count="6"').replace('</dataValidations>','<dataValidation type="decimal" operator="between" showErrorMessage="1" sqref="B7"><formula1>1</formula1><formula2>10</formula2></dataValidation><dataValidation type="whole" operator="between" showErrorMessage="1" sqref="B8 B10 B11 B12 B16"><formula1>0</formula1><formula2>1</formula2></dataValidation><dataValidation type="decimal" operator="between" showErrorMessage="1" sqref="E20:G22"><formula1>0</formula1><formula2>1</formula2></dataValidation></dataValidations>')
 sheet(config,rows,validations=dv)
 rows={'A1':'V05 | Reservas adicionais e evidência documental','A2':'B: proteção adicional NÃO duplicada noutras reservas. C: montante aprovado para o mês. D: aprovação comprovada1/0. E: pagamento efetivo comprovado. Vazios = indisponível. Sem alterar retroativamente o cenário.','A4':'Mês','B4':'Reserva extra €','C4':'Teto aprovado mês €','D4':'Deliberação comprovada','E4':'Pagamento comprovado €','F4':'Documento / data'}
 for m in range(1,181):
  rr=m+4;rows['A'+str(rr)]=m;rows['B'+str(rr)]=0
  for cc in 'CDEF':rows[cc+str(rr)]=None
 INPUTS['V05 Controlo']={cc+str(r) for cc in 'BCDEF' for r in range(5,185)};sheet('V05 Controlo',rows,width=25)
 rows={'A1':'V05 | Dividendos mensais — simulação e documentação separadas','A2':'Geração líquida exclui vendas de imóveis, capital e crédito; inclui operação, encargos obrigatórios e investimentos. Caixa livre não equivale a lucro distribuível.','A4':'Mês'}
 headers=['Geração12M','Caixa livre','Capacidade acumulados','Capacidade1,20x','Capacidade escolhida','Objetivo €','Dividendo simulado','Estado financeiro','Cobertura geração','Caixa após dividendo','Reserva protegida','Proteção futura obra','Extra compromisso','Elegível documentado €','Pagamento documentado €','Estado documentação','Dividendo P','Dividendo G','Dividendo S','Mínimo não distribuído','Diferença pagamento/elegível']
 for i,h in enumerate(headers,2):rows[CL(i)+'4']=h
 for m in range(1,181):
  r=m+4;rows['A'+str(r)]=m
  for cc,srccl in [('B','BE'),('C','BF'),('D','BG'),('E','BH'),('F','BI'),('G','BK'),('H','AD'),('I','BR'),('J','BS'),('K','AE'),('L','Q'),('M','AR'),('O','BQ')]:rows[cc+str(r)]=f"='Fluxo 180M'!{srccl}{r}"
  rows['O'+str(r)]=f'=IF(AND(\'V05 Controlo\'!D{r}=1,ISNUMBER(\'V05 Controlo\'!C{r})),\'Fluxo 180M\'!BQ{r},"Indisponível")';rows['N'+str(r)]=f"='V05 Controlo'!B{r}";rows['P'+str(r)]=f'=IF(ISNUMBER(\'V05 Controlo\'!E{r}),\'V05 Controlo\'!E{r},"Indisponível")';rows['Q'+str(r)]=f'=IF(AND(\'V05 Controlo\'!D{r}=1,ISNUMBER(\'V05 Controlo\'!C{r})),"Documentação indicada — verificar suporte","Simulado; sem aprovação documental")'
  for k,cc in enumerate('RST'):rows[cc+str(r)]=f"='V04 Waterfall180'!{'GHI'[k]}{r}"
  rows['U'+str(r)]=f'=IF(\'Fluxo 180M\'!BL{r},MAX(0,\'V05 Config\'!E24-H{r}),0)';rows['V'+str(r)]=f'=IF(ISNUMBER(P{r}),MAX(0,P{r}-N(O{r})),0)'
 sheet('V05 Dividendos',rows,width=24)
 # Fifteen real blocks; 12 payment legs are mapped to eight investor blocks.
 blockcodes=['JSCV-P01','JSCV-P02']+['JALS-S'+str(i).zfill(2) for i in range(1,6)]+['P01','G01','G02','S01','S02','S03','S04','S05']
 rows={'A1':'V05 | 15 blocos — cap table e retornos','A2':'7 blocos promotores convencionais + 8 blocos novos. Promotores: ticket de referência não é dinheiro novo; TIR individual histórica indisponível.','A4':'Bloco','B4':'Titular','C4':'Categoria','D4':'Participação','E4':'Capital novo cenário','F4':'Dividendos15A','G4':'Saída15A','H4':'MOIC efetivo','I4':'TIR mensal anualizada','J4':'VPL12%','K4':'Base convencional','L4':'XIRR — datas convencionais','M4':'Estado'}
 for i,code in enumerate(blockcodes):
  r=i+5;cat='Platinum' if code.startswith('JSCV') or code=='P01' else 'Gold' if code.startswith('G') else 'Silver';k=cats.index(cat);owner='JSCV' if i<2 else 'JALS' if i<7 else 'Novos investidores';rows['A'+str(r)]=code;rows['B'+str(r)]=owner;rows['C'+str(r)]=cat;rows['D'+str(r)]=tickets[k]/50e6;rows['K'+str(r)]=tickets[k]
  rows['E'+str(r)]='=0' if i<7 else f'=SUMIF(\'V04 Pipeline\'!$A$5:$A$16,A{r},\'V04 Pipeline\'!$T$5:$T$16)'
  rows['F'+str(r)]=f"=SUM('V04 Waterfall180'!{'GHI'[k]}5:{'GHI'[k]}184)/{counts[k]}";rows['G'+str(r)]=f"='V04 Politica'!B11*D{r}"
  if i>=7:
   col=CL(i-7+2);rows['H'+str(r)]=f'=IF(E{r}>0,(F{r}+G{r})/E{r},"")';rows['I'+str(r)]=f'=IF(E{r}>0,IFERROR((1+IRR(\'V05 Fluxos Blocos\'!{col}5:{col}185,0.005))^12-1,"TIR não definida"),"")';rows['J'+str(r)]=f'=NPV((1+{PV("equity_discount")})^(1/12)-1,\'V05 Fluxos Blocos\'!{col}6:{col}185)';rows['L'+str(r)]=f'=IF(E{r}>0,IFERROR(XIRR(\'V05 Fluxos Blocos\'!{col}5:{col}185,\'V05 Fluxos Blocos\'!$S$5:$S$185,0.08),"TIR não definida"),"")'
  else:
   for cc in 'HIJL':rows[cc+str(r)]='Indisponível: custos/datas individuais históricos'
  rows['M'+str(r)]='Projeção; não constitui aprovação ou pagamento'
 rows['A22']='Total';rows['D22']='=SUM(D5:D19)';rows['E22']='=SUM(E5:E19)';rows['F22']='=SUM(F5:F19)';rows['G22']='=SUM(G5:G19)';rows['A24']='Total de blocos';rows['B24']='=COUNTA(A5:A19)';sheet('V05 Blocos',rows,width=26)
 rows={'A1':'V05 | Fluxos dos oito blocos novos','A2':'Meses relativos. A coluna S usa datas convencionais uniformes de365/12dias por mês; não são datas contratuais de realização. XIRR concilia com TIR mensal anualizada.','A4':'Mês','S4':'Data convencional'}
 for i,code in enumerate(['P01','G01','G02','S01','S02','S03','S04','S05']):rows[CL(i+2)+'4']=code
 for m in range(181):
  r=m+5;fr=m+4;rows['A'+str(r)]=m;rows['S'+str(r)]=f'=DATE(2026,1,1)+A{r}*365/12'
  for i,code in enumerate(['P01','G01','G02','S01','S02','S03','S04','S05']):
   k=0 if i==0 else 1 if i<3 else 2;cc=CL(i+2)
   if m==0:rows[cc+str(r)]='=0';continue
   income=f"('V04 Waterfall180'!{'GHI'[k]}{fr}+'V04 Waterfall180'!{'JKL'[k]}{fr})/{counts[k]}";outlay=f'SUMIFS(\'V04 Pipeline\'!$T$5:$T$16,\'V04 Pipeline\'!$A$5:$A$16,"{code}",\'V04 Pipeline\'!$J$5:$J$16,A{r})';rows[cc+str(r)]='='+income+'-'+outlay
 sheet('V05 Fluxos Blocos',rows,width=23)
 rows={'A1':'V05 | Síntese financeira Fase 2','A2':'Comparar com V04: base de9x e waterfall antiga não são a referência V05. Dashboard visual ainda não reformulado.','A4':'Indicador','B4':'Resultado de cenário'}
 summary=[('Caixa M30',"'Fluxo 180M'!AE34"),('Dívida M30',"'Fluxo 180M'!AB34"),('Reserva M30',"'Fluxo 180M'!Q34"),('Caixa M42',"'Fluxo 180M'!AE46"),('Dívida M42',"'Fluxo 180M'!AB46"),('Reserva M42',"'Fluxo 180M'!Q46"),('Caixa M54',"'Fluxo 180M'!AE58"),('Dividendo simulado M54',"'Fluxo 180M'!AD58"),('Geração12M M54',"'Fluxo 180M'!BE58"),('Caixa livre antes distribuição M54',"'Fluxo 180M'!BF58"),('Reserva M54',"'Fluxo 180M'!Q58"),('Dividendos globais180M',"SUM('Fluxo 180M'!AD5:AD184)"),('EBITDA Ano15',"SUM(Hotel!T173:T184)"),('Enterprise Value estimado',f'B17*{C(30)}'),('Equity Value líquido saída',"'V04 Politica'!B11"),('TIR novos investidores',"'V04 Retornos'!B27"),('MOIC novos investidores',"'V04 Retornos'!B28"),('VPL novos investidores',"'V04 Retornos'!B29"),('Saída novos investidores',"'V04 Retornos'!B36"),('Dividendos novos investidores',"'V04 Retornos'!B37"),('Reconciliação participações',"'V05 Blocos'!D22-1"),('Reconciliação dividendos',"'V05 Blocos'!F22-B16"),('Reconciliação saída',"'V05 Blocos'!G22-B19"),('Pagamentos documentados conhecidos',"IF(COUNT('V05 Controlo'!E5:E184)>0,SUM('V05 Controlo'!E5:E184),\"Indisponível\")")]
 for i,(label,f) in enumerate(summary,5):rows['A'+str(i)]=label;rows['B'+str(i)]='='+f
 rows['A29']='Pagamentos acima elegibilidade indicada';rows['B29']="=SUM('V05 Dividendos'!V5:V184)"
 rows['A30']='Estado técnico dos controlos V05';rows['B30']='=IF(AND(ABS(B25)<0.01,ABS(B26)<0.01,ABS(B27)<0.01,B29<0.01),"Conforme nos controlos; validar documentação","Erro de reconciliação ou documentação")'
 rows['A31']='Estado jurídico das distribuições';rows['B31']='Pendente de documentação e aprovação; números projetados não são pagamentos'
 rows['A32']='Estado de financiamento e reservas';rows['B32']='=IF(OR(MAX(\'Fluxo 180M\'!AF5:AF184)>0.01,MAX(\'Fluxo 180M\'!AG5:AG184)>0.01),"Alerta: défice de funding ou reservas","Coberto no cenário; fontes/documentos por confirmar")'
 rows['A33']='Capital-alvo no cenário';rows['B33']='=IF(SUM(\'V04 Pipeline\'!T5:T16)>=25000000-0.01,"Meta integral no cenário; não comprova realização","Captação-alvo incompleta; direitos por formalizar")'
 sheet('V05 Retornos',rows,width=30)
 # Update executive only version note; preserve visuals and every preexisting chart.
 # Cross-linked numbers update via KPI and V04 Retornos already.
 # Add direct navigation using new cells, not replacements of old hyperlinks.
 with zipfile.ZipFile(OUT,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as zo:
  nextsheet=max(int(s.attrib['sheetId']) for s in wb.find(T('sheets')))+1;maxrid=max(int(re.search(r'\d+',a.attrib['Id'])[0]) for a in rel if re.search(r'\d+',a.attrib['Id']))+1
  ct=E.fromstring(z.read('[Content_Types].xml'))
  for i,(name,raw) in enumerate(extrasheets.items()):
   path=f'xl/worksheets/sheet{nextsheet+i}.xml';rid=f'rId{maxrid+i}'
   E.SubElement(wb.find(T('sheets')),T('sheet'),{'name':name,'sheetId':str(nextsheet+i),RID:rid});E.SubElement(rel,'{http://schemas.openxmlformats.org/package/2006/relationships}Relationship',{'Id':rid,'Type':'http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet','Target':'worksheets/'+Path(path).name});E.SubElement(ct,'{http://schemas.openxmlformats.org/package/2006/content-types}Override',{'PartName':'/'+path,'ContentType':'application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml'});zo.writestr(path,raw)
  cp=wb.find(T('calcPr'));cp.set('calcMode','auto');cp.set('fullCalcOnLoad','1');cp.set('forceFullCalc','1');cp.set('calcId','0')
  for it in z.infolist():
   data=z.read(it.filename)
   if it.filename=='xl/workbook.xml':data=E.tostring(wb,encoding='utf-8',xml_declaration=True)
   elif it.filename=='xl/_rels/workbook.xml.rels':data=E.tostring(rel,encoding='utf-8',xml_declaration=True)
   elif it.filename=='[Content_Types].xml':data=E.tostring(ct,encoding='utf-8',xml_declaration=True)
   elif it.filename in newraw:data=newraw[it.filename]
   zo.writestr(it,data)
(R/'entrega/Registo_Alteracoes_Fase2.json').write_text(json.dumps(changes,ensure_ascii=False,indent=2));(R/'src/mapa_motor.json').write_text(json.dumps({'flows':list(flows),'waterfalls':wfmeta,'param_rows':PR},ensure_ascii=False,indent=2));print('Built',OUT,'changes',len(changes),flush=True)
