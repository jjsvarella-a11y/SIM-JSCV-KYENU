"""Transfer validated formula caches only; retain original financial formulas and UI parts.
Refresh chart caches from the same recalculated cells without redesigning charts.
"""
from pathlib import Path
import zipfile,xml.etree.ElementTree as E,re,json,html,hashlib,sys,os,collections
R=Path(__file__).resolve().parents[1];P=R/'entrega/KK01_Modelo_Integrado_V05_Executive.xlsx';Q=R/'validacao/Teste_Base/out/Base.xlsx';N='{http://schemas.openxmlformats.org/spreadsheetml/2006/main}';RID='{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id';CN='{http://schemas.openxmlformats.org/drawingml/2006/chart}'
def paths(z):
 w=E.fromstring(z.read('xl/workbook.xml'));rels={x.attrib['Id']:x.attrib['Target'] for x in E.fromstring(z.read('xl/_rels/workbook.xml.rels'))};return {s.attrib['name']:(rels[s.attrib[RID]].lstrip('/') if rels[s.attrib[RID]].startswith('/') else 'xl/'+rels[s.attrib[RID]]) for s in w.find(N+'sheets')}
count=0;before=hashlib.sha256();after=hashlib.sha256();chartlog=[]
with zipfile.ZipFile(P) as zi,zipfile.ZipFile(Q) as zr,zipfile.ZipFile(P.with_suffix('.cached'),'w',zipfile.ZIP_DEFLATED,compresslevel=6) as zo:
 pi=paths(zi);pr=paths(zr);names={v:k for k,v in pi.items()};ss=[]
 if 'xl/sharedStrings.xml' in zr.namelist():ss=[''.join(x.itertext()) for x in E.fromstring(zr.read('xl/sharedStrings.xml'))]
 chartrefs=collections.defaultdict(set)
 for fn in zi.namelist():
  if not re.fullmatch(r'xl/charts/chart\d+.xml',fn):continue
  raw=zi.read(fn).decode()
  for m in re.finditer(r'<c:f>(.*?)</c:f>',raw):
   f=html.unescape(m[1]);ma=re.fullmatch(r"(?:'((?:[^']|'')+)'|([^!]+))!\$?([A-Z]+)\$?(\d+):\$?([A-Z]+)\$?(\d+)",f)
   if ma:
    sn=(ma[1] or ma[2]).replace("''", "'")
    from openpyxl.utils import column_index_from_string as CI,get_column_letter as CL
    for rr in range(int(ma[4]),int(ma[6])+1):
     for cc in range(CI(ma[3]),CI(ma[5])+1):chartrefs[sn].add(CL(cc)+str(rr))
 chartvalues={}
 for inf in zi.infolist():
  raw=zi.read(inf.filename)
  if inf.filename in names:
   sn=names[inf.filename];x=E.fromstring(zr.read(pr[sn]));cache={}
   for c in x.iter(N+'c'):
    addr=c.attrib['r'];typ=c.attrib.get('t','n');v=c.find(N+'v');val=v.text if v is not None else None
    if typ=='s':val=ss[int(val)] if val is not None else '';typ='str'
    elif typ=='inlineStr':val=''.join(c.find(N+'is').itertext());typ='str'
    cache[addr]=(typ,val,c.find(N+'f') is not None)
    if addr in chartrefs.get(sn,set()):chartvalues[(sn,addr)]=(typ,val)
   def update(m):
    global count
    full=m[0];fm=re.search(r'<f(?:\s[^>]*)?>.*?</f>',full,re.S)
    if not fm:return full
    addr=m[1];assert addr in cache,(sn,addr);t,val,isf=cache[addr];assert isf,(sn,addr);assert t!='e',(sn,addr,val)
    before.update((sn+'!'+addr+'\0'+fm[0]).encode());count+=1
    full=re.sub(r'<v(?:\s[^>]*)?>.*?</v>|<v\s*/>','',full,flags=re.S);st=full[:full.index('>')];st=re.sub(r'\s+t="[^"]*"','',st);st+=' t="'+t+'"';full=st+full[full.index('>'):];full=full[:-4]+'<v>'+html.escape(val or '',quote=False)+'</v></c>';nf=re.search(r'<f(?:\s[^>]*)?>.*?</f>',full,re.S)[0];after.update((sn+'!'+addr+'\0'+nf).encode());return full
   raw=re.sub(r'<c\b[^>]*\br="([A-Z]+\d+)"[^>]*(?<!/)>.*?</c>',update,raw.decode(),flags=re.S).encode()
  # Chart cache update postponed until every sheet's values have been read.
  if not re.fullmatch(r'xl/charts/chart\d+.xml',inf.filename):zo.writestr(inf,raw)
 for fn in zi.namelist():
  if not re.fullmatch(r'xl/charts/chart\d+.xml',fn):continue
  raw=zi.read(fn).decode()
  def chart_ref(m):
   full=m[0];fm=re.search(r'<c:f>(.*?)</c:f>',full);f=html.unescape(fm[1]);ma=re.fullmatch(r"(?:'((?:[^']|'')+)'|([^!]+))!\$?([A-Z]+)\$?(\d+):\$?([A-Z]+)\$?(\d+)",f)
   kind=m[1];cachetag='numCache' if kind=='numRef' else 'strCache';values=[]
   if ma:
    sn=(ma[1] or ma[2]).replace("''", "'")
    for rr in range(int(ma[4]),int(ma[6])+1):
     for cc in range(CI(ma[3]),CI(ma[5])+1):values.append(chartvalues.get((sn,CL(cc)+str(rr)),('n',None)))
   elif f.startswith('"') and f.endswith('"'):values=[('str',f[1:-1])]
   else:return full
   pts=[]
   for i,(t,v) in enumerate(values):
    if v is None or v=='':continue
    if kind=='numRef' and t not in ['n','b']:continue
    pts.append(f'<c:pt idx="{i}"><c:v>'+html.escape(v,quote=False)+'</c:v></c:pt>')
   oldcache=re.search(r'<c:'+cachetag+r'>.*?</c:'+cachetag+r'>',full,re.S)
   formatcode=''
   if oldcache:
    mm=re.search(r'<c:formatCode>.*?</c:formatCode>',oldcache[0],re.S);formatcode=mm[0] if mm else ''
   newcache='<c:'+cachetag+'>'+formatcode+f'<c:ptCount val="{len(values)}"/>'+''.join(pts)+'</c:'+cachetag+'>'
   if oldcache:full=full[:oldcache.start()]+newcache+full[oldcache.end():]
   else:full=full.replace('</c:'+kind+'>',newcache+'</c:'+kind+'>')
   chartlog.append({'chart':fn,'reference':f,'points':len(values),'numeric_points':len(pts)});return full
  raw=re.sub(r'<c:(numRef|strRef)>.*?</c:\1>',chart_ref,raw,flags=re.S)
  zo.writestr(fn,raw.encode())
 assert before.hexdigest()==after.hexdigest()
os.replace(P.with_suffix('.cached'),P)
report={'ok':True,'source_recalculated':str(Q),'formula_caches':count,'formulas_unchanged':True,'formula_sha256':before.hexdigest(),'chart_caches':chartlog,'note':'Only caches updated. LibreOffice worksheet/styles/chart layouts were not used as final presentation.'};(R/'entrega/Reconciliacao_Caches_Final.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(count,'formula caches transferred; charts',len(chartlog))
