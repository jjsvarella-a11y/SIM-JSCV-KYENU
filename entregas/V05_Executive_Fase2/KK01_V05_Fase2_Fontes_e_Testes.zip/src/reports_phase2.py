from pathlib import Path
import sys,json,csv,hashlib,re
from xml.sax.saxutils import escape
sys.path.insert(0,str(Path(__file__).parent));import v05_engine as e
R=Path(__file__).resolve().parents[1];O=R/'entrega'
def pt(x,dec=2):
 if x is None:return 'Não definida'
 return f'{x:,.{dec}f}'.replace(',','X').replace('.',',').replace('X','.')
def money(x):return pt(x)+' €'
def pct(x):return 'Não definida' if x is None else pt(x*100)+'%'
def table(headers,rows):return '\n'.join(['| '+' | '.join(headers)+' |','| '+' | '.join(['---']*len(headers))+' |']+['| '+' | '.join(str(v) for v in row)+' |' for row in rows])
def polish(text):
 text=re.sub(r'(?<=\d)(?=[A-Za-zÀ-ÿ])',' ',text)
 text=re.sub(r'\b([A-Za-zÀ-ÿ]{3,})(?=\d)',r'\1 ',text)
 text=re.sub(r'([€×%])(?=[A-Za-zÀ-ÿ])',r'\1 ',text)
 for a,b in [('Fluxo 180 M','Fluxo 180M'),('Geração 12 M','Geração 12M'),('simuladaseleciona','simulada seleciona'),('ObjetivoKKseleciona','Objetivo KK seleciona'),('Acumulados/Máximo','Acumulados / Máximo'),('M54eM','M54 e M'),('eM54','e M54'),('eM66','e M66'),('eM174','e M174'),('eM180','e M180'),('PT/ENé','PT/EN é'),('M€e','M€ e'),('QuadroV05','Quadro V05')]:text=text.replace(a,b)
 return text

def pdf(md,path):
 from reportlab.pdfbase import pdfmetrics
 from reportlab.pdfbase.ttfonts import TTFont
 from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle
 from reportlab.lib.styles import getSampleStyleSheet
 from reportlab.lib import colors
 pdfmetrics.registerFont(TTFont('DVS','/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'));pdfmetrics.registerFont(TTFont('DVS-B','/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'))
 styles=getSampleStyleSheet()
 for st in styles.byName.values():st.fontName='DVS';st.fontSize=9;st.leading=13
 for name in ['Title','Heading1','Heading2','Heading3']:styles[name].fontName='DVS-B'
 styles['Title'].fontSize=17;styles['Title'].leading=22;styles['Heading2'].fontSize=12;styles['Heading2'].leading=16;styles['Heading3'].fontSize=10;styles['Heading3'].leading=14
 story=[];lines=md.splitlines();i=0
 while i<len(lines):
  s=lines[i];i+=1
  if not s.strip():continue
  if s.startswith('|'):
   rs=[s]
   while i<len(lines) and lines[i].startswith('|'):rs.append(lines[i]);i+=1
   data=[[Paragraph(escape(c.strip()),styles['BodyText']) for c in r.strip('|').split('|')] for r in rs if not set(r.replace('|','').replace(' ','')).issubset(set('-:'))]
   n=len(data[0]);widths=[240,271] if n==2 else [215]+[(511-215)/(n-1)]*(n-1) if n<=4 else [130]+[(511-130)/(n-1)]*(n-1)
   t=Table(data,colWidths=widths,repeatRows=1,hAlign='LEFT');t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#e7e8eb')),('VALIGN',(0,0),(-1,-1),'TOP'),('GRID',(0,0),(-1,-1),.25,colors.HexColor('#cccccc')),('BOTTOMPADDING',(0,0),(-1,-1),6)]));story.extend([t,Spacer(1,9)])
  else:
   sty='Title' if s.startswith('# ') else 'Heading2' if s.startswith('## ') else 'Heading3' if s.startswith('### ') else 'BodyText';story.extend([Paragraph(escape(s.lstrip('# ').strip()),styles[sty]),Spacer(1,5)])
 def footer(c,d):c.setFont('DVS',7);c.drawString(42,23,'KK-01 | V05 Executive — Fase 2 | Projeções condicionais');c.drawRightString(553,23,str(d.page))
 SimpleDocTemplate(str(path),leftMargin=42,rightMargin=42,topMargin=36,bottomMargin=40).build(story,onFirstPage=footer,onLaterPages=footer)

def main():
 native=json.loads((O/'Testes_Sensibilidade_Fase2.json').read_text());assert len(native)==20 and all(x['ok'] for x in native)
 py=json.loads((O/'Testes_Python_Fase2.json').read_text());assert py['ok']
 risks=json.loads((O/'Testes_Riscos_Auxiliares_Fase2.json').read_text());assert risks['ok']
 struct=json.loads((O/'Testes_Estruturais_Fase2.json').read_text());assert struct['ok']
 r=e.run(e.config());m=e.results(r);old=e.v4.run(e.v4.config());s=e.v4.summary(old);sel=e.v4_selected(old);bridge=json.loads((O/'Ponte_Impactos_V04_V05.json').read_text());f=r['flow'];x=f[53]
 rows=[]
 baseline={'cash30':s['cash30'],'cash42':s['cash42'],'cash54':old['flow'][53]['cash'],'div54':0,'cash_end':s['cash_end'],'dividends':s['dividends'],'ev':s['ev'],'exit_equity':s['exit_equity'],'new_irr':sel['metrics']['new_irr'],'new_moic':sel['metrics']['new_moic'],'new_npv':sel['metrics']['new_npv']}
 for label,k,fmt in [('Caixa M30','cash30',money),('Caixa M42','cash42',money),('Caixa M54 após distribuição','cash54',money),('Dividendo M54','div54',money),('Dividendos globais180M','dividends',money),('Caixa final','cash_end',money),('Enterprise Value estimado','ev',money),('Equity Value na saída','exit_equity',money),('TIR novos15A','new_irr',pct),('MOIC novos15A','new_moic',lambda v:pt(v,4)+'×'),('VPL novos a12%','new_npv',money)]:rows.append([label,fmt(baseline[k]),fmt(m[k])])
 md='''# KK-01 | V05 Executive — Relatório da Fase 2

Data de referência: 20/10/2026. Sociedade: KK Hotelaria e Turismo, S.A. Base exclusiva: KK01_Modelo_Integrado_V04_Excel_Fix.xlsx. Entrega intermédia financeira; dashboards executivos e sistema bilingue ainda não reformulados.

## 1. Conclusão executiva

A nova estrutura de15blocos, os dividendos progressivos e a saída proporcional foram implementados sobre o motor mensal da V04 Fixed. Não foi criado um modelo financeiro independente. O original foi preservado integralmente.

No cenário de referência, a geração de caixa dos12meses anteriores suporta uma distribuição financeira parcial no M54. O objetivo mínimo anual de3M€não é integralmente coberto a1,20×. A análise independente de lucros acumulados e caixa livre admite um montante superior, mantendo reservas, mas não demonstra aprovação jurídica. O ficheiro distingue projeções, montantes documentados aprovados e pagamentos comprovados.

A valorização e o retorno dependem de execução, desempenho operacional e de uma saída hipotética. O VPL agregado dos novos investidores a12% continua negativo. Não se declara financiamento assegurado, dividendos garantidos, direitos estatutários aprovados ou compatibilidade certificada com Excel Desktop.

## 2. Preservação e configuração

O original Fixed tem SHA-256 be8288ced2494ef31c2dbe1d31d77b8277a0753a1209a8df0a83c3a5d86dcdc0. A cópia imutável mantém os mesmos bytes. A V04 anterior sem correção não foi usada como base de atualização.

Mantiveram-se200quartos, MICE e94apartamentos, VGV de50.656.336,37€, CAPEX futuro de63.168.000€, calendário de obra30meses e aberturaM31, cenário Hotel Favorável, condições bancárias Limite aceitável (6%,42meses de carência,10anos posteriores), linha não revolving de30M€e fees de referência3%/3%/6%. São condições de cenário, não contratos comprovados.

Foram preservadas as313folhas originais, os módulos auxiliares, notas, nomes, validações, hiperligações e os17gráficos. Seis folhas financeiras foram acrescentadas: V05 Config, V05 Controlo, V05 Dividendos, V05 Blocos, V05 Fluxos Blocos e V05 Retornos. Os nomes técnicos V03/V04 foram preservados para não quebrar referências; os módulos ativos atualizados estão assinalados.

## 3. Estrutura de15blocos e calendário de capital

'''+table(['Titular','Platinum','Gold','Silver'],[['JSCV —40%','2','0','0'],['JALS —10%','0','0','5'],['Novos —50%','1','2','5'],['Total —100%','3','2','10']])+'''

Existem8blocos novos:1Platinum de10M€,2Gold de5M€e5Silver de1M€, total25M€. Os7blocos dos promotores não geram novas entradas de caixa. As bases convencionais agregadas dos15blocos não constituem capital novo nem avaliação de mercado comprovada.

Preservou-se exatamente cada recebimento mensal de capital da V04. O novo G02 agrupa cinco antigas parcelas de1M€. No calendário Base recebe3M€no M3 e2M€no M4. Cada um dos cinco Silver restantes paga1M€nos meses4,5,5,6e6. Os calendários Acelerado e Prudente conservam também os mesmos fluxos agregados. Assim, as12linhas de pipeline são parcelas de8blocos, e não12blocos novos. A TIR do G02 utiliza todas as cinco parcelas.

Os campos documentados de compromissos, recebimentos e transferências permanecem independentes e vazios na referência. Uma captação parcial não aprova automaticamente uma nova diluição; a repartição económica40%/10%/50% continua a ser a hipótese-alvo, sujeita a formalização e completude do financiamento.

## 4. Política de dividendos

'''+table(['Categoria','Mínimo por bloco','Intermédio','Máximo'],[['Platinum',money(700000),money(850000),money(1000000)],['Gold',money(250000),money(287500),money(325000)],['Silver',money(40000),money(45000),money(50000)],['Global15blocos',money(3000000),money(3575000),money(4150000)]])+'''

Datas: M54,M66,M78,M90,M102,M114,M126,M138,M150,M162eM174. Não há dividendos ordinários antes deM54 nem pagamento ordinário adicional implícito no M180. Como convenção prudencial da simulação, exige-se também o final de24meses desde a abertura própria do cenário; atrasos podem deslocar a primeira distribuição para uma data anual posterior.

Base Geração12M: capacidade é o mínimo entre caixa livre, teto de lucros selecionado e geração líquida dos últimos12meses dividida por1,20. A geração exclui capital, vendas residenciais e novos empréstimos; inclui caixa Hotel+MICE e residual KK, deduzindo serviço obrigatório, custos comerciais, comissões e investimentos pagos no período. FF&E, manutenção e fiscalidade já incluídos no CFADS não são deduzidos novamente.

Base Acumulados: avalia separadamente o mínimo entre caixa livre e lucros acumulados disponíveis no critério selecionado, sem impor a cobertura12M. O rácio de geração continua visível. Este modo não elimina reservas, compromissos, serviço da dívida ou limites de lucros.

A caixa livre parte da caixa após serviço e amortização voluntária e deduz reserva protegida, proteção futura da obra e reservas adicionais informadas em V05 Controlo. A referência conserva também os bloqueios prudenciais por dívida bancária/suprimentos pendentes e défices não financiados. Um controlo editável exige capital-alvo integralmente recebido no cenário antes de distribuir; não equivale a comprovação documental da captação.

O patamar solicitado funciona como teto. Escolhe-se o patamar integralmente suportado mais elevado até esse teto. Apenas quando o mínimo não é suportado se permite parcial, proporcional aos objetivos mínimos. Não se criam prioridades adicionais, juros, dividendos cumulativos ou créditos por metas não alcançadas. Os patamares são dividend yields pretendidas sobre bases convencionais, não metas de TIR. A repartição dos dividendos ordinários segue estes objetivos por categoria, não40%/10%/50%. Essa proporcionalidade aplica-se às participações e à saída; todos os blocos da mesma categoria recebem o mesmo montante. A formalização desses direitos permanece externa.

## 5. Liquidez e primeira distribuição M54

'''+table(['Indicador M54','Referência V05'],[['Caixa antes de dividendos',money(x['post']-x['sweep'])],['Reserva protegida',money(x['reserve'])],['Caixa livre antes de dividendos',money(x['div_metrics']['free'])],['Geração líquida12M',money(x['div_metrics']['generation12'])],['Dividendo com cobertura1,20×',money(x['dividend'])],['Falta para objetivo mínimo3M€',money(3e6-x['dividend'])],['Caixa após distribuição',money(x['cash'])]])+'''

Na alternativa Acumulados/Máximo, o modelo suporta financeiramente4.150.000€no M54 e mantém10.015.048,93€de caixa. A geração desse período, isoladamente, não cobre esse pagamento a1,20×. São análises independentes, não duas distribuições a somar.

A reserva M30 é3.633.802,73€, distinta da caixa M30 de8.717.152,56€. As reservas M42 eM54 são3M€na referência. A caixa M42 sobe porque a política V05 retém o dividendo V04 do M36 (3.247.301,01€). AtéM54 retém também o dividendo V04 do M48 (3.159.258,70€). A ponte de caixa é a soma dessas retenções menos a nova distribuição M54; não houve receitas adicionais criadas para obter o saldo.

## 6. Reconciliação financeira V04 Fixed / V05

'''+table(['Indicador','V04 Fixed','V05 referência'],rows)+'''

A diminuição dos dividendos globais explica, cêntimo a cêntimo, o aumento da caixa final, mantendo as demais operações de referência. O aumento do múltiplo de9×para12×acrescenta valor estimado, não caixa operacional nem crédito disponível. O pico de dívida e a utilização acumulada permanecem14.883.293,59€e19.187.648,01€.

Mantendo9×apenas como sensibilidade comparável, a nova política com saída proporcional produz TIR deaproximadamente7,06% eMOIC de2,4476×. Assim, parte principal da melhoria da referência12×resulta da hipótese de valorização superior, e não de maior geração operacional.

A melhoria de TIR/MOIC não permite omitir o VPL negativo a12% nem a dependência da saída. A redução das distribuições antecipadas e a concentração de valor no M180 alteram o perfil temporal do retorno. O payback do projeto sem saída permanece86meses; não é o payback dos acionistas.

A ponte em Ponte_Impactos_V04_V05.json e no CSV separa composição, nova política de dividendos, repartição proporcional da saída e múltiplo. As etapas intermédias1e2 retêm pools/pesos V04 apenas como contrafactuais para atribuição de efeitos; esses pesos não foram importados para a política ativa V05 e não são propostas de direitos.

## 7. Saída no M180

Utiliza-se o EBITDA do Ano15 do projeto, M169–M180: '''+money(m['ebitda15'])+'''. Não é o décimo quinto ano de operação do Hotel.

'''+table(['Cenário','Múltiplo','Enterprise Value ilustrativo'],[[n,str(mult)+'×',money(m['ebitda15']*mult)] for n,mult in [('Prudente',10),('Base',12),('Favorável',15)]])+'''

Os valores são fórmulas ligadas à operação, não constantes. Custos de saída de2%sobreEV, dívida bancária e suprimentos aplicáveis são deduzidos. A caixa é incorporada uma única vez, deduzindo reservas HOTUSA/contingências e proteção adicional de compromissos no mês de saída. Conserva-se a convenção de venda da V04 para a reserva operacional: protege a exploração, mas não é automaticamente abatida como perda de valor no preço da venda. Ajustamentos de caixa normalizada exigidos pelo comprador devem ser explicitados como proteção adicional, sem duplicação.

O Equity Value líquido é repartido40%JSCV,10%JALS e50%novos investidores, sem preferências ou saldos da antiga waterfall. A opção Continuidade mantém EV estimado, mas coloca o recebimento terminal em zero. Os apartamentos vendidos não são reavaliados como ativos da KK. Reservas pool/FF&E não são somadas como caixa livre.

## 8. Resultados simulados, aprovação e pagamento

O dividendo que alimenta o fluxo mensal é uma projeção financeira, limitado pela base de lucros selecionada. Na referência usa-se a proxy prudente herdada, não contas estatutárias aprovadas. O modo Documentado do teto de lucros exige o montante documentado; sem esse valor, não autoriza distribuição financeira no cenário.

V05 Controlo separa teto mensal indicado, deliberação comprovada e pagamento comprovado, com campo de documento/data. V05 Dividendos mostra o limite reconhecido documentalmente e pagamentos de forma independente. Vazios são Indisponível. Estes campos não são adicionados ao dividendo projetado nem alteram automaticamente a projeção como se fossem uma segunda saída. A aprovação externa precisa de ser verificada; preencher uma célula não substitui a deliberação ou o extrato bancário.

Os testes documentais utilizam dados sintéticos em cópias isoladas; nenhum pagamento ou aprovação fictícia foi introduzido na referência entregue. Custos/datas históricos individuais dos promotores continuam indisponíveis; não se apresenta TIR individual histórica como comprovada.

## 9. Auditoria, correções e limites

O registo de alterações identifica as fórmulas e textos modificados. Foram inativados os saldos preferenciais antigos e as metas TIR V04 como regra ativa; preservaram-se fontes e benchmarks identificados. Corrigiram-se as notas desatualizadas de25M€por49%e de realização integral no mês1, e o controlo de auditoria que ainda exigia20blocos. Este último foi atualizado para15e reconfirmado no recálculo final da referência, sem alterar os vetores financeiros das sensibilidades.

Nos testes de desenvolvimento foram corrigidos: fórmula SUMIF inicialmente escrita como texto na nova tabela de blocos; elegibilidade nos cenários de abertura atrasada; alocação de saída que não podia inferir direitos de uma percentagem paga; e subtração de TIR não definida no comparativo de continuidade. Nenhuma correção substituiu resultados económicos por constantes.

Foi observada falha Signal11 do LibreOfficeDev em cálculo paralelo. A validação final utilizou perfil isolado e cálculo controlado, com expressão escalar da data de abertura de cada motor. A causa específica da falha do programa não é apresentada como comprovada. Os números finais foram reconciliados com Python; as caches não constituem, por si, validação.

Permanece o alerta herdado de objetivo de rendimento residencial não coberto:164.946,24€acumulados nos180meses. O objetivo não é garantido, e o modelo não inventa uma compensação para o eliminar. A fiscalidade simplificada da V04 permanece sujeita a apuramento imobiliário e consolidado; esta fase não comprova imposto final da promoção nem lucro legalmente distribuível.

Persistem validações externas: instrumentos de capital, direitos e deliberações, contas distribuíveis, fiscalidade, contratos de venda, crédito e condições precedentes, HMA/fees e realizabilidade do preço de saída. Não existe Microsoft Excel Desktop no ambiente. A aceitação nativa Microsoft, Excel Web eWPS permanece por testar. O relatório de testes distingue o que foi efetivamente executado.

## 10. Entrega e limite de fase

Entregam-se modelo financeiro intermédio V05 Executive, reconciliação mensal e por alteração, relatório de testes, guia e fontes de reprodução. A fase financeira está separada da reformulação visual dos sete dashboards e da interface bilingue, que não foram declaradas concluídas nesta entrega.
'''
 md=polish(md);(O/'KK01_Relatorio_Fase2_Reconciliacao.md').write_text(md);pdf(md,O/'KK01_Relatorio_Fase2_Reconciliacao.pdf')
 testsmd='''# KK-01 | V05 Executive — Relatório de Testes Fase 2

Data de referência:20/10/2026. Validação financeira em Python e recálculo externo LibreOffice. Sem Microsoft Excel Desktop disponível.

## 1. Resultado e escopo

'''+table(['Verificação','Resultado'],[['Controlos Python',str(py['tests'])+' aprovados;0falhas'],['Seletores com recálculo externo',str(len(native))+' casos aprovados'],['Comparações seletores',str(sum(t['comparisons'] for t in native))],['Cenários auxiliares integrados',str(risks['cases'])+' casos;'+str(risks['comparisons'])+' comparações'],['Controlos estruturais',str(struct['checks'])+' aprovados'],['Erros de célula nos recálculos finais','0inesperados'],['Excel Desktop','Não executado; compatibilidade não certificada']])+'''

As contagens de comparações não são números de testes independentes. Os controlos Python incluem paridade do motor original e invariantes; as comparações externas confrontam os valores recalculados com novas execuções Python. As cópias dos casos são isoladas e os inputs efetivamente modificados antes do recálculo.

## 2. Cenários executados

'''+table(['Cenário','Comparações','Dividendo M54','TIR novos15A'],[[t['case'],str(t['comparisons']),money(t['metrics']['div54']),pct(t['metrics']['new_irr'])] for t in native])+'''

Os casos incluem os três patamares, cobertura versus acumulados, falta de capacidade/parcial/suspensão, fees3/3/6e4/3/10, múltiplos10/12/15, continuidade, documentação ausente/sintética, reservas adicionais, captação parcial, atrasos e custos de benefícios não nulos. Reserva extra é proteção, não despesa fictícia. O caso de capital parcial não valida direitos societários por um preço inferior ao alvo.

## 3. Reconciliação do motor e invariantes

Compararam-se os180meses dos campos financeiros do motor: entradas de capital e vendas, custos comerciais, CAPEX, operação, financiamento, juros/comissões, amortizações, dividendos, caixa, reservas e verificações de caixa/dívida. Verificaram-se ainda capacidades12M/acumulados, objetivos e fluxos dos oito blocos, incluindo as cinco parcelas G02. As TIR são obtidas dos vetores de caixa; as yields pretendidas não são usadas como TIR.

A referência preserva cada recebimento mensal de capital V04. Com a política nova desligada, a implementação Python reproduz na referência caixa, dívida, juros, dividendos e fluxo do projeto originais. Os pagamentos ordinários só ocorrem nos meses elegíveis; a cobertura1,20×é imposta apenas no modo Geração12M. O parcial conserva os pesos dos objetivos mínimos. Não existem saldos automáticos de dividendos em atraso.

Verificaram-se o limite não revolving, a proteção de caixa na distribuição, a diferença entre valores estimados e recebidos na saída e a conservação dos montantes por categoria/acionista. Uma TIR não definida é texto explícito, não zero ou erro aritmético.

## 4. Riscos auxiliares preservados

'''+table(['Cenário','Comparações','Falta máxima de reserva','Resultado técnico'],[[x['case'],str(x['comparisons']),money(x['reserve_gap']),'Conforme na reconciliação'] for x in risks['results']])+'''

Conforme na reconciliação significa que as fórmulas reproduzem o cenário, não que esse cenário seja financeiramente viável. Insuficiências de reservas ou funding permanecem expostas e exigem ações; não foram anuladas com capital ou dívida fictícios.

## 5. Estrutura, tolerâncias e limitações

Os controlos preservam as folhas originais e estados,347nomes definidos, notas, imagens, estilos e ligações. Os gráficos conservam desenho e referências; apenas caches de dados foram atualizadas a partir das mesmas células recalculadas. As fórmulas foram preservadas durante a transferência de caches, com fingerprint antes/depois. A integridade ZIP, ausência de células duplicadas, limites de comprimento e ausência de macros/links externos foram verificadas.

Tolerância externa: máximo entre0,01€e|valor|×1e-9para montantes; TIR e rácios com máximo entre1e-7e|valor|×1e-8; participação reconciliada a1e-10. Há controlo adicional nos invariantes. Comparação de saldos do original é independente dos testes de sensibilidade. Fórmulas em cache não foram aprovadas sem recálculo externo correspondente.

Falhas de desenvolvimento e de execução paralela foram registadas e corrigidas/reexecutadas. A tabela acima apresenta apenas os resultados finais. O ambiente LibreOffice de desenvolvimento não substitui Microsoft Excel. Procedimento Microsoft ainda necessário: abrir cópia, cálculo automático, Ctrl+Alt+Shift+F9, confrontar KPI eM30/M42/M54, alterar um input e confirmar propagação. Sem essa execução não se certifica compatibilidade nativa.
'''
 testsmd=polish(testsmd);(O/'KK01_Relatorio_Testes_Fase2.md').write_text(testsmd);pdf(testsmd,O/'KK01_Relatorio_Testes_Fase2.pdf')
 guide='''# KK-01 | V05 Executive — Guia Financeiro Fase 2

Base: V04 Excel Fix. Guardar sempre uma cópia antes de alterar cenários. Todos os valores de referência são projeções, não pagamentos comprovados. Os dashboards antigos permanecem para continuidade; a reformulação visual ePT/ENé posterior.

## 1. Onde começar

Abrir V05 Retornos para a síntese. Consultar V05 Config para a política, V05 Dividendos para os180meses, V05 Blocos para os15blocos e V05 Fluxos Blocos para os oito vetores de investidores. Os links na linha3dos novos separadores permitem navegar. No Excel, também pode usar a caixa de nome ouIrPara com 'V05 Retornos'!A1.

## 2. Repor a referência

Em V05 Config: Base de capacidade=Geração12M; patamar=Automático; cobertura=1,20; parcial=1; saída=Base; realizar saída=1; políticaV05=1; composiçãoV05=1; primeiro mês54; exigir capital-alvo integral=1. Os interruptores de política/composição são técnicos, não alternativas de direitos aprovadas. Em Pressupostos, preservar cenárioKK-E25, calendárioBase, HotelFavorável, bancoLimite aceitável, linha30M€e feesObjetivoKK3/3/6.

Não existe macro de reposição. Recuperar uma cópia original da entrega ou selecionar os valores de referência. Alterar um input mantém o motor dinâmico; não escrever sobre fórmulas.

## 3. Dividendos e liquidez

Selecionar Geração12M para impor cobertura1,20×ouAcumulados para analisar separadamente lucros e caixa acumulados. Selecionar um teto de patamar. O modelo reduz para o patamar integralmente suportado; se nem o mínimo couber, parcial=1permite rateio proporcional aos mínimos. Parcial=0suspende esse pagamento. Suspenso elimina dividendos ordinários, sem transformar metas em dívida.

Na referência, conferir M30na linha34do Fluxo180M, M42na46eM54na58. A primeira distribuição simulada é2.630.786,91€com caixa posterior11.534.262,02€. No modoAcumulados/Máximo, é4.150.000€e caixa10.015.048,93€. Os montantes são cenários alternativos, não cumulativos.

A reserva adicional em V05 Controlo colunaBé um valor de proteção no respetivo mês; não é saída de caixa e não deve duplicar valores já reservados emQ/ARdo motor. Uma obrigação com vencimento futuro deve ser protegida nos meses relevantes até ao pagamento. Não informar apenas o mês do pagamento se a intenção for impedir distribuição anterior. O valor protegido no M180é também deduzido da saída.

## 4. Documentação e pagamentos

V05 Controlo: colunaC=teto mensal indicado como aprovado;D=deliberação comprovada1/0;E=pagamento comprovado;F=documento/data. Manter em branco o que não esteja disponível. A referência não contém aprovações ou pagamentos fictícios. V05 Dividendos mostra os três conceitos separadamente.

Estes campos são controlos e reporting, não uma atualização automática de todos os realizados históricos. Não somar pagamento comprovado ao dividendo projetado. Para simular o teto legal documentado, selecionar Documentado em Pressupostos e preencher o teto acumulado correspondente com suporte verificado. As restrições legais, bancárias, fiscais e societárias precisam de confirmação externa.

## 5. Capital e blocos

Consultar15blocos em V05 Blocos. O pipeline legado mantém12parcelas para preservar a tesouraria da V04. Cinco parcelas pertencem ao mesmoG02; não são cinco blocos Gold. No calendárioBase, esse bloco aplica3M€noM3e2M€noM4. Não alterar quantidades de categorias para inferir direitos societários diferentes sem decisão formal.

Os retornos dos novos investidores consideram as datas mensais de todas as parcelas. O MOIC usa recebido total dividido por capital de cenário. A TIR mensal anualizada é calculada com os vetores0..180. A colunaXIRRcom datas convencionais utiliza uma base uniforme apenas para comparação matemática; não representa datas contratuais ou realização documental. As TIR históricas individuais dos promotores permanecem indisponíveis.

## 6. Operador e financiamento

Usar os inputs centrais existentes em Pressupostos/Condicoes Operador. ObjetivoKKseleciona3%base+3%sistemas+6%incentivo; Proposta simuladaseleciona4%/3%/10%. Não aplicar todos os fees sobre a mesma base. Comparar EBITDA, CFADS, dividendos e saída depois de recalcular.

Alterar linha/taxa/carência/prazo e comissões nos controlos já existentes. A linha é não revolving: amortizar não repõe disponibilidade acumulada. Limite, utilização acumulada e pico da dívida são diferentes.

## 7. Saída e continuidade

Em V05 Config selecionarPrudente10×,Base12×ouFavorável15×. O EBITDA é do Ano15do projeto, M169–M180. Realizar saída=0mantém a exploração sem recebimento terminal. EVestimado não é caixa disponível. A distribuição líquida é40%JSCV,10%JALS,50%novos. As metas TIR e preferências V04 não governam a V05.

Rever custos de transação, dívida, caixa normalizada e compromissos antes de negociar uma saída real. Não somar apartamentos vendidos, dividendos anteriores ou fundos restritos ao preço. O múltiplo é uma hipótese económica, não oferta de compra.

## 8. Conferência e exportação

Verificar estados em V05 Retornos eAUDITORIA; consultar o dicionário e fontes existentes. Os relatórios PDF desta entrega contêm a síntese e os testes. Para imprimir uma folha financeira, ajustar a área de impressão e confirmar a pré-visualização. A configuração definitiva dos sete relatórios executivos pertence à fase visual.

No ExcelDesktop, executar recálculo integral e conferir a referência antes de utilizar em decisão. Esta aplicação não está disponível no ambiente de desenvolvimento; não foi certificada a compatibilidade nativa. Se aparecer erro, conservar a cópia e identificar a primeira célula de origem, sem substituir fórmulas por valores ou zeros.
'''
 guide=polish(guide);(O/'KK01_Guia_Financeiro_Fase2.md').write_text(guide);pdf(guide,O/'KK01_Guia_Financeiro_Fase2.pdf')
 # CSVs are explicit reference comparisons, not hard-coded replacements of model calculations.
 with (O/'Reconciliacao_Mensal_V04_V05.csv').open('w',newline='') as file:
  cw=csv.writer(file,delimiter=';');cw.writerow(['Mes','Caixa_V04_EUR','Caixa_V05_EUR','Delta_Caixa_EUR','Dividendos_V04_EUR','Dividendos_V05_EUR','Div_Cumulados_V04_EUR','Div_Cumulados_V05_EUR','Divida_V04_EUR','Divida_V05_EUR','Reserva_V05_EUR']);a=b=0
  for x,y in zip(old['flow'],f):a+=x['dividend'];b+=y['dividend'];cw.writerow([x['m']]+[pt(v) for v in [x['cash'],y['cash'],y['cash']-x['cash'],x['dividend'],y['dividend'],a,b,x['debt'],y['debt'],y['reserve']]])
 with (O/'Ponte_Impactos_V04_V05.csv').open('w',newline='') as file:
  cw=csv.writer(file,delimiter=';');keys=['stage','basis','cash30','cash42','cash54','div54','cash_end','dividends','ev','exit_equity','new_irr','new_moic','new_npv'];cw.writerow(keys)
  for stage in bridge:cw.writerow([stage[k] if isinstance(stage[k],str) else pt(stage[k],8 if k in ['new_irr','new_moic'] else 2) for k in keys])
 print('Relatórios PDF/MD, guia e reconciliações gerados.')
if __name__=='__main__':main()
