from pathlib import Path
import sys,json,openpyxl
sys.path.insert(0,str(Path(__file__).parent));import v05_engine as e
M=json.load(open(Path(__file__).resolve().parents[1]/'reference/src/build_metadata.json'));RM=json.load(open(Path(__file__).resolve().parents[1]/'reference/src/v04_risk_metadata.json'));R=Path(__file__).resolve().parents[1]
def audit(path):
 w=openpyxl.load_workbook(path,read_only=True,data_only=True);out=[]
 for item in RM:
  par=item['params'].copy()
  if 'res_adr_multiplier' in par:par['res_adr']=e.v4.DEFAULT['res_adr']*par.pop('res_adr_multiplier')
  r=e.run(e.config(**par));mm=e.results(r);fails=[];count=0
  def eq(label,a,b):
   nonlocal count
   count+=1
   if not isinstance(a,(int,float)) or abs(a-b)>max(.01,abs(b)*1e-9):fails.append([label,a,b])
  for row,x in zip(w[item['flow']].iter_rows(min_row=5,max_row=184,values_only=True),r['flow']):
   for k,c in M['flow_columns'].items():
    if isinstance(x.get(k),(int,float)):eq(str(x['m'])+' '+k,row[c],x[k])
  for row,x in zip(w[item['waterfall']].iter_rows(min_row=5,max_row=184,values_only=True),r['flow']):
   m=x['m'];weights=x['div_metrics']['weights'];d=[x['dividend']*q for q in weights];ee=mm['exit_equity'] if m==180 else 0;new=d[0]/3+d[1]+d[2]/2+ee*.5
   for c,b in {6:d[0],7:d[1],8:d[2],9:ee*.6,10:ee*.2,11:ee*.2,19:new,20:e.investor_outlay(r['p'],m),21:new-e.investor_outlay(r['p'],m),22:d[0]*2/3+ee*.4,23:d[2]/2+ee*.1}.items():eq('WF '+str(m)+' c'+str(c),row[c],b)
  res={'case':item['code'],'ok':not fails,'comparisons':count,'failures':fails[:12],'div54':r['flow'][53]['dividend'],'reserve_gap':mm['reserve_gap'],'new_irr':mm['new_irr']};out.append(res);print(item['code'],res['ok'],res['failures'][:1],flush=True)
 w.close();return {'ok':all(x['ok'] for x in out),'cases':len(out),'comparisons':sum(x['comparisons'] for x in out),'results':out}
if __name__=='__main__':
 path=Path(sys.argv[1]);report=audit(path);dest=path.parent/'Testes_Riscos_V05.json';dest.write_text(json.dumps(report,ensure_ascii=False,indent=2));raise SystemExit(not report['ok'])
