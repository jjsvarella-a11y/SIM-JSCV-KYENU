from pathlib import Path
import sys,json,copy,hashlib
sys.path.insert(0,str(Path(__file__).parent));import v05_engine as e
from run_sensitivities import CASES
R=Path(__file__).resolve().parents[1];tests=[]
def test(name,condition,detail=None):tests.append({'test':name,'ok':bool(condition),'detail':detail})
base=e.run(e.config());metrics=e.results(base);old=e.v4.run(e.v4.config());oldsel=e.v4_selected(old)
# Original engine parity with every V05 financial override switched off.
par=e.run(e.config(block_v05=False,benefit_v05=False,div_v05=False,exit_mult=9))
for key in ['cash','dividend','debt','interest','cumulative','project_cf','equity']:
 test('Paridade V04: '+key,max(abs(x[key]-y[key]) for x,y in zip(par['flow'],old['flow']))<.005)
for m in range(1,181):test('Calendário de capital M'+str(m),abs(e.investor_outlay(base['p'],m)-e.v4.investor_outlay(old['p'],m))<.005)
test('15blocos e quotas',sum(e.COUNTS)==15 and 3*.2+2*.1+10*.02==1)
test('8blocos novos e25M',len(set(x['code'] for x in e.pipeline(base['p'])))==8 and abs(sum(x['planned_received'] for x in e.pipeline(base['p']))-25e6)<.005)
test('G02 cinco parcelas somam5M',sum(x['planned_received'] for x in e.pipeline(base['p']) if x['code']=='G02')==5e6)
test('Mínimo/intermédio/máximo por fórmula',[sum(n*t*r for n,t,r in zip(e.COUNTS,e.TICKETS,rates)) for rates in e.RATES]==[3e6,3575000.,4150000.])
case_results=[]
for name,params,_ in CASES:
 rr=e.run(e.config(**params));mm=e.results(rr);f=rr['flow'];paid=[x['m'] for x in f if x['dividend']>.005]
 test(name+': calendário',all(m>=54 and (m-54)%12==0 for m in paid))
 test(name+': caixa/reconciliação',max(abs(x['cash_check']) for x in f)<.005 and max(abs(x['debt_check']) for x in f)<.005)
 test(name+': dividendos protegem reservas',all(x['dividend']<.005 or x['cash']>=x['reserve']+x['forward']+params.get('extra_reserves',{}).get(x['m'],0)-.005 for x in f))
 test(name+': limite de lucros e caixa',all(x['dividend']<=x['div_metrics']['independent']+.005 for x in f))
 if params.get('div_basis','Geração 12M')=='Geração 12M':test(name+': cobertura1,20x',all(x['dividend']<.005 or x['div_metrics']['coverage_ratio']>=1.2-1e-9 for x in f))
 test(name+': saída proporcional',abs(sum(v[-1]+sum(x['planned_received'] for x in e.pipeline(rr['p']) if x['code']==code and x['pay_month']==180) for code,v in mm['block_cf'].items())-mm['exit_equity']*.5)<.01)
 case_results.append({'case':name,'params':params,'metrics':{k:v for k,v in mm.items() if k not in ['block_cf','new_cf']}})
test('M54 parcial',0<metrics['div54']<3e6)
test('M54 acumulados máximo',abs(e.results(e.run(e.config(div_basis='Acumulados',div_tier='Máximo')))['div54']-4150000)<.005)
test('M54 mínimo faltante não vira dívida',not any('dividend_arrears' in x for x in base['flow']))
test('Sem pagamento efetivo inventado',all(x['div_metrics']['actual_documented'] is None and x['div_metrics']['approved_documented']==0 for x in base['flow']))
# New counts propagate to benefit costs; not a zero-cost-only test.
rr=e.run(e.config(benefit_platinum=12000,benefit_gold=8000,benefit_silver=4000));plain=e.run(e.config());diff=plain['hotel'][53]['ebitda']-rr['hotel'][53]['ebitda'];test('Benefícios3P2G10S',abs(diff-(3*12000+2*8000+10*4000)/12)<.005)
# Conditional documentation is distinct from actual paid input.
rr=e.run(e.config(document_caps={54:1e6},approvals={54:1},actual_payments={54:500000}));d=rr['flow'][53]['div_metrics'];test('Simulado/aprovado/pago separados',d['financial_dividend']>d['approved_documented'] and d['approved_documented']==1e6 and d['actual_documented']==500000)
# Frozen bridge: old allocations are counterfactual only, never the V05 operative policy.
def bridge_metrics(f,newreceived,ev,eq,divs):
 cf=[0]+[n-e.investor_outlay(base['p'],x['m']) for x,n in zip(f,newreceived)]
 return {'cash30':f[29]['cash'],'cash42':f[41]['cash'],'cash54':f[53]['cash'],'div54':f[53]['dividend'],'cash_end':f[-1]['cash'],'dividends':divs,'ev':ev,'exit_equity':eq,'new_irr':e.v4.irr(cf),'new_moic':sum(newreceived)/25e6,'new_npv':sum(v/(1+.12)**(i/12) for i,v in enumerate(cf))}
os=e.v4.summary(old);oldreceived=[x['new_received'] for x in oldsel['rows']];bridge=[{'stage':'0 — V04 Fixed','basis':'Referência original; políticaV04 e9x',**bridge_metrics(old['flow'],oldreceived,os['ev'],os['exit_equity'],os['dividends'])}]
old_exits=[sum(x['exit'][k] for x in oldsel['rows']) for k in range(3)];oldweights=[x/os['exit_equity'] for x in old_exits]
# Cap-table-only attribution holds V04 class pools fixed. It is NOT an approved distribution rule.
newmix=lambda a:a[0]/3+a[1]+a[2]/2
s1=[newmix(x['dividends'])+newmix(x['exit']) for x in oldsel['rows']]
bridge.append({'stage':'1 — Alterar composição dos blocos','basis':'Contrafactual: piscinas de classeV04 fixas apenas para medir composição; nunca usados naV05',**bridge_metrics(old['flow'],s1,os['ev'],os['exit_equity'],os['dividends'])})
r9=e.run(e.config(exit_mult=9));m9=e.results(r9);newdivs=[newmix([x['dividend']*w for w in x['div_metrics']['weights']]) for x in r9['flow']];s2=newdivs.copy();s2[-1]+=m9['exit_equity']*newmix(oldweights)
bridge.append({'stage':'2 — Dividendos progressivos M54','basis':'Nova política/calendário;9x; alocação antiga de saída mantida só como contrafactual de atribuição',**bridge_metrics(r9['flow'],s2,m9['ev'],m9['exit_equity'],m9['dividends'])})
s3=newdivs.copy();s3[-1]+=m9['exit_equity']*.5
bridge.append({'stage':'3 — Saída proporcional','basis':'50% saída novos; sem preferências; múltiplo9x apenas para isolar efeito de repartição',**bridge_metrics(r9['flow'],s3,m9['ev'],m9['exit_equity'],m9['dividends'])})
bridge.append({'stage':'4 — Saída Base12x (V05)','basis':'Configuração financeiraV05 de referência',**{k:metrics[k] for k in bridge[0] if k not in ['stage','basis']}})
for i,x in enumerate(bridge):
 if i:x['delta']={k:x[k]-bridge[i-1][k] for k in bridge[0] if k not in ['stage','basis'] and isinstance(x.get(k),(int,float)) and isinstance(bridge[i-1].get(k),(int,float))}
(R/'entrega/Ponte_Impactos_V04_V05.json').write_text(json.dumps(bridge,ensure_ascii=False,indent=2))
(R/'entrega/Cenarios_Python_Fase2.json').write_text(json.dumps(case_results,ensure_ascii=False,indent=2))
report={'ok':all(x['ok'] for x in tests),'tests':len(tests),'failures':[x for x in tests if not x['ok']],'results':tests};(R/'entrega/Testes_Python_Fase2.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='results'},ensure_ascii=False,indent=2));raise SystemExit(not report['ok'])
