from pathlib import Path
import zipfile,hashlib,json,shutil,fitz
R=Path(__file__).resolve().parents[1];O=R/'entrega';D=Path('/workspace/SIM-JSCV-KYENU/entregas/V04_Excel_Fix')
main=['KK01_Modelo_Integrado_V04_Excel_Fix.xlsx','KK01_Relatorio_Tecnico_V04_Excel_Fix.pdf','KK01_Relatorio_Tecnico_V04_Excel_Fix.md']
for n in ['Testes_Seletores','Testes_Riscos_Integrados','Testes_Retornos_Completion','Testes_Executive_Excel_Fix']:
 a=json.loads((O/(n+'.json')).read_text());assert a and all(x['ok'] for x in a),n
for n in ['Testes_Estruturais_V04','Testes_Integridade_Excel_Fix']:
 a=json.loads((O/(n+'.json')).read_text());assert a['failed']==0,n
for n in ['Testes_Fase1','Testes_Fases23']:
 a=json.loads((O/(n+'.json')).read_text());assert a['tests']>0 and a['failures']==a['errors']==0,n
for n in ['Reconciliacao_Integral_Original','Verificacao_Reabertura_V04']:assert json.loads((O/(n+'.json')).read_text())['ok'],n
assert all((O/n).is_file() and 0<(O/n).stat().st_size<40000000 for n in main)
assert not json.loads((O/'Ambiente_Validacao.json').read_text())['excel_desktop_tested']
doc=fitz.open(O/main[1]);assert len(doc)>0 and 'Não existe Microsoft Excel Desktop' in doc[0].get_text();doc.close()
records=['Inventario_Compatibilidade.json','SUMPRODUCT_shapes.json','Formulas_Corrigidas.json','Formulas_Corrigidas.csv','Formulas_Auxiliares.json','Resumo_Correcao.json','Rastreio_Dependencias_KPI_B14.json','Reconciliacao_Integral_Original.json','Ambiente_Validacao.json','Testes_Fase1.json','Testes_Fase1.txt','Testes_Fases23.json','Testes_Fases23.txt','Testes_Seletores.json','Testes_Riscos_Integrados.json','Testes_Retornos_Completion.json','Testes_Executive_Excel_Fix.json','Testes_Estruturais_V04.json','Testes_Integridade_Excel_Fix.json','Verificacao_Reabertura_V04.json','Verificacao_Relatorio_Excel_Fix.json']
code=['compat_patch.py','fix_metadata.py','trace_compat.py','merge_recalculated_caches.py','test_compatibility_integrity.py','test_executive_fix.py','report_excel_fix.py','package_excel_fix.py','engine.py','waterfall.py','completion.py','selected_policy.py','test_phase1.py','test_phase23.py','test_selectors.py','audit_risks.py','audit_returns_v04.py','test_structure_v04.py','verify_reopen_v04.py']
data=['source.json','build_metadata.json','v04_risk_metadata.json','v04_risk_results.json','v04_kpi_dictionary.json']
originals=[R/'original/KK01_Modelo_Integrado_V04_Recebido.xlsx',R/'original/KK01_Modelo_Integrado_V03.xlsx',R/'original/Manifesto_Base_V03.json',R/'original/v03/src/engine.py',R/'original/v03/src/source.json']
files=[O/n for n in main+records]+[R/'src'/n for n in code+data]+originals+[R/'README.md',R/'requirements.txt'];assert all(p.is_file() for p in files)
manifest={str(p.relative_to(R)):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files};m=O/'Manifesto_Conteudo_Excel_Fix.json';m.write_text(json.dumps(manifest,ensure_ascii=False,indent=2));files.append(m);archive=O/'KK01_V04_Excel_Fix_Pacote_Completo.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in files:z.write(p,'kk01_v04_excel_fix/'+str(p.relative_to(R)))
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
assert archive.stat().st_size<40000000,archive.stat().st_size
pub=main+[archive.name];manifest={n:{'bytes':(O/n).stat().st_size,'sha256':hashlib.sha256((O/n).read_bytes()).hexdigest()} for n in pub};mf=O/'Manifesto_SHA256_Excel_Fix.json';mf.write_text(json.dumps(manifest,indent=2));D.mkdir(parents=True,exist_ok=True)
for name in pub+[mf.name]:shutil.copy2(O/name,D/name)
shutil.copy2(R/'README.md',D/'README.md')
print('Pacote',archive.stat().st_size,'bytes;',len(files),'ficheiros; publicação preparada em',D)
