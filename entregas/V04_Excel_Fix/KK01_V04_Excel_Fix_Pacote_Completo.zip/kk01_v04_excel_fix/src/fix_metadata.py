from pathlib import Path
import zipfile,xml.etree.ElementTree as E,re,json,html,os
R=Path(__file__).resolve().parents[1];P=R/'entrega/KK01_Modelo_Integrado_V04_Excel_Fix.xlsx';N='{http://schemas.openxmlformats.org/spreadsheetml/2006/main}';RID='{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id';edits=json.loads((R/'entrega/Formulas_Corrigidas.json').read_text());updates={x['cell']:x for x in edits if x['sheet']=='KPI'};D=json.loads((R/'src/v04_kpi_dictionary.json').read_text());dictionary={}
for i,d in enumerate(D,5):
 for addr,item in updates.items():
  if item['old'] in d['formula'] or item['new'] in d['formula']:d['formula']=d['formula'].replace(item['old'],item['new']);dictionary['H'+str(i)]=d['formula']
(R/'src/v04_kpi_dictionary.json').write_text(json.dumps(D,ensure_ascii=False,indent=2))
with zipfile.ZipFile(P) as zi,zipfile.ZipFile(P.with_suffix('.meta'),'w',zipfile.ZIP_DEFLATED,compresslevel=6) as zo:
 wb=E.fromstring(zi.read('xl/workbook.xml'));rels={x.attrib['Id']:x.attrib['Target'] for x in E.fromstring(zi.read('xl/_rels/workbook.xml.rels'))};names={}
 for s in wb.find(N+'sheets'):
  t=rels[s.attrib[RID]];names[t.lstrip('/') if t.startswith('/') else 'xl/'+t]=s.attrib['name']
 for inf in zi.infolist():
  data=zi.read(inf.filename)
  if inf.filename in names:
   s=names[inf.filename];text=data.decode()
   if 'r="BD184"' in text:text=re.sub(r'(<dimension\b[^>]*ref="[A-Z]+\d+:)[A-Z]+(\d+")',lambda m:m[1]+'BD'+m[2],text,count=1)
   elif 'r="AC98"' in text and (s=='Residencial' or s.endswith('Resid') or s.startswith('CalcA')):text=re.sub(r'(<dimension\b[^>]*ref="[A-Z]+\d+:)[A-Z]+(\d+")',lambda m:m[1]+'AC'+m[2],text,count=1)
   if s=='V04 Dicionario KPI':
    for addr,value in dictionary.items():
     pat=r'<c\b([^>]*\br="'+addr+r'"[^>]*)>.*?</c>';m=re.search(pat,text);assert m
     attr=re.sub(r'\s+t="[^"]*"','',m[1]);text=text[:m.start()]+'<c'+attr+' t="inlineStr"><is><t>'+html.escape(value,quote=False)+'</t></is></c>'+text[m.end():]
   data=text.encode()
  zo.writestr(inf,data)
os.replace(P.with_suffix('.meta'),P);print('Dimensões e fórmulas do dicionário atualizadas.')
