"""Keep the patched original OOXML/presentation; transfer only validated formula caches.
Every formula remains a formula. Excel must rebuild its calculation graph on opening.
"""
from pathlib import Path
import zipfile,xml.etree.ElementTree as E,re,json,html,os,hashlib,math
R=Path(__file__).resolve().parents[1];P=R/'entrega/KK01_Modelo_Integrado_V04_Excel_Fix.xlsx';Q=R/'validacao/V04_Final/out/V04_Final.xlsx';O=R/'original/KK01_Modelo_Integrado_V04_Recebido.xlsx';N='{http://schemas.openxmlformats.org/spreadsheetml/2006/main}';RID='{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id'
def paths(z):
 wb=E.fromstring(z.read('xl/workbook.xml'));rels={x.attrib['Id']:x.attrib['Target'] for x in E.fromstring(z.read('xl/_rels/workbook.xml.rels'))};return {s.attrib['name']:(rels[s.attrib[RID]].lstrip('/') if rels[s.attrib[RID]].startswith('/') else 'xl/'+rels[s.attrib[RID]]) for s in wb.find(N+'sheets')}
count=0;numeric=0;failure=[];per_sheet=[];formula_hash=hashlib.sha256();formula_hash_after=hashlib.sha256()
with zipfile.ZipFile(P) as zi,zipfile.ZipFile(Q) as zr,zipfile.ZipFile(O) as original,zipfile.ZipFile(P.with_suffix('.cached'),'w',zipfile.ZIP_DEFLATED,compresslevel=6) as zo:
 pi=paths(zi);pr=paths(zr);po=paths(original);names={v:k for k,v in pi.items()}
 for inf in zi.infolist():
  data=zi.read(inf.filename)
  if inf.filename in names:
   sn=names[inf.filename];x=E.fromstring(zr.read(pr[sn]));cache={c.attrib['r']:(c.attrib.get('t','n'),c.find(N+'v').text if c.find(N+'v') is not None else None,c.find(N+'f') is not None) for c in x.iter(N+'c')};original_values={}
   for c in E.fromstring(original.read(po[sn])).iter(N+'c'):
    v=c.find(N+'v')
    if c.attrib.get('t','n') in ['n','b'] and v is not None and v.text is not None:
     try:original_values[c.attrib['r']]=float(v.text)
     except ValueError:pass
   for addr,value in original_values.items():
    val=cache.get(addr)
    if val is None or val[0] not in ['n','b'] or val[1] is None:failure.append((sn,addr,value,val));continue
    actual=float(val[1]);numeric+=1
    if not math.isfinite(actual) or abs(value-actual)>max(1e-8,abs(value)*1e-10):failure.append((sn,addr,value,actual))
   sheet_count=[0]
   def update(m):
    global count
    full=m.group();fm=re.search(r'<f(?:\s[^>]*)?>.*?</f>',full,re.S)
    if not fm:return full
    addr=m[1];assert addr in cache,(sn,addr);t,value,is_formula=cache[addr];assert is_formula,(sn,addr);assert t!='e',(sn,addr,value)
    key=(sn+'!'+addr+'\0'+fm.group()).encode();formula_hash.update(key);count+=1;sheet_count[0]+=1
    full=re.sub(r'<v(?:\s[^>]*)?>.*?</v>|<v\s*/>','',full,flags=re.S);start=full[:full.index('>')];start=re.sub(r'\s+t="[^"]*"','',start);start+=' t="'+t+'"';full=start+full[full.index('>'):]
    val='<v>'+html.escape(value or '',quote=False)+'</v>';result=full[:-4]+val+'</c>';af=re.search(r'<f(?:\s[^>]*)?>.*?</f>',result,re.S).group();formula_hash_after.update((sn+'!'+addr+'\0'+af).encode());return result
   text=data.decode();text=re.sub(r'<c\b[^>]*\br="([A-Z]+\d+)"[^>]*(?<!/)>.*?</c>',update,text,flags=re.S);data=text.encode();per_sheet.append({'sheet':sn,'formula_caches':sheet_count[0]})
  zo.writestr(inf,data)
 assert not failure, failure[:12]
 assert formula_hash.hexdigest()==formula_hash_after.hexdigest()
os.replace(P.with_suffix('.cached'),P)
report={'ok':not failure,'formula_caches_updated':count,'original_numeric_cells_compared':numeric,'numeric_failures':failure,'formula_fingerprint':formula_hash.hexdigest(),'formulas_preserved':True,'presentation_not_resaved_by_libreoffice':True,'sheets':per_sheet};(R/'entrega/Reconciliacao_Integral_Original.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print({k:v for k,v in report.items() if k!='sheets'},flush=True)
