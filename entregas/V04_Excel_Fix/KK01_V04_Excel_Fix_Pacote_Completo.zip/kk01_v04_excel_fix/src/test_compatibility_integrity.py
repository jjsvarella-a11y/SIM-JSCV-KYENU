"""Structural/economic invariants specific to the compatibility fix, independent of LO save."""
from pathlib import Path
import zipfile,xml.etree.ElementTree as E,json,hashlib,collections,re,openpyxl
R=Path(__file__).resolve().parents[1];P=R/'entrega/KK01_Modelo_Integrado_V04_Excel_Fix.xlsx';O=R/'original/KK01_Modelo_Integrado_V04_Recebido.xlsx';N='{http://schemas.openxmlformats.org/spreadsheetml/2006/main}';RID='{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id';checks=[]
def check(label,ok,details=None):checks.append({'check':label,'ok':bool(ok),'details':details})
def paths(z):
 w=E.fromstring(z.read('xl/workbook.xml'));r={x.attrib['Id']:x.attrib['Target'] for x in E.fromstring(z.read('xl/_rels/workbook.xml.rels'))};return {s.attrib['name']:(r[s.attrib[RID]].lstrip('/') if r[s.attrib[RID]].startswith('/') else 'xl/'+r[s.attrib[RID]]) for s in w.find(N+'sheets')}
changes=json.loads((R/'entrega/Formulas_Corrigidas.json').read_text());newcells=json.loads((R/'entrega/Formulas_Auxiliares.json').read_text());expected={(x['sheet'],x['cell']):x for x in changes};added={(x['sheet'],x['cell']):x for x in newcells};invalid=[];inputs=[];missing=[];presentation=[];errors=[];count=0;countoriginal=0;hidden=[]
with zipfile.ZipFile(O) as old,zipfile.ZipFile(P) as new:
 check('ZIP CRC válido',new.testzip() is None);po=paths(old);pn=paths(new);check('313 folhas; mesmos nomes e ordem',list(po)==list(pn) and len(po)==313)
 parts=[n for n in old.namelist() if n.startswith(('xl/charts/','xl/media/','xl/drawings/','xl/comments','xl/tables/')) or n in ['xl/styles.xml','xl/sharedStrings.xml','xl/_rels/workbook.xml.rels']]
 check('Gráficos,imagens,notas,estilos,tabelas e relações byte-idênticos',all(old.read(n)==new.read(n) for n in parts),len(parts))
 for sn,path in po.items():
  a=E.fromstring(old.read(path));b=E.fromstring(new.read(pn[sn]));ca={c.attrib['r']:c for c in a.iter(N+'c')};cb={c.attrib['r']:c for c in b.iter(N+'c')};cols=b.find(N+'cols')
  for addr,c in ca.items():
   f=c.find(N+'f');d=cb.get(addr)
   if d is None:missing.append((sn,addr));continue
   if f is not None:
    countoriginal+=1;g=d.find(N+'f');wanted=expected.get((sn,addr),{}).get('new',f.text)
    if g is None or g.text!=wanted:invalid.append((sn,addr,'formula'))
   else:
    if sn=='V04 Dicionario KPI' and addr.startswith('H'):continue
    if E.tostring(c)!=E.tostring(d):inputs.append((sn,addr))
  for addr,c in cb.items():
   f=c.find(N+'f')
   if f is not None:
    count+=1
    if len(f.text or '')>8192:invalid.append((sn,addr,'8192length'))
    if '_xlfn.' in (f.text or ''):invalid.append((sn,addr,'future function'))
    if c.attrib.get('t')=='e':errors.append((sn,addr))
   if addr not in ca:
    rule=added.get((sn,addr))
    if rule is None or f is None or f.text!=rule['formula']:invalid.append((sn,addr,'unexpected addition'))
    if rule is not None:
     cc=re.match(r'[A-Z]+',addr).group();idx=0
     for char in cc:idx=idx*26+ord(char)-64
     if not any(int(x.attrib['min'])<=idx<=int(x.attrib['max']) and x.attrib.get('hidden')=='1' for x in cols):hidden.append((sn,addr))
  for tag in ['hyperlinks','dataValidations','mergeCells','autoFilter','tableParts','drawing','legacyDrawing','sheetViews','pageMargins','pageSetup','printOptions','headerFooter','sheetProtection']:
   aa=a.find(N+tag);bb=b.find(N+tag)
   if (E.tostring(aa) if aa is not None else None)!=(E.tostring(bb) if bb is not None else None):presentation.append((sn,tag))
 check('Todas as fórmulas originais preservadas ou corrigidas conforme registo',not invalid,invalid[:8]);check('Nenhuma entrada ou pressuposto alterado',not inputs,inputs[:8]);check('Nenhuma célula original removida',not missing,missing[:8]);check('Todos os auxiliares técnicos ocultos',not hidden,len(added));check('Hyperlinks,seletores,filtros,merges e impressão preservados',not presentation,presentation[:8]);check('Sem erros armazenados',not errors,errors[:8]);check('Contagem de fórmulas reconciliada',countoriginal==1469149 and count==countoriginal+len(added),{'original':countoriginal,'final':count,'added':len(added)});check('Não há IFERROR novo a esconder erros',all(x['new'].count('IFERROR(')<=x['old'].count('IFERROR(') for x in changes))
 cp=E.fromstring(new.read('xl/workbook.xml')).find(N+'calcPr');check('Recálculo automático,integral e sem iteração',cp.attrib.get('calcMode')=='auto' and cp.attrib.get('forceFullCalc')=='1' and cp.attrib.get('fullCalcOnLoad')=='1' and cp.attrib.get('iterate')=='false');check('Sem macros ou vínculos externos',not any('vbaProject' in n or n.startswith('xl/externalLinks/') for n in new.namelist()))
check('Original do utilizador preservado por SHA256',hashlib.sha256(O.read_bytes()).hexdigest()=='b812f5b34be8f81575b227295738fe1a8005c8cc21c347d1d678870ed62fc0e2');numeric=json.loads((R/'entrega/Reconciliacao_Integral_Original.json').read_text());check('Reconciliação integral dos números da V04 original',numeric['ok'] and numeric['original_numeric_cells_compared']>1400000,numeric['original_numeric_cells_compared']);check('Ficheiro inferior a40MB',P.stat().st_size<40000000,P.stat().st_size)
w=openpyxl.load_workbook(P,read_only=True,data_only=False);check('KPI!B14 usa um intervalo de somas mensais',w['KPI']['B14'].value=="=MAX('Fluxo 180M'!$BD$5:$BD$184)");check('Origem residencial usa COUNTIFS/SUMIFS escalares','COUNTIFS(' in w['Residencial']['D5'].value and 'SUMIFS(' in w['Residencial']['L5'].value);w.close()
out={'passed':sum(x['ok'] for x in checks),'failed':sum(not x['ok'] for x in checks),'checks':checks};(R/'entrega/Testes_Integridade_Excel_Fix.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print(json.dumps(out,ensure_ascii=False,indent=2));raise SystemExit(out['failed']>0)
