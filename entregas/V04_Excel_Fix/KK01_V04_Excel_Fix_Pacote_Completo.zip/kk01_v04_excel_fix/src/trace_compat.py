"""Static dependency trace. Does not claim to reproduce Microsoft Excel errors."""
from pathlib import Path
import zipfile,xml.etree.ElementTree as E,re,json,collections
R=Path(__file__).resolve().parents[1];P=R/'original/KK01_Modelo_Integrado_V04_Recebido.xlsx';N='{http://schemas.openxmlformats.org/spreadsheetml/2006/main}';RID='{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id'
PAT=re.compile(r"(?<![A-Za-z0-9_.])(?:(?P<sheet>'(?:[^']|'')+'|[A-Za-zÀ-ÿ_][A-Za-zÀ-ÿ_0-9 ]*)!)?(?P<c1>\$?[A-Z]{1,3})(?P<r1>\$?\d+)(?::(?P<c2>\$?[A-Z]{1,3})(?P<r2>\$?\d+))?(?![A-Za-z0-9_(])")
def ci(s):
 n=0
 for x in s.replace('$',''):n=n*26+ord(x)-64
 return n

def cl(n):
 s=''
 while n:n,x=divmod(n-1,26);s=chr(65+x)+s
 return s

with zipfile.ZipFile(P) as z:
 wb=E.fromstring(z.read('xl/workbook.xml'));rels={x.attrib['Id']:x.attrib['Target'] for x in E.fromstring(z.read('xl/_rels/workbook.xml.rels'))};paths={};cache={}
 for s in wb.find(N+'sheets'):
  t=rels[s.attrib[RID]];paths[s.attrib['name']]=t.lstrip('/') if t.startswith('/') else 'xl/'+t
 def cells(sn):
  if sn not in cache:
   x=E.fromstring(z.read(paths[sn]));cache[sn]={c.attrib['r']:(c.find(N+'f').text if c.find(N+'f') is not None else None,c.attrib.get('t'),c.find(N+'v').text if c.find(N+'v') is not None else None) for c in x.iter(N+'c')}
  return cache[sn]
 def deps(sn,formula):
  text=re.sub(r'"(?:[^"]|"")*"','""',formula or '')
  result=[]
  for m in PAT.finditer(text):
   sh=(m['sheet'] or sn).strip("'").replace("''", "'");r1=int(m['r1'].replace('$',''));r2=int((m['r2'] or m['r1']).replace('$',''));c1=ci(m['c1']);c2=ci(m['c2'] or m['c1'])
   if sh not in paths:continue
   for rr in range(r1,r2+1):
    for cc in range(c1,c2+1):result.append((sh,cl(cc)+str(rr)))
  return list(dict.fromkeys(result))
 root=('KPI','B14');queue=collections.deque([root]);parents={root:None};candidates=[];cached_errors=[];edges=0;formulas=0
 while queue:
  node=queue.popleft();sn,addr=node;f,t,v=cells(sn).get(addr,(None,None,None))
  if t=='e':cached_errors.append((sn,addr,v))
  if not f:continue
  formulas+=1
  if 'SUMPRODUCT' in f and ('IF(' in f[f.find('SUMPRODUCT'):] or ',0,' in f[f.find('SUMPRODUCT'):]):
   chain=[];x=node
   while x is not None:chain.append('!'.join(x));x=parents[x]
   candidates.append({'cell':'!'.join(node),'formula':f,'path_from_KPI_B14':list(reversed(chain)),'status':'Risco de contexto matricial; não confirmado no Excel Desktop'})
  for dep in deps(sn,f):
   edges+=1
   if dep not in parents:parents[dep]=node;queue.append(dep)
 result={'reported_cell':'KPI!B14','reported_error':'#VALOR! no Microsoft Excel','cached_error_cells':cached_errors,'visited_cells':len(parents),'formula_cells':formulas,'reference_edges_expanded':edges,'matrix_context_candidates':candidates,'cached_errors_reproduced_in_attachment':bool(cached_errors),'note':'O anexo é idêntico à V04 publicada e contém caches válidas. As primeiras células com erro em Excel não podem ser confirmadas sem recálculo no Microsoft Excel. Os caminhos listados identificam origens estruturais candidatas e não erros armazenados.'}
 (R/'entrega/Rastreio_Dependencias_KPI_B14.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print({k:v for k,v in result.items() if k!='matrix_context_candidates'});print('candidate_count',len(candidates));print('paths',[(x['cell'],x['path_from_KPI_B14']) for x in candidates[:5]])
