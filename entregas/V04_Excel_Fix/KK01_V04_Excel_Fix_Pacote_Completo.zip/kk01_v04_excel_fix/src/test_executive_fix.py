"""Direct check of reported KPI!B14 and each numeric Executive card, against Python."""
from engine import *
from selected_policy import selected
import openpyxl

def audit(path,params):
 r=run(config(**params));p=r['p'];s=selected(r);w=openpyxl.load_workbook(path,read_only=True,data_only=True);annual=summary(r)['annual'];partial=math.ceil(p['open']/12)-1;full=math.ceil((p['open']+11)/12)-1
 expected={'A7':sum(x['equity'] for x in r['flow']),'E7':economic_share(p,180),'I7':max(x['debt_open']+x['draw'] for x in r['flow']),'M7':r['flow'][-1]['cumulative'],'A12':min(x['cash'] for x in r['flow']),'E12':r['flow'][29]['debt'],'I12':sum(x['interest'] for x in r['flow']),'M12':annual[partial]['dscr'],'A17':sum(x['ebitda'] for x in r['hotel'][p['open']+11:p['open']+23]),'E17':s['metrics']['new_irr'],'I17':s['metrics']['new_moic'],'M17':s['metrics']['new_npv']};values={c.coordinate:c.value for row in w['EXEC KK01'].iter_rows(max_row=17,max_col=13) for c in row if hasattr(c,'coordinate')};fails=[]
 for addr,v in expected.items():
  a=values[addr]
  if v is None:
   if isinstance(a,(int,float)):fails.append((addr,a,v))
  elif not isinstance(a,(int,float)) or abs(a-v)>max(1e-7,abs(v)*1e-9):fails.append((addr,a,v))
 a=w['KPI']['B14'].value;v=expected['I7']
 if not isinstance(a,(int,float)) or abs(a-v)>max(1e-7,abs(v)*1e-9):fails.append(('KPI!B14',a,v))
 ratios=[x['dscr'] for x in annual[full:] if x['dscr'] is not None];v=min(ratios) if ratios else None;a=w['KPI']['B34'].value
 if (v is None and isinstance(a,(int,float))) or (v is not None and (not isinstance(a,(int,float)) or abs(a-v)>max(1e-7,abs(v)*1e-9))):fails.append(('KPI!B34',a,v))
 w.close();return {'case':path.stem,'ok':not fails,'comparisons':14,'failures':fails,'reported_kpi_peak':values['I7']}
if __name__=='__main__':
 cases=json.loads((ROOT/'entrega/Testes_Seletores.json').read_text());out=[audit(Path(x['output']),x['params']) for x in cases];(ROOT/'entrega/Testes_Executive_Excel_Fix.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print(json.dumps(out,ensure_ascii=False,indent=2));raise SystemExit(not all(x['ok'] for x in out))
