"""Minimal, reversible formula hardening; no changes to inputs/economic parameters.
Scalar technical columns stay hidden in existing sheets. All source changes logged.
"""
from pathlib import Path
import zipfile,xml.etree.ElementTree as E,re,json,hashlib,html,os,collections
ROOT=Path(__file__).resolve().parents[1];SOURCE=ROOT/'original/KK01_Modelo_Integrado_V04_Recebido.xlsx';OUT=ROOT/'entrega/KK01_Modelo_Integrado_V04_Excel_Fix.xlsx';N='http://schemas.openxmlformats.org/spreadsheetml/2006/main';T=lambda x:'{'+N+'}'+x;RID='{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id'
def args(s):
 result=[];start=0;depth=0;dq=False;sq=False;i=0
 while i<len(s):
  c=s[i]
  if c=='"' and not sq:
   if dq and i+1<len(s) and s[i+1]=='"':i+=2;continue
   dq=not dq
  if c=="'" and not dq:sq=not sq
  if not dq and not sq:
   if c=='(':depth+=1
   elif c==')':depth-=1
   elif c==',' and depth==0:result.append(s[start:i]);start=i+1
  i+=1
 result.append(s[start:]);return result

def calls(s,name):
 pat=re.compile(r'(?<![\w.])'+re.escape(name)+r'\(',re.I);pos=0
 while (m:=pat.search(s,pos)):
  depth=1;i=m.end();dq=False;sq=False
  while i<len(s) and depth:
   c=s[i]
   if c=='"' and not sq:dq=not dq
   if c=="'" and not dq:sq=not sq
   if not dq and not sq:
    if c=='(':depth+=1
    elif c==')':depth-=1
   i+=1
  assert depth==0,(name,s)
  yield m.start(),i,args(s[m.end():i-1]);pos=i

def strip(s):
 while s.startswith('(') and s.endswith(')'):
  d=0;complete=True
  for i,c in enumerate(s):
   d+=1 if c=='(' else -1 if c==')' else 0
   if d==0 and i<len(s)-1:complete=False;break
  if not complete:break
  s=s[1:-1]
 return s

def comparison(s):
 s=strip(s.removeprefix('--'));d=0;quoted=False
 for i,c in enumerate(s):
  if c=='"':quoted=not quoted
  if quoted:continue
  if c=='(':d+=1
  elif c==')':d-=1
  if d==0 and s[i:i+2]=='<=':return strip(s[:i]),strip(s[i+2:])
 raise ValueError(s)

changes=[];added=[];classes=collections.Counter();helpers={};pathnames={};roots={};oldhash=hashlib.sha256(SOURCE.read_bytes()).hexdigest()
def log(sn,addr,old,new,reason):
 if old!=new:changes.append({'sheet':sn,'cell':addr,'old':old,'new':new,'reason':reason});classes[reason]+=1

def ref_endpoints(index):
 a=args(index[6:-1])
 if len(a)!=3 or a[1].strip()!='0':return index
 m=re.fullmatch(r'(.+!)?(\$?[A-Z]+)\$?(\d+):(\$?[A-Z]+)\$?(\d+)',a[0]);assert m,index
 height=int(m[5])-int(m[3])+1
 return f'INDEX({a[0]},1,{a[2]}):INDEX({a[0]},{height},{a[2]})'

with zipfile.ZipFile(SOURCE) as zi:
 wb=E.fromstring(zi.read('xl/workbook.xml'));rels={r.attrib['Id']:r.attrib['Target'] for r in E.fromstring(zi.read('xl/_rels/workbook.xml.rels'))}
 for sn in wb.find(T('sheets')):
  target=rels[sn.attrib[RID]];path=target.lstrip('/') if target.startswith('/') else 'xl/'+target;pathnames[path]=sn.attrib['name']
 # Find scalar technical helpers needed by peak metrics; do not store all1.47Mformula trees.
 peaks={}
 for path,sn in pathnames.items():
  if sn not in ['KPI','Comparacao','V04 Riscos'] and not sn.startswith('CalcF') and not sn.startswith('V04'):continue
  raw=zi.read(path)
  if b'MAX(' not in raw:continue
  for cm in re.finditer(rb'<c\b[^>]*\br="([A-Z]+\d+)"[^>]*(?<!/)>(.*?)</c>',raw,re.S):
   fm=re.search(rb'<f(?:\s[^>]*)?>(.*?)</f>',cm[2],re.S)
   if not fm:continue
   f=html.unescape(fm[1].decode())
   for st,en,aa in calls(f,'MAX'):
    if len(aa)!=180:continue
    parsed=[re.fullmatch(r"('(?:[^']|'')+'|[A-Za-z0-9_ ]+)!\$?O(\d+)\+\1!\$?X\2",s) for s in aa]
    if not all(parsed) or [int(m[2]) for m in parsed]!=list(range(5,185)):continue
    fs=parsed[0][1].strip("'").replace("''", "'");peaks[(sn,cm[1].decode())]=(f[st:en],fs)
 for old,fs in peaks.values():helpers[fs]='peak'
 print('Peak expressions',len(peaks),'flow sheets',len(helpers),flush=True)
 with zipfile.ZipFile(OUT,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as zo:
  for inf in zi.infolist():
   data=zi.read(inf.filename)
   if inf.filename in pathnames:
    sn=pathnames[inf.filename];text=data.decode();extras={};changed=False
    # Scalar per-fraction dates replace IF(range) inside unmarked SUMPRODUCTs.
    is_res=sn=='Residencial' or sn.endswith('Resid') or sn.startswith('CalcA')
    if is_res:
     xm=E.fromstring(data);cells={c.attrib['r']:c for c in xm.iter(T('c'))};d=cells['D5'].find(T('f')).text;dc=next(calls(d,'SUMPRODUCT'));deed,month=comparison(dc[2][0]);sale,stop=comparison(dc[2][1]);assert month=='A5'
     for rr in range(5,99):
      for cc,formula in [('AA',sale),('AB',deed),('AC','Unidades!$H$5:$H$98')]:
       formula=re.sub(r'(?P<sh>Unidades!)\$(?P<c>[A-Z]+)\$5:\$(?P=c)\$98',lambda m:m['sh']+'$'+m['c']+'$'+str(rr),formula);assert ':$' not in formula,formula
       extras[cc+str(rr)]=formula;added.append({'sheet':sn,'cell':cc+str(rr),'formula':formula,'reason':'scalar_dates'})
    def cell_replace(m):
     global changed
     full=m.group();addr=m.group(1);fm=re.search(r'<f(?:\s[^>]*)?>(.*?)</f>',full,re.S)
     if not fm:return full
     f=html.unescape(fm[1]);new=f;why=[]
     if is_res and addr[0] in ['D','L'] and re.fullmatch(r'[DL]\d+',addr) and 5<=int(addr[1:])<=184:
      entries=list(calls(new,'SUMPRODUCT'))
      if entries:
       st,en,a=entries[0];mm='A'+addr[1:];replacement=f'COUNTIFS($AB$5:$AB$98,"<="&{mm},$AA$5:$AA$98,"<="&{stop})' if addr[0]=='D' else f'SUMIFS($AC$5:$AC$98,$AB$5:$AB$98,"<="&{mm},$AA$5:$AA$98,"<="&{stop})'
       new=new[:st]+replacement+new[en:];why.append('scalar_residential')
     # INDEX(...,0,column) is replaced by an explicit reference with two scalar endpoints.
     if 'SUMPRODUCT' in new and 'INDEX(' in new:
      for st,en,a in reversed(list(calls(new,'SUMPRODUCT'))):
       part=new[st:en];pp=part
       for i,j,ia in reversed(list(calls(part,'INDEX'))):
        if len(ia)==3 and ia[1].strip()=='0':part=part[:i]+ref_endpoints(part[i:j])+part[j:]
       if part!=pp:new=new[:st]+part+new[en:];why.append('explicit_index_range')
     if (sn,addr) in peaks:
      old,fs=peaks[(sn,addr)];new=new.replace(old,f"MAX('{fs}'!$BD$5:$BD$184)");why.append('scalar_peak')
     if sn=='KPI' and addr=='B34':
      pr=json.loads((ROOT/'src/build_metadata.json').read_text())['param_rows'];op=f'Pressupostos!$B${pr["open"]}';threshold=f'ROUNDUP(({op}+11)/12,0)';terms=[f'IF(AND(Anual!A{r}>={threshold},Anual!Y{r}>0),Anual!Z{r},1E99)' for r in range(5,20)];new=f'IF(COUNTIFS(Anual!$A$5:$A$19,">="&{threshold},Anual!$Y$5:$Y$19,">0")>0,MIN({",".join(terms)}),"")';why.append('legacy_minifs')
     if new!=f:
      assert len(new)<=8192,(sn,addr,len(new));log(sn,addr,f,new,'+'.join(why));changed=True;full=full[:fm.start(1)]+html.escape(new,quote=False)+full[fm.end(1):];full=re.sub(r'<v>.*?</v>','',full)
     return full
    text=re.sub(r'<c\b[^>]*\br="([A-Z]+\d+)"[^>]*(?<!/)>.*?</c>',cell_replace,text,flags=re.S)
    if sn in helpers:
     for rr in range(5,185):extras['BD'+str(rr)]=f'O{rr}+X{rr}';added.append({'sheet':sn,'cell':'BD'+str(rr),'formula':f'O{rr}+X{rr}','reason':'scalar_peak'})
    if extras:
     cols=['AA','AB','AC'] if is_res else ['BD'];lo,hi=(27,29) if is_res else (56,56)
     # Existing generic column ranges can overlap; specific hidden range is appended last.
     col=f'<col min="{lo}" max="{hi}" width="12" customWidth="1" hidden="1"/>'
     if '</cols>' in text:text=text.replace('</cols>',col+'</cols>',1)
     else:text=text.replace('<sheetData>','<cols>'+col+'</cols><sheetData>',1)
     byrow=collections.defaultdict(list)
     for addr,f in extras.items():
      rr=int(re.search(r'\d+',addr).group());byrow[rr].append(f'<c r="{addr}" t="n"><f>{html.escape(f,quote=False)}</f></c>')
     for rr,newcells in byrow.items():
      pat=r'(<row\b[^>]*\br="'+str(rr)+r'"[^>]*>)(.*?)(</row>)';m=re.search(pat,text,re.S);assert m,(sn,rr)
      text=text[:m.end(2)]+''.join(newcells)+text[m.end(2):]
     changed=True
    if changed:
     if extras:
      endcol='AC' if is_res else 'BD';text=re.sub(r'(<dimension\b[^>]*ref="[A-Z]+\d+:)[A-Z]+(\d+")',lambda m:m[1]+endcol+m[2],text,count=1)
     data=text.encode()
   elif inf.filename=='xl/workbook.xml':
    # Rebuild the graph in Excel; never rely on LibreOffice formula caches.
    x=E.fromstring(data);cp=x.find(T('calcPr'))
    if cp is None:cp=E.SubElement(x,T('calcPr'))
    cp.set('calcMode','auto');cp.set('calcId','0');cp.set('fullCalcOnLoad','1');cp.set('forceFullCalc','1');cp.set('iterate','false');data=E.tostring(x,encoding='utf-8',xml_declaration=True)
   zo.writestr(inf,data)
(ROOT/'entrega/Formulas_Corrigidas.json').write_text(json.dumps(changes,ensure_ascii=False,indent=2));(ROOT/'entrega/Formulas_Auxiliares.json').write_text(json.dumps(added,ensure_ascii=False,indent=2));(ROOT/'entrega/Resumo_Correcao.json').write_text(json.dumps({'source_sha256':oldhash,'modified_formulas':len(changes),'technical_formulas_added':len(added),'classes':dict(classes),'sheet_count':len(pathnames),'excel_desktop_available':False},ensure_ascii=False,indent=2));print('Saved',OUT,dict(classes),len(added),flush=True)
