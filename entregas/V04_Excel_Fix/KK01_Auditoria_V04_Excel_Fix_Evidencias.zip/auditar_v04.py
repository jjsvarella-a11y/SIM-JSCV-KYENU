from pathlib import Path
import zipfile,xml.etree.ElementTree as E,re,json,csv,hashlib,shutil,collections,sys
R=Path('/workspace/kk01/v05'); O=R/'fase1'
src=Path('/workspace/kk01/v04_excel_fix/entrega/KK01_Modelo_Integrado_V04_Excel_Fix.xlsx'); dst=R/'original'/src.name
if not dst.exists(): shutil.copy2(src,dst)
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert h(src)==h(dst)
N={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'};ns='{'+N['m']+'}'
sheets=[];edges=collections.Counter();functions=collections.Counter();errors=[]; inventory=[]; formula_examples={}
with zipfile.ZipFile(dst) as z:
 assert z.testzip() is None
 wb=E.fromstring(z.read('xl/workbook.xml'));rels=E.fromstring(z.read('xl/_rels/workbook.xml.rels'))
 targets={r.attrib['Id']:r.attrib['Target'].lstrip('/') for r in rels}
 for s in wb.find('m:sheets',N):
  t=targets[s.attrib['{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id']]; t=t if t.startswith('xl/') else 'xl/'+t
  d={'folha':s.attrib['name'],'estado':s.attrib.get('state','visible'),'ficheiro':t,'celulas':0,'formulas':0,'validacoes':0,'hyperlinks':0,'tabelas':0,'graficos_desenhos':0,'matriciais':0}
  refs=collections.Counter()
  for ev,c in E.iterparse(z.open(t),events=['end']):
   if c.tag==ns+'c':
    d['celulas']+=1; f=c.find(ns+'f');v=c.find(ns+'v')
    if c.attrib.get('t')=='e':errors.append([d['folha'],c.attrib['r'],v.text if v is not None else None])
    if f is not None:
     d['formulas']+=1;d['matriciais']+=f.attrib.get('t')=='array';txt=f.text or ''
     for a,b in re.findall(r"(?:'((?:[^']|'')+)'|([A-Za-z_][A-Za-z0-9_. ]*))!",txt):refs[(a or b).replace("''", "'")]+=1
     functions.update(re.findall(r'(?<![A-Za-z0-9_])([A-Z_][A-Z0-9_.]*)\s*\(',txt))
     if d['folha'] in ['Fluxo 180M','KPI','V04 Retornos','V04 Waterfall','Matriz Societaria V03'] and len(formula_examples.setdefault(d['folha'],[]))<8:formula_examples[d['folha']].append([c.attrib['r'],txt])
    c.clear()
   elif c.tag==ns+'dataValidation':d['validacoes']+=1
   elif c.tag==ns+'hyperlink':d['hyperlinks']+=1
   elif c.tag==ns+'tablePart':d['tabelas']+=1
   elif c.tag==ns+'drawing':d['graficos_desenhos']+=1
  for ref,num in refs.items():edges[(d['folha'],ref)]+=num
  inventory.append(d)
 out={'origem_sha256':h(src),'copia_sha256':h(dst),'original_preservado':True,'folhas':len(inventory),'estados':dict(collections.Counter(x['estado'] for x in inventory)),'formulas':sum(x['formulas'] for x in inventory),'erros_armazenados':errors,'nomes_definidos':[{'nome':x.attrib.get('name'),'ref':x.text} for x in wb.findall('m:definedNames/m:definedName',N)],'calculo':wb.find('m:calcPr',N).attrib,'graficos':len([x for x in z.namelist() if re.match(r'xl/charts/chart\d+.xml$',x)]),'ligacoes_externas':[x for x in z.namelist() if x.startswith('xl/externalLinks/')],'vba':any(x.endswith('vbaProject.bin') for x in z.namelist()),'funcoes':dict(functions),'exemplos':formula_examples}
(O/'Inventario_V04.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
with (O/'Mapa_Folhas_V04.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(inventory[0]));w.writeheader();w.writerows(inventory)
with (O/'Dependencias_Entre_Folhas.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['folha_dependente','folha_origem','referencias_explicitas']);w.writerows((a,b,n) for (a,b),n in edges.items())
print(json.dumps({k:v for k,v in out.items() if k not in ['nomes_definidos','funcoes','exemplos']},ensure_ascii=False,indent=2))
