from pathlib import Path
import openpyxl,json,collections,sys
O=Path('/workspace/kk01/v05/fase1');p=Path('/workspace/kk01/v05/original/KK01_Modelo_Integrado_V04_Excel_Fix.xlsx')
w=openpyxl.load_workbook(p,read_only=True,data_only=True)
out={}
for n in ['Pressupostos','KPI','EXEC KK01','V04 Retornos','V04 Pipeline','Matriz Societaria V03','Hotel','Fluxo 180M']:
 if n in w:
  rows=list(w[n].values)
  if n=='Fluxo 180M':
   out[n]={'cabecalho':rows[3],'marcos':{str(m):rows[m+3] for m in [24,30,42,54,66,78,86,180]}}
  elif n=='Hotel':
   out[n]={'cabecalho':rows[3], 'ano15':rows[171:184]}
  else:out[n]=rows
units=list(w['Unidades'].values)[4:98];out['fracoes']={'contagem':len(units),'tipologias':dict(collections.Counter(x[1] for x in units)),'vgv':sum(x[7] for x in units),'areas':sum(x[3] for x in units)}
out['folhas_modulos']=[n for n in w.sheetnames if not n.startswith(('Calc','Risk'))]
w.close();(O/'Fotografia_V04_Valores.json').write_text(json.dumps(out,ensure_ascii=False,indent=2,default=str))
sys.path.insert(0,'/workspace/kk01/v04_excel_fix/src')
from engine import run,config,summary
from test_executive_fix import audit
r=run(config());s=summary(r)
res=audit(p,{})
res['motor_marcos']={str(m):r['flow'][m-1] for m in [24,30,42,54,66,78,86,180]}
res['ebitda_ano15']=sum(x['ebitda'] for x in r['hotel'][168:180]);res['resumo']={k:v for k,v in s.items() if k!='annual'}
(O/'Reconferencia_Python_V04.json').write_text(json.dumps(res,ensure_ascii=False,indent=2))
print(json.dumps({'teste':{k:v for k,v in res.items() if k in ['ok','comparisons','failures']},'fracoes':out['fracoes'],'ebitda_ano15':res['ebitda_ano15'],'marcos':{str(m):{k:r['flow'][m-1].get(k) for k in ['cash','reserve','dividend','debt']} for m in [30,42,54]}},ensure_ascii=False,indent=2))
