from pathlib import Path
from lxml import etree as E
import zipfile,json,sys,time
ROOT=Path(__file__).resolve().parents[1]
SCHEMA=ROOT/'validacao/schemas'
M='http://schemas.openxmlformats.org/spreadsheetml/2006/main';D='http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing';C='http://schemas.openxmlformats.org/drawingml/2006/chart';A='http://schemas.openxmlformats.org/drawingml/2006/main'
def validate(path):
 schemas={M:E.XMLSchema(E.parse(str(SCHEMA/'sml.xsd'))),D:E.XMLSchema(E.parse(str(SCHEMA/'dml-spreadsheetDrawing.xsd'))),C:E.XMLSchema(E.parse(str(SCHEMA/'dml-chart.xsd'))),A:E.XMLSchema(E.parse(str(SCHEMA/'dml-main.xsd')))}
 result={'file':str(path),'parts_checked':0,'invalid_parts':[],'unexpected_parse_errors':[],'xml_space_profile':'xml:space on SpreadsheetML text is supported by Microsoft Open XML Text.Space; omitted only from the validation copy because the ECMA mirror types t as a simple string. The workbook is never changed by validation.','xml_space_attributes_profiled':0}
 with zipfile.ZipFile(path) as z:
  assert z.testzip() is None
  for name in z.namelist():
   if not name.endswith('.xml'):continue
   try:x=E.fromstring(z.read(name))
   except Exception as e:result['unexpected_parse_errors'].append([name,str(e)]);continue
   ns=E.QName(x).namespace
   for t in x.iter('{'+M+'}t'):
    if '{http://www.w3.org/XML/1998/namespace}space' in t.attrib:
     del t.attrib['{http://www.w3.org/XML/1998/namespace}space'];result['xml_space_attributes_profiled']+=1
   if ns not in schemas:continue
   result['parts_checked']+=1;s=schemas[ns]
   if not s.validate(x):result['invalid_parts'].append({'part':name,'errors':[{'line':er.line,'message':er.message} for er in s.error_log]})
 result['ok']=not result['invalid_parts'] and not result['unexpected_parse_errors'];return result
if __name__=='__main__':
 file=Path(sys.argv[1]);out=Path(sys.argv[2]);r=validate(file);out.write_text(json.dumps(r,ensure_ascii=False,indent=2));print(r['parts_checked'],'parts;',len(r['invalid_parts']),'invalid; errors',sum(len(x['errors']) for x in r['invalid_parts']));print([(x['part'],x['errors'][:2]) for x in r['invalid_parts']][:8])
