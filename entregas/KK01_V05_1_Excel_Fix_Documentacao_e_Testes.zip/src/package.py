from fix import *
import shutil
from pypdf import PdfReader

def main():
 out=ROOT/'entrega'
 guards=['KK01_V05_1_Excel_Fix_Schema.json','KK01_V05_1_Excel_Fix_Integridade.json','KK01_V05_1_Excel_Fix_Funcionalidades.json','KK01_V05_1_Excel_Fix_Pacote.json','KK01_V05_1_Excel_Fix_Regressao_Estrutural.json','KK01_V05_1_Excel_Fix_Testes_Nativos.json']
 for name in guards:assert json.loads((out/name).read_text())['ok'],name
 assert json.loads((out/'KK01_V05_1_Excel_Fix_Testes_Nativos.json').read_text())['case_count']==6
 with zipfile.ZipFile(OUTPUT) as z:assert z.testzip() is None
 assert OUTPUT.stat().st_size<40000000
 for p in out.glob('*.pdf'):assert all(page.extract_text().strip() for page in PdfReader(p).pages)
 for name,sha in [('KK01_Modelo_Integrado_V05_1_Executive.xlsx','63acf31c9673c7f70a20947fa066a6f864cb4e1cd6c0d25a26258d93798d490e'),('KK01_Modelo_Integrado_V05_Executive.xlsx','432fdb6040316056c0f0e1125125f356660df5003719172de368123026452ed5')]:assert hashlib.sha256((Path('/workspace/SIM-JSCV-KYENU/entregas')/name).read_bytes()).hexdigest()==sha
 bundle=out/'KK01_V05_1_Excel_Fix_Documentacao_e_Testes.zip'
 with zipfile.ZipFile(bundle,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for p in sorted(out.glob('*')):
   if p.is_file() and p.suffix not in ['.xlsx','.zip'] and 'Manifesto' not in p.name:z.write(p,p.name)
  for p in sorted((ROOT/'src').glob('*')):
   if p.is_file():z.write(p,'src/'+p.name)
  for p in sorted((ROOT/'validacao/schemas').glob('*.xsd')):z.write(p,'validacao/schemas/'+p.name)
  for directory in ['src','reference/src']:
   for p in sorted((Path('/workspace/kk01/v05_final')/directory).glob('*')):
    if p.is_file():z.write(p,'financial_reference/'+directory+'/'+p.name)
  z.write(ROOT/'README_Fontes.md','README_Fontes.md')
 assert bundle.stat().st_size<40000000
 with zipfile.ZipFile(bundle) as z:assert z.testzip() is None
 names=[p.name for p in sorted(out.glob('*')) if p.is_file() and 'Manifesto' not in p.name]
 manifest={'date':'2026-10-21','status':'Candidata corrigida; aceitação em Excel Desktop pendente','files':{name:{'bytes':(out/name).stat().st_size,'sha256':hashlib.sha256((out/name).read_bytes()).hexdigest()} for name in names}}
 (out/'KK01_V05_1_Excel_Fix_Manifesto_SHA256.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
 for destination in [Path('/workspace/kk01/entrega'),Path('/workspace/SIM-JSCV-KYENU/entregas')]:
  for p in sorted(out.glob('*')):
   if not p.is_file():continue
   target=destination/p.name
   if target.exists():assert hashlib.sha256(target.read_bytes()).hexdigest()==hashlib.sha256(p.read_bytes()).hexdigest(),str(target)
   shutil.copy2(p,target)
 print('Packaged',len(names)+1,'files; XLSX',OUTPUT.stat().st_size,'bytes; documentation',bundle.stat().st_size,'bytes')
if __name__=='__main__':main()
