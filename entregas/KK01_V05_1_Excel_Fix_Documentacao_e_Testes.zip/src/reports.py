from fix import *
import csv,html
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

def pdf(text,path):
 pdfmetrics.registerFont(TTFont('KK','/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf'));pdfmetrics.registerFont(TTFont('KKB','/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf'))
 styles=getSampleStyleSheet();styles['BodyText'].fontName='KK';styles['BodyText'].fontSize=9;styles['BodyText'].leading=12;styles['Heading1'].fontName='KKB';styles['Heading1'].fontSize=17;styles['Heading2'].fontName='KKB';styles['Heading2'].fontSize=12
 story=[];lines=text.splitlines();i=0
 def para(s):return Paragraph(html.escape(s),styles['BodyText'])
 while i<len(lines):
  s=lines[i]
  if s.startswith('|'):
   rows=[]
   while i<len(lines) and lines[i].startswith('|'):
    cells=[q.strip() for q in lines[i].strip('|').split('|')]
    if not all(re.fullmatch('[-: ]+',q) for q in cells):rows.append([para(q) for q in cells])
    i+=1
   cols=len(rows[0]);widths=[175,348] if cols==2 else [205]+[318/(cols-1)]*(cols-1);t=Table(rows,colWidths=widths,repeatRows=1);t.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'TOP'),('BACKGROUND',(0,0),(-1,0),colors.HexColor('#E8EEF3')),('BOTTOMPADDING',(0,0),(-1,-1),6),('LINEBELOW',(0,0),(-1,-1),.3,colors.HexColor('#DCE4EC'))]));story.extend([t,Spacer(1,10)]);continue
  if s.startswith('# '):story.append(Paragraph(html.escape(s[2:]),styles['Heading1']))
  elif s.startswith('## '):story.append(Paragraph(html.escape(s[3:]),styles['Heading2']))
  elif s.strip():story.append(para(s))
  story.append(Spacer(1,6));i+=1
 def foot(c,doc):c.setFont('KK',8);c.setFillColor(colors.HexColor('#586B7D'));c.drawString(36,22,'KK-01 | V05.1 Excel Fix | 21/10/2026 | Aceitação Excel Desktop pendente');c.drawRightString(A4[0]-36,22,str(doc.page))
 SimpleDocTemplate(str(path),leftMargin=36,rightMargin=36,topMargin=36,bottomMargin=36).build(story,onFirstPage=foot,onLaterPages=foot)
def table(head,rows):return '| '+' | '.join(head)+' |\n|'+'|'.join(['---']*len(head))+'|\n'+''.join('| '+' | '.join(str(q) for q in row)+' |\n' for row in rows)
def fmt(v,typ='EUR'):
 x=float(v);s=f'{100*x:,.2f}%' if typ=='%' else f'{x:,.2f}×' if typ=='x' else f'{x:,.2f} €';return s.replace(',','X').replace('.',',').replace('X','.')
def save(name,text):
 text=re.sub(r'(?<=\d),(?=\d{3}(?:,|\s|[.;]))','.',text)
 p=ROOT/'entrega'/name;p.with_suffix('.md').write_text(text,encoding='utf-8');pdf(text,p.with_suffix('.pdf'))
def main():
 out=ROOT/'entrega';components=json.loads((out/'KK01_V05_1_Excel_Fix_Componentes.json').read_text());integ=json.loads((out/'KK01_V05_1_Excel_Fix_Integridade.json').read_text());native=json.loads((out/'KK01_V05_1_Excel_Fix_Testes_Nativos.json').read_text());schema=json.loads((out/'KK01_V05_1_Excel_Fix_Schema.json').read_text());assert native['ok'] and integ['ok'] and schema['ok']
 records={r['ID']:r for r in csv.DictReader((out/'KK01_V05_1_Excel_Fix_Comparacao_KPI.csv').open())};metrics=[]
 for key in ['vgv','capex','peak','cash30','cash42','cash54','div54','irr','moic','equity','npv']:
  r=records[key];typ='%' if key=='irr' else 'x' if key=='moic' else 'EUR';metrics.append([r['KPI'],fmt(r['Antes'],typ),fmt(r['Depois'],typ),'0'])
 text=f'''# KK-01 V05.1 Executive — correção OOXML e cartão TIR

21/10/2026. Ficheiro: KK01_Modelo_Integrado_V05_1_Executive_Excel_Fix.xlsx.

## Estado da entrega

As violações estruturais identificadas foram corrigidas. A versão é uma candidata corrigida para aceitação no Microsoft Excel Desktop. A abertura nesse programa sem recuperação de conteúdo permanece Pendente de Validação Externa: Excel Desktop não está disponível neste ambiente. Não se declara a compatibilidade nativa certificada nem o incidente encerrado.

A validação anterior de ZIP, fórmulas e LibreOffice foi insuficiente para detetar ordens XML inválidas. Esta correção acrescenta validação por esquemas e testes negativos que reproduzem as violações. Não foi fornecido o XML de reparação do Excel; os defeitos normativos abaixo são causas estruturais aptas a explicar uma reparação, mas não permitem identificar os registos que o Excel efetivamente removeu na abertura observada pelo utilizador.

## Diagnóstico comparativo

A V05 anterior apresenta nove vistas de folha com cinco seleções de painéis. O esquema admite até quatro; há seleções repetidas. A V05.1 herda esses nove defeitos e introduz mais 35 violações: 15 estilos e 20 propriedades de linhas de gráficos. Total: 44 ocorrências em 19 partes. A integridade ZIP, isoladamente, não revela estes erros.

'''+table(['Componente','Defeito comprovado e correção'],[
 ['xl/styles.xml — 15 cellXfs','alignment aparecia depois de protection. CT_Xf exige alignment antes de protection. Reordenados os elementos sem alterar a proteção, as fontes referenciadas ou os formatos numéricos.'],
 ['9 gráficos — 20 linhas','solidFill aparecia depois de prstDash. CT_LineProperties exige o preenchimento antes do traço. Reordenadas as propriedades, preservando as séries, referências, categorias e dados.'],
 ['9 vistas dos dashboards','Cinco selection, incluindo panes repetidos. Passam a três seleções distintas: topRight/D1, bottomLeft/A6 e bottomRight/D6. Os painéis congelados e a sidebar mantêm-se.'],
 ['Cores e fundos — robustez visual',f'{components["opaque_rgb"]} cores ARGB normalizadas para alfa FF; {components["solid_backgrounds_explicit"]} fundos sólidos tornados explícitos. São medidas de consistência, não violações de esquema por si mesmas.'],
 ['Cartões TIR — 6 regras de formato','Mantidas as expressões e prioridades. As regras passam a alterar apenas a cor explícita do texto; o fundo branco da célula não é substituído por preenchimentos condicionais.'],
 ])+f'''
## Cartão TIR e consistência visual

O EXEC V05!P8 continua numérico, com valor {fmt(records['irr']['Depois'],'%')}, formato percentual português, alinhamento à esquerda e centralização vertical. O fundo é branco opaco, com foreground/background FFFFFFFF. A cor vermelha assinala TIR inferior à taxa exigida; a condição financeira não mudou. Aplicado o mesmo tratamento às TIR dos dashboards de estrutura e retornos.

Cores com alfa zero e fundos automáticos existiam no ficheiro. A renderização preta observada no Excel pode estar associada à interpretação ou recuperação destes estilos; sem reproduzir o evento no Excel não é possível afirmar qual destes fatores causou o cartão preto. A renderização no LibreOffice da candidata mostra texto vermelho legível sobre branco.

## Preservação financeira e funcional

Comparadas {integ['formulas_checked']:,} fórmulas e {integ['numeric_cells_checked']:,} valores numéricos existentes, sem alterações. Os 40 KPI centrais têm delta zero. Não foram substituídas fórmulas por constantes, acrescentados financiamentos ou alterados pressupostos.

Mantêm-se 348 folhas, os nove dashboards, 180 meses, cenários fiscais, política de dividendos, simuladores e PT/EN. O workbook, nomes definidos, relações do workbook, desenhos/formas, notas, imagens, hiperligações e validações de dados foram preservados. Não se eliminaram gráficos nem a sidebar. Apenas 19 partes existentes foram modificadas, todas de estilos, vistas ou propriedades gráficas.

'''+table(['KPI','Antes','Depois','Delta'],metrics)+f'''
O CSV Comparacao_KPI contém os 40 indicadores, valores e fórmulas antes/depois. A prova JSON identifica os hashes da origem e da candidata. A V05 e a V05.1 anteriores permanecem intactas.

## Testes e alcance

Validadas {schema['parts_checked']} partes SpreadsheetML/DrawingML abrangidas pelos esquemas: zero violações no perfil documentado. Relações do pacote resolvidas, IDs e índices de estilos verificados, sem erros de fórmula armazenados. Dez grupos de regressão Python aprovados; seis cenários de recálculo nativo no LibreOffice, com {native['comparisons']:,} comparações e zero falhas inesperadas, incluindo reconciliação dos 62 motores na Base.

Os seis casos são Base, IVA diferido, dividendos Máximo/Acumulados, juro de 8%, PT/EN e filtro ID 201. Não se afirma que os 35 casos anteriores tenham sido todos repetidos: a preservação de todas as fórmulas e valores é comprovada separadamente.

## Método de validação por esquemas

Esquemas ECMA-376 Transitional obtidos do espelho público QtExcel/ecma-376-5th, acompanhados no pacote com hashes. O perfil respeita xml:space em SpreadsheetML Text, suportado por Microsoft Open XML Text.Space. O espelho tipa t como string simples e rejeita esse atributo; apenas a cópia em memória usada no validador omite o atributo. O ficheiro entregue preserva integralmente xml:space e o texto. Nenhum outro erro de esquema é ignorado.

Foram introduzidos, em cópias de teste, alignment após protection, solidFill após prstDash e cinco selection; o validador rejeitou os três casos. Um teste adicional confirma os dois canais brancos opacos do cartão TIR.

## Limitações e aceitação pendente

Abertura sem reparação, aparência e recálculo em Microsoft Excel Desktop: Pendente de Validação Externa. LibreOffice e validação OOXML não substituem esse teste. O relatório de reparação original do Excel não foi disponibilizado.

A Vista Protegida pode continuar a aparecer em ficheiros descarregados, conforme a política de segurança do Excel. Não foi desativado qualquer mecanismo de segurança. A correção dirige-se aos defeitos de conteúdo; não suprime avisos nem força a abertura de ficheiros inválidos.

A pré-visualização PDF é uma renderização estática dos valores em cache com os pressupostos necessários à formatação condicional; serve para inspeção visual, não como teste financeiro adicional nem certificação Excel.
'''
 save('KK01_V05_1_Excel_Fix_Relatorio_Tecnico',text)
 rows=[[r['case'],'Conforme',r['comparisons'],r['failure_count'],r['error_count']] for r in native['cases']]
 test=f'''# KK-01 V05.1 Excel Fix — relatório de testes

21/10/2026. Estado: Conforme nos testes executados; aceitação Microsoft Excel Desktop pendente.

'''+table(['Caso nativo','Estado','Comparações','Falhas','Erros'],rows)+f'''
Comparações nativas/Python totais: {native['comparisons']:,}. O caso Base abrange os 62 motores; os outros casos verificam o fluxo de 180 meses, retornos e os seletores alterados. Os snapshots verificam erros de fórmula em todas as folhas. Os testes são executados por cliente Java/UNO externo, sem macros no workbook, numa cópia privada cujo SHA-256 é {native['canonical_input_sha256']}.

'''+table(['Verificação','Resultado'],[
 ['Pacote ZIP / relações / índices','Conforme; 104 partes de relações verificadas, 364 nomes definidos preservados.'],
 ['Esquemas OOXML — antes','V05: 9 ocorrências; V05.1: 44 ocorrências, no perfil documentado.'],
 ['Esquemas OOXML — depois',f'{schema["parts_checked"]} partes; zero violações.'],
 ['Fórmulas existentes',f'{integ["formulas_checked"]:,} comparadas; nenhuma alteração.'],
 ['Valores numéricos existentes',f'{integ["numeric_cells_checked"]:,} comparados; nenhuma alteração.'],
 ['Dicionário KPI','40 KPI; delta zero.'],
 ['Regressão financeira Python','10 grupos aprovados.'],
 ['Regressão estrutural','3 mutações inválidas rejeitadas e fundo do cartão TIR verificado.'],
 ['Visualização','Nove painéis renderizados em PDF; cartão TIR branco, texto vermelho no cenário atual.'],
 ['Excel Desktop','Não executado; abertura sem recuperação e aparência nativa pendentes.'],
 ])+'''
Não foram alterados os critérios financeiros de alerta para melhorar a aparência. As fórmulas de formatação condicional mantêm-se; a apresentação da TIR passa a usar apenas cores de fonte. A prova de preservação, o comparativo CSV e os registos por componente acompanham esta entrega.
'''
 save('KK01_V05_1_Excel_Fix_Relatorio_Testes',test)
 print('Technical and test reports generated')
if __name__=='__main__':main()
