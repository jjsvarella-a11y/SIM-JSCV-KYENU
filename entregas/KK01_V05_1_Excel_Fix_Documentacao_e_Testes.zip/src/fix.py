"""OOXML order/style correction only; no cell formula or cached value changes."""
from pathlib import Path
import os,sys,zipfile,xml.etree.ElementTree as E,hashlib,json,re,copy
previous=Path(os.environ.get('KK01_V05_SRC',str(Path(__file__).resolve().parents[1]/'financial_reference/src')))
if not previous.exists():previous=Path('/workspace/kk01/v05_final/src')
sys.path.insert(0,str(previous))
from common import paths,T
ROOT=Path(__file__).resolve().parents[1]
SOURCE=Path(os.environ.get('KK01_COMPAT_SOURCE','/workspace/SIM-JSCV-KYENU/entregas/KK01_Modelo_Integrado_V05_1_Executive.xlsx'))
OUTPUT=ROOT/'entrega/KK01_Modelo_Integrado_V05_1_Executive_Excel_Fix.xlsx'
A='{http://schemas.openxmlformats.org/drawingml/2006/main}'
IRR={'EXEC V05':'P8','DASH 06 V05':'L8','DASH 07 V05':'D8'}
def main():
 mods={};log={'styles_reordered':[],'chart_lines_reordered':[],'views_repaired':[],'opaque_rgb':0,'solid_backgrounds_explicit':0,'irr_rules_font_only':[]}
 with zipfile.ZipFile(SOURCE) as z:
  ps=paths(z);st=E.fromstring(z.read('xl/styles.xml'))
  order={'alignment':0,'protection':1,'extLst':2}
  for group in ['cellStyleXfs','cellXfs']:
   for i,xf in enumerate(st.find(T(group))):
    children=list(xf);sorted_children=sorted(children,key=lambda q:order[q.tag.split('}')[-1]])
    if children!=sorted_children:xf[:]=sorted_children;log['styles_reordered'].append({'group':group,'index':i,'before':[c.tag.split('}')[-1] for c in children],'after':[c.tag.split('}')[-1] for c in sorted_children]})
  for el in st.iter():
   rgb=el.attrib.get('rgb')
   if rgb and (len(rgb)==6 or len(rgb)==8 and rgb[:2]=='00'):
    el.set('rgb','FF'+rgb[-6:]);log['opaque_rgb']+=1
  for fill in st.iter(T('patternFill')):
   fg=fill.find(T('fgColor'));bg=fill.find(T('bgColor'))
   if fill.attrib.get('patternType')=='solid' and fg is not None and 'rgb' in fg.attrib:
    attrs={'rgb':fg.attrib['rgb']}
    if bg is None:bg=E.SubElement(fill,T('bgColor'));log['solid_backgrounds_explicit']+=1
    elif bg.attrib!=attrs:log['solid_backgrounds_explicit']+=1
    bg.attrib.clear();bg.attrib.update(attrs)
  # Keep the financial alert logic; use only explicit opaque font colours on white KPI cards.
  dx=st.find(T('dxfs'));newids={}
  for name,color in [('green','FF176C3A'),('red','FFB3261E')]:
   newids[name]=str(len(dx));d=E.SubElement(dx,T('dxf'));font=E.SubElement(d,T('font'));E.SubElement(font,T('b'),{'val':'1'});E.SubElement(font,T('color'),{'rgb':color})
  dx.set('count',str(len(dx)))
  for sn,p in ps.items():
   if sn not in ['EXEC V05','DASH 01 V05','DASH 02','DASH 03 V05','DASH 04A V05','DASH 04B V05','DASH 05 V05','DASH 06 V05','DASH 07 V05']:continue
   x=E.fromstring(z.read(p));changed=False
   for view in x.iter(T('sheetView')):
    pane=view.find(T('pane'))
    if pane is None:continue
    selections=[c for c in view if c.tag==T('selection')]
    before=[dict(c.attrib) for c in selections]
    for c in selections:view.remove(c)
    wanted=[('topRight','D1'),('bottomLeft','A6'),('bottomRight','D6')]
    for j,(name,addr) in enumerate(wanted):view.insert(list(view).index(pane)+1+j,E.Element(T('selection'),{'pane':name,'activeCell':addr,'sqref':addr}))
    pane.set('activePane','bottomRight');log['views_repaired'].append({'sheet':sn,'before':before,'after':wanted});changed=True
   if sn in IRR:
    for cf in x.iter(T('conditionalFormatting')):
     if cf.attrib.get('sqref')!=IRR[sn]:continue
     for rule in cf:
      formula=rule.findtext(T('formula'),'');key='green' if '>=' in formula else 'red';old=rule.attrib.get('dxfId');rule.set('dxfId',newids[key]);log['irr_rules_font_only'].append({'sheet':sn,'cell':IRR[sn],'old_dxf':old,'new_dxf':newids[key],'formula':formula});changed=True
   if changed:mods[p]=E.tostring(x)
  # CT_LineProperties order: fill, dash, join, ends, extensions.
  lnorder={tag:i for i,tag in enumerate(['noFill','solidFill','gradFill','pattFill','prstDash','custDash','round','bevel','miter','headEnd','tailEnd','extLst'])}
  for f in z.namelist():
   if not re.fullmatch(r'xl/charts/[^/]+\.xml',f):continue
   x=E.fromstring(z.read(f));changed=False
   for i,line in enumerate(x.iter(A+'ln')):
    before=list(line);after=sorted(before,key=lambda e:lnorder[e.tag.split('}')[-1]])
    if before!=after:line[:]=after;changed=True;log['chart_lines_reordered'].append({'part':f,'line':i,'before':[c.tag.split('}')[-1] for c in before],'after':[c.tag.split('}')[-1] for c in after]})
   if changed:mods[f]=E.tostring(x)
  mods['xl/styles.xml']=E.tostring(st)
  with zipfile.ZipFile(OUTPUT,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as out:
   for it in z.infolist():out.writestr(it,mods.get(it.filename,z.read(it.filename)))
 log.update(source_sha256=hashlib.sha256(SOURCE.read_bytes()).hexdigest(),output_sha256=hashlib.sha256(OUTPUT.read_bytes()).hexdigest(),changed_parts=list(mods),cell_formulas_or_cached_values_changed=False,repair_log_supplied=False)
 (ROOT/'entrega/KK01_V05_1_Excel_Fix_Componentes.json').write_text(json.dumps(log,ensure_ascii=False,indent=2));print({k:len(v) if isinstance(v,list) else v for k,v in log.items()})
if __name__=='__main__':main()
