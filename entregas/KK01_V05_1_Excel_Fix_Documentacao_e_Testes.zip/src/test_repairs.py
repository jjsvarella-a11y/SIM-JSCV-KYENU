from fix import *
from lxml import etree as L
SC=ROOT/'validacao/schemas'
def profile(x):
 for t in x.iter('{http://schemas.openxmlformats.org/spreadsheetml/2006/main}t'):t.attrib.pop('{http://www.w3.org/XML/1998/namespace}space',None)
 return x

def main():
 sml=L.XMLSchema(L.parse(str(SC/'sml.xsd')));chart=L.XMLSchema(L.parse(str(SC/'dml-chart.xsd')));tests=[]
 with zipfile.ZipFile(OUTPUT) as z:
  st=L.fromstring(z.read('xl/styles.xml'));assert sml.validate(st)
  xf=next(x for x in st.find(T('cellXfs')) if x.find(T('alignment')) is not None and x.find(T('protection')) is not None);a=xf.find(T('alignment'));xf.remove(a);xf.append(a);tests.append({'test':'Reject protection before alignment','ok':not sml.validate(st)})
  p='xl/charts/v05_chart1.xml';x=L.fromstring(z.read(p));assert chart.validate(x);ln=next(q for q in x.iter(A+'ln') if q.find(A+'solidFill') is not None and q.find(A+'prstDash') is not None);fill=ln.find(A+'solidFill');ln.remove(fill);ln.append(fill);tests.append({'test':'Reject fill after dash in chart line','ok':not chart.validate(x)})
  ps=paths(z);x=profile(L.fromstring(z.read(ps['EXEC V05'])));assert sml.validate(x);view=x.find('.//'+T('sheetView'));view.append(L.Element(T('selection'),pane='bottomRight'));view.append(L.Element(T('selection'),pane='bottomLeft'));tests.append({'test':'Reject five pane selections','ok':not sml.validate(x)})
  st=L.fromstring(z.read('xl/styles.xml'));cs={c.attrib['r']:c for c in x.iter(T('c'))};xf=st.find(T('cellXfs'))[int(cs['P8'].attrib['s'])];fill=st.find(T('fills'))[int(xf.attrib['fillId'])].find(T('patternFill'));tests.append({'test':'IRR card explicit opaque white foreground/background','ok':fill.find(T('fgColor')).attrib=={'rgb':'FFFFFFFF'} and fill.find(T('bgColor')).attrib=={'rgb':'FFFFFFFF'}})
 result={'ok':all(t['ok'] for t in tests),'tests':tests};(ROOT/'entrega/KK01_V05_1_Excel_Fix_Regressao_Estrutural.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(result);assert result['ok']
if __name__=='__main__':main()
