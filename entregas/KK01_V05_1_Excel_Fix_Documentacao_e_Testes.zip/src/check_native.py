from fix import *
from validate import CASES,check
from openpyxl.utils import column_index_from_string as CI

def main():
 folder=ROOT/'validacao/NativeFinal/out';wanted={'Base','PT_EN','Filtro_ID201','IVA_Diferido','Div_Maximo_Acumulados','Juro8'};results=[]
 for name,params,changes in CASES:
  if name not in wanted:continue
  path=folder/(name+'.json');r=check(path,params,risks=name=='Base');d=json.loads(path.read_text());front=d['sheets']['EXEC V05'];ui=[]
  if name=='PT_EN':ui=[front[0][3]=='Executive Overview',front[5][0].startswith('01  Executive Overview')]
  if name=='Filtro_ID201':ui=[abs(d['sheets']['DASH 04A V05'][53][7]-552000)<.01]
  r.update(case=name,params=params,interface_checks=ui);r['ok']=r['ok'] and all(ui);results.append(r);print(name,r['ok'],r['comparisons'],r['failure_count'],r['error_count'],flush=True)
 result={'ok':all(r['ok'] for r in results),'case_count':len(results),'engines_reconciled_in_base':62,'comparisons':sum(r['comparisons'] for r in results),'financial_failures':sum(r['failure_count'] for r in results),'unexpected_errors':sum(r['error_count'] for r in results),'canonical_input_sha256':(folder.parent/'canonical.sha256').read_text(),'cases':results,'Excel_Desktop':'Unavailable; opening without repair remains pending native Excel Desktop acceptance.','original_35_cases':'Not all repeated: same formulas and numeric values proven; six native scenario cases plus ten Python regression groups executed.'}
 (ROOT/'entrega/KK01_V05_1_Excel_Fix_Testes_Nativos.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));assert result['ok'];print('All native tests passed',flush=True)
if __name__=='__main__':main()
