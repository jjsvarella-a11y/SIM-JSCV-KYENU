from pathlib import Path
import urllib.request
from lxml import etree as E
ROOT=Path(__file__).resolve().parents[1]/'validacao/schemas';ROOT.mkdir(exist_ok=True)
URL='https://raw.githubusercontent.com/QtExcel/ecma-376-5th/master/ECMA-376/OfficeOpenXML-XMLSchema-Transitional/'
seen=set()
def get(name):
 if name in seen:return
 seen.add(name);p=ROOT/name
 if not p.exists():p.write_bytes(urllib.request.urlopen(URL+name,timeout=60).read())
 for ref in E.parse(str(p)).xpath('//@schemaLocation'):
  if not ref.startswith('http'):get(ref)
for name in ['sml.xsd','dml-spreadsheetDrawing.xsd','dml-chart.xsd','opc-relationships.xsd']:
 try:get(name)
 except Exception as e:print(name,str(e))
print('schemas',len(seen))
