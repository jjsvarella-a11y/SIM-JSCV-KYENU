from fix import *
import posixpath
BASE=SOURCE
OUT=OUTPUT
C='http://schemas.openxmlformats.org/drawingml/2006/chart'
NAV=[(s,'','') for s in ['EXEC V05','DASH 01 V05','DASH 02','DASH 03 V05','DASH 04A V05','DASH 04B V05','DASH 05 V05','DASH 06 V05','DASH 07 V05']]
def cells(x):return {c.attrib['r']:c for c in x.iter(T('c'))}

from openpyxl.utils.cell import range_boundaries
def main():
 result={'ok':True,'formulas_checked':0,'numeric_cells_checked':0,'failures':[],'dashboards':{},'formula_sha256':None}
 h=hashlib.sha256()
 with zipfile.ZipFile(BASE) as old,zipfile.ZipFile(OUT) as new:
  assert new.testzip() is None
  op,np=paths(old),paths(new);assert set(op)<=set(np)
  for sn,p in op.items():
   a=E.fromstring(old.read(p));b=E.fromstring(new.read(np[sn]));bc=cells(b)
   for c in a.iter(T('c')):
    addr=c.attrib['r'];f=c.find(T('f'));v=c.find(T('v'));other=bc.get(addr)
    if f is not None:
     result['formulas_checked']+=1
     if other is None or other.find(T('f')) is None or f.text!=other.find(T('f')).text or f.attrib!=other.find(T('f')).attrib:result['failures'].append([sn,addr,'formula changed'])
     h.update((sn+'!'+addr+'\0'+(f.text or '')).encode())
    if v is not None and c.attrib.get('t','n') in ['n','b']:
     result['numeric_cells_checked']+=1
     if other is None or other.findtext(T('v'))!=v.text or other.attrib.get('t','n') not in ['n','b']:result['failures'].append([sn,addr,'numeric value changed'])
   if sn in [q[0] for q in NAV]:
    merged=[q.attrib['ref'] for q in b.iter(T('mergeCell'))];bounds=[range_boundaries(m) for m in merged]
    for i,(l,t,r,bt) in enumerate(bounds):
     for j,(ll,tt,rr,bb) in enumerate(bounds[:i]):
      if l<=rr and ll<=r and t<=bb and tt<=bt:result['failures'].append([sn,merged[i],merged[j],'overlapping merges'])
    result['dashboards'][sn]={'hyperlinks':len(list(b.iter(T('hyperlink')))),'freeze':b.find('.//'+T('pane')).attrib,'print':b.find(T('pageSetup')).attrib}
  for f in old.namelist():
   if '/charts/' in f and f.endswith('.xml'):
    a=E.fromstring(old.read(f));b=E.fromstring(new.read(f));refs=lambda x:[q.text for q in x.iter('{'+C+'}f')]
    assert refs(a)==refs(b),('chart references changed',f)
   if f.startswith('xl/media/') or f.endswith('.vml'):assert old.read(f)==new.read(f),f
  broken=[]
  for sn,p in np.items():
   x=E.fromstring(new.read(p))
   for q in x.iter(T('hyperlink')):
    target=q.attrib.get('location','')
    if '!' in target and target.split('!')[0].strip("'").replace("''", "'") not in np:broken.append([sn,target])
  assert not broken,broken
  result['new_sheets']=sorted(set(np)-set(op));result['formula_sha256']=h.hexdigest();result['original_sha256']=hashlib.sha256(BASE.read_bytes()).hexdigest();result['final_sha256']=hashlib.sha256(OUT.read_bytes()).hexdigest();result['bytes']=OUT.stat().st_size;result['ok']=not result['failures'];assert OUT.stat().st_size<40000000
 tested=ROOT/'validacao/NativeFinal/worker4/Input.xlsx'
 if tested.exists():
  from finish_presentation import fingerprint
  with zipfile.ZipFile(tested) as z:before=fingerprint(z)
  with zipfile.ZipFile(OUT) as z:after=fingerprint(z)
  result['native_test_input_sha256']=hashlib.sha256(tested.read_bytes()).hexdigest()
  result['final_presentation_math_matches_native_input']=before==after
  result['presentation_math_fingerprints']={'tested':before,'final':after}
  assert before==after,'Final geometry changes must preserve all formulas and numeric values'
 (ROOT/'entrega/KK01_V05_1_Excel_Fix_Integridade.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps({k:v for k,v in result.items() if k!='dashboards'},ensure_ascii=False,indent=2));assert result['ok']
if __name__=='__main__':main()
