# KK-01 V05.1 Excel Fix — reprodução e limites

Este pacote inclui correção por OOXML, validadores, esquemas e testes. A pasta financial_reference contém as fontes financeiras anteriores sem alterações. O XLSX V05.1 de origem não está duplicado. Disponível no mesmo diretório público entregas/KK01_Modelo_Integrado_V05_1_Executive.xlsx. SHA-256 da origem: 63acf31c9673c7f70a20947fa066a6f864cb4e1cd6c0d25a26258d93798d490e.

Definir KK01_COMPAT_SOURCE para o caminho absoluto do XLSX original V05.1. KK01_V05_SRC pode indicar fontes financeiras anteriores; por defeito usa financial_reference/src quando existe. Criar entrega e validacao. Requisitos Python: lxml, openpyxl, numpy, scipy, psutil, reportlab e pypdf. Java e LibreOffice/soffice são necessários apenas para recálculo nativo.

Sequência: python src/fix.py; python src/verify.py; python src/validate_schema.py entrega/KK01_Modelo_Integrado_V05_1_Executive_Excel_Fix.xlsx entrega/KK01_V05_1_Excel_Fix_Schema.json; python src/test_repairs.py; python src/run_native.py; python src/check_native.py. Os esquemas são acompanhados em validacao/schemas, com origem e hashes em Esquemas_Fontes.json. run_native descarrega e verifica o cliente Java de Maven Central. Nenhum VBA é adicionado ao modelo.

O perfil XSD aceita xml:space em SpreadsheetML Text, conforme Microsoft Open XML Text.Space. O atributo é omitido apenas numa cópia em memória de validação; os ficheiros e os textos não são modificados. Não se ignoram outras violações.

preview.py produz uma cópia estática para inspeção visual por PDF, com Pressupostos incluída para permitir avaliar a formatação condicional da TIR. Não usar essa cópia como modelo financeiro nem como prova adicional de recálculo. reports.py produz os relatórios após os testes.

A validação OOXML e o recálculo LibreOffice não certificam Excel Desktop. A confirmação de abertura sem reparação no Excel Desktop continua pendente. Sem o XML de reparação do Excel, os componentes que foram efetivamente removidos nessa abertura original não são conhecidos.
