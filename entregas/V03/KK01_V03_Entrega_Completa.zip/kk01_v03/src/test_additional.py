from test_selectors import *
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 results=list(pool.map(worker,[('V03_Recebido_Final',dict(received_ratio=.5),{}),('V03_Referencia_Final',{}, {})]))
(ROOT/'entrega/Testes_Adicionais.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
for r in results:print(json.dumps(r,ensure_ascii=False),flush=True)
raise SystemExit(not all(r['ok'] for r in results))
