from test_selectors import *
CASES=CASES+[('V03_Recebido_Final',dict(received_ratio=.5),{}),('V03_Referencia_Final',{}, {})]
reports=[]
for name,params,extras in CASES:
 p=ROOT/'validacao'/name/'out'/(name+'.xlsx')
 if not p.exists():continue
 r=run(config(**params));sm=summary(r);pp=r['p'];paid=(pp['equity']-pp['conversion'])*pp['received_ratio'];nval=sum((x['dividend']*sm['share']-paid*sum(pp['fund_part'+str(j)] for j in [1,2,3] if x['m']==pp['fund_month'+str(j)]))/(1+pp['equity_discount'])**(x['m']/12) for x in r['flow'])+sm['exit_equity']*sm['share']/(1+pp['equity_discount'])**15;w=openpyxl.load_workbook(p,data_only=True,read_only=True);fails=[];n=0
 for cell,expected in [('C13',sm['share']),('C19',sm['equity_irr']),('C18',sm['moic']),('C11',sm['exit_equity']),('C17',(sm['dividends']+sm['exit_equity'])*sm['share']-paid),('C26',nval)]:
  got=w['Retornos'][cell].value
  if expected is not None:
   n+=1
   if not isinstance(got,(int,float)) or abs(got-expected)>max(.01,abs(expected)*1e-8):fails.append(f'{cell} {got} != {expected}')
 # Every promoter monthly receipt reconciles divs, retained cash and seller creditor flows.
 pp=r['p'];share=sm['share'];expected_cf=[-pp['historic']]
 for x in r['flow']:
  weight=sum(pp['fund_part'+str(j)] for j in [1,2,3] if x['m']==pp['fund_month'+str(j)])
  val=x['dividend']*(1-share)+(pp['equity']-pp['conversion'])*pp['received_ratio']*(1-pp['treasury_ratio'])*weight+x['loan_interest']+x['loan_principal']
  if x['m']==180:val+=sm['exit_equity']*(1-share)+x['shareloan']
  expected_cf.append(val)
 for row,expected in zip(w['Fluxos Retorno'].iter_rows(min_row=5,max_row=185,min_col=5,max_col=5,values_only=True),expected_cf):
  n+=1;got=row[0]
  if not isinstance(got,(int,float)) or abs(got-expected)>max(.01,abs(expected)*1e-8):fails.append(f'Promotor {got} != {expected}')
 w.close();reports.append(dict(case=name,ok=not fails,comparisons=n,failures=fails[:8]))
print(json.dumps(reports,ensure_ascii=False,indent=2));(ROOT/'entrega/Testes_Metricas_Seletores.json').write_text(json.dumps(reports,ensure_ascii=False,indent=2));raise SystemExit(not all(r['ok'] for r in reports))
