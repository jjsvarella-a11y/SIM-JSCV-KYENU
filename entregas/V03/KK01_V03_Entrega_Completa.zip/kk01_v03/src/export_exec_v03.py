from pathlib import Path
import zipfile,xml.etree.ElementTree as E,subprocess
ROOT=Path(__file__).resolve().parents[1];folder=ROOT/'validacao/executivo';folder.mkdir(parents=True,exist_ok=True);P=ROOT/'entrega/KK01_Modelo_Integrado_V03.xlsx';out=folder/'KK01_Painel_Executivo_V03.xlsx';N='http://schemas.openxmlformats.org/spreadsheetml/2006/main';tag=lambda s:'{'+N+'}'+s
import openpyxl
values=openpyxl.load_workbook(P,data_only=True,read_only=True);source=openpyxl.load_workbook(P,data_only=False,read_only=True)
locale_cells={}
for row in values['EXEC KK01']:
 for c in row:
  if isinstance(c.value,(int,float)):
   fmt=source['EXEC KK01'][c.coordinate].number_format
   val=c.value*100 if '%' in fmt else c.value
   txt=f'{val:,.2f}'.replace(',','X').replace('.',',').replace('X','.')
   txt+= '%' if '%' in fmt else ' €' if '€' in fmt else 'x' if 'x' in fmt else ''
   locale_cells[c.coordinate]=txt
locale_cells['A3']=str(values['EXEC KK01']['A3'].value).replace('.0 M€',',0 M€')
values.close();source.close()
with zipfile.ZipFile(P) as zi,zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as zo:
 w=E.fromstring(zi.read('xl/workbook.xml'));rels=E.fromstring(zi.read('xl/_rels/workbook.xml.rels'));targets={x.attrib['Id']:x.attrib['Target'] for x in rels};path=None
 for i,s in enumerate(w.find(tag('sheets'))):
  if s.attrib['name']=='EXEC KK01':
   s.set('state','visible');t=targets[s.attrib['{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id']];path=t.lstrip('/') if t.startswith('/') else 'xl/'+t;idx=i
  else:s.set('state','hidden')
 names=w.find(tag('definedNames'))
 for x in list(names):
  if x.attrib.get('name')=='_xlnm.Print_Area':names.remove(x)
 E.SubElement(names,tag('definedName'),{'name':'_xlnm.Print_Area','localSheetId':str(idx)}).text="'EXEC KK01'!$A$1:$P$68"
 for inf in zi.infolist():
  data=zi.read(inf.filename)
  if inf.filename=='xl/workbook.xml':data=E.tostring(w,encoding='utf-8',xml_declaration=True)
  if inf.filename==path:
   root=E.fromstring(data)
   for c in root.findall('.//'+tag('c')):
    if c.attrib.get('r') in locale_cells:
     for ch in list(c):c.remove(ch)
     c.set('t','inlineStr');E.SubElement(E.SubElement(c,tag('is')),tag('t')).text=locale_cells[c.attrib['r']]
   for el in list(root):
    if el.tag in [tag('legacyDrawing'),tag('legacyDrawingHF')]:root.remove(el)
   ps=root.find(tag('pageSetup'))
   if ps is None:ps=E.SubElement(root,tag('pageSetup'))
   for k,v in {'paperSize':'8','orientation':'portrait','fitToWidth':'1','fitToHeight':'1','cellComments':'none'}.items():ps.set(k,v)
   sf=root.find(tag('sheetPr'))
   if sf is None:sf=E.Element(tag('sheetPr'));root.insert(0,sf)
   pp=sf.find(tag('pageSetUpPr'))
   if pp is None:pp=E.SubElement(sf,tag('pageSetUpPr'))
   pp.set('fitToPage','1');data=E.tostring(root,encoding='utf-8',xml_declaration=True)
  if inf.filename==path.rsplit('/',1)[0]+'/_rels/'+path.rsplit('/',1)[1]+'.rels':
   rr=E.fromstring(data)
   for rel in list(rr):
    if rel.attrib['Type'].endswith('/comments') or rel.attrib['Type'].endswith('/vmlDrawing'):rr.remove(rel)
   data=E.tostring(rr,encoding='utf-8',xml_declaration=True)
  if inf.filename.startswith('xl/charts/') and inf.filename.endswith('.xml'):
   cr=E.fromstring(data)
   for axis in cr.findall('.//{http://schemas.openxmlformats.org/drawingml/2006/chart}valAx'):
    for num in axis.findall('{http://schemas.openxmlformats.org/drawingml/2006/chart}numFmt'):num.set('formatCode','0,," M€"');num.set('sourceLinked','0')
   data=E.tostring(cr,encoding='utf-8',xml_declaration=True)
  zo.writestr(inf,data)
profile=folder/'profile/user';profile.mkdir(parents=True,exist_ok=True);(profile/'registrymodifications.xcu').write_text('''<?xml version="1.0"?><oor:items xmlns:oor="http://openoffice.org/2001/registry"><item oor:path="/org.openoffice.Setup/L10N"><prop oor:name="ooLocale" oor:op="fuse"><value>pt-PT</value></prop></item></oor:items>''')
p=subprocess.run(['soffice','-env:UserInstallation='+(folder/'profile').as_uri(),'--headless','--convert-to','pdf:calc_pdf_Export','--outdir',str(ROOT/'entrega'),str(out)],capture_output=True,text=True,timeout=420);print(p.returncode,p.stdout,p.stderr[-500:]);assert (ROOT/'entrega/KK01_Painel_Executivo_V03.pdf').exists()
