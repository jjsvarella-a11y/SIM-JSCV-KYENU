"""Arranjo de cinco KPI adicionais sem truncagem; preserva os cálculos auditados."""
from pathlib import Path
import zipfile,xml.etree.ElementTree as E,os,json,openpyxl,posixpath
ROOT=Path(__file__).resolve().parents[1];P=ROOT/'entrega/KK01_Modelo_Integrado_V03.xlsx';M=json.loads((ROOT/'src/build_metadata.json').read_text());N='http://schemas.openxmlformats.org/spreadsheetml/2006/main';tag=lambda s:'{'+N+'}'+s
w=openpyxl.load_workbook(P,data_only=True,read_only=True)
items=[(43,'A','Capacidade bancária remanescente','E',"'KPI'!B"+str(M['kpi_rows']['unused']),w['KPI'].cell(M['kpi_rows']['unused'],2).value),(43,'I','JSCV — dois Platinum','M',"'Capital V03'!B8",w['Capital V03']['B8'].value),(45,'A','JALS','E',"'Capital V03'!B9",w['Capital V03']['B9'].value),(45,'I','CFADS Hotel ano 4','M',"'Anual'!J8",w['Anual']['J8'].value),(47,'A','Retorno agregado promotores 15A','E',"'Retornos'!C21",w['Retornos']['C21'].value)];w.close()
with zipfile.ZipFile(P) as zi,zipfile.ZipFile(P.with_suffix('.tmp'),'w',zipfile.ZIP_DEFLATED) as zo:
 book=E.fromstring(zi.read('xl/workbook.xml'));rels=E.fromstring(zi.read('xl/_rels/workbook.xml.rels'));rid=next(s for s in book.find(tag('sheets')) if s.attrib['name']=='EXEC KK01').attrib['{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id'];t=next(r for r in rels if r.attrib['Id']==rid).attrib['Target'];path=t.lstrip('/') if t.startswith('/') else 'xl/'+t
 relpath=posixpath.dirname(path)+'/_rels/'+posixpath.basename(path)+'.rels';notes=set();vml=set()
 if relpath in zi.namelist():
  for x in E.fromstring(zi.read(relpath)):
   if x.attrib['Type'].endswith('/comments'):
    t=x.attrib['Target'];notes.add(t.lstrip('/') if t.startswith('/') else posixpath.normpath(posixpath.join(posixpath.dirname(path),t)))
 if relpath in zi.namelist():
  for x in E.fromstring(zi.read(relpath)):
   if x.attrib['Type'].endswith('/vmlDrawing'):
    t=x.attrib['Target'];vml.add(t.lstrip('/') if t.startswith('/') else posixpath.normpath(posixpath.join(posixpath.dirname(path),t)))
 for inf in zi.infolist():
  data=zi.read(inf.filename)
  if inf.filename==path:
   root=E.fromstring(data);sd=root.find(tag('sheetData'));merges=root.find(tag('mergeCells'));labelstyle=root.find('.//'+tag('c')+'[@r="A43"]').attrib.get('s');eurstyle=(root.find('.//'+tag('c')+'[@r="B43"]') if root.find('.//'+tag('c')+'[@r="B43"]') is not None else root.find('.//'+tag('c')+'[@r="E43"]')).attrib.get('s');pctstyle=(root.find('.//'+tag('c')+'[@r="B44"]') if root.find('.//'+tag('c')+'[@r="B44"]') is not None else root.find('.//'+tag('c')+'[@r="M43"]')).attrib.get('s')
   for rr in range(43,48):
    row=sd.find(tag('row')+'[@r="'+str(rr)+'"]')
    if row is not None:
     for c in list(row):row.remove(c)
   for rr,lc,label,vc,f,v in items:
    assert isinstance(v,(int,float)),(label,v)
    row=sd.find(tag('row')+'[@r="'+str(rr)+'"]')
    if row is None:row=E.SubElement(sd,tag('row'),{'r':str(rr)})
    row.set('ht','24');row.set('customHeight','1')
    c=E.SubElement(row,tag('c'),{'r':lc+str(rr),'t':'inlineStr','s':labelstyle});E.SubElement(E.SubElement(c,tag('is')),tag('t')).text=label
    c=E.SubElement(row,tag('c'),{'r':vc+str(rr),'s':pctstyle if label.startswith('JSCV') or label=='JALS' else eurstyle});E.SubElement(c,tag('f')).text=f;E.SubElement(c,tag('v')).text=str(v)
    for a,b in [(lc,{'A':'D','I':'L'}[lc]),(vc,{'E':'H','M':'P'}[vc])]:
     ref=f'{a}{rr}:{b}{rr}'
     if not any(m.attrib['ref']==ref for m in merges):E.SubElement(merges,tag('mergeCell'),{'ref':ref})
   merges.set('count',str(len(merges)));data=E.tostring(root,encoding='utf-8',xml_declaration=True)
  if inf.filename in notes:
   comments=E.fromstring(data);moved={'B43':'E43','B44':'M43','B45':'E45','B46':'M45','B47':'E47'}
   for c in comments.findall('.//'+tag('comment')):
    if c.attrib.get('ref') in moved:c.set('ref',moved[c.attrib['ref']])
   data=E.tostring(comments,encoding='utf-8',xml_declaration=True)
  if inf.filename in vml:
   vr=E.fromstring(data);V='{urn:schemas-microsoft-com:vml}';X='{urn:schemas-microsoft-com:office:excel}';coords={(42,1):(42,4),(43,1):(42,12),(44,1):(44,4),(45,1):(44,12),(46,1):(46,4)}
   for shape in vr.findall('.//'+V+'shape'):
    st=shape.attrib.get('style','');import re
    st=re.sub(r'visibility:[^;]+','visibility:hidden',st)
    if 'visibility:' not in st:st+=';visibility:hidden'
    shape.set('style',st);client=shape.find(X+'ClientData')
    if client is not None:
     rr=client.find(X+'Row');cc=client.find(X+'Column')
     if rr is not None and cc is not None and (int(rr.text),int(cc.text)) in coords:rr.text,cc.text=map(str,coords[(int(rr.text),int(cc.text))])
     for flag in list(client):
      if flag.tag==X+'Visible':client.remove(flag)
   data=E.tostring(vr,encoding='utf-8',xml_declaration=True)
  zo.writestr(inf,data)
os.replace(P.with_suffix('.tmp'),P)
