from pathlib import Path
import zipfile,xml.etree.ElementTree as E,json,os
ROOT=Path(__file__).resolve().parents[1];P=ROOT/'entrega/KK01_Modelo_Integrado_V03.xlsx';PR=json.loads((ROOT/'src/build_metadata.json').read_text())['param_rows'];N='http://schemas.openxmlformats.org/spreadsheetml/2006/main';tag=lambda s:'{'+N+'}'+s
pv=lambda k:"'Pressupostos'!$B$"+str(PR[k]);updates={'Fluxos Retorno':{},'Retornos':{},'Retorno Socios':{}}
for m in range(181):
 r=m+5;fr=m+4;weight='+'.join(f'IF(A{r}={pv("fund_month"+str(j))},{pv("fund_part"+str(j))},0)' for j in [1,2,3])
 for col,h in [('D',120),('E',180)]:
  rc='B' if h==120 else 'C';f=f'-{pv("historic")}' if m==0 else '0' if m>h else f"'Fluxo 180M'!AD{fr}*'Retornos'!{rc}20+'Capital V03'!B11*({weight})+'Fluxo 180M'!AV{fr}+'Fluxo 180M'!AW{fr}"
  if m==h:f+=f"+'Retornos'!{rc}11*'Retornos'!{rc}20+'Fluxo 180M'!AX{fr}"
  updates['Fluxos Retorno'][f'{col}{r}']=f
for col,h in [('B',120),('C',180)]:updates['Retornos'][f'{col}21']=f"({col}11+{col}12)*{col}20+'Capital V03'!B11+SUM('Fluxo 180M'!AV5:AW{h+4})+'Fluxo 180M'!AX{h+4}"
for col in ['B','C']:updates['Retornos'][f'{col}17']=f"{col}16-('Ronda Investidores'!B20-{pv('conversion')})*{pv('received_ratio')}"
src="IF('Capital V03'!B7>0,(51%-'Capital V03'!B8)/'Capital V03'!B7,0)"
for r,ratio in [(5,src),(6,'(1-'+src+')')]:updates['Retorno Socios'][f'E{r}']=f"('Capital V03'!B11+SUM('Fluxo 180M'!AV5:AW184)+'Fluxo 180M'!AX184)*({ratio})"
with zipfile.ZipFile(P) as zi,zipfile.ZipFile(P.with_suffix('.tmp'),'w',zipfile.ZIP_DEFLATED) as zo:
 w=E.fromstring(zi.read('xl/workbook.xml'));rels=E.fromstring(zi.read('xl/_rels/workbook.xml.rels'));targets={x.attrib['Id']:x.attrib['Target'] for x in rels};paths={}
 for s in w.find(tag('sheets')):
  t=targets[s.attrib['{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id']];paths[s.attrib['name']]=t.lstrip('/') if t.startswith('/') else 'xl/'+t
 for inf in zi.infolist():
  data=zi.read(inf.filename)
  for name,changes in updates.items():
   if inf.filename==paths[name]:
    root=E.fromstring(data)
    for addr,f in changes.items():
     c=root.find('.//'+tag('c')+'[@r="'+addr+'"]');c.attrib.pop('t',None)
     for ch in list(c):c.remove(ch)
     E.SubElement(c,tag('f')).text=f
    data=E.tostring(root,encoding='utf-8',xml_declaration=True)
  zo.writestr(inf,data)
os.replace(P.with_suffix('.tmp'),P)
