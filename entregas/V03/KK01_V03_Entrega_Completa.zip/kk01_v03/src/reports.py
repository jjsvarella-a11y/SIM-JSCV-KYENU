from engine import *
import openpyxl,json,collections,datetime,html
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,PageBreak
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
OUT=ROOT/'entrega';r=run();s=summary(r);s10=summary(r,120)
def num(v,d=2):
 if v is None:return 'não definida'
 return f'{v:,.{d}f}'.replace(',','X').replace('.',',').replace('X','.')
def eur(v):return num(v)+' €'
def pct(v):return num(v*100)+'%' if v is not None else 'não definida'
M=json.loads((ROOT/'src/build_metadata.json').read_text())

AUD=f'''# KK-01 — Relatório de auditoria e reconstrução técnica

Data: 17/10/2026. Fonte: KK_V45_Etapas_ABC_Dashboards_Auditoria_FINAL.xlsx. SHA-256: `{SOURCE['source_sha256']}`.

## Conclusão e alcance

O modelo foi reconstruído num único motor de 180 meses, com demonstrações autónomas Hotel + MICE e residencial, síntese anual, retornos e cinco dashboards nativos Excel. A conformidade técnica não é aprovação económica, bancária, jurídica ou fiscal. A viabilidade dos cenários continua condicionada às confirmações identificadas. As alterações são efetuadas num novo ficheiro; o original foi preservado integralmente.

## Etapa A — análise integral da V45

- 70 folhas; {SOURCE['formula_count']:,} fórmulas; {SOURCE['formula_edges']:,} dependências entre células com fórmulas nas referências A1 suportadas.
- Zero ligações externas de workbook encontradas; zero ciclos no grafo A1 expandido analisado. Não se afirma auditoria universal de referências indiretas dinâmicas: OFFSET/INDIRECT, nomes e semântica de macros requereriam análise adicional; o novo modelo evita essas funções e macros.
- 510 registos de erro em cache, 5 fórmulas com sintaxe `IF(=...)` e 12 fórmulas rejeitadas pelo parser na matriz de fees. Estes são registos de deteção, não 527 erros económicos independentes. Algumas caches contêm mensagens de motor anterior (por exemplo OFFSET não implementado); não se confundem com uma certificação de erro no Excel nativo.
- Os ficheiros Inventario_V45.csv, Erros_V45.csv e Dependencias_V45.json incluem o inventário completo, células, fórmulas e dependências.
- 94 IDs distintos, 13.290 m², todas as áreas totais iguais a interior + varanda. Preços de origem somam {eur(SOURCE['vgv_source'])}; preços por fração a cêntimos somam exatamente {eur(SOURCE['vgv_cents'])}. A precisão de origem é preservada numa coluna própria.
- Os 30 capítulos somam 100% de incidência; os pesos mensais de cada capítulo somam 100%. Construção + FF&E inicial: 56,4 M€; fiscalização: 1,128 M€; contingência integralmente utilizada no cenário prudente: 5,64 M€. Saída futura de CAPEX: 63,168 M€, antes de HOTUSA, comercialização e financiamento.

## Etapa B — correções e consolidação

| Tema | Correção | Estado |
|---|---|---|
| Motores concorrentes | Substituídos por Fluxo 180M e blocos de cenário com as mesmas fórmulas | Conforme |
| Recebimentos | 5% + 20% + 55% nos semestres disponíveis + saldo final exato; última prestação absorve cêntimos | Conforme no calendário de referência |
| Arredondamento | Python alinhado com ROUND de Excel, em vez de arredondamento bancário nativo de Python | Conforme |
| Datas sem semestre disponível | Não se inventa antecipação dos 55%; diferença de recebimentos e alerta de calendário permanecem visíveis | Alerta se o utilizador escolher calendário incompatível |
| 504 e 810 | Mês 29 mantido como hipótese herdada; controlo próprio impede considerá-lo validado | Pendente de Validação Externa |
| Custos comerciais | Imposto na escritura; marketing e Kyenu no contrato, separados e ligados ao caixa | Conforme tecnicamente; incidência fiscal pendente |
| Histórico do Grupo | 4,5 M€ excluídos das saídas futuras; base histórica só nos retornos dos promotores | Conforme |
| HOTUSA | Seleção 0 / 0,5 / 1 M€; reserva por defeito, saída apenas por seletor explícito | Conforme; obrigação jurídica pendente |
| Contingência | Pagamento proporcional à realização; parcela não utilizada integra reserva, sem dupla saída | Conforme |
| Banco | Linha não renovável, desembolso por necessidade, juros sobre abertura + draw do mês | Conforme |
| Comissões | Abertura 1%, broker 1,5%, mobilização 1,25% no primeiro draw; sem fee se não houver financiamento | Hipóteses editáveis; contratos pendentes |
| Carência | 42 meses na referência, juros pagos; 120 meses adicionais de capital após carência | Conforme tecnicamente |
| Amortização | Capital igual sobre saldo e meses restantes, recalculado após sweep; sem penalização | Método negocial por confirmar |
| Reservas | Mínimo operacional, buffer obra, riscos reservados e colchão pré-abertura para FM/juros | Conforme no cenário de referência |
| Défices | Caixa não é artificialmente limitada a zero nem coberta por dívida inexistente | Conforme |
| DSCR | CFADS Hotel dividido por juros + capital obrigatório; antecipações excluídas | Conforme |
| Hotel | 200 quartos; MICE e F&B segregados; projeção 294 unidades não usada como Hotel | Conforme tecnicamente; forecast por validar |
| CFADS | Removido piso MAX(0); fundo de maneio inicial e perdas aparecem no caixa | Conforme |
| Residencial | Pool 94 separado; yield alvo limitado à caixa, residual KK uma vez | Direitos e segmentação pendentes |
| Equity | Proporção exata 40% / 15 M€; direitos pós entrada não presumidos como aprovados | Conforme como cenário; societário pendente |
| Saída | EBITDA Hotel últimos 12 meses × múltiplo; custos/dívida deduzidos, caixa somada uma vez | Avaliação estimada, não garantia |
| TIR | Vetores de caixa explícitos, juros mensais anualizados; projeto e equity separados | Conforme nas raízes numéricas testadas |

## Etapa C — apresentação e utilização

Cinco dashboards: Real Estate, Comercial, Hotel + MICE, Acionistas e Consolidado. Gráficos nativos, tabelas filtráveis, células azuis editáveis, notas em inputs e KPI e alertas financeiros. O Comercial combina ID, tipologia, piso, mês e trimestre; curvas mensais 30M, detalhe 180M e vendas/recebimentos trimestrais. As cores de condições bancárias favoráveis não significam aprovação do banco.

## Decisões de modelação que exigem confirmação

1. Operação a partir do mês 31, após obra de 30 meses; a V45 usava mês 30. É convenção operacional transparente e editável, não alteração contratual aprovada.
2. Reservar HOTUSA até existir resolução; não presumir dívida nem libertar automaticamente a reserva.
3. Imputar CAPEX residencial pela proporção 13.290 / 47.000 como proxy, sem afirmar margem contabilística certificada. Áreas comuns e orçamento por componente faltam.
4. Banco não renovável; draw até mês 30; juros de mês inteiro sobre abertura + draw; fee sobre facilidade na primeira utilização; amortização por capital constante remanescente. Confirmar term sheet e contratos.
5. FM de 15 dias de receitas e segregação MICE 50% espaços / 35% banquetes / 15% serviços são hipóteses explícitas adicionais.
6. Residual KK do pool residencial (45% antes de imposto) e renda moderada inicial 4,25% preservam a lógica V45, mas não constituem garantia de yield ou direito de distribuição aprovado.
7. Ponte JSCV/JALS pro rata é apenas ilustração. Classes Platinum, Gold, Silver Plus e Silver mantidas como pendências sem inventar quantidades ou direitos.
8. Conversão ações/fração é mecanismo piloto alternativo, com capital e recebimentos reduzidos, sem garantia de recompra. Não modela automaticamente votação, tributação ou contratos de cancelamento.

## Riscos externos e limitações

Fiscalidade Cabo Verde (IVA, incidência de transmissão, imposto da promoção, amortizações e compensação de perdas), licenças/escrituras, HMA, custos de mobilização e dupla incidência de comissões, forecast operacional e rendimento dos apartamentos, orçamento segmentado, direitos acionistas e avaliação de saída dependem de documentação externa. O imposto de exploração é proxy de 20% sobre EBITDA menos reposições; não é declaração fiscal nem leva escudo de juros. O impacto de impostos adicionais não quantificados exige cenário específico antes de financiar ou investir.

O retorno dos promotores usa 4,5 M€ no mês 0 como proxy, porque faltam datas históricas efetivas. A TIR real histórica não foi certificada. Os retornos dos novos investidores são condicionais quando faltam reservas ou financiamento. A sensibilização ADR/ocupação escala custos variáveis; custos fixos não foram documentados separadamente. Os contratos de venda e arrendamento não acompanham a fonte: não se validam cláusulas por inferência.

## Testes

Consultar Resultados_Testes.txt e Testes_Seletores.json: resultado executado, não apenas comandos propostos. O confronto é feito entre o motor Python e as fórmulas recalculadas por LibreOffice, com verificação de erros do ficheiro inteiro e de 23 cenários completos. Não foi executado Microsoft Excel neste ambiente. Ficheiro OOXML sem macros; fórmulas, validações e gráficos nativos são preservados e inspecionados.
'''

rows=[]
for eq in [0,5e6,10e6,15e6]:
 for hn in HOTELS:
  t=summary(run(config(equity=eq,hotel=hn)));rows.append(f'| {num(eq/1e6,0)} | {hn} | {num(t["peak"]/1e6)} | {num(t["funding_gap"]/1e6)} | {num(t["reserve_gap"]/1e6)} | {num(t["min_dscr"])} |')
full=[x['dscr'] for x in s['annual'] if x['year']>=4 and x['dscr'] is not None]
newnpv=sum((-x['equity']+x['dividend']*.4)/1.12**(x['m']/12) for x in r['flow'])+s['exit_equity']*.4/1.12**15
EXEC=f'''# KK-01 — Relatório executivo de viabilidade

Referência de cálculo: 17/10/2026. Euros nominais; meses relativos. Resultados de cenário, não garantia ou recomendação de investimento.

## Conclusão

No cenário reconstruído com 15 M€ de capital novo, banco Limite aceitável (6%, 42 meses de carência, 10 anos de amortização após carência), Hotel Favorável e residual residencial da V45, o fluxo não apresenta caixa negativa nem insuficiência das reservas definidas. Contudo, a facilidade bancária não renovável fica praticamente esgotada: são utilizados cumulativamente {eur(r['flow'][-1]['cumulative'])}, deixando apenas {eur(DEFAULT['limit']-r['flow'][-1]['cumulative'])} dos 30 M€ por utilizar, dentro da janela contratual assumida. O projeto precisa de condições de utilização e calendarização das vendas compatíveis com esta exigência.

O retorno estimado dos novos investidores é {pct(s['equity_irr'])} ao ano a 15 anos, MOIC {num(s['moic'])}x, incluindo saída estimada. É inferior à taxa de desconto de equity de 12%: VPL dos novos investidores {eur(newnpv)}. Portanto, o modelo não demonstra automaticamente uma remuneração atrativa para essa exigência de retorno, apesar do VPL incremental positivo do projeto. Rentabilidade do projeto e rentabilidade da nova ronda são diferentes devido à participação negociada de 40% por 15 M€.

## Indicadores de referência

| Indicador | Resultado |
|---|---:|
| VGV 94 frações | {eur(SOURCE['vgv_cents'])} |
| Vendas líquidas de custos comerciais | {eur(SOURCE['vgv_cents']-sum(sum(r['re'][k]) for k in ['tax','marketing','kyenu']))} |
| Construção + FF&E inicial | 56.400.000,00 € |
| Fiscalização + contingência paga | 6.768.000,00 € |
| CAPEX futuro | 63.168.000,00 € |
| Reserva HOTUSA, sem pagamento presumido | 1.000.000,00 € |
| Capital novo | 15.000.000,00 € |
| Pico de dívida intramês | {eur(s['peak'])} |
| Utilização acumulada não renovável | {eur(r['flow'][-1]['cumulative'])} |
| Dívida mês 30 | {eur(s['debt30'])} |
| Caixa mês 30, incluindo colchão abertura | {eur(s['cash30'])} |
| Dívida mês 42 | {eur(s['debt42'])} |
| Caixa mês 42 | {eur(s['cash42'])} |
| Caixa mínima | {eur(s['cash_min'])} |
| Juros 180 meses | {eur(s['interest'])} |
| Comissões banco e broker | {eur(s['fees'])} |
| Dívida liquidada no cenário | mês {next(x['m'] for x in r['flow'] if x['m']>30 and x['debt']==0)} |
| DSCR ano 3 parcial, com juros construção | {num(s['annual'][2]['dscr'])}x |
| DSCR mínimo anos completos com serviço | {num(min(full))}x |
| Caixa final | {eur(s['cash_end'])} |
| Dividendos totais 15A | {eur(s['dividends'])} |
| VPL incremental projeto sem saída (10%) | {eur(s['npv_project'])} |
| VPL incremental projeto com saída (10%) | {eur(s['npv_project_exit'])} |
| TIR incremental projeto sem saída | {pct(irr([0]+[x['project_cf'] for x in r['flow']]))} |
| TIR novos investidores 10A | {pct(s10['equity_irr'])} |
| TIR novos investidores 15A | {pct(s['equity_irr'])} |
| MOIC novos investidores 10A / 15A | {num(s10['moic'])}x / {num(s['moic'])}x |
| EV Hotel 15A, a 9x EBITDA | {eur(s['ev'])} |
| Valor de saída do equity total estimado | {eur(s['exit_equity'])} |

O DSCR parcial de {num(s['annual'][2]['dscr'])}x fica abaixo do limiar indicativo de 1,30x, porque o ano 3 contém juros de construção e seis meses de operação. No mês de abertura, a constituição de fundo de maneio torna o CFADS negativo; o colchão pré-abertura cobre esse consumo. Não se deve apresentar uma série anual madura como se eliminasse esse risco inicial.

## Comparação de capital e operação

| Equity M€ | Hotel | Pico dívida M€ | Défice caixa máx. M€ | Falta reserva máx. M€ | DSCR mínimo com ano parcial |
|---:|---|---:|---:|---:|---:|
'''+ '\n'.join(rows)+f'''

Com 0 ou 5 M€ de capital aparecem défices efetivos não financiados; 10 M€ evita caixa negativa nos cenários testados, mas não cumpre todas as reservas. Com 15 M€, os cenários Base e Conservador mantêm liquidez sob as reservas definidas, embora a cobertura do ano parcial permaneça inferior. Isto não substitui teste a atraso de vendas, sobrecusto adicional ao orçamento prudente ou fiscalidade real.

## Condições necessárias ao sucesso

- Capital novo efetivamente disponível no mês 1; cobrança integral do calendário das 94 frações e confirmação jurídica das escrituras, especialmente 504/810.
- Facilidade próxima de 30 M€ com mobilização e utilização durante construção, juros pagos, carência adequada e antecipação sem penalização.
- Não distribuir caixa protegida; não confundir limite menos pico de dívida com disponibilidade da linha não renovável.
- Comprovar receitas/custos Hotel + MICE e contratos do pool residencial; reexecutar sem residual residencial se o direito da KK não for confirmado.
- Negociar e confirmar remuneração Operador Internacional (3% base + 3% sistemas + 6% incentivo como referência), sem sobreposição de encargos e com performance test.
- Confirmar impostos, IVA, custos do Grupo e orçamento segmentado; os montantes não quantificados podem consumir a reduzida disponibilidade bancária.
- Rever preço de entrada, participação, distribuição e/ou criação de valor se a nova ronda exigir 12% ou mais de TIR. Nenhuma alteração estratégica foi aprovada pelo modelo.

## Saída e acionistas

O EV de saída é EBITDA dos últimos 12 meses Hotel + MICE × múltiplo editável, menos custos de transação. Deduz-se dívida, soma-se caixa uma vez e retêm-se riscos HOTUSA e contingência reservada. Apartamentos vendidos e fundos restritos não são somados. O múltiplo 9x não é avaliação independente nem compromisso de compra. Uma parte relevante do retorno depende desse valor de saída; o modelo mostra VPL do projeto sem saída separadamente.

JSCV/JALS mantêm apenas uma ponte de diluição ilustrativa; não foram alterados direitos societários. O retorno dos promotores usa a base histórica de 4,5 M€ com data proxy; exige datas reais para calcular TIR histórica válida. Não se criam garantias de yield, reembolso de capital ou liquidez das ações.
'''

DOC=f'''# KK-01 — Documentação técnica e utilização

## Conteúdo do pacote

- KK01_Modelo_Integrado.xlsx: único ficheiro de cálculo; 180 meses, 15 anos, cinco dashboards.
- V45_original.xlsx: cópia preservada; hash no relatório de auditoria e manifest.
- Auditoria.md / .pdf; Viabilidade_Executiva.md / .pdf; Documentacao_Tecnica.md / .pdf.
- Inventario_V45.csv, Erros_V45.csv e Dependencias_V45.json: análise integral da fonte.
- src/: código de reconstrução, fonte estruturada, metadados e testes. Resultados_Testes.txt / .json e Testes_Seletores.json registam execuções.

## Mapa e fluxo de dados

Pressupostos e Cenarios → Unidades + Obra → Recebimentos / Imobiliario / CAPEX; Cenarios + Pressupostos → Hotel; Pressupostos + pricing → Residencial. Todos convergem em Fluxo 180M. Anual, KPI, Retornos, Investidores e dashboards usam esse motor. AUDITORIA contém controlos vivos. Origem e Alteracoes e Mapa V45 documentam migração. Listas e CalcH01–23 / CalcF01–23 são folhas de apoio ocultas, sem motores económicos alternativos: cada bloco usa as mesmas regras do cenário principal.

Comparacao contém 12 combinações 0/5/10/15 M€ × Conservador/Base/Favorável, três cenários bancários e oito taxas de juro. Pressupostos comuns propagam-se aos blocos. Quando equity/operação de uma linha estão explicitamente fixados para comparação, não seguem o seletor correspondente: essa é a dimensão comparada. As restantes hipóteses seguem o centro de pressupostos. Sensibilidade é uma proxy operacional 3×3 e valorização 7x/9x/11x, não um refinanciamento automático.

## Recebimentos das frações

Preço operacional = ROUND(preço origem; 2). Sinal = ROUND(preço cobrável × 5%; 2). Tranche = ROUND(preço cobrável × 20%; 2). Progressivos = ROUND(preço cobrável × 55%; 2). N = MAX(0; INT((mês escritura − mês tranche − 1) / 6)). Progressivos regulares = ROUND(55% / N; 2); última prestação absorve diferença. Escritura = preço cobrável − sinal − tranche − progressivos. Não se inventa um semestre se N = 0: calendário e recebimentos deixam de reconciliar e devem ser corrigidos com base no contrato. Datas fora de 180 meses não são válidas.

A primeira tranche usa mês venda + atraso central. Os 5% e 20% são separados no detalhe, mas agregados em 25% no gráfico comercial. Sinal no mês venda, prestação semestral antes da escritura; a escritura não substitui silenciosamente os 55%. A soma dos quatro percentuais é controlada à parte, apesar de o saldo final ser complemento.

## CAPEX, reservas e financiamento

Orçamento base = área × €/m² × incidência capítulo; distribuição por pesos originais de 30 meses. Fiscalização 2%; contingência 10% × realização. Histórico 4,5 M€ não é saída futura.

Reserva mensal = MAX(2 M€; próximos 3 meses CAPEX durante obra) + HOTUSA não paga + contingência não realizada + colchão pré-abertura (até mês 30). Colchão = MAX(0; −CFADS Hotel mês abertura −residual KK mês abertura + linha × juro / 12). Os parâmetros são editáveis. HOTUSA reservado não reduz caixa como pagamento. O fundo FF&E Hotel e fundos do pool estão fora da caixa distribuível; o fundo Hotel só cresce se utilização for inferior à dotação.

Caixa disponível antes banco = caixa inicial + capital novo + recebimentos + CFADS Hotel + residual KK − CAPEX − custos comerciais − HOTUSA efetivamente paga.

Capital contratual = saldo inicial / meses restantes até maturidade, apenas após carência, limitado ao saldo. A referência usa maturidade mês 162 (=42+10×12). Desembolso D = MIN(linha ainda não utilizada; MAX(0; [reserva − caixa disponível + capital obrigatório + saldo inicial×i + fees primeira utilização] / (1−i))), i = taxa anual/12. Juros = (saldo inicial + D) × i. O desembolso do início do mês suporta um mês inteiro de juros; não se presume cronograma diário.

Abertura, broker e mobilização são pagas apenas na primeira utilização. Na referência incidem sobre 30 M€ e totalizam 1,125 M€; isso carece de contratos e teste de eventual sobreposição. Ausência de utilização implica zero success fee. A facilidade não é renovável e fecha para novos desembolsos após mês 30; amortizar não reabre limite.

Sweep = mínimo entre dívida disponível, excedente após reservas × sweep e limite de caixa proveniente de vendas líquidas durante obra. Proteção futura adicional considera CAPEX futuro menos cobranças líquidas futuras e linha ainda não utilizada. Após a obra, o excesso operacional pode amortizar. Dividendos: apenas fecho anual, dívida liquidada, sem défice anterior e caixa excedente às reservas × payout. Não se pressupõe aprovação legal de dividendos nem existência de reservas distribuíveis contabilísticas.

## Hotel e residencial

Hotel: 200 quartos × 365/12 × ADR × ocupação. ADR e ocupação evoluem por aniversário operacional, com teto de ocupação. MICE e outras receitas usam rácios da V45 por cenário; subdivisão em categorias é hipótese editável. F&B exclui banquetes já incluídos no MICE. GOP = receita − custos departamentais − gerais. EBITDA = GOP − base − sistemas − incentivo. Incentivo = MAX(0; GOP − base − sistemas) × taxa. CFADS = EBITDA − dotação FF&E − CAPEX adicional − imposto proxy − variação FM. Não há piso zero.

Residencial: 94 frações, ADR/ocupação próprios. Caixa do pool após OPEX, fees fixos, dotação FF&E e FM financia renda alvo; a renda efetiva não excede caixa disponível. Excedente positivo é repartido em fundo 20%, Kyenu 15%, operador 20% e KK 45% antes de imposto. Não se repete incentivo de 10% antes da mesma waterfall. Dotações e residual podem ser negativos quando o pool perde caixa; a consolidação não oculta perdas. Não se incluem receitas/ativos do pool como se fossem receita Hotel.

## KPI e retornos

DSCR Hotel = CFADS Hotel / (juros + principal contratual). DSCR total inclui residual KK, apresentado separado. Quando não há serviço, rácio vazio, nunca 999. Ano parcial e anos completos são distinguidos. LTV é dívida / valor Hotel por múltiplo, portanto indicativo e vazio sem EBITDA. Dívida líquida/EBITDA = (dívida − caixa) / EBITDA; fundos restritos não entram em caixa.

VPL projeto = desconto mensal equivalente de 10% anual sobre fluxo incremental não alavancado, excluindo histórico afundado; versões sem saída e com saída separadas. TIR projeto usa o mesmo fluxo nominal. Fluxos de venda podem ser positivos antes de CAPEX e ter múltiplas mudanças de sinal; teste numérico procura raízes numa grelha de taxas mensais logarítmicas de −0,1 a 0,5, não prova unicidade em todo o domínio matemático.

MOIC novos investidores = (dividendos atribuídos + saída atribuída) / capital novo líquido. TIR é mensal anualizada, com aporte mês 1 e saída no mês 120/180. VPL equity usa 12%. Payback projeto usa última recuperação do fluxo acumulado sem saída; payback investidor usa apenas dividendos e capital próprio, sem valor terminal. Histórico entra separadamente na proxy dos promotores, no mês 0; sem datas reais não é retorno histórico certificado.

EV saída = EBITDA Hotel últimos 12 meses × múltiplo. Equity value = MAX(0; EV×(1−custos saída) − dívida + caixa − reservas contingentes). Não se somam imóveis vendidos nem fundos pool/FF&E; caixa já retida por payout entra uma única vez. Tickets 1–15 M€ em Investidores são participações dentro da ronda selecionada, não recálculos de quinze estruturas diferentes; tickets acima do capital disponível ficam fora da ronda. As rondas 0/5/10/15 são recalculadas integralmente em Comparacao.

Conversão: abate ao preço cobrável da fração selecionada e ao novo aporte; participação nova diminui linearmente. Não pode exceder preço da fração nem capital. É mecanismo alternativo simplificado de liquidez, sujeito a deliberação e efeitos fiscais a modelar quando documentados.

## Como utilizar

1. Abrir com cálculo automático; em Excel usar Calcular Tudo se necessário. Números são numéricos com formatos de euro/percentagem/múltiplo; a vírgula decimal depende da configuração regional portuguesa do Excel.
2. Alterar células azuis em Pressupostos; escolher Personalizado para taxa 4,5%–8%, carência e 5/10/15/20 anos. Cenarios permite ajustar ADR, ocupação e rácios de receita por cenário.
3. Rever as 94 linhas de Unidades, especialmente meses de venda/escritura. Não escrever sobre fórmulas sem alterar os testes.
4. Filtrar DASH Comercial por ID, tipo, piso, mês e trimestre. Os filtros analíticos combinam-se; o AutoFiltro da tabela serve para navegar linhas e não substitui os seletores dos KPI.
5. Consultar AUDITORIA e Comparacao antes de interpretar TIR. Falha de reserva ou fonte não é sanada por retorno positivo.
6. Validar externamente HMA, term sheet, contratos de venda, fiscalidade, orçamento segmentado e direitos societários. Alterar a decisão estratégica apenas com suporte documental.

## Reprodução e regressão

Python 3, openpyxl, xlsxwriter, numpy, scipy e reportlab; versões exatas no pacote requirements.txt. Ficheiros fonte e original mantidos ao lado do código. Executar a partir da raiz do pacote, em ambiente já instalado:

```bash
python src/audit_source.py
python src/engine.py
python src/build_model.py
# Recalcular o Excel inteiro no Excel ou LibreOffice, incluindo hard recalc.
python src/test_model.py entrega/KK01_Modelo_Integrado.xlsx
```

O recálculo é obrigatório: caches escritos pelo gerador não constituem validação. O perfil LibreOffice de testes define OOXMLRecalcMode=0 (recalcular sempre), com verificação de seletores após mutação real do XML e comparação contra Python. O motor independente e os testes consideram a referência guardada em source.json; se forem aprovadas novas frações ou pressupostos base, atualizar a fixture de referência de forma explícita e repetir a auditoria, sem simplesmente aceitar um novo golden result.

A reconstrução trabalha na cópia existente do workspace; não cria worktrees. Não exige serviços web, credenciais ou macros. O código e outputs ficam fora do repositório SIM-JSCV-KYENU, cujos ficheiros não foram alterados. O pacote permite conservar o trabalho mesmo que a sessão termine.

## Critério de aceitação e o que não foi comprovado

Foi testada coerência técnica e capacidade de recalcular cenários. Não foi comprovada contratação bancária, validade jurídica de escrituras, realização de preços/vendas, forecast de operador, aprovação fiscal, direitos de classes, comprador de saída, retorno histórico real ou financiamento em data futura. Não foi executado Excel desktop. A aceitação financeira externa depende destes pontos e não pode ser inferida dos testes de software.
'''

# Evidence from completed executions, distinguished from scenario warnings.
tr=json.loads((OUT/'Resultados_Testes.json').read_text()) if (OUT/'Resultados_Testes.json').exists() else {}
sel=json.loads((OUT/'Testes_Seletores.json').read_text()) if (OUT/'Testes_Seletores.json').exists() else []
recheck=json.loads((OUT/'Reverificacao_Erros_V45.json').read_text()) if (OUT/'Reverificacao_Erros_V45.json').exists() else {}
AUD += f"""
## Reverificação dos 510 erros e resultado final dos testes

A referência desta verificação é 510 erros nos caches originais. Foram reencontradas as 510 células com erro nos caches originais. A análise estática registou 527 ocorrências em 515 células únicas: 510 caches, 5 fórmulas IF malformadas e 12 rejeições de parser (estas últimas sobrepõem-se a caches). Não se somam estes grupos como se fossem causas independentes.

No hard recalc da cópia original, 466 dos 510 caches não se reproduziram e 44 persistiram; 17 outras células passaram a revelar erro. Total: 61 códigos de erro, 60 #VALUE! e 1 #N/A. A célula DASH Viabilidade Final!B31 usa NA() intencionalmente para TIR não validada: não é ocultada nem classificada como fórmula quebrada. A listagem individual está em Reverificacao_Erros_V45.csv e os totais em Reverificacao_Erros_V45.json. A lista da sessão anterior não está disponível para comparação histórica célula a célula; esta é uma nova contagem verificável da V45 recebida.

Causas confirmadas: KK01 Caixa Mensal!J34 cria OFFSET com altura zero no fim da obra; a matriz V25 B31:D34 tem expressões inválidas; AUDIT Final Modelo!D4:D8 contém IF(=...); DASH Comercial Interativo!N22:N31 faz aritmética com trimestres em texto T01/T02 e N32 propaga o erro. Os módulos foram substituídos no novo motor, não corrigidos por valores fixos.

O ficheiro reconstruído passou {tr.get('tests',0)} testes principais, com {tr.get('failures',0)} falhas, {tr.get('errors',0)} erros e {tr.get('skipped',0)} testes saltados. Os {len(sel)} testes com mutações reais de seletores passaram: {sum(bool(x.get('ok')) for x in sel)} conformes, com {sum(x.get('comparisons',0) for x in sel):,} comparações numéricas. Incluem Hotel Conservador, capital 10 M€, juros personalizados 8%, pagamento HOTUSA, filtro ID 201 e alteração da venda da fração 201. No ficheiro inteiro reconstruído não foram encontrados códigos de erro de fórmula após recálculo. Isto não transforma pendências contratuais em conformidade.

A auditoria viva do cenário de referência contém 20 controlos Conformes, 2 Alertas (DSCR no ano parcial e yield residencial insuficiente no arranque) e 11 Pendentes de Validação Externa. São resultados de negócio distintos de falhas de software. O yield alvo do primeiro mês do pool excede a renda suportável em 164.946,24 €; a constituição de FM consome caixa, pelo que não se garante esse rendimento aos compradores.
"""
EXEC += """
## Alerta adicional — arranque do residencial

No mês 31, o objetivo de renda dos proprietários é 179.407,86 €, mas o caixa disponível depois de OPEX, fees, FF&E e constituição de fundo de maneio só permite 14.461,62 €. A diferença é 164.946,24 €. O modelo paga apenas o suportável, sem criar garantia inexistente. Se se pretender garantir o yield inicial, será necessário financiar explicitamente esta diferença e aprovar o compromisso; não está incluída uma garantia automática da KK.
"""
DOC += """
## Rastreio dos erros originais

Reverificacao_Erros_V45.csv cruza cada célula assinalada com cache original, deteção estática, erro após hard recalc e classificação. As 510 células de cache não equivalem a 510 causas independentes; 466 não se reproduziram no recálculo e 44 persistiram. O recálculo expôs 17 outras, totalizando 61 códigos (um NA intencional). A comparação entre motores e os testes no modelo reconstruído estão separados desta classificação.
"""
for name,body in [('Auditoria',AUD),('Viabilidade_Executiva',EXEC),('Documentacao_Tecnica',DOC)]:
 (OUT/f'{name}.md').write_text(body)
 styles=getSampleStyleSheet();styles['BodyText'].fontSize=9;styles['BodyText'].leading=13;styles['BodyText'].spaceAfter=6
 story=[];tablelines=[]
 def flush():
  if not tablelines:return
  rows=[[Paragraph(html.escape(v.strip()).replace('`',''),styles['BodyText']) for v in line.strip().strip('|').split('|')] for line in tablelines if not set(line.replace('|','').replace(':','').replace('-','').strip())==set()]
  if rows:
   widths=[490/len(rows[0])]*len(rows[0]);t=Table(rows,colWidths=widths,repeatRows=1,hAlign='LEFT');t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#DFEAF1')),('VALIGN',(0,0),(-1,-1),'TOP'),('LINEBELOW',(0,0),(-1,0),.5,colors.HexColor('#007F86')),('GRID',(0,0),(-1,-1),.2,colors.lightgrey),('LEFTPADDING',(0,0),(-1,-1),5),('RIGHTPADDING',(0,0),(-1,-1),5)]));story.append(t);story.append(Spacer(1,8))
  tablelines.clear()
 incode=False
 for line in body.splitlines():
  if line.startswith('|'):tablelines.append(line);continue
  flush()
  if line.startswith('```'):incode=not incode;continue
  if not line.strip():continue
  if line.startswith('# '):story.append(Paragraph(html.escape(line[2:]),styles['Title']))
  elif line.startswith('## '):story.append(Spacer(1,8));story.append(Paragraph(html.escape(line[3:]),styles['Heading2']))
  else:story.append(Paragraph(html.escape(line).replace('`',''),styles['BodyText']))
 flush()
 def footer(canvas,doc):
  canvas.setFont('Helvetica',8);canvas.setFillColor(colors.HexColor('#526575'));canvas.drawString(42,27,'KK-01 | Modelo de cenário — confirmações externas pendentes');canvas.drawRightString(553,27,str(doc.page))
 SimpleDocTemplate(str(OUT/f'{name}.pdf'),pagesize=(595,842),leftMargin=42,rightMargin=42,topMargin=42,bottomMargin=42).build(story,onFirstPage=footer,onLaterPages=footer)
print('Relatórios Markdown e PDF gravados')
