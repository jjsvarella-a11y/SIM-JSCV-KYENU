from pathlib import Path
import openpyxl,json,re,hashlib,csv
from openpyxl.formula.tokenizer import Tokenizer
from openpyxl.utils.cell import range_boundaries
ROOT=Path('/workspace/kk01');P=ROOT/'original/V45_original.xlsx'
w=openpyxl.load_workbook(P);d=openpyxl.load_workbook(P,data_only=True)
units=[]
for r in range(4,98):
 s=d['Unidades Pricing'];units.append(dict(id=str(s.cell(r,1).value),tipo=s.cell(r,2).value,piso=str(s.cell(r,3).value),area=s.cell(r,4).value,price_source=s.cell(r,5).value,price=round(s.cell(r,5).value,2),sale=s.cell(r,7).value,deed=s.cell(r,13).value,interior=s.cell(r,11).value,varanda=s.cell(r,12).value,source_row=r))
chapters=[]
for r in range(4,34):
 s=d['Orcamento Capitulos'];amount=s.cell(r,4).value
 chapters.append(dict(id=s.cell(r,1).value,name=s.cell(r,2).value,share=s.cell(r,3).value,weights=[s.cell(r,c).value/amount for c in range(5,35)]))
formulas={};issues=[];sheets=[];edges=[];dependencies={}
for s in w:
 sf=0;refs=set()
 for row in s:
  for c in row:
   if c.data_type=='e':issues.append(dict(sheet=s.title,cell=c.coordinate,type='Erro explícito',formula=c.value,cached=d[s.title][c.coordinate].value))
   if c.data_type!='f':continue
   sf+=1;key=(s.title,c.coordinate);formulas[key]=c.value
   cached=d[s.title][c.coordinate]
   if cached.data_type=='e':issues.append(dict(sheet=s.title,cell=c.coordinate,type='Erro em cache',formula=c.value,cached=cached.value))
   if re.search(r'[(,]=',c.value):issues.append(dict(sheet=s.title,cell=c.coordinate,type='Fórmula malformada',formula=c.value,cached=cached.value))
   if '#REF!' in c.value:issues.append(dict(sheet=s.title,cell=c.coordinate,type='Referência quebrada',formula=c.value,cached=cached.value))
   try:
    for tok in Tokenizer(c.value).items:
     if tok.subtype!='RANGE':continue
     val=tok.value
     if '!' in val:
      sn,addr=val.rsplit('!',1);sn=sn.strip("'").replace("''", "'");refs.add(sn)
     else:sn,addr=s.title,val
     if sn not in w.sheetnames:continue
     try:
      a,b,e,f=range_boundaries(addr.replace('$',''))
      if not all([a,b,e,f]) or (e-a+1)*(f-b+1)>20000:continue
      for rowref in w[sn].iter_rows(min_row=b,max_row=f,min_col=a,max_col=e):
       for cr in rowref:
        if cr.data_type=='f':edges.append((key,(sn,cr.coordinate)))
     except ValueError:pass
   except Exception as ex:issues.append(dict(sheet=s.title,cell=c.coordinate,type='Parser',formula=c.value,cached=str(ex)))
 refs.discard(s.title);dependencies[s.title]=sorted(refs)
 sheets.append(dict(sheet=s.title,rows=s.max_row,columns=s.max_column,formulas=sf,dependencies=sorted(refs),charts=len(s._charts),validations=len(s.data_validations.dataValidation)))
# Tarjan: cycles include all expanded formula-to-formula references in supported A1 ranges.
import sys
sys.setrecursionlimit(100000)
g={k:[] for k in formulas}
for a,b in edges:g[a].append(b)
idx={};low={};stack=[];on=set();cycles=[]
def visit(v):
 idx[v]=low[v]=len(idx);stack.append(v);on.add(v)
 for t in g[v]:
  if t not in idx:visit(t);low[v]=min(low[v],low[t])
  elif t in on:low[v]=min(low[v],idx[t])
 if low[v]==idx[v]:
  comp=[]
  while True:
   t=stack.pop();on.remove(t);comp.append(t)
   if t==v:break
  if len(comp)>1 or v in g[v]:cycles.append([f'{s}!{a}' for s,a in comp])
for v in g:
 if v not in idx:visit(v)
result=dict(source_sha256=hashlib.sha256(P.read_bytes()).hexdigest(),units=units,chapters=chapters,sheets=sheets,issues=issues,cycles=cycles,formula_count=len(formulas),formula_edges=len(edges),vgv_source=sum(u['price_source'] for u in units),vgv_cents=round(sum(u['price'] for u in units),2),external_links=len(w._external_links))
(ROOT/'src/source.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
for name,rows in [('Inventario_V45',sheets),('Erros_V45',issues)]:
 with (ROOT/'entrega'/f'{name}.csv').open('w',newline='') as f:
  writer=csv.DictWriter(f,fieldnames=list(rows[0]) if rows else ['sem_erros'],delimiter=';');writer.writeheader();writer.writerows(rows)
(ROOT/'entrega/Dependencias_V45.json').write_text(json.dumps(dependencies,ensure_ascii=False,indent=2))
print(json.dumps({k:result[k] for k in ['formula_count','formula_edges','vgv_source','vgv_cents','cycles','external_links']},ensure_ascii=False));print('Issues',len(issues));print(issues[:8])
