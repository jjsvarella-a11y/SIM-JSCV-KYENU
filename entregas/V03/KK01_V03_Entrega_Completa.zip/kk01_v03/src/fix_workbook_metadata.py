"""Corrige índices de apresentação após ordenação; não altera células ou fórmulas."""
from pathlib import Path
import zipfile,xml.etree.ElementTree as E,hashlib,json,os
ROOT=Path(__file__).resolve().parents[1];p=ROOT/'entrega/KK01_Modelo_Integrado.xlsx';n='http://schemas.openxmlformats.org/spreadsheetml/2006/main'
with zipfile.ZipFile(p) as zi:
 root=E.fromstring(zi.read('xl/workbook.xml'));names=[s.attrib['name'] for s in root.find('{'+n+'}sheets')];fixed=0
 for entry in root.find('{'+n+'}definedNames'):
  if 'localSheetId' not in entry.attrib or not entry.text or '!' not in entry.text:continue
  sn=entry.text.split('!')[0].lstrip('=').strip("'").replace("''", "'")
  if sn in names and entry.attrib['localSheetId']!=str(names.index(sn)):entry.set('localSheetId',str(names.index(sn)));fixed+=1
 root.find('{'+n+'}bookViews')[0].set('activeTab',str(names.index('DASH Consolidado')))
 root.find('{'+n+'}bookViews')[0].set('firstSheet','0')
 sheet_hashes={i.filename:hashlib.sha256(zi.read(i.filename)).hexdigest() for i in zi.infolist() if i.filename.startswith('xl/worksheets/')}
 tmp=p.with_suffix('.tmp')
 with zipfile.ZipFile(tmp,'w',zipfile.ZIP_DEFLATED) as zo:
  for item in zi.infolist():zo.writestr(item,E.tostring(root,encoding='utf-8',xml_declaration=True) if item.filename=='xl/workbook.xml' else zi.read(item.filename))
with zipfile.ZipFile(tmp) as z:
 assert all(hashlib.sha256(z.read(k)).hexdigest()==v for k,v in sheet_hashes.items())
os.replace(tmp,p)
(ROOT/'entrega/Verificacao_Apresentacao.json').write_text(json.dumps({'indices_impressao_e_filtros_corrigidos':fixed,'celulas_e_formulas_inalteradas':True,'folha_inicial':'DASH Consolidado'},ensure_ascii=False,indent=2))
print('Índices de apresentação corrigidos:',fixed,'; todas as células e fórmulas inalteradas')
