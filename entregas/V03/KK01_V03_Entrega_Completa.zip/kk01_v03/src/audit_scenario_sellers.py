from engine import *
import openpyxl
meta=json.loads((ROOT/'src/v03_metadata.json').read_text())['capital_scenarios'];results=[]
for name,updates in [('V03_Recebido_Final',{'received_ratio':.5}),('V03_Referencia_Final',{})]:
 w=openpyxl.load_workbook(ROOT/'validacao'/name/'out'/(name+'.xlsx'),read_only=True,data_only=True);bad=[]
 for label,item in meta.items():
  r=run(config(capital_scenario=label,**updates));sm=summary(r);p=r['p'];ret=p['equity']*p['received_ratio']*(1-p['treasury_ratio']);credit=sum(x['loan_interest']+x['loan_principal'] for x in r['flow'])+r['flow'][-1]['shareloan'];expected=(sm['dividends']+sm['exit_equity'])*(1-sm['share'])+ret+credit
  actual=w['Resultados Cenarios'][f'X{item["row"]}'].value
  if not isinstance(actual,(int,float)) or abs(actual-expected)>.01:bad.append((label,actual,expected))
 results.append({'case':name,'ok':not bad,'comparisons':4,'failures':bad});w.close()
(ROOT/'entrega/Testes_Cenarios_Vendedores.json').write_text(json.dumps(results,ensure_ascii=False,indent=2));print(results);raise SystemExit(not all(r['ok'] for r in results))
