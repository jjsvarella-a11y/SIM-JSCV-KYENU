from pathlib import Path
import json,hashlib,zipfile,shutil
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'entrega';repo=Path('/workspace/SIM-JSCV-KYENU/entregas/V03')
expected=['KK01_Modelo_Integrado_V03.xlsx','KK01_Comparativo_Capital_V03.pdf','KK01_Matriz_Societaria_V03.pdf','KK01_Rentabilidade_Categorias_V03.pdf','KK01_Financiamento_Risco_V03.pdf','KK01_Decisoes_Pendentes_V03.pdf','KK01_Documentacao_Tecnica_V03.pdf','KK01_Auditoria_V03.pdf','KK01_Painel_Executivo_V03.pdf']
assert all((OUT/x).is_file() for x in expected)
tests=json.loads((OUT/'Resultados_Testes_V03.json').read_text());selectors=json.loads((OUT/'Testes_Seletores.json').read_text());extra=json.loads((OUT/'Testes_Adicionais.json').read_text());metrics=json.loads((OUT/'Testes_Metricas_Seletores.json').read_text());assert tests['failures']==tests['errors']==0 and all(r['ok'] for r in selectors+extra+metrics)
# Ship audited records and complete sources; exclude stale diagnostics and rendering copies.
records=['Resultados_Testes_V03.json','Resultados_Testes_V03.txt','Testes_Seletores.json','Testes_Adicionais.json','Testes_Metricas_Seletores.json','Testes_Cenarios_Vendedores.json','Regressao_V02_Preservada.txt','Registo_Alteracoes_V03.csv','Controlos_Auditoria_V03.json','Dados_Comparativos_V03.json','Resumo_Motor_V03.json']
files=[OUT/x for x in expected+records]+list(OUT.glob('KK01_*V03.md'))+[ROOT/'README.md',ROOT/'requirements.txt']+list((ROOT/'src').glob('*.py'))+list((ROOT/'src').glob('*.json'))+list((ROOT/'src/icons').glob('*.png'))+[p for p in (ROOT/'original').rglob('*') if p.is_file()]
files=list(dict.fromkeys(files));assert all(p.is_file() for p in files)
manifest={str(p.relative_to(ROOT)):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files}
(OUT/'Manifesto_Conteudo_V03.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2));files.append(OUT/'Manifesto_Conteudo_V03.json')
archive=OUT/'KK01_V03_Entrega_Completa.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in files:z.write(p,'kk01_v03/'+str(p.relative_to(ROOT)))
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
assert archive.stat().st_size<40000000
publication=expected+[archive.name]
(OUT/'Manifesto_SHA256_V03.json').write_text(json.dumps({x:{'bytes':(OUT/x).stat().st_size,'sha256':hashlib.sha256((OUT/x).read_bytes()).hexdigest()} for x in publication},indent=2))
repo.mkdir(parents=True,exist_ok=True)
for x in publication+['Manifesto_SHA256_V03.json']:shutil.copy2(OUT/x,repo/x)
for x in expected+[archive.name,'Manifesto_SHA256_V03.json']:shutil.copy2(OUT/x,ROOT.parent/'entrega'/x)
print('Pacote:',archive.stat().st_size,'bytes;',len(files),'ficheiros. Publicação preparada em',repo)
