from engine import ROOT,SOURCE
import openpyxl,json,csv,collections
p=ROOT/'validacao/auditoria_v45/V45_original.xlsx'
a=openpyxl.load_workbook(ROOT/'original/V45_original.xlsx',data_only=True,read_only=True)
b=openpyxl.load_workbook(p,data_only=True,read_only=True)
f=openpyxl.load_workbook(ROOT/'original/V45_original.xlsx',data_only=False,read_only=True)
old={};new={};formulas={}
for s in a:
 for row in s:
  for c in row:
   if c.data_type=='e':old[(s.title,c.coordinate)]=str(c.value)
for s in b:
 for row in s:
  for c in row:
   if c.data_type=='e':new[(s.title,c.coordinate)]=str(c.value)
for s in f:
 for row in s:
  for c in row:
   if c.data_type=='f':formulas[(s.title,c.coordinate)]=c.value
flags=collections.defaultdict(list)
for i in SOURCE['issues']:flags[(i['sheet'],i['cell'])].append(i['type'])
keys=sorted(set(old)|set(new)|set(flags));rows=[]
for key in keys:
 rows.append(dict(folha=key[0],celula=key[1],formula_origem=formulas.get(key,''),deteccao='; '.join(flags[key]),cache_origem=old.get(key,''),erro_recalculo=new.get(key,''),estado='NA() intencional — TIR não validada' if formulas.get(key)=='=NA()' else 'Erro confirmado no recálculo V45' if key in new else 'Sintaxe assinalada; avaliar expressão' if any('malformada' in x or x=='Parser' for x in flags[key]) else 'Cache antigo não reproduzido'))
with (ROOT/'entrega/Reverificacao_Erros_V45.csv').open('w',newline='') as fp:
 wr=csv.DictWriter(fp,fieldnames=list(rows[0]),delimiter=';');wr.writeheader();wr.writerows({k:("'"+str(v) if isinstance(v,str) and v.startswith(('=','+','-','@')) else v) for k,v in row.items()} for row in rows)
summary=dict(ocorrencias_analise_estatica=len(SOURCE['issues']),celulas_unicas_analise_estatica=len({(i['sheet'],i['cell']) for i in SOURCE['issues']}),caches_erro_origem=len(old),sintaxe_if_invalida=sum(i['type']=='Fórmula malformada' for i in SOURCE['issues']),rejeicoes_parser=sum(i['type']=='Parser' for i in SOURCE['issues']),erros_apos_recalculo_v45=len(new),caches_nao_reproduzidos=len(set(old)-set(new)),novos_erros_detectados_no_recalculo=len(set(new)-set(old)),celulas_reverificadas=len(keys),tipos_recalculados=dict(collections.Counter(new.values())),folhas_recalculadas=dict(collections.Counter(k[0] for k in new)),lista_anterior_510_disponivel=False,metodo='Fonte original intacta; cópia com hard recalc OOXMLRecalcMode=0 em LibreOffice 26.8. Fórmulas inválidas causam erros propagados; não equivalem a causas económicas independentes.')
(ROOT/'entrega/Reverificacao_Erros_V45.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2));print(json.dumps(summary,ensure_ascii=False,indent=2))
a.close();b.close();f.close()
