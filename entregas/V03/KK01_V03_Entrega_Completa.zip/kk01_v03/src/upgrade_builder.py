from pathlib import Path
p=Path(__file__).with_name('build_model.py');s=p.read_text()
s=s.replace("OUT=ROOT/'entrega/KK01_Modelo_Integrado.xlsx'", "OUT=ROOT/'entrega/KK01_Modelo_Integrado_V02.xlsx'")
s=s.replace('def pv(k):return f', 'def rawpv(k):return f',1)
pos=s.index('\ndef vr(')
s=s[:pos]+'''\ndef pv(k):
 if k=='equity':return "'Ronda Investidores'!$B$20"
 if k in ['base_fee','systems','incentive']:return "'Condicoes Operador'!$F$"+str({'base_fee':5,'systems':6,'incentive':7}[k])
 return rawpv(k)
'''+s[pos:]
s=s.replace("['0','5000000','10000000','15000000']", "['0','5000000','10000000','15000000','20000000']")
s=s.replace("elif k=='hotel':dv", "elif k=='fee_mode':dv({'validate':'list','source':['Objetivo KK','Proposta simulada','Personalizado']})\n elif k=='equity_mode':dv({'validate':'list','source':['Capital selecionado','Combinação tickets']})\n elif k=='equity_price':dv({'validate':'list','source':['15000000','20000000']})\n elif k=='hotel':dv")
s=s.replace("'Equity 15 M€; banco", "'Equity 20 M€ por 40%, condicionado à entrada na KK; banco")
s=s.replace("'Preço cobrável €','Estado calendário'", "'Preço cobrável €','Estado calendário','Venda cenário','Tranche cenário','Escritura cenário'")
# Effective dates keep original editable sales/deeds and add a transparent stress shift.
s=s.replace("fw(s,r,9,f'ROUNDUP(I{r}/3,0)'", "fw(s,r,9,f'ROUNDUP((I{r}+{pv(\"commercial_delay\")})/3,0)'")
needle=" for c in [6,8,11]:s.write_comment"
pos=s.index(needle);s=s[:pos]+''' for c,letter in [(23,'I'),(24,'K'),(25,'L')]:fw(s,r,c,f'{letter}{r}+{pv("commercial_delay")}',u['sale'] if c<25 else u['deed'],'int')
'''+s[pos:]
s=s.replace("m}>{U(10)}", "m}>{U(24)}") if False else s
# Only the receipts loop references dates through column indexes; replace within that block.
a=s.index("s=sh('Recebimentos'");b=s.index("s=sh('Obra'",a)
block=s[a:b].replace('U(8)','U(23)').replace('U(10)','U(24)').replace('U(11)','U(25)')
s=s[:a]+block+s[b:]
s=s.replace("*{pv(\"cost\")}',ch['share']", "*{pv(\"cost\")}*(1+{pv(\"cost_overrun\")})',ch['share']")
s=s.replace("(1,'I','N','deposit'),(2,'K','O','tranche'),(4,'L','Q','final'),(6,'L','S','tax'),(7,'I','T','marketing'),(8,'I','U','kyenu'),(11,'I','H',None)","(1,'X','N','deposit'),(2,'Y','O','tranche'),(4,'Z','Q','final'),(6,'Z','S','tax'),(7,'X','T','marketing'),(8,'X','U','kyenu'),(11,'X','H',None)")
# Hotel can simulate fees via the same formulas and condition incentive on explicit performance inputs.
s=s.replace("def hotel_formulas(r,scenario_expr=None):", "def hotel_formulas(r,scenario_expr=None,fees_override=None):")
s=s.replace(" init=lambda c:", " fee=lambda k:fees_override[{'base_fee':0,'systems':1,'incentive':2}[k]] if fees_override else pv(k)\n init=lambda c:")
# Scoped substitution only in hotel_formulas.
a=s.index('def hotel_formulas');b=s.index("s=sh('Hotel'",a);block=s[a:b]
block=block.replace('pv("base_fee")','fee("base_fee")').replace('pv("systems")','fee("systems")').replace('pv("incentive")','fee("incentive")')
block=block.replace("*{fee(\"incentive\")}'", "*{fee(\"incentive\")}*IF(OR({pv(\"incentive_gate\")}=0,AND({gop}*12>={pv(\"gop_floor\")},({gop}-{base}-{systems})*12>={pv(\"ebitda_floor\")})),1,0)'")
s=s[:a]+block+s[b:]
s=s.replace("bank_override=None):", "bank_override=None,capex_sn='CAPEX',re_sn='Imobiliario',cost_factor='1'):")
s=s.replace("RE=lambda c:vr('Imobiliario',sr,c);CAP=lambda c:vr('CAPEX',sr,c)", "RE=lambda c:vr(re_sn,sr,c);CAP=lambda c:vr(capex_sn,sr,c)")
s=s.replace("SUM('CAPEX'!E{sr+1}:E184)","SUM('{capex_sn}'!E{sr+1}:E184)")
s=s.replace("SUM('Imobiliario'!J{sr+1}:J184)","SUM('{re_sn}'!J{sr+1}:J184)")
s=s.replace("SUMIFS(\\'CAPEX\\'!$E$5:$E$184,\\'CAPEX\\'!$A$5:$A$184", "SUMIFS(\\'{capex_sn}\\'!$E$5:$E$184,\\'{capex_sn}\\'!$A$5:$A$184")
s=s.replace("\\'CAPEX\\'!$A$5:$A$184,\"<=\"", "\\'{capex_sn}\\'!$A$5:$A$184,\"<=\"")
s=s.replace("{eq}-{pv(\"conversion\")},0)", "({eq}-{pv(\"conversion\")})*{pv(\"treasury_ratio\")},0)")
s=s.replace("*{pv(\"contingency\")}*(1-{pv(\"cont_used\")})", "*(1+{pv(\"cost_overrun\")})*({cost_factor})*{pv(\"contingency\")}*(1-{pv(\"cont_used\")})")
# Pricing and ownership, no JSCV dilution.
s=s.replace('/1000000*40%/15','/{pv("equity_price")}*{pv("equity_stake")}')
s=s.replace("'legacy_share_jscv':(1-sm['share'])*DEFAULT['legacy_jscv']", "'legacy_share_jscv':DEFAULT['legacy_jscv']").replace("'legacy_share_jals':(1-sm['share'])*(1-DEFAULT['legacy_jscv'])", "'legacy_share_jals':1-DEFAULT['legacy_jscv']-sm['share']")
s=s.replace("f'{B(20)}*{pv(\"legacy_jscv\")}'", "pv('legacy_jscv')").replace("f'{B(20)}*(1-{pv(\"legacy_jscv\")})'", "f'1-{pv(\"legacy_jscv\")}-{B(13)}'")
s=s.replace("for i in range(1,16):\n r=i+4;ticket=i*1e6;", "for i in range(1,21):\n r=i+4;ticket=i*1e6;")
s=s.replace("share=ticket/1e6*.4/15", "share=ticket/DEFAULT['equity_price']*DEFAULT['equity_stake']")
s=s.replace("s.autofilter('A4:AE19')", "s.autofilter('A4:AE24')")
# Investor cash outlay is the acquisition price, not the amount that reaches project treasury.
s=s.replace("f\"-'Fluxo 180M'!C{sr}+'Fluxo 180M'!AD{sr}*{share}\"", "f\"-IF(A{r}=1,{pv('equity')}-{pv('conversion')},0)+'Fluxo 180M'!AD{sr}*{share}\"")
s=s.replace("f'J{r-1}-\\'Fluxo 180M\\'!C{m+4}+", "f'J{r-1}-IF(A{r}=1,{pv(\"equity\")}-{pv(\"conversion\")},0)+")
s=s.replace("sum(y['dividend']*.4 for y in BASE['flow'][:x['m']])>=15000000", "sum(y['dividend']*SUM['share'] for y in BASE['flow'][:x['m']])>=DEFAULT['equity']")
# Commercial selections use effective scenario sale month while keeping original dates intact.
s=s.replace("(5,8),(6,9)","(5,23),(6,9)")
s=s.replace("\\'Unidades\\'!$I$5:$I$98=A{r}","\\'Unidades\\'!$X$5:$X$98=A{r}").replace("\\'Unidades\\'!$K$5:$K$98=A{r}","\\'Unidades\\'!$Y$5:$Y$98=A{r}").replace("\\'Unidades\\'!$L$5:$L$98=A{r}","\\'Unidades\\'!$Z$5:$Z$98=A{r}")
# Build more scenarios through the existing loop. Add labels and scenario metadata in columns N:U.
s=s.replace("for eq in [0,5e6,10e6,15e6]:", "for eq in [0,5e6,10e6,15e6,20e6]:")
needle="SCRESULT=[]"
s=s.replace(needle,'''SCEN += [dict(equity=eq,hotel='Favorável',bank=None,equity_price=eq,label=f'{int(eq/1e6)}M por 40%') for eq in [15e6,20e6]]
for eq in [15e6,20e6]:
 for extra in [dict(delay=6,label='Atraso comercial +6M'),dict(overrun=.10,label='Sobrecusto +10%'),dict(hotel='Base',label='Hotel Base'),dict(hotel='Conservador',label='Hotel Conservador')]:
  SCEN.append(dict(equity=eq,hotel=extra.get('hotel','Favorável'),bank=None,equity_price=eq,**{k:v for k,v in extra.items() if k!='hotel'}))
for fee_kind in ['target','offer','custom']:
 SCEN.append(dict(equity=None,hotel=None,bank=None,fee_kind=fee_kind,label='Operador '+fee_kind))
SCRESULT=[]''')
s=s.replace("rr=run(config(**changes));SCRESULT",'''if 'equity_price' in sc:changes['equity_price']=sc['equity_price']
 if 'delay' in sc:changes['commercial_delay']=DEFAULT['commercial_delay']+sc['delay']
 if 'overrun' in sc:changes['cost_overrun']=(1+DEFAULT['cost_overrun'])*(1+sc['overrun'])-1
 if 'fee_kind' in sc:
  changes['fee_mode']={'target':'Objetivo KK','offer':'Proposta simulada','custom':'Personalizado'}[sc['fee_kind']]
 rr=run(config(**changes));SCRESULT''')
s=s.replace("fs=hotel_formulas(r,vr('Comparacao',row,1,True))", "fs=hotel_formulas(r,vr('Comparacao',row,1,True),[vr('Condicoes Operador',j,{'target':2,'offer':1,'custom':4}[sc['fee_kind']],True) for j in [5,6,7]] if 'fee_kind' in sc else None)")
needle=" write_flow(fs,rr,equity_expr="
pos=s.index(needle)
end=s.index('\n',pos)
s=s[:pos]+''' # Scenario CAPEX/receipts wrappers preserve the single original engine and common base sheets.
 capsn='CAPEX';resn='Imobiliario'
 if 'overrun' in sc:
  capsn=f'CalcC{si+1:02d}';cs=sh(capsn,['Mês','Base','Fiscalização','Contingência','Total'],'Stress adicional por fator; pesos e calendário preservados.');cs.hide()
  for mi,x in enumerate(rr['cap'],5):
   text(cs,mi,0,mi-4,'int')
   for cc,key in [(1,'base'),(2,'supervision'),(3,'cont'),(4,'total')]:fw(cs,mi,cc,vr('CAPEX',mi,cc)+f'*(1+{sc["overrun"]})',x[key])
 if 'delay' in sc:
  resn=f'CalcR{si+1:02d}';rs=sh(resn,['Mês']+list(REKEY[1:]),'Desfasamento comercial adicional; não altera a obra nem constitui aprovação contratual.');rs.hide()
  for mi in range(5,185):
   text(rs,mi,0,mi-4,'int')
   for cc in range(1,12):fw(rs,mi,cc,'0' if mi-5<sc['delay'] else vr('Imobiliario',mi-sc['delay'],cc),0)
 write_flow(fs,rr,equity_expr=f"'Comparacao'!$A${row}*1000000",hotel_sn=hsname,bank_override=bankexpr,capex_sn=capsn,re_sn=resn,cost_factor=str(1+sc.get('overrun',0)))'''+s[end:]
s=s.replace("text(sens,30,0,'Nota');text(sens,30,1,", "text(sens,55,0,'Nota');text(sens,55,1,")
s=s.replace("s.set_row(29,30);alert(sens,'M5:M27')", "s.set_row(54,30);alert(sens,f'M5:M{len(SCEN)+4}')")
# Load V02 panels before comments/navigation and closing. Existing sheets remain intact.
needle='# Navigation links and consistent print settings.'
s=s.replace(needle,"exec((ROOT/'src/v02_panels.py').read_text(),globals())\n\n"+needle)
s=s.replace("front=['LEIA-ME'", "front=['EXEC KK01','LEIA-ME'")
s=s.replace("S['DASH Consolidado'].activate();S['LEIA-ME'].set_first_sheet()", "S['EXEC KK01'].activate();S['EXEC KK01'].set_first_sheet()")
s=s.replace("'source_sha256':SOURCE['source_sha256']}", "'source_sha256':SOURCE['source_sha256'],'v02':True}")
p.write_text(s)
