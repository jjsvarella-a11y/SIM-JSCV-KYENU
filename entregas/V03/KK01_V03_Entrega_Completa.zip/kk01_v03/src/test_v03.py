"""Auditoria V03 e regressão económica V02; executar após recálculo externo."""
from engine import *
import unittest,openpyxl,hashlib,importlib.util,sys,zipfile
FILE=Path(sys.argv[1]) if len(sys.argv)>1 else ROOT/'entrega/KK01_Modelo_Integrado_V03.xlsx';sys.argv=sys.argv[:1]
META=json.loads((ROOT/'src/build_metadata.json').read_text())
spec=importlib.util.spec_from_file_location('legacy_v02',ROOT/'original/v02/src/engine.py');legacy=importlib.util.module_from_spec(spec);spec.loader.exec_module(legacy)
class V03Tests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.r=run();cls.w=openpyxl.load_workbook(FILE,data_only=True,read_only=True);cls.f=openpyxl.load_workbook(FILE,data_only=False,read_only=False)
 @classmethod
 def tearDownClass(cls):cls.w.close();cls.f.close()
 def test_01_v02_preserved(self):
  original=ROOT/'original/KK01_Modelo_Integrado_V02.xlsx';live=ROOT.parent/'v02/entrega/KK01_Modelo_Integrado_V02.xlsx';self.assertEqual(hashlib.sha256(original.read_bytes()).hexdigest(),json.loads((ROOT/'original/V02_SHA256.json').read_text())['sha256']);self.assertTrue(not live.exists() or original.read_bytes()==live.read_bytes())
 def test_02_units(self):
  self.assertEqual(len(UNITS),94);self.assertAlmostEqual(sum(u['price'] for u in UNITS),50656336.37,2)
  for u,rs in zip(UNITS,self.r['re']['units']):self.assertAlmostEqual(sum(rs),u['price'],2)
 def test_03_budget(self):self.assertAlmostEqual(sum(x['total'] for x in self.r['cap']),63168000,2)
 def test_04_shares_blocks(self):
  s=self.w['Matriz Societaria V03'];self.assertEqual(s['I9'].value,100000);self.assertEqual(s['H9'].value,1)
  self.assertEqual([s[f'G{r}'].value for r in [5,6,7]],[40000,10000,50000]);self.assertEqual([s[f'{c}9'].value for c in 'BCD'],[3,1,15])
  b=self.w['Blocos V03'];self.assertEqual(b['D10'].value,12);self.assertEqual(b['E10'].value,25000000);self.assertEqual(b['G10'].value,50000)
 def test_05_default_and_actual(self):
  s=self.w['Capital V03'];self.assertEqual(s['B5'].value,'KK-E25');self.assertEqual(s['B12'].value,25000000)
  for r in [21,22,23,24]:self.assertIsNone(s[f'B{r}'].value)
 def test_06_cash_debt_identities(self):
  for x in self.r['flow']:self.assertAlmostEqual(x['cash_check'],0,6);self.assertAlmostEqual(x['debt_check'],0,6);self.assertLessEqual(x['cumulative'],3e7+.01)
 def test_07_excel_vs_engine_180m(self):
  for row,x in zip(self.w['Fluxo 180M'].iter_rows(min_row=5,max_row=184,values_only=True),self.r['flow']):
   for k,c in META['flow_columns'].items():
    if isinstance(x[k],(int,float)):self.assertIsInstance(row[c],(int,float));self.assertAlmostEqual(row[c],x[k],delta=max(.01,abs(x[k])*1e-9),msg=f'{x["m"]} {k}')
 def test_08_old_economics_preserved(self):
  for eq in [15e6,20e6]:
   a=run(config(equity=eq,equity_price=eq));b=legacy.run(legacy.config(equity=eq,equity_price=eq))
   for x,y in zip(a['flow'],b['flow']):
    for k in y:
     if isinstance(y[k],(int,float)):self.assertAlmostEqual(x[k],y[k],delta=.00001,msg=f'{eq} m{x["m"]} {k}')
   self.assertAlmostEqual(summary(a)['equity_irr'],legacy.summary(b)['equity_irr'],10)
 def test_09_partial_subscription(self):
  p=config(equity_mode='Combinação tickets',n_platinum=0,n_gold=0,n_silver_plus=0,n_silver=1);self.assertEqual(p['equity'],1e6);self.assertEqual(p['equity_stake'],.02);self.assertEqual(p['legacy_jscv'],.51)
 def test_10_mobilisation(self):
  r=run(config(fund_part1=.5,fund_part2=.3,fund_part3=.2));self.assertEqual([r['flow'][m-1]['equity'] for m in [1,7,13]],[12500000,7500000,5000000]);self.assertEqual(sum(x['equity'] for x in r['flow']),25e6)
 def test_11_no_transfer_not_feasible(self):
  s=summary(run(config(treasury_ratio=0)));self.assertGreater(s['funding_gap'],0)
 def test_12_shareloan_service(self):
  r=run(config(funding_kind='Empréstimo'));self.assertEqual(r['flow'][0]['loan_in'],25e6);self.assertAlmostEqual(r['flow'][0]['loan_interest'],25e6*.05/12,6)
  for x in r['flow']:
   self.assertAlmostEqual(x['service'],x['interest']+x['principal']+x['loan_interest']+x['loan_principal'],6);self.assertAlmostEqual(x['cash_check'],0,6)
   if x['shareloan']>.01:self.assertEqual(x['dividend'],0)
  self.assertLess(r['flow'][-1]['shareloan'],.01)
 def test_13_benefits_reduce_returns(self):
  r=run(config(benefit_platinum=1e5));self.assertAlmostEqual(self.r['hotel'][30]['ebitda']-r['hotel'][30]['ebitda'],25000,6);self.assertLess(summary(r)['equity_irr'],summary(self.r)['equity_irr'])
 def test_14_category_returns(self):
  s=self.w['Retorno Categorias V03'];self.assertAlmostEqual(s['M5'].value,s['M6'].value,10);self.assertAlmostEqual(s['M5'].value,s['M7'].value,10)
  self.assertAlmostEqual(sum(s[f'J{r}'].value*q for r,q in [(5,1),(6,1),(7,10)]),summary(self.r)['dividends']*.50,2)
 def test_15_scenario_metrics(self):
  s=self.w['Comparativo Capital V03']
  for row,label in enumerate(['KK-E15','KK-E20-A','KK-E20-B','KK-E25'],5):
   r=run(config(capital_scenario=label));sm=summary(r)
   for c,val in [('B',r['p']['equity']),('C',sum(x['equity'] for x in r['flow'])),('D',sm['share']),('E',sm['peak']),('N',sm['equity_irr']),('O',sm['moic'])]:self.assertAlmostEqual(s[f'{c}{row}'].value,val,delta=.01,msg=label+c)
 def test_16_reserves_dividends(self):
  self.assertLess(max(x['reservegap'] for x in self.r['flow']),.01)
  for x in self.r['flow']:
   if x['dividend']>.01:self.assertLess(x['debt']+x['shareloan'],.01);self.assertGreaterEqual(x['cash'],x['reserve']-.01)
 def test_17_no_formula_errors(self):
  errors=[(s.title,c.coordinate,c.value) for s in self.w for row in s for c in row if c.data_type=='e'];self.assertEqual(errors,[])
 def test_18_navigation_and_no_macros(self):
  w=self.f;self.assertEqual(w.active.title,'EXEC KK01');self.assertGreaterEqual(sum(c.hyperlink is not None for row in w['EXEC KK01'] for c in row),8)
  with zipfile.ZipFile(FILE) as z:
   import xml.etree.ElementTree as E
   self.assertFalse(any('vbaProject' in n for n in z.namelist()))
   drawing=E.fromstring(z.read('xl/drawings/drawing1.xml'));ns={'s':'http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing','a':'http://schemas.openxmlformats.org/drawingml/2006/main'}
   self.assertEqual(len(drawing.findall('.//s:pic',ns)),8);self.assertEqual(len(drawing.findall('.//a:hlinkClick',ns)),8)
   rels=E.fromstring(z.read('xl/drawings/_rels/drawing1.xml.rels'));links=[x.attrib['Target'] for x in rels if x.attrib['Type'].endswith('/hyperlink')];self.assertEqual(len(set(links)),8)
 def test_19_controls_filters(self):
  self.assertIsNotNone(self.f['DASH Comercial']['B5']);self.assertGreater(len(self.f['Pressupostos'].data_validations.dataValidation),10);self.assertGreater(len(self.f['EXEC KK01']._charts),0)
 def test_20_irr_npv_consistent(self):
  sm=summary(self.r);self.assertAlmostEqual(self.w['Retornos']['C19'].value,sm['equity_irr'],8);self.assertAlmostEqual(self.w['Retornos']['C18'].value,sm['moic'],8)
  flows=[0]+[(-25e6 if x['m']==1 else 0)+x['dividend']*.50+(sm['exit_equity']*.50 if x['m']==180 else 0) for x in self.r['flow']];v=sum(f/(1+.12)**(m/12) for m,f in enumerate(flows));self.assertAlmostEqual(self.w['Retornos']['C26'].value,v,2)
if __name__=='__main__':
 suite=unittest.defaultTestLoader.loadTestsFromTestCase(V03Tests);result=unittest.TextTestRunner(verbosity=2).run(suite);(ROOT/'entrega/Resultados_Testes_V03.json').write_text(json.dumps({'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped)},indent=2));sys.exit(not result.wasSuccessful())
