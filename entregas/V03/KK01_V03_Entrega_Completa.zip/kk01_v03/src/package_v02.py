from pathlib import Path
import json,hashlib,zipfile,shutil
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'entrega'
tr=json.loads((OUT/'Resultados_Testes.json').read_text());ss=json.loads((OUT/'Testes_Seletores.json').read_text());pres=json.loads((OUT/'Verificacao_Apresentacao_V02.json').read_text())
assert tr['ok'] and tr['tests']==29 and len(ss)==11 and all(x['ok'] for x in ss) and pres['caption_ok']
files=[ROOT/'README.md',ROOT/'requirements.txt']
files += [p for p in OUT.iterdir() if p.is_file() and p.suffix in ['.xlsx','.pdf','.md','.json','.txt'] and p.name!='Manifesto_SHA256_V02.json']
files += [p for p in (ROOT/'src').rglob('*') if p.is_file() and p.suffix in ['.py','.json','.png'] and '__pycache__' not in p.parts]
files += [p for p in (ROOT/'original').rglob('*') if p.is_file() and '__pycache__' not in p.parts]
manifest={str(p.relative_to(ROOT)):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files}
mp=OUT/'Manifesto_SHA256_V02.json';mp.write_text(json.dumps(manifest,ensure_ascii=False,indent=2));files.append(mp)
package=OUT/'KK01_V02_Entrega_Completa.zip'
with zipfile.ZipFile(package,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,'kk01_v02/'+str(p.relative_to(ROOT)))
with zipfile.ZipFile(package) as z:assert z.testzip() is None
# Mirror named V02 deliverables at the requested parent delivery location; never overwrite V01.
parent=ROOT.parent/'entrega'
for p in OUT.iterdir():
 if p.is_file() and ('V02' in p.name or p.name=='Comparativo_15_20_Dados.json'):shutil.copyfile(p,parent/p.name)
for n in ['Resultados_Testes.json','Resultados_Testes.txt','Testes_Seletores.json']:shutil.copyfile(OUT/n,parent/('KK01_V02_'+n))
print('Pacote:',package.stat().st_size,'bytes;',len(files),'ficheiros')
print('Excel:',(OUT/'KK01_Modelo_Integrado_V02.xlsx').stat().st_size,'bytes')
print('Testes:',tr['tests'],'; seletores:',len(ss),'; comparações:',sum(x['comparisons'] for x in ss))
