from pathlib import Path
p=Path(__file__).with_name('engine.py');s=p.read_text()
s=s.replace("('equity','Capital novo',15000000", "('equity','Capital novo',20000000")
s=s.replace("DEFAULT={k:v for k,l,v,u,n in PARAMS}",'''PARAMS += [
('equity_price','Preço da ronda por 40%',20000000,'€','20 M€ por 40% na referência; 15 M€ por 40% preservado para comparação.'),
('equity_stake','Participação máxima da ronda',.40,'%','40.000 das 100.000 ações existentes da JALS; sem diluição da JSCV.'),
('treasury_ratio','Parcela do preço entregue à KK',1,'%','100% é hipótese condicional: compra de ações JALS não financia automaticamente a sociedade. Não presumir suprimento sem modelar dívida.'),
('legal_confirmed','Mecanismo de entrada na KK formalizado',0,'0/1','0: pendência externa. Referência assume entrada irrevogável sem reembolso; validar mecanismo e fiscalidade.'),
('shares_total','Ações existentes',100000,'unidades','JSCV 51.000, JALS 49.000 antes da operação; 40.000 ações JALS disponibilizadas.'),
('commercial_delay','Desfasamento comercial de cenário',0,'meses','Desloca cobranças, contrato e escritura em simulação; não aprova alterações contratuais. Obra não se desloca.'),
('cost_overrun','Sobrecusto adicional da obra',0,'%','Sobre orçamento e contingência; cenário de esforço, distinto da contingência já orçamentada.'),
('fee_mode','Condições do Operador selecionadas','Objetivo KK','lista','Objetivo KK / Proposta simulada / Personalizado. Nenhum modo representa HMA aprovado.'),
('target_base','Objetivo KK — fee base',.03,'%','Referência de negociação, não contrato.'),
('target_systems','Objetivo KK — distribuição/sistemas',.03,'%','Sem sobreposição de encargos.'),
('target_incentive','Objetivo KK — incentivo',.06,'%','Base GOP após fees fixos.'),
('offer_base','Proposta simulada — fee base',.04,'%','Hipótese para negociação; não representa proposta recebida.'),
('offer_systems','Proposta simulada — sistemas',.03,'%','Hipótese editável; confirmar encargos.'),
('offer_incentive','Proposta simulada — incentivo',.10,'%','Hipótese editável; não condição apresentada confirmada.'),
('offer_received','Proposta efetiva recebida',0,'0/1','Só assinalar 1 quando houver documento; valores da proposta têm de corresponder ao documento.'),
('incentive_gate','Condicionar incentivo ao desempenho',0,'0/1','Simulação facultativa; 0 preserva motor V01. Critérios não contratados.'),
('gop_floor','GOP anualizado mínimo para incentivo',0,'€','0 = não definido; simulação mensal anualizada, não substitui performance test plurianual do HMA.'),
('ebitda_floor','Resultado pré-incentivo anualizado mínimo',0,'€','Base antes de incentivo evita circularidade. Não confundir com EBITDA líquido de incentivo.'),
('actual_month','Mês de referência execução',0,'mês','0: ainda sem data de execução informada; indicadores realizados permanecem indisponíveis.'),
]
DEFAULT={k:v for k,l,v,u,n in PARAMS}''')
s=s.replace(" p['adr'],p['occ'],p['mice'],p['other']=HOTELS[p['hotel']]",''' p['adr'],p['occ'],p['mice'],p['other']=HOTELS[p['hotel']]
 if p['fee_mode']=='Objetivo KK':
  p['base_fee'],p['systems'],p['incentive']=[p['target_'+k] for k in ['base','systems','incentive']]
 elif p['fee_mode']=='Proposta simulada':
  p['base_fee'],p['systems'],p['incentive']=[p['offer_'+k] for k in ['base','systems','incentive']]''')
s=s.replace("net=price-conv;s=u['sale'];d=u['deed'];", "net=price-conv;s=u['sale']+int(p['commercial_delay']);d=u['deed']+int(p['commercial_delay']);")
s=s.replace("c['share']*p['area']*p['cost']*c['weights'][m]", "c['share']*p['area']*p['cost']*(1+p['cost_overrun'])*c['weights'][m]")
s=s.replace("inc=max(0,gop-base-systems)*p['incentive'];", "inc=max(0,gop-base-systems)*p['incentive']*(not p['incentive_gate'] or (gop*12>=p['gop_floor'] and (gop-base-systems)*12>=p['ebitda_floor']));")
s=s.replace("equity=p['equity']-p['conversion'] if m==1 else 0", "equity=(p['equity']-p['conversion'])*p['treasury_ratio'] if m==1 else 0")
s=s.replace("p['area']*p['cost']*p['contingency']*(1-p['cont_used'])", "p['area']*p['cost']*(1+p['cost_overrun'])*p['contingency']*(1-p['cont_used'])")
s=s.replace("share=(p['equity']-p['conversion'])/1e6*(.4/15)", "share=(p['equity']-p['conversion'])/p['equity_price']*p['equity_stake']")
s=s.replace("[-x['equity']+x['dividend']*share+", "[-(p['equity']-p['conversion']) if False else (-(p['equity']-p['conversion']) if x['m']==1 else 0)+x['dividend']*share+")
# simplify the inserted expression without changing the legacy monthly sequence.
s=s.replace("-(p['equity']-p['conversion']) if False else ", "")
p.write_text(s)
