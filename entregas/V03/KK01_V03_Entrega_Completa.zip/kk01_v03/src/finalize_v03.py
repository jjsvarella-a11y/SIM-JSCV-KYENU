"""Ajustes de rótulos/validações e recálculo automático, preservando fórmulas/caches auditados."""
from pathlib import Path
import xml.etree.ElementTree as E,zipfile,json,os,openpyxl
ROOT=Path(__file__).resolve().parents[1];P=ROOT/'entrega/KK01_Modelo_Integrado_V03.xlsx';M=json.loads((ROOT/'src/build_metadata.json').read_text());N='http://schemas.openxmlformats.org/spreadsheetml/2006/main';R='http://schemas.openxmlformats.org/officeDocument/2006/relationships';tag=lambda n:'{'+N+'}'+n
values=openpyxl.load_workbook(P,data_only=True,read_only=True);capital={k:values['Capital V03'][addr].value for k,addr in [('equity','B6'),('equity_price','B6'),('equity_stake','B7'),('legacy_jscv','B8')]};values.close()
updates={'Ronda Investidores':{'A2':'V03: 25 M€ por 50%; 12 blocos. Valores de cenário separados dos valores comprovados em Capital V03.','C4':'Quota por bloco','B34':'V03: JSCV = 2 Platinum','B35':'V03: JALS = 5 Silver'},'Societario':{'A12':'Silver Plus — histórico desativado','D12':'Retirado da oferta ativa V03; consultar Matriz Societaria V03.','A2':'Estrutura ativa ligada ao cenário V03; KK-E25:40%JSCV/10%JALS/50%novos. Direitos jurídicos pendentes.'},'Resultados Cenarios':{'D4':'Preço referência da ronda'},'Retorno Socios':{'A2':'V03: JSCV40%, JALS10%, novos50% na referência. Custos históricos individuais desconhecidos; TIR individual dos promotores indisponível.','E4':'Retido + crédito vendedores'},'Pressupostos':{'A'+str(M['param_rows']['equity_price']):'Preço contratado da ronda (calculado)','D'+str(M['param_rows']['equity_price']):'V03:25 M€ por50% na referência; controlar em capital_scenario / Capital V03.','A'+str(M['param_rows']['legacy_jscv']):'JSCV pós-operação (calculado)','D'+str(M['param_rows']['legacy_jscv']):'Histórico51%;40% na referência confirmada E25. Direitos jurídicos pendentes.','D'+str(M['param_rows']['equity_stake']):'E25:50.000ações;11.000JSCV+39.000JALS. Apenas participação económica confirmada.'},'Fluxo 180M':{'C4':'Fundos acionistas recebidos KK'},'Anual':{'G4':'Fundos acionistas KK','X4':'Dívida bancária final','AC4':'Banco líquido / EBITDA','AD4':'LTV banco indicativo'},'AUDITORIA':{}}
with zipfile.ZipFile(P) as zi:
 wb=E.fromstring(zi.read('xl/workbook.xml'));rels=E.fromstring(zi.read('xl/_rels/workbook.xml.rels'));targets={x.attrib['Id']:x.attrib['Target'] for x in rels};paths={}
 for s in wb.find(tag('sheets')):
  t=targets[s.attrib['{'+R+'}id']];paths[s.attrib['name']]=t.lstrip('/') if t.startswith('/') else 'xl/'+t
 shared=[]
 if 'xl/sharedStrings.xml' in zi.namelist():
  for si in E.fromstring(zi.read('xl/sharedStrings.xml')):shared.append(''.join(x.text or '' for x in si.iter(tag('t'))))
 def put(root,addr,text):
  c=root.find('.//'+tag('c')+'[@r="'+addr+'"]')
  if c is None:return
  for x in list(c):c.remove(x)
  c.set('t','inlineStr');E.SubElement(E.SubElement(c,tag('is')),tag('t')).text=text
 calc=wb.find(tag('calcPr'))
 if calc is None:calc=E.SubElement(wb,tag('calcPr'))
 for k,v in {'calcMode':'auto','fullCalcOnLoad':'1','forceFullCalc':'1'}.items():calc.set(k,v)
 with zipfile.ZipFile(P.with_suffix('.tmp'),'w',zipfile.ZIP_DEFLATED) as zo:
  for info in zi.infolist():
   data=zi.read(info.filename)
   if info.filename=='xl/workbook.xml':data=E.tostring(wb,encoding='utf-8',xml_declaration=True)
   for name,changes in updates.items():
    if info.filename==paths[name]:
     root=E.fromstring(data)
     for addr,t in changes.items():put(root,addr,t)
     if name=='AUDITORIA':
      for row in root.findall('.//'+tag('row')):
       for c in row:
        if c.attrib.get('r','').startswith('A') and c.attrib.get('t')=='s':
         old=shared[int(c.find(tag('v')).text)]
         if old=='JSCV mantém 51%':put(root,c.attrib['r'],'JSCV corresponde ao cenário V03')
         if old=='Participação dentro 40%':put(root,c.attrib['r'],'Participação dentro dos cenários aprovados para análise (até50%)')
         if old=='Combinação cabe na ronda':put(root,c.attrib['r'],'Combinação até25M€; verificar quantidades em Blocos V03')
     data=E.tostring(root,encoding='utf-8',xml_declaration=True)
   if info.filename==paths['Pressupostos']:
    root=E.fromstring(data);dvs=root.find(tag('dataValidations'))
    for key,colrow in [('equity',6),('equity_price',6),('equity_stake',7),('legacy_jscv',8)]:
     addr='B'+str(M['param_rows'][key]);c=root.find('.//'+tag('c')+'[@r="'+addr+'"]');c.attrib.pop('t',None)
     for ch in list(c):c.remove(ch)
     E.SubElement(c,tag('f')).text="'Capital V03'!B"+str(colrow);E.SubElement(c,tag('v')).text=str(capital[key])
     if dvs is not None:
      for dv in list(dvs):
       if dv.attrib.get('sqref')==addr:dvs.remove(dv)
    if dvs is None:dvs=E.SubElement(root,tag('dataValidations'))
    bounds={k:(0,v) for k,v in [('n_platinum',1),('n_gold',1),('n_silver_plus',0),('n_silver',10)]}
    bounds.update({k:(1,180) for k in ['fund_month1','fund_month2','fund_month3','shareloan_start']});bounds['shareloan_term']=(1,240)
    for key,(lo,hi) in bounds.items():
     addr='B'+str(M['param_rows'][key]);dv=next((d for d in dvs if d.attrib.get('sqref')==addr),None)
     if dv is None:dv=E.SubElement(dvs,tag('dataValidation'),{'sqref':addr})
     dv.set('type','whole');dv.set('operator','between');dv.set('errorStyle','stop');dv.set('showErrorMessage','1')
     for ch in list(dv):dv.remove(ch)
     E.SubElement(dv,tag('formula1')).text=str(lo);E.SubElement(dv,tag('formula2')).text=str(hi)
    dvs.set('count',str(len(dvs)));data=E.tostring(root,encoding='utf-8',xml_declaration=True)
   zo.writestr(info,data)
os.replace(P.with_suffix('.tmp'),P);print(P,P.stat().st_size)
