"""Ajustes de apresentação e validação, sem alterar o motor ou valores financeiros."""
from pathlib import Path
import zipfile,xml.etree.ElementTree as E,json,hashlib,os,shutil,openpyxl
ROOT=Path(__file__).resolve().parents[1];p=ROOT/'entrega/KK01_Modelo_Integrado_V02.xlsx';src=ROOT/'recalc/KK01_Modelo_Integrado_V02.xlsx';shutil.copyfile(src,p)
M=json.loads((ROOT/'src/build_metadata.json').read_text());NS='http://schemas.openxmlformats.org/spreadsheetml/2006/main';REL='http://schemas.openxmlformats.org/officeDocument/2006/relationships'
values=openpyxl.load_workbook(src,data_only=True,read_only=True)
payback_value=values['KPI'].cell(M['kpi_rows']['investor_payback'],2).value
eq=values['Ronda Investidores']['B20'].value;stake=values['Retornos']['C13'].value
hotel=values['Pressupostos'].cell(M['param_rows']['hotel'],2).value;bank=values['Pressupostos'].cell(M['param_rows']['bank'],2).value
caption_cached=f'V02 • {eq/1000000:.1f} M€ / {stake:.0%} • Hotel {hotel} • Banco {bank} • Fundos sujeitos a formalização jurídica'.replace('.0 M€',',0 M€')
values.close()
caption='"V02 • "&TEXT(\'Ronda Investidores\'!B20/1000000,"0.0")&" M€ / "&TEXT(\'Retornos\'!C13,"0%")&" • Hotel "&\'Pressupostos\'!$B$'+str(M['param_rows']['hotel'])+'&" • Banco "&\'Pressupostos\'!$B$'+str(M['param_rows']['bank'])+'&" • Fundos sujeitos a formalização jurídica"'
with zipfile.ZipFile(p) as zi:
 book=E.fromstring(zi.read('xl/workbook.xml'));rels=E.fromstring(zi.read('xl/_rels/workbook.xml.rels'));targets={r.attrib['Id']:r.attrib['Target'] for r in rels};paths={}
 for s in book.find('{'+NS+'}sheets'):
  target=targets[s.attrib['{'+REL+'}id']];paths[s.attrib['name']]=target.lstrip('/') if target.startswith('/') else 'xl/'+target
 calc=book.find('{'+NS+'}calcPr')
 if calc is None:calc=E.SubElement(book,'{'+NS+'}calcPr')
 calc.set('calcMode','auto');calc.set('fullCalcOnLoad','1');calc.set('forceFullCalc','1')
 tmp=p.with_suffix('.tmp')
 with zipfile.ZipFile(tmp,'w',zipfile.ZIP_DEFLATED) as zo:
  for item in zi.infolist():
   data=zi.read(item.filename)
   if item.filename=='xl/workbook.xml':data=E.tostring(book,encoding='utf-8',xml_declaration=True)
   elif item.filename==paths['Pressupostos']:
    root=E.fromstring(data);dvs=root.find('{'+NS+'}dataValidations')
    for key in ['commercial_delay','actual_month','n_platinum','n_gold','n_silver_plus','n_silver']:
     addr='B'+str(M['param_rows'][key]);dv=next((x for x in dvs if x.attrib.get('sqref')==addr),None)
     if dv is None:dv=E.SubElement(dvs,'{'+NS+'}dataValidation',{'sqref':addr})
     dv.set('type','whole');dv.set('operator','between');dv.set('errorStyle','stop');dv.set('showErrorMessage','1')
     for x in list(dv):dv.remove(x)
     E.SubElement(dv,'{'+NS+'}formula1').text='0';E.SubElement(dv,'{'+NS+'}formula2').text='180' if key in ['commercial_delay','actual_month'] else '100000'
    dvs.set('count',str(len(dvs)));data=E.tostring(root,encoding='utf-8',xml_declaration=True)
   elif item.filename==paths['EXEC KK01']:
    root=E.fromstring(data);cell=root.find('.//{'+NS+'}c[@r="A3"]');assert cell is not None
    for child in list(cell):cell.remove(child)
    cell.set('t','str');E.SubElement(cell,'{'+NS+'}f').text=caption;E.SubElement(cell,'{'+NS+'}v').text=caption_cached
    data=E.tostring(root,encoding='utf-8',xml_declaration=True)
   elif item.filename==paths['DASH Acionistas']:
    root=E.fromstring(data);sd=root.find('{'+NS+'}sheetData');row=sd.find('{'+NS+'}row[@r="20"]')
    if row is None:
     row=E.Element('{'+NS+'}row',{'r':'20'})
     nexti=next((i for i,x in enumerate(sd) if int(x.attrib['r'])>20),len(sd));sd.insert(nexti,row)
    for addr,formula,value in [('A20',None,'Payback por dividendos (meses)'),('B20',"'KPI'!B"+str(M['kpi_rows']['investor_payback']),payback_value)]:
     c=row.find('{'+NS+'}c[@r="'+addr+'"]')
     if c is None:c=E.SubElement(row,'{'+NS+'}c',{'r':addr})
     for child in list(c):c.remove(child)
     if formula is None:
      c.set('t','inlineStr');E.SubElement(E.SubElement(c,'{'+NS+'}is'),'{'+NS+'}t').text=str(value)
     else:
      c.set('t','str' if isinstance(value,str) else 'n');E.SubElement(c,'{'+NS+'}f').text=formula;E.SubElement(c,'{'+NS+'}v').text=str(value)
    data=E.tostring(root,encoding='utf-8',xml_declaration=True)
   zo.writestr(item,data)
os.replace(tmp,p)
print('V02 finalizada:',p.stat().st_size,'bytes; cálculo integral ao abrir e validações inteiras.')
