# KK-01 — V03

Continuidade da V02. Alteração expressamente confirmada pelo utilizador: apenas Platinum, Gold e Silver; 25 M€ por50%, JSCV40%, JALS10%. Não modifica Estatutos ou contratos.

## Utilização

Abrir entrega/KK01_Modelo_Integrado_V03.xlsx em Excel com cálculo automático. Começar em EXEC KK01. Editar células azuis e selecionar capital_scenario em Pressupostos. Para subscrição parcial selecionar Combinação tickets: máximo1Platinum,1Gold,10Silver. Silver Plus está desativado na V03 e preservado apenas no histórico.

Os valores de cenário não são comprovativos de capital realizado. Capital V03 distingue contratado, recebido, retido e transferido. Campos documentados sem prova ficam vazios. 25M€ entram na KK apenas sob a hipótese contratual de transferência integral. Testar empréstimo se houver reembolso.

## Ambiente e reprodução

Python3.11+; `python -m pip install -r requirements.txt`. Recálculo externo requer LibreOffice/soffice. Sem serviços persistentes, macros ou novas credenciais. Usar o checkout existente, sem criar worktree.

1. `python src/engine.py`
2. `python src/build_model.py`
3. `python src/test_selectors.py` — invalida todas as caches e recalcula cada variante com perfil isolado. Inclui referência V03_Referencia e12casos. Não aceitar saídas sem execução concluída e sem confronto Python.
4. Copiar validacao/V03_Referencia/out/V03_Referencia.xlsx para entrega/KK01_Modelo_Integrado_V03.xlsx.
5. `python src/finalize_v03.py` e `python src/presentation_v03.py` — rótulos, validações e disposição, sem mudar resultados financeiros.
6. `python src/test_v03.py` e `python src/audit_selector_metrics.py`.
7. `python src/reports_v03.py` e `python src/export_exec_v03.py`.

`correct_seller_flows.py` é um registo de correção aditiva; o builder já contém a correção. Scripts upgrade_* e finalize_v02 são históricos, não executar sobre V03. O pacote inclui a V02 preservada, a V45 original e motor V02 para regressão económica. Resultados detalhados em entrega/.

O recálculo foi executado com LibreOffice e confrontado com Python. Excel desktop não foi executado. Formatos Excel seguem a região portuguesa; no PDF executivo os separadores são explicitamente portugueses. Cópia PDF transforma apenas a apresentação em texto, nunca as fórmulas do modelo entregue.
