# KK-01 | Rentabilidade por categoria V03

18/10/2026 | KK Hotelaria e Turismo, S.A. | V03

| Categoria | Ticket | Quota | €/p.p. | TIR10A | TIR15A | MOIC15A | VPL15A |
|---|---|---|---|---|---|---|---|
| Platinum | 10.000.000,00 € | 20,00% | 500.000,00 € | 7,04% | 7,79% | 2,50 | -3.460.824,07 € |
| Gold | 5.000.000,00 € | 10,00% | 500.000,00 € | 7,04% | 7,79% | 2,50 | -1.730.412,04 € |
| Silver | 1.000.000,00 € | 2,00% | 500.000,00 € | 7,04% | 7,79% | 2,50 | -346.082,41 € |

Por bloco e sem benefícios económicos inventados. Platinum, Gold eSilver têm o mesmo preço por ponto percentual e, nas mesmas datas, igual TIR. Todos os blocos ativos têm o mesmo preço por ponto percentual (500.000€) e, com datas e direitos iguais, a mesma TIR. A soma dos retornos de 1 Platinum+1 Gold+10 Silver reconcilia a participação de 50%.

Não existe preferência de dividendos nem retorno garantido. Custos de benefícios são zero apenas por falta de proposta documentada; podem ser simulados por categoria em Pressupostos e afetam EBITDA, CFADS, dívida, dividendos e saída. Aplicam-se a todos os 19 blocos; direitos económicos preferenciais carecem de aprovação expressa e modelação contratual adicional.

## Platinum

| Horizonte | Dividendos | Saída estimada | Total recebido |
|---|---|---|---|
| 10anos | 5.508.926,55 € | 12.637.768,82 € | 18.146.695,37 € |
| 15anos | 9.923.144,91 € | 15.043.771,66 € | 24.966.916,57 € |

## Gold

| Horizonte | Dividendos | Saída estimada | Total recebido |
|---|---|---|---|
| 10anos | 2.754.463,28 € | 6.318.884,41 € | 9.073.347,68 € |
| 15anos | 4.961.572,46 € | 7.521.885,83 € | 12.483.458,29 € |

## Silver

| Horizonte | Dividendos | Saída estimada | Total recebido |
|---|---|---|---|
| 10anos | 550.892,66 € | 1.263.776,88 € | 1.814.669,54 € |
| 15anos | 992.314,49 € | 1.504.377,17 € | 2.496.691,66 € |

## Dividendos anuais por bloco

| Ano | Platinum | Gold | Silver |
|---|---|---|---|
| 1 | 0,00 € | 0,00 € | 0,00 € |
| 2 | 0,00 € | 0,00 € | 0,00 € |
| 3 | 649.460,20 € | 324.730,10 € | 64.946,02 € |
| 4 | 631.851,74 € | 315.925,87 € | 63.185,17 € |
| 5 | 640.514,49 € | 320.257,25 € | 64.051,45 € |
| 6 | 661.411,91 € | 330.705,96 € | 66.141,19 € |
| 7 | 686.729,67 € | 343.364,84 € | 68.672,97 € |
| 8 | 715.038,90 € | 357.519,45 € | 71.503,89 € |
| 9 | 745.654,64 € | 372.827,32 € | 74.565,46 € |
| 10 | 778.264,99 € | 389.132,50 € | 77.826,50 € |
| 11 | 812.745,64 € | 406.372,82 € | 81.274,56 € |
| 12 | 847.883,21 € | 423.941,60 € | 84.788,32 € |
| 13 | 882.336,30 € | 441.168,15 € | 88.233,63 € |
| 14 | 917.548,83 € | 458.774,41 € | 91.754,88 € |
| 15 | 953.704,38 € | 476.852,19 € | 95.370,44 € |

Payback corresponde apenas a dividendos acumulados cobrindo o preço pago, sem venda hipotética. Consultar a folha Retorno Categorias V03 para os meses por bloco. Hospitalidade subjetiva não é fluxo financeiro recebido.
