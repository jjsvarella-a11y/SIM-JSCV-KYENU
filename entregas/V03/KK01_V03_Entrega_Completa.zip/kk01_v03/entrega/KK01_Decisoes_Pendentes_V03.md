# KK-01 | Decisões pendentes V03

18/10/2026 | KK Hotelaria e Turismo, S.A. | V03

| Estado | Decisão / evidência necessária |
|---|---|
| Pendente de Validação Externa | Formalizar juridicamente a estrutura confirmada40/10/50 e transmissão11.000JSCV/39.000JALS |
| Pendente de Validação Externa | Validar alocação das ações por bloco e titularidade em subscrição parcial |
| Pendente de Validação Externa | Definir instrumento de transferência KK, fiscalidade, irrevogabilidade e reembolso |
| Pendente de Validação Externa | Confirmar compromissos, recebimentos, retenções e transferências por comprovativos |
| Pendente de Validação Externa | Validar votos, nomeações, matérias reservadas, proteção minoritária e direitos Platinum |
| Pendente de Validação Externa | Aprovar custos e regras benefícios; nenhuma yield/recompra/preferência aprovada |
| Pendente de Validação Externa | Confirmar banco6%/42M/10A, comissões, reservas, subordinação e aceitação equity |
| Pendente de Validação Externa | Receber proposta documentada e negociar HMA do Operador Internacional |
| Pendente de Validação Externa | Confirmar orçamento, áreas, cronograma, escrituras504/810 e incidências fiscais |
| Alerta | VPL investidores negativo à taxa desconto12%; saída não contratual |
| Alerta | Yield residencial inicial não coberta integralmente |

A hipótese não reembolsável do cenário principal não significa formalização. Se a operação for empréstimo, ativar a natureza reembolsável e rever os resultados. Campos documentados em branco permanecem indisponíveis. Não foi assinado ou alterado qualquer instrumento jurídico neste trabalho.
