# KK-01 | Quatro cenários de capital V03

18/10/2026 | KK Hotelaria e Turismo, S.A. | V03

Comparação independente, com o motor V02 preservado e extensões V03. Os 25 M€ são uma hipótese de transferência integral à KK no mês 1, sem obrigação de reembolso, não capital já comprovadamente realizado. Hotel Favorável; banco 6%,42 meses carência,10 anos após carência.

| Indicador | KK-E15 | KK-E20-A | KK-E20-B | KK-E25 |
|---|---|---|---|---|
| Preço / capital contratado | 15.000.000,00 € | 20.000.000,00 € | 20.000.000,00 € | 25.000.000,00 € |
| Capital mobilizado KK (hipótese) | 15.000.000,00 € | 20.000.000,00 € | 20.000.000,00 € | 25.000.000,00 € |
| Participação novos | 40,00% | 40,00% | 50,00% | 50,00% |
| Pico dívida bancária | 25.423.784,44 € | 20.117.238,46 € | 20.117.238,46 € | 14.883.293,59 € |
| Uso acumulado linha não renovável | 29.731.809,88 € | 24.423.415,74 € | 24.423.415,74 € | 19.187.648,01 € |
| Capacidade remanescente | 268.190,12 € | 5.576.584,26 € | 5.576.584,26 € | 10.812.351,99 € |
| Juros bancários | 1.858.076,72 € | 1.009.291,86 € | 1.009.291,86 € | 619.930,36 € |
| Comissões / broker | 1.125.000,00 € | 1.125.000,00 € | 1.125.000,00 € | 1.125.000,00 € |
| Caixa mínima 180M | 3.000.000,00 € | 3.000.000,00 € | 3.000.000,00 € | 3.633.802,73 € |
| Reserva construção máxima | 14.777.168,49 € | 14.777.168,49 € | 14.777.168,49 € | 14.777.168,49 € |
| Caixa M30 | 3.633.802,73 € | 3.633.802,73 € | 3.633.802,73 € | 8.717.152,56 € |
| Reserva M30 | 3.633.802,73 € | 3.633.802,73 € | 3.633.802,73 € | 3.633.802,73 € |
| Dívida abertura M31 | 5.771.735,94 € | 303.716,91 € | 303.716,91 € | 0,00 € |
| DSCR anual parcial | 1,01 | 1,82 | 1,82 | 2,99 |
| DSCR mínimo anual com serviço | 1,01 | 1,82 | 1,82 | 2,99 |
| Dividendos totais 15A | 38.379.937,37 € | 44.227.020,93 € | 44.227.020,93 € | 49.615.724,55 € |
| TIR projeto com saída | 21,87% | 21,87% | 21,87% | 21,87% |
| TIR investidores 15A | 8,73% | 7,06% | 9,03% | 7,79% |
| MOIC investidores 15A | 3,03 | 2,39 | 2,99 | 2,50 |
| VPL investidores (12%) | -4.686.835,26 € | -8.307.581,96 € | -5.431.475,47 € | -8.652.060,18 € |
| VPL projeto sem saída (10%) | 7.071.194,36 € | 7.071.194,36 € | 7.071.194,36 € | 7.071.194,36 € |
| Valor saída equity (estimado) | 75.216.499,14 € | 75.218.200,44 € | 75.218.200,44 € | 75.218.858,32 € |
| Recebimentos promotores 15A | 68.157.861,91 € | 71.667.132,82 € | 59.722.610,68 € | 62.417.291,44 € |
| Défice não financiado | 0,00 € | 0,00 € | 0,00 € | 0,00 € |
| Falta máxima reserva | 0,00 € | 0,00 € | 0,00 € | 0,00 € |

## Interpretação económica

KK-E25 reduz o pico da dívida para 14.883.293,59 €, juros para 619.930,36 € e dívida M30 para 0,00 €. A TIR agregada de 7,79% supera KK-E20-A (7,06%), mas fica abaixo de KK-E15 (8,73%). Maior segurança não constitui, por si só, superior retorno.

O VPL dos novos investidores, descontado a12%, permanece negativo no cenário de referência. A estrutura não demonstra atratividade suficiente para um investidor que exija 12%, apesar de melhorar a segurança financeira. A decisão depende do preço, participação, desempenho, valor de saída e custo de capital exigido.

O retorno depende substancialmente da saída estimada: EBITDA Hotel dos últimos 12 meses ×9, menos 2% custos, dívida e reservas restritas, com caixa adicionada uma vez. Não há venda ou liquidez contratualmente garantida. Apartamentos vendidos não são reavaliados na saída.

## Liquidez trimestre 1

| Cenário | T1: capital KK | RE líquido | CAPEX | Banco | Juros | Caixa fim |
|---|---|---|---|---|---|---|
| KK-E15 | 15.000.000,00 € | 1.829.645,00 € | 2.577.254,40 € | 0,00 € | 0,00 € | 14.252.390,60 € |
| KK-E20-A | 20.000.000,00 € | 1.829.645,00 € | 2.577.254,40 € | 0,00 € | 0,00 € | 19.252.390,60 € |
| KK-E20-B | 20.000.000,00 € | 1.829.645,00 € | 2.577.254,40 € | 0,00 € | 0,00 € | 19.252.390,60 € |
| KK-E25 | 25.000.000,00 € | 1.829.645,00 € | 2.577.254,40 € | 0,00 € | 0,00 € | 24.252.390,60 € |

## Liquidez trimestre 2

| Cenário | T2: capital KK | RE líquido | CAPEX | Banco | Juros | Caixa fim |
|---|---|---|---|---|---|---|
| KK-E15 | 0,00 € | 1.056.923,31 € | 4.576.521,60 € | 0,00 € | 0,00 € | 10.732.792,32 € |
| KK-E20-A | 0,00 € | 1.056.923,31 € | 4.576.521,60 € | 0,00 € | 0,00 € | 15.732.792,32 € |
| KK-E20-B | 0,00 € | 1.056.923,31 € | 4.576.521,60 € | 0,00 € | 0,00 € | 15.732.792,32 € |
| KK-E25 | 0,00 € | 1.056.923,31 € | 4.576.521,60 € | 0,00 € | 0,00 € | 20.732.792,32 € |

## Liquidez trimestre 3

| Cenário | T3: capital KK | RE líquido | CAPEX | Banco | Juros | Caixa fim |
|---|---|---|---|---|---|---|
| KK-E15 | 0,00 € | 2.334.308,38 € | 2.709.907,20 € | 0,00 € | 0,00 € | 10.357.193,50 € |
| KK-E20-A | 0,00 € | 2.334.308,38 € | 2.709.907,20 € | 0,00 € | 0,00 € | 15.357.193,50 € |
| KK-E20-B | 0,00 € | 2.334.308,38 € | 2.709.907,20 € | 0,00 € | 0,00 € | 15.357.193,50 € |
| KK-E25 | 0,00 € | 2.334.308,38 € | 2.709.907,20 € | 0,00 € | 0,00 € | 20.357.193,50 € |

## Liquidez trimestre 4

| Cenário | T4: capital KK | RE líquido | CAPEX | Banco | Juros | Caixa fim |
|---|---|---|---|---|---|---|
| KK-E15 | 0,00 € | 1.849.782,73 € | 3.651.110,40 € | 2.154.558,97 € | 10.772,79 € | 9.574.652,01 € |
| KK-E20-A | 0,00 € | 1.849.782,73 € | 3.651.110,40 € | 0,00 € | 0,00 € | 13.555.865,83 € |
| KK-E20-B | 0,00 € | 1.849.782,73 € | 3.651.110,40 € | 0,00 € | 0,00 € | 13.555.865,83 € |
| KK-E25 | 0,00 € | 1.849.782,73 € | 3.651.110,40 € | 0,00 € | 0,00 € | 18.555.865,83 € |
