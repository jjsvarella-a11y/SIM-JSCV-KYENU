# KK-01 | Auditoria e testes V03

18/10/2026 | KK Hotelaria e Turismo, S.A. | V03

A V03 foi desenvolvida de forma aditiva sobre a V02, com a V45 original e a V02 preservadas. O utilizador confirmou a revisão final para 25 M€/50%, JSCV40%/JALS10%, apenas Platinum,Gold,Silver. Nenhuma alteração de direitos jurídicos foi formalizada por este trabalho.

## Testes executados

| Verificação | Resultado |
|---|---|
| Regressão V02 intacta | 29testes passaram |
| V03 integrada | 20testes;0falhas;0erros |
| Seletores reais / recálculo externo | 12casos passaram;106652comparações numéricas |
| Retornos dos seletores | 14casos;2618comparações adicionais |
| Fórmulas com códigos de erro | 0na referência e variantes testadas |
| Ações e blocos | 100.000ações;100%;19blocos totais;12novos |
| Captação | 10+5+10×1=25M€;50%novos |
| Hiperligações / macros | 8ícones com8destinos distintos;sem macros |

## Alterações e fundamentos

| Módulo | Correção / conclusão |
|---|---|
| Capital | 25 M€/50% — Alteração expressamente confirmada pelo utilizador; não confundir com formalização societária. |
| Categorias | Platinum/Gold/Silver — Silver Plus desativado, preservado só no histórico. |
| Investidores | 1P+1G+10S;12blocos — 25 M€;50.000ações;preço uniforme500mil€/p.p. |
| JSCV/JALS | 40%/10% — 40.000/10.000ações;JSCV2P;JALS5S. |
| Ações cedidas | JSCV11.000/JALS39.000 — Alocação comercial proposta; validar transmissão e titularidade. |
| Tesouraria | Contratado/recebido/retido/transferido separados — Documentado desconhecido fica em branco; cenário não é realização comprovada. |
| Mobilização | Três tranches editáveis — Calendário alimenta caixa e fluxos dos investidores/promotores. |
| Reembolso | Se empréstimo:stock,juros,principal,serviço e saída — Bloqueia dividendos enquanto crédito dos vendedores não liquidado. |
| Retorno | Matriz por bloco10/15A — Dividendos,saída,MOIC,TIR,VPL,payback e dividendos anuais. |
| Benefícios | Custo por categoria na operação — 3P+1G+15S;sem yield,preferência ou recompra garantida. |
| Navegação | Preservado+comparação4cenários+5KPI — Ligações internas reais;PDF próprio com números portugueses. |
| Caches | Invalidar todos os caches e forçar recálculo — Confronto mensal independente, sem substituir fórmulas por constantes. |
| Teste imagens | 8objetos com8hiperligações distintas — LibreOffice reutiliza ficheiro idêntico em2ícones;as8ações foram verificadas. |
| Original | Preservados por SHA256 — Não reconstruído de raiz;novos fontes emv03/. |

## Estados financeiros e externos

| Estado | N.º controlos |
|---|---|
| Conforme | 30 |
| Alerta | 1 |
| Pendente de Validação Externa | 15 |

Conforme significa que o controlo técnico passou sob os pressupostos selecionados. Alerta não é ocultado. Pendente de Validação Externa assinala ausência de confirmação documental; resultados favoráveis não a substituem.

A auditoria histórica daV45 identificou 510 células com erro emcache, além de construções sintáticas inválidas. A V03 não declara que esses 510 erros eram 510 defeitos económicos independentes. A rastreabilidade histórica é mantida; os atuais resultados foram novamente recalculados e testados.

Não há défice nem falta material de reserva emKK-E25 sob a referência adotada. O cenário sem transferência KK apresenta défice e não é viável, mesmo comTIR positiva. Direitos,residencial,fiscalidade,HMA,comissões,banco,orçamento,escrituras 504/810e saída continuam dependentes de validação. O valor de saída é estimado e o VPL à taxa 12% é negativo.

Excel desktop não foi executado neste ambiente. FórmulasOOXML,gráficos,validações e hiperligações foram preservados; recálculo externo porLibreOffice confrontado comPython. Não há certificação financeira,jurídica,fiscal ou de avaliação independente.
