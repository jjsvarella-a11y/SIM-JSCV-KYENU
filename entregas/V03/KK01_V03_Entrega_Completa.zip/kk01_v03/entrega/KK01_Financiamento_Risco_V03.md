# KK-01 | Financiamento, liquidez e risco V03

18/10/2026 | KK Hotelaria e Turismo, S.A. | V03

| Cenário | Pico banco | Juros banco | Caixa M30 | Défice máx. | Falta reserva | TIR novos |
|---|---|---|---|---|---|---|
| KK-E25 referência | 14.883.293,59 € | 619.930,36 € | 8.717.152,56 € | 0,00 € | 0,00 € | 7,79% |
| Atraso comercial6meses | 26.519.380,35 € | 1.753.584,36 € | 3.633.802,73 € | 0,00 € | 0,00 € | 7,64% |
| Sobrecusto adicional10% | 21.208.382,85 € | 1.053.094,26 € | 3.633.802,73 € | 0,00 € | 0,00 € | 6,88% |
| Hotel Base | 14.729.944,18 € | 605.014,10 € | 8.732.068,81 € | 0,00 € | 0,00 € | 5,75% |
| Hotel Conservador | 14.618.426,81 € | 598.352,77 € | 8.738.730,15 € | 0,00 € | 0,00 € | 3,44% |
| Sem transferência KK | 28.436.657,01 € | 9.317.901,71 € | 3.633.802,73 € | 5.913.096,33 € | 13.248.672,83 € | 4,11% |
| Mobilização50/30/20% | 14.883.293,59 € | 619.930,36 € | 8.717.152,56 € | 0,00 € | 0,00 € | 8,04% |
| Empréstimo vendedores5% | 17.469.381,44 € | 787.506,49 € | 5.424.576,43 € | 0,00 € | 0,00 € | 3,79% |

TIR positiva com défice ou falta de reserva não comprova viabilidade. A linha é não renovável; amortização não recria capacidade. Juros sobre saldo utilizado. Equity prometido não constitui equity realizado para o banco. A tabela contém resultados condicionais, não previsões certificadas.

No modo Empréstimo, os fundos recebidos KK criam dívida separada: juro mensal 5%/12, carência de principal até 61,120 prestações lineares de 61a180, sem escudo fiscal de juros. Juros e capital entram no caixa e serviço obrigatório; dividendos bloqueados até dívida banco e vendedores liquidada. Saldo residual deduzido na saída e valor do crédito e pagamentos acrescidos ao retorno agregado dos vendedores. Subordinação e reconhecimento bancário por validar.

## Operador Internacional

| Condição | EBITDA180M | CFADS180M | Dividendos | TIR novos | Saída equity |
|---|---|---|---|---|---|
| Objetivo KK | 78.566.336,26 € | 46.553.922,59 € | 49.615.724,55 € | 7,79% | 75.218.858,32 € |
| Proposta simulada | 72.609.158,21 € | 41.788.180,16 € | 45.304.948,98 € | 7,03% | 69.572.121,59 € |
| Limites propostos | 78.566.336,26 € | 46.553.922,59 € | 49.615.724,55 € | 7,79% | 75.218.858,32 € |

Objetivo KK3% base+3% distribuição/sistemas+6% incentivo. Incentivo incide noGOP positivo após fees fixos; pode ser condicionado aos mínimos deGOP e resultado pré-incentivo. Coluna proposta simulada 4/3/10 não representa oferta recebida. Limites não definidos usam objetivo como hipótese, sem aprovação.

Gestão/CFADS≥35%, sistemas/CFADS≥25% e total/CFADS≥50% geram alertas. Comparar valor produzido, não apenas desconto de fees. Agenda editável em Condicoes Operador abrange performance, orçamento,FF&E,CAPEX,distribuição,reporting,auditoria,rescisão.

Aumento 25M melhora resistência a riscos, mas não elimina os riscos de preço, calendário comercial, fiscalidade, custos, direitos residencial e desempenho do operador. VGV50.656.336,37€,94 frações; escrituras 504/810m29 provisórias. Yield residencial não integralmente coberta no arranque; não há garantia presumida.
