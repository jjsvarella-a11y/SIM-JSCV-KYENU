# KK-01 | Sociedade, blocos e governação V03

18/10/2026 | KK Hotelaria e Turismo, S.A. | V03

| Acionista | Platinum | Gold | Silver | Quota | Ações |
|---|---|---|---|---|---|
| JSCV | 2 | 0 | 0 | 40% | 40.000 |
| JALS | 0 | 0 | 5 | 10% | 10.000 |
| Novos | 1 | 1 | 10 | 50% | 50.000 |
| Total | 3 | 1 | 15 | 100% | 100.000 |

19 blocos totais;12 blocos investidores. Tickets 10+5+10×1=25 M€. Silver Plus desativado por instrução expressa e distribuição 40/10/50 confirmada pelo utilizador. JSCV cede 11.000 ações e JALS39.000 face à estrutura histórica 51/49. Não se aplica diluição proporcional.

A alocação de origem por bloco para permitir subscrição parcial é uma hipótese nova:11.000 ações JSCV e9.000 JALS no Platinum investidor; restantes 30.000 ações dos blocos Gold e Silver originárias JALS. Validar escolha, titularidade e transmissão. Nenhuma participação é concedida por blocos não subscritos no modo Combinação tickets.

No caso de pagamento parcial do preço, o modelo mostra participação subscrita esperada e saldo por realizar; não certifica aquisição/liquidação jurídica das ações. Ações, capital comprometido, recebido e transferido são conceitos separados.

## Matriz de governação proposta

| Dimensão | Estudo / proteção |
|---|---|
| Direitos económicos | Proporcionais às ações; sem preferência aprovada |
| Votos | Hipótese uma ação/um voto; confirmar Estatutos |
| Nomeações | Representação estratégica JSCV, investidores e independentes |
| Matérias reservadas | Orçamento, dívida, alienação; quóruns por aprovar |
| Platinum | Dois blocos/40% não são controlo absoluto; direitos por validar |
| Minoritários | Informação, igualdade tratamento, conflitos, auditoria |
| Liquidez | Estudar tag/drag/preferência; sem recompra obrigatória |

As propostas não alteram Estatutos, Acordo de Acionistas nem direitos legais. A eventual concentração de controlo pode criar conflitos com os 50% investidores e10% JALS; representação, proteção minoritária, regras de impasse e transmissibilidade precisam de parecer jurídico.
