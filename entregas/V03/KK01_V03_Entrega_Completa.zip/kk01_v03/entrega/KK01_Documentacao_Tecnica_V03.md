# KK-01 | Uso e documentação técnica V03

18/10/2026 | KK Hotelaria e Turismo, S.A. | V03

Continuidade aditiva sobre V02. Preservados os motores de 94 frações, construção, Hotel 200 quartos+MICE, residencial, banco não renovável e fluxos 180M. V02 original e fontes permanecem intactas. A V03 acrescenta cenários, calendário de capital, empréstimo de vendedores, benefícios, matrizes societárias e retornos por categoria.

| Folha | Função / fluxo |
|---|---|
| Pressupostos | Seletores de capital, operação, banco, custos, tranches, benefícios |
| Capital V03 | Contratado, recebido cenário, retido, transferido; realizado documentado separado |
| Blocos V03 | Quantidades inteiras, tickets, quotas, ações e saldos disponíveis |
| Matriz Societaria V03 | Antes/alvo/ativo; reconciliação100% e100.000ações |
| Governacao V03 / Beneficios V03 | Propostas separadas dos direitos económicos aprovados |
| Hotel / Residencial | Exploração autónoma; benefícios deduzidos após incentivo e antes do imposto |
| Fluxo180M / Anual | Reserva, banco, dívida vendedores, serviço obrigatório e dividendos |
| Comparativo Capital V03 | Quatro cenários recalculados em blocos do mesmo motor |
| Retorno Categorias V03 | Ticket próprio; dividendos,saída,TIR,MOIC,VPL,payback,anuais |
| EXEC KK01 /8painéis | Navegação interna real e KPI ligados às fontes |
| AUDITORIA / Mapa V45 | Controlos atuais e rastreabilidade da origem |

Escolher capital_scenario em Pressupostos:KK-E15,KK-E20-A,KK-E20-B,KK-E25. Para subscrição parcial escolher equity_mode=Combinação tickets e ajustar n_platinum≤1,n_gold≤1,n_silver≤10 (Silver Plus desativado). Quantidades não subscritas não atribuem ações. Modo Capital selecionado corresponde ao pacote de cenário; quantidades no quadro comercial são simulação independente até escolher Combinação tickets.

Capital mobilizado mensal=(preço−conversão)×received_ratio×treasury_ratio×peso das tranches no mês. Os pesos têm de somar 100%. Datas 1..180. Cenário de referência mês 1=100%, meses 7/13=0%. Capital recebido investidores=preço×received_ratio; retido=recebido×(1−treasury_ratio); KK=recebido×treasury_ratio. Realizado documentado não é inventado nem utilizado automaticamente.

KK-E25: 25 M€/50%; E20-A:20 M€/40%; E15:15 M€/40%; E20-B:20 M€/50% hipotético. E15/E20-A mantêm ponte 51% JSCV; E20-B assume 40% JSCV para comparação. Origem final de ações E20-B não é proposta contratual. Preço uniforme por ponto percentual nas três categorias; a tabela Investidores linear V02 é histórica, usar Retorno Categorias V03 para a oferta atual.

TIR anualizada=(1+TIR mensal)^12−1. VPL desconta cada fluxo mensal com taxa anual 12%; projeto 10%. MOIC=recebimentos totais/preço efetivamente pago no cenário. DSCR inclui principal obrigatório e juros bancários e eventual empréstimo dos vendedores; cash sweep voluntário excluído. Payback apenas por dividendos, sem saída estimada.

Custos benefício por bloco:3 Platinum+1 Gold+15 Silver. Dedução mensal na operação; custo zero por defeito é hipótese, não benefício contratado gratuito. Incentivo permanece sobre desempenho GOP após fees fixos, sem circularidade com EBITDA após incentivo. Eventuais direitos preferenciais não são obrigações incorporadas.

Execução: instalar requirements.txt,python src/engine.py,python src/build_model.py; invalidar caches de fórmulas e recalcular externamente com perfilLibreOffice OOXMLRecalcMode=0; python src/test_v03.py epython src/test_selectors.py. Não executar scripts antigos upgrade_engine/upgrade_builder sobre a V03. Excel cálculo automático, sem macros, inputs azuis com comentários. Revalidar qualquer alteração estrutural.

Limites: fiscalidade simplificada, histórico 4,5 M€ sem datas individuais, custos por atividade e valor terminal sujeitos a validação. Recalcular comLibreOffice é verificação externa de fórmulas; não substitui certificação porMicrosoftExcel desktop ou auditoria financeira/legal independente.
