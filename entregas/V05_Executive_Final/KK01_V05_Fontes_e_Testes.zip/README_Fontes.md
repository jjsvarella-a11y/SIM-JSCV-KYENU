# KK-01 V05 Executive — fontes e regressão

Este pacote preserva a referência numérica V04 e a camada financeira anterior; não contém as duas bases Excel, para evitar duplicação de ficheiros grandes. Python 3.12, Java 21 e LibreOffice são necessários para repetir todos os testes. Não utiliza macros no workbook. Consulte Ambiente_Validacao.json para versões e SHA do cliente Java.

## Bases necessárias

No repositório jjsvarella-a11y/SIM-JSCV-KYENU, branch entrega-k01:

- entregas/V04_Excel_Fix/KK01_Modelo_Integrado_V04_Excel_Fix.xlsx (SHA-256 be8288ced2494ef31c2dbe1d31d77b8277a0753a1209a8df0a83c3a5d86dcdc0).
- entregas/V05_Executive_Fase2/KK01_Modelo_Integrado_V05_Executive.xlsx (base da camada anterior).

Configurar KK01_ORIGINAL_PATH e KK01_BASE_PATH com os caminhos absolutos destas bases. Extrair este pacote para uma pasta de trabalho nova; os scripts identificam a raiz pela localização de src. Instalar requirements.txt e disponibilizar soffice e java no PATH. Criar entrega e validacao antes de iniciar.

## Sequência de reprodução

Executar a partir da pasta extraída:

```bash
python src/build.py
python src/bilingual_metadata.py
python src/test_model.py
python src/run_live.py
python src/audit_live.py
python src/merge_caches.py
python src/finish_presentation.py
python src/audit_structure.py
```

Executar cada etapa uma única vez numa construção nova. bilingual_metadata e finish_presentation são passos de construção, não comandos de edição repetida. run_live executa 35 cenários em cópias privadas e pode demorar dezenas de minutos. O cliente Java é obtido de Maven Central e o SHA usado nesta entrega está em Ambiente_Validacao.json. A comparação é entre recálculo nativo e motor Python, incluindo 180 meses e reabertura dos 62 motores.

Nesta entrega foi ainda executada uma verificação final independente da interface bilingue (NativeUI), resumida em Testes_Nativos_Final_UI.json. audit_ui.py é o analisador dos snapshots dessa sessão, não o lançador; para repetir, usar run_live.worker com os casos Base/PT_EN/Filtro_ID201 e raiz validacao/NativeUI, após criar out e canonical.sha256 nessa raiz. O resultado Base.xlsx é o que foi usado para caches finais.

reports.py e package_delivery.py documentam a emissão desta entrega. As pontes históricas em reports.py requerem também Ponte_Impactos_V04_V05.json e Registo_Alteracoes_Fase2.json da entrega anterior nos caminhos históricos indicados no script. package_delivery.py tem um destino de publicação local explícito, que deve ser adaptado antes de o executar noutro ambiente. Estes passos não são necessários para reproduzir os cálculos.

## Evidência e limites

Resumo_Testes_Nativos.json identifica os hashes das construções testadas. Reconciliacao_Caches_Final.json demonstra preservação das fórmulas na transferência de caches. Prova_Formatacao_Sem_Alteracao_Financeira.json demonstra igualdade de fórmulas e valores numéricos antes/depois da apresentação final. Teste_Final_Entregue.json compara o próprio XLSX entregue com Python. Manifesto_SHA256.json identifica os ficheiros finais.

A ausência de erros no LibreOffice e a inspeção OOXML não certificam Microsoft Excel Desktop. Não foi possível executar esse programa neste ambiente. Hipóteses fiscais, societárias, contratuais e dividendos legalmente aprovados requerem validação externa; simulações não são pagamentos efetivos.
