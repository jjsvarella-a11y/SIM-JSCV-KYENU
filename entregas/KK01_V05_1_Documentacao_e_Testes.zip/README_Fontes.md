# KK-01 V05.1 — reprodução da atualização visual

A pasta src contém os passos de refinamento, inspeção visual, prova de invariância e verificação nativa. financial_reference contém uma cópia das fontes numéricas anteriores, utilizada como referência sem alterações. O XLSX V05 de origem não está duplicado neste pacote.

Definir KK01_VISUAL_BASE para o caminho absoluto de KK01_Modelo_Integrado_V05_Executive.xlsx da entrega anterior. SHA-256 esperado: 432fdb6040316056c0f0e1125125f356660df5003719172de368123026452ed5. Opcionalmente definir KK01_V05_SRC para a pasta src das fontes anteriores; sem esta variável, usa financial_reference/src, quando existe.

Dependências: Python 3.12; openpyxl, numpy, scipy, psutil; Java 21 e LibreOffice/soffice no PATH para recálculo nativo. O cliente UNO é descarregado de Maven Central por run_native.py e validado por SHA-256. Não são executadas macros no ficheiro.

Sequência numa extração nova: python src/refine.py; python src/run_native.py; python src/check_native.py; python src/verify.py. Criar entrega e validacao previamente. preview.py produz uma cópia estática para conversão PDF; não a usar como modelo financeiro nem como evidência de recálculo.

O teste verifica os 180 meses e os 62 motores em Base, e a interface PT/EN/filtro em três casos. A prova compara também todas as fórmulas e valores numéricos existentes com a V05 original. Não certifica Excel Desktop.
