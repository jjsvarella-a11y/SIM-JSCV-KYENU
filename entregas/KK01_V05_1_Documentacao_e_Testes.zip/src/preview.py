"""Static cached-value copy for visual inspection only; never financial evidence."""
from refine import *
def main():
 keep={q[0] for q in NAV}|{'DIC_TRANSLATIONS','V05 Dados','V05 Trimestres','V05 RE A','V05 RE B'}
 preview=ROOT/'validacao/Preview_Static.xlsx'
 with zipfile.ZipFile(OUT) as z:
  ps=paths(z);kept={p for sn,p in ps.items() if sn in keep};drop={p for sn,p in ps.items() if sn not in keep};drop|={posixpath.dirname(p)+'/_rels/'+posixpath.basename(p)+'.rels' for p in drop}
  wb=E.fromstring(z.read('xl/workbook.xml'));sheets=wb.find(T('sheets'));oldindices={i:q.attrib['name'] for i,q in enumerate(sheets)}
  for sh in list(sheets):
   if sh.attrib['name'] not in keep:sheets.remove(sh)
   else:sh.set('state','visible' if sh.attrib['name'] in {q[0] for q in NAV} else 'hidden')
  newindices={q.attrib['name']:i for i,q in enumerate(sheets)};names=wb.find(T('definedNames'))
  for name in list(names):
   sn=oldindices.get(int(name.attrib.get('localSheetId','-1')))
   if sn in keep and name.attrib['name']=='_xlnm.Print_Area':name.set('localSheetId',str(newindices[sn]))
   else:names.remove(name)
  for v in wb.find(T('bookViews')):v.set('activeTab',str(newindices['EXEC V05']))
  wr=E.fromstring(z.read('xl/_rels/workbook.xml.rels'))
  for r in list(wr):
   if r.attrib['Type'].endswith('/worksheet'):
    t=r.attrib['Target'];p=t.lstrip('/') if t.startswith('/') else posixpath.normpath('xl/'+t)
    if p not in kept:wr.remove(r)
  ct=E.fromstring(z.read('[Content_Types].xml'))
  for el in list(ct):
   if el.attrib.get('PartName','').lstrip('/') in drop:ct.remove(el)
  mods={'xl/workbook.xml':E.tostring(wb),'xl/_rels/workbook.xml.rels':E.tostring(wr),'[Content_Types].xml':E.tostring(ct)}
  for p in kept:
   x=E.fromstring(z.read(p))
   for c in x.iter(T('c')):
    f=c.find(T('f'))
    if f is not None:
     c.remove(f)
     if c.attrib.get('t')=='str':
      v=c.findtext(T('v'),'');c.remove(c.find(T('v')));c.set('t','inlineStr');E.SubElement(E.SubElement(c,T('is')),T('t')).text=v
   mods[p]=E.tostring(x)
  with zipfile.ZipFile(preview,'w',zipfile.ZIP_DEFLATED,compresslevel=3) as dst:
   for item in z.infolist():
    if item.filename not in drop:dst.writestr(item,mods.get(item.filename,z.read(item.filename)))
 print(preview)
if __name__=='__main__':main()
