"""External UNO driver; no macros. Requires Java, soffice and prior model sources."""
from refine import *
import urllib.request
import run_live as native
def main():
 jar=ROOT/'validacao/java/libreoffice-26.2.2.jar';jar.parent.mkdir(parents=True,exist_ok=True)
 if not jar.exists():jar.write_bytes(urllib.request.urlopen('https://repo.maven.apache.org/maven2/org/libreoffice/libreoffice/26.2.2/libreoffice-26.2.2.jar',timeout=60).read())
 assert hashlib.sha256(jar.read_bytes()).hexdigest()=='37b94f944cb35fdbdb586d08df65419b42f1bd2363e143958dbae63ca15c23b3'
 root=ROOT/'validacao/NativeFinal';(root/'out').mkdir(parents=True,exist_ok=True);(root/'canonical.sha256').write_text(hashlib.sha256(OUT.read_bytes()).hexdigest());native.ROOT=ROOT;native.OUTPUT=OUT
 native.worker(4,[c for c in native.CASES if c[0] in ['Base','PT_EN','Filtro_ID201']],root)
if __name__=='__main__':main()
