"""Surgical presentation upgrade: preserve every existing formula and numeric cache."""
from pathlib import Path
import os,sys,zipfile,xml.etree.ElementTree as E,hashlib,json,re,posixpath,copy
previous=Path(os.environ.get('KK01_V05_SRC',str(Path(__file__).resolve().parents[1]/'financial_reference/src')))
if not previous.exists():previous=Path('/workspace/kk01/v05_final/src')
sys.path.insert(0,str(previous))
from common import paths,T,N,RID,PR
from openpyxl.styles import Font,PatternFill,Border,Side,Alignment
from openpyxl.utils import get_column_letter as CL,column_index_from_string as CI

ROOT=Path(__file__).resolve().parents[1]
BASE=Path(os.environ.get('KK01_VISUAL_BASE','/workspace/SIM-JSCV-KYENU/entregas/KK01_Modelo_Integrado_V05_Executive.xlsx'))
OUT=ROOT/'entrega/KK01_Modelo_Integrado_V05_1_Executive.xlsx'
REL='http://schemas.openxmlformats.org/package/2006/relationships'
DRAW='http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing'
A='http://schemas.openxmlformats.org/drawingml/2006/main'
C='http://schemas.openxmlformats.org/drawingml/2006/chart'
GUIDE='V05.1 KPI Guide'
NAV=[('EXEC V05','Visão Executiva','Executive Overview'),('DASH 01 V05','Investimento e Construção','Investment & Construction Cost Breakdown'),('DASH 02','Fiscalidade, Incentivos e Seguros','Tax, Incentives & Insurance'),('DASH 03 V05','Análise Consolidada','Project Consolidated'),('DASH 04A V05','Promoção Imobiliária','Real Estate Development'),('DASH 04B V05','Residencial e Exploração','Residential Sell & Leaseback'),('DASH 05 V05','Hotel e Centro MICE','Hotel & MICE'),('DASH 06 V05','Acionistas e Blocos','Shareholder Structure & Investment Blocks'),('DASH 07 V05','Retornos e Distribuições','Equity Returns & Waterfall')]
def sheet_value(c):
 if c is None:return ''
 if c.attrib.get('t')=='inlineStr':return ''.join(c.find(T('is')).itertext())
 return c.findtext(T('v'),'')
def cells(x):return {c.attrib['r']:c for c in x.iter(T('c'))}
def cell(x,addr):
 data=x.find(T('sheetData'));m=re.fullmatch(r'([A-Z]+)(\d+)',addr);r=int(m[2]);row=next((q for q in data if int(q.attrib['r'])==r),None)
 if row is None:
  row=E.Element(T('row'),{'r':str(r)});data.insert(next((i for i,q in enumerate(data) if int(q.attrib['r'])>r),len(data)),row)
 c=next((q for q in row if q.attrib.get('r')==addr),None)
 if c is None:
  c=E.Element(T('c'),{'r':addr});idx=CI(m[1]);row.insert(next((i for i,q in enumerate(row) if CI(re.match('[A-Z]+',q.attrib['r'])[0])>idx),len(row)),c)
 return c
def settext(c,text):
 assert c.find(T('f')) is None,c.attrib
 for q in list(c):c.remove(q)
 c.set('t','inlineStr');E.SubElement(E.SubElement(c,T('is')),T('t')).text=text
def setformula(c,formula,value,typ='n'):
 assert c.find(T('f')) is None,c.attrib
 for q in list(c):c.remove(q)
 c.set('t',typ);E.SubElement(c,T('f')).text=formula.lstrip('=');E.SubElement(c,T('v')).text=str(value)
def addmerge(x,ref):
 merge=x.find(T('mergeCells'))
 if merge is None:merge=E.SubElement(x,T('mergeCells'))
 if not any(q.attrib['ref']==ref for q in merge):E.SubElement(merge,T('mergeCell'),{'ref':ref})
 merge.set('count',str(len(merge)))
def hyperlink(x,addr,dest,tip=''):
 links=x.find(T('hyperlinks'))
 if links is None:
  links=E.Element(T('hyperlinks'));idx=next((i for i,q in enumerate(x) if q.tag.split('}')[-1] in ['printOptions','pageMargins','pageSetup','headerFooter','drawing','legacyDrawing']),len(x));x.insert(idx,links)
 h=next((h for h in links if h.attrib.get('ref')==addr),None)
 if h is None:h=E.SubElement(links,T('hyperlink'),{'ref':addr})
 h.attrib.pop(RID,None);h.set('location',dest.lstrip('#'));h.set('tooltip',tip or 'Open linked section')
def namespace(el):
 if not isinstance(el,E.Element):
  from openpyxl.xml.functions import tostring
  el=E.fromstring(tostring(el))
 for q in el.iter():q.tag=T(q.tag)
 return el
def signature(z):
 f={};numbers={}
 for sn,p in paths(z).items():
  # Stream very large engines, avoiding simultaneous full workbook allocation.
  x=E.fromstring(z.read(p));fd={};nd={}
  for c in x.iter(T('c')):
   a=c.attrib['r'];formula=c.find(T('f'));v=c.find(T('v'))
   if formula is not None:fd[a]=(formula.text or '',dict(formula.attrib))
   if v is not None and c.attrib.get('t','n') in ['n','b']:nd[a]=v.text
  f[sn]=fd;numbers[sn]=nd
 return f,numbers

READ={
 'area':('Sum of the total residential unit areas recorded in the 94-unit inventory.','The inventory basis includes balconies as recorded; this is different from the approximately 47,000 sqm overall construction area.','Reconcile areas with the approved architectural documents before contractual use.'),
 'historic':('Historical promoter investment retained as a sunk-cost reference.','It is not repeated as a future cash outflow or treated as new cash contributed to KK.','Reconcile supporting evidence; individual promoter IRRs require actual dates and costs.'),
 'cash30':('Month-end consolidated cash balance at project month 30.','Read with construction completion, final deeds, tax liabilities and the required opening reserve.','At least the protected reserve; total cash is not the same as free cash.'),
 'cash42':('Month-end consolidated cash balance at project month 42.','This is the reference end of capital grace under the acceptable-limit bank scenario; other scenarios can use different grace periods.','Review mandatory debt service, tax payments and reserve coverage at the selected terms.'),
 'cash54':('Month-end consolidated cash after the simulated month-54 distribution.','The distribution has already been deducted; do not subtract it again. A positive balance can still be fully protected.','Compare with the month-54 reserve and future obligations before considering additional distributions.'),
 'reserve54':('Protected liquidity requirement in project month 54.','Includes the operating reserve and relevant study provisions, assessed tax and future commitment protections from the existing engine.','Month-end cash must cover this amount; reserve policy does not replace contractual covenants.'),
 'used':('Cumulative bank drawdowns over the 180-month horizon.','Repayments do not restore availability under the nonrevolving facility; cumulative use differs from outstanding debt.','Stay within the approved facility and permitted drawdown window.'),
 'dividends':('Total simulated ordinary distributions over the modelled distribution dates.','Excludes terminal sale proceeds; simulated, legally approved and actually paid amounts are separate.','Protect reserves and future commitments, profit availability and the selected distribution policy.'),
 'price_m2':('Total unit selling prices divided by total inventoried residential area.','This is an area-weighted portfolio price, not an arithmetic average of individual unit prices per sqm.','Compare like-for-like areas, unit mix, floors and contracted market evidence.'),
 're_net':('Residential sale receipts less KK-borne transfer tax, marketing and Kyenu sales commission.','This is net commercial receipts before construction, other deed costs and financing/tax charges.','Reconcile the full 100% collection schedule and avoid interpreting receipts as promotion profit.'),
 're_margin':('Gross selling prices less modelled commercial costs and allocated construction economic cost, divided by gross sales.','Construction allocation uses the selected area-based share; financing and corporate taxes are not included in this margin.','A positive margin is desirable, but the allocation is a study proxy rather than a certified component budget.'),
 'ltv':('Month-180 outstanding debt divided by estimated Hotel + MICE enterprise value.','Uses an indicative exit valuation; it is not an appraisal-based construction-stage lending covenant.','A lower ratio reduces leverage; obtain the bank definition and an independent valuation where required.'),
 'net_debt':('Ending debt less cash available after protected reserves, tax and relevant controls, divided by Year-15 EBITDA.','Protected liquidity is excluded from the cash deduction; a negative ratio indicates surplus eligible cash under the study definition.','Read with the exact prudential source formula and the bank covenant definition, which may differ.'),
 'interest':('Sum of monthly bank interest on the balance actually drawn.','Financing fees are shown separately; the amount depends on rates, timing, drawdowns and repayments.','Minimise financing cost while preserving mandatory liquidity and opening reserves.'),
 'payback':('Month when cumulative future project cash flow recovers after its last negative cumulative balance, excluding exit.','This is incremental project payback; it is not shareholder payback and does not repeat historical sunk investment.','Earlier recovery generally reduces exposure; read together with project NPV and liquidity risks.'),
 'vgv':('Forecast selling prices of all 94 apartments.','Read as gross sales potential, not cash already collected.','Reconcile to the unit inventory; no guaranteed sales.'),
 'capex':('Future base construction, supervision and contingency in the monthly engine.','Read together with VAT funding, financing fees and incremental costs.','Budget control; historical sunk investment is excluded.'),
 'capital':('Forecast primary capital entering KK under the selected contribution calendars.','This is planned funding, not documentary evidence of money received.','Compare with the approved EUR 25 million target; secondary proceeds do not fund KK.'),
 'peak':('Maximum drawn debt before repayment within a monthly period.','Shows the maximum financing exposure; cumulative use is a different measure.','Compare with the selected bank limit and drawdown conditions.'),
 'irr':('Monthly investor IRR annualised as (1 + monthly IRR)^12 - 1.','Includes contributions, projected distributions and the selected exit; read with MOIC and timing.','Compare with the editable equity discount rate; a higher IRR is not a guarantee.'),
 'moic':('Total investor proceeds divided by contributed capital.','Includes the hypothetical exit and ignores the time value of money.','Read alongside IRR; a multiple above 1 means projected nominal proceeds exceed capital.'),
 'npv':('Net investor cash flows discounted at the editable equity discount rate.','A negative result means the simulated return is below that required rate.','Zero or positive at the selected discount rate; assumptions still require validation.'),
 'project_npv':('Unlevered future project cash flows, including the selected exit, discounted at the project rate.','Different from investor NPV; excludes historical sunk costs and financing flows.','Read against the project discount rate and exit assumptions.'),
 'project_irr':('Annualised IRR of unlevered future project cash flows including the selected exit.','Not shareholder IRR; excludes historical sunk investment.','Read with project NPV and future funding requirements.'),
 'div54':('Simulated ordinary distribution in month 54 after the selected cash/profit safeguards.','An eligible date is not a promise of payment; partial distributions are possible.','Compare with the selected category objectives, 1.20x coverage and protected reserves.'),
 'equity':('Enterprise value less debt, transaction costs, protected contingencies and unpaid tax, plus eligible cash once.','Estimated proceeds at exit; not a contracted or guaranteed sale price.','Use the selected 10x / 12x / 15x EBITDA multiple and avoid counting cash twice.'),
 'ev':('Hotel + MICE value based on the selected multiple and project Year 15 EBITDA.','Sold apartments are excluded; this is enterprise value before the equity bridge.','Compare valuation scenarios; no buyer or exit price is contracted.'),
 'vat_peak':('Peak outstanding deductible input VAT awaiting offset or reimbursement.','Represents temporary financing exposure under the selected recovery assumptions.','Assess recovery delays and eligibility; reimbursement is not contractually confirmed.'),
 'vat':('Input VAT on taxable construction and supervision under the selected budget convention.','VAT cash outflow and recoverable balance are different from permanent economic cost.','Check deductibility, recovery timing and whether the quoted budget includes VAT.'),
 'gap':('Maximum positive difference between protected reserves and month-end cash.','A positive value is a reserve breach even if the cash balance remains positive.','Zero; review construction, tax and opening liquidity obligations.'),
 'fundgap':('Maximum unfinanced cash deficit in the monthly model.','A positive value requires a funding response; the model does not invent a bank draw.','Zero across all 180 months; also test reserve shortfalls.'),
 'dscr':('Annual CFADS divided by mandatory interest, principal and required debt charges.','Voluntary cash sweep is excluded. No mandatory service means not applicable, not infinite coverage.','Above 1 indicates cash coverage; negotiated covenants may require a higher ratio.'),
 'ebitda15':('Hotel + MICE EBITDA for project months 169 to 180.','This is project Year 15, not the fifteenth full operating year; replacement CAPEX and tax are separate.','Read with cash conversion, operator charges and maintenance needs.'),
 'headroom':('Minimum monthly cash remaining above the protected reserve.','A zero result means no additional cushion; a negative result signals a reserve breach.','Nonnegative throughout; a larger buffer provides more room for execution risk.'),
 'owners':('Residential owner pool distributions supported by the selected operating cash flows.','Not a guaranteed yield; distinct from Hotel + MICE shareholder distributions.','Compare supported income with the target-yield shortfall and owner obligations.'),
 'owner_short':('Residential target yield less distributions supported by the model.','A target shortfall is not automatically a debt or guarantee owed to owners.','Zero is desirable, subject to signed owner/operator terms.'),
 'irpc':('Corporate tax accrued on modelled annual taxable profits after the selected loss rules.','Accrual and cash payment differ; project-year calendars and fiscal bases are study assumptions.','Obtain external tax validation before treating amounts as legally payable.'),
 'irpc_paid':('Forecast corporate income-tax cash payments on the modelled payment calendar.','Not proof of an actual payment; unpaid accrued tax is protected in the liquidity and exit bridges.','Reconcile accrual, payments and the outstanding tax liability.'),
 'insurance':('Construction and operating insurance costs not already included elsewhere.','Budget provisions based on editable rates and bases; not binding insurer quotations.','Confirm coverage, insured values and inclusion in construction/OPEX to avoid duplication.'),
 'tax_saving':('Modelled tax difference versus the general regime on the same eligible profit basis.','A proposed incentive is not a granted benefit; approved mode requires documentary gating.','Validate each benefit, entity and approval document independently.'),
}

def main():
 ROOT.joinpath('entrega').mkdir(exist_ok=True)
 changes={};newparts={};stats={}
 with zipfile.ZipFile(BASE) as z:
  ps=paths(z);sty=E.fromstring(z.read('xl/styles.xml'));xfs=sty.find(T('cellXfs'));stylecache={};numberformats={q.attrib['numFmtId']:q.attrib['formatCode'] for q in sty.find(T('numFmts'))};localformats={}
  palette={'navy':'132436','nav2':'1C344B','gold':'C8AB77','paper':'F2F5F8','white':'FFFFFF','ink':'182D43','muted':'586B7D','line':'DCE4EC','teal':'146C78','blue':'E8F3FC'}
  def appendstyle(group,el):
   dest=sty.find(T(group));idx=len(dest);dest.append(namespace(el));dest.set('count',str(len(dest)));return idx
  def style(old='0',kind='body'):
   key=(str(old),kind)
   if key in stylecache:return stylecache[key]
   settings={
    'body':(11,'ink','white',False),'bg':(11,'ink','paper',False),'sidebar':(10,'white','navy',False),'nav':(10,'white','navy',False),'active':(10,'navy','gold',True),'brand':(18,'white','navy',True),'model':(10,'gold','navy',True),'subbrand':(9,'white','navy',False),'title':(23,'ink','paper',True),'subtitle':(10,'muted','paper',False),'meta':(10,'muted','paper',False),'label':(10,'muted','white',True),'value':(20,'ink','white',True),'section':(12,'ink','paper',True),'link':(10,'teal','paper',True),'alert':(11,'ink','blue',True),'note':(10,'muted','white',False),'foot':(9,'muted','paper',False),'tablehead':(10,'white','nav2',True),'table':(10,'ink','white',False),'help':(10,'teal','white',True)}
   size,fg,bg,bold=settings[kind];xf=copy.deepcopy(xfs[int(old)]);font=Font(name='Aptos',size=size,bold=bold,color=palette[fg]);fill=PatternFill('solid',fgColor=palette[bg]);border=Border(bottom=Side(style='thin',color=palette['line'])) if kind in ['table','tablehead'] else Border()
   xf.set('fontId',str(appendstyle('fonts',font.to_tree())));xf.set('fillId',str(appendstyle('fills',fill.to_tree())));xf.set('borderId',str(appendstyle('borders',border.to_tree())))
   oldalign=xf.find(T('alignment'))
   if oldalign is not None:xf.remove(oldalign)
   al=Alignment(vertical='center',horizontal='left',wrap_text=True,indent=1 if kind in ['nav','active','label','value','note','sidebar','brand','subbrand','model'] else 0)
   xf.append(namespace(al.to_tree()));xf.set('applyAlignment','1');xf.set('applyFont','1');xf.set('applyFill','1');xf.set('applyBorder','1')
   nf=xf.attrib.get('numFmtId','0');code=numberformats.get(nf,{'9':'0%','10':'0.00%','2':'0.00','3':'#,##0','4':'#,##0.00'}.get(nf))
   if code and kind in ['value','table']:
    if nf not in localformats:
     fmt=sty.find(T('numFmts'));newid=str(max(int(q.attrib['numFmtId']) for q in fmt)+1);E.SubElement(fmt,T('numFmt'),{'numFmtId':newid,'formatCode':code if '[$-' in code else '[$-0816]'+code});fmt.set('count',str(len(fmt)));localformats[nf]=newid
    xf.set('numFmtId',localformats[nf]);xf.set('applyNumberFormat','1')
   idx=len(xfs);xfs.append(xf);xfs.set('count',str(len(xfs)));stylecache[key]=idx;return idx
  def paint(x,addr,kind):
   c=cell(x,addr);c.set('s',str(style(c.attrib.get('s','0'),kind)));return c
  def band(x,r1,r2,c1,c2,kind):
   for r in range(r1,r2+1):
    for cc in range(c1,c2+1):paint(x,f'{CL(cc)}{r}',kind)
  dic=E.fromstring(z.read(ps['DIC_TRANSLATIONS']));dcs=cells(dic);nextrow=max(int(re.search(r'\d+',a)[0]) for a in dcs)
  def tr(key,pt,en):
   nonlocal nextrow
   nextrow+=1;r=nextrow
   for co,txt in [('A',key),('B',pt),('C',en)]:settext(cell(dic,f'{co}{r}'),txt)
   setformula(cell(dic,f'D{r}'),f'IF(CONFIG_LANGUAGE!$B$5="PT",B{r},C{r})',pt,'str')
   return f"'DIC_TRANSLATIONS'!D{r}",pt
  def translated(x,addr,key,pt,en):
   f,v=tr(key,pt,en);setformula(cell(x,addr),f,v,'str')
  for i,(sn,pt,en) in enumerate(NAV):
   for row in dic.find(T('sheetData')):
    rr=row.attrib['r'];cc={c.attrib['r']:c for c in row}
    if sheet_value(cc.get('A'+rr))=='nav'+sn:
     settext(cc['B'+rr],f'{i+1:02}  {pt}');settext(cc['C'+rr],f'{i+1:02}  {en}');cc['D'+rr].find(T('v')).text=f'{i+1:02}  {pt}'
    if sheet_value(cc.get('A'+rr))=='title'+sn:
     settext(cc['B'+rr],pt);settext(cc['C'+rr],en)
  kp=E.fromstring(z.read(ps['V05 KPI']));kc=cells(kp);entries={}
  for r in range(5,45):
   key=sheet_value(kc.get(f'A{r}'))
   if not key:continue
   entries[key]={'row':r,'name':sheet_value(kc.get(f'C{r}')),'pt':sheet_value(kc.get(f'B{r}')),'source':sheet_value(kc.get(f'F{r}')),'value':sheet_value(kc.get(f'D{r}')),'type':kc[f'D{r}'].attrib.get('t','n'),'style':kc[f'D{r}'].attrib.get('s','0')}
  # A dedicated reading guide augments, rather than replaces, the existing dictionaries.
  guide=E.Element(T('worksheet'));E.SubElement(guide,T('sheetPr'));E.SubElement(guide,T('dimension'),{'ref':'A1:G45'});views=E.SubElement(guide,T('sheetViews'));view=E.SubElement(views,T('sheetView'),{'workbookViewId':'0','showGridLines':'0','zoomScale':'85'});E.SubElement(view,T('pane'),{'ySplit':'4','topLeftCell':'A5','activePane':'bottomLeft','state':'frozen'});E.SubElement(guide,T('sheetFormatPr'),{'defaultRowHeight':'18'});cols=E.SubElement(guide,T('cols'))
  for i,width in enumerate([27,48,49,49,30,20,22],1):E.SubElement(cols,T('col'),{'min':str(i),'max':str(i),'width':str(width),'customWidth':'1'})
  E.SubElement(guide,T('sheetData'));settext(paint(guide,'A1','title'),'KK-01 | KPI READING GUIDE');addmerge(guide,'A1:G2');settext(paint(guide,'A3','subtitle'),'Definitions and interpretation in English | Linked to the central KPI Dictionary and original monthly engines.');addmerge(guide,'A3:G3')
  for col,txt in zip('ABCDEFG',['Metric','Definition','How to read','Desired reading / limitation','Source / engine','Full KPI Dictionary','Executive Overview']):settext(paint(guide,col+'4','tablehead'),txt)
  gr={}
  for j,(key,info) in enumerate(entries.items(),5):
   r=info['row'];gr[key]=j
   definition,reading,target=READ.get(key,(info['name']+' as calculated by the existing monthly model.','Read together with the linked definition, source formula and scenario limitations.','Review the selected assumptions; this is a simulation, not documentary evidence.'))
   texts=[info['name'],definition,reading,target,info['source'],'See KPI Dictionary','Return to Overview']
   for co,txt in zip('ABCDEFG',texts):settext(paint(guide,f'{co}{j}','help' if co in 'FG' else 'table'),txt)
   next(q for q in guide.find(T('sheetData')) if q.attrib['r']==str(j)).attrib.update({'ht':'94','customHeight':'1'})
   hyperlink(guide,f'F{j}',f"'V05 KPI'!A{r}",'Open the central definition, formula and limitations');hyperlink(guide,f'G{j}',"'EXEC V05'!A1")
   settext(paint(kp,f'J{r}','help'),'i  Reading Guide');hyperlink(kp,f'J{r}',f"'{GUIDE}'!A{j}",definition)
  E.SubElement(guide,T('autoFilter'),{'ref':f'A4:G{4+len(entries)}'})
  # mergeCells must precede hyperlinks / page configuration.
  gm=guide.find(T('mergeCells'));guide.remove(gm);guide.insert(list(guide).index(guide.find(T('hyperlinks'))),gm)
  settext(paint(kp,'J4','tablehead'),'Interpretation / Help');kp.find(T('dimension')).set('ref','A1:J47')
  order=['sheetPr','dimension','sheetViews','sheetFormatPr','cols','sheetData','autoFilter','mergeCells','hyperlinks']
  guide[:]=sorted(guide,key=lambda el:order.index(el.tag.split('}')[-1]))
  newparts['xl/worksheets/v051_guide.xml']=E.tostring(guide)
  tips={};chartfiles=[]
  for index,(sn,pt,en) in enumerate(NAV):
   x=E.fromstring(z.read(ps[sn]));cs=cells(x)
   band(x,1,46,1,3,'sidebar');band(x,1,46,4,20,'bg')
   colspec=x.find(T('cols'));colspec.clear()
   for a,b,width in [(1,1,2.8),(2,2,34),(3,3,2.8),(4,20,9.2)]:E.SubElement(colspec,T('col'),{'min':str(a),'max':str(b),'width':str(width),'customWidth':'1'})
   for row in x.find(T('sheetData')):
    r=int(row.attrib['r'])
    if r<=46:row.set('ht','18');row.set('customHeight','1')
   for rr,ht in [(1,24),(2,24),(3,20),(4,21),(5,11),(10,9),(15,9),(20,20),(36,8),(39,8),(42,8),(45,7)]:
    cell(x,'T'+str(rr));row=next(q for q in x.find(T('sheetData')) if q.attrib['r']==str(rr));row.set('ht',str(ht));row.set('customHeight','1')
   for addr,kind in [('A1','brand'),('D1','title'),('D3','subtitle'),('D4','meta'),('D37','alert'),('D40','note'),('D43','foot'),('D46','link'),('I46','link'),('O46','link'),('N3','link'),('P3','link'),('S3','link'),('D49','section')]:paint(x,addr,kind)
   settext(cell(x,'A1'),'KK-01\nHOTEL & RESIDENCES');addmerge(x,'A4:C4');settext(paint(x,'A4','model'),'V05.1 EXECUTIVE')
   for j,(target,_,_) in enumerate(NAV):
    rr=6+j*3;band(x,rr,rr+1,1,3,'active' if target==sn else 'nav');paint(x,'A'+str(rr),'active' if target==sn else 'nav')
    # Transparent native shapes handle sidebar clicks; linked cell text can otherwise
    # be forced to unreadable dark-blue by Calc's hyperlink colour preference.
    links=x.find(T('hyperlinks'))
    for h in list(links):
     if h.attrib.get('ref')=='A'+str(rr):links.remove(h)
    cell(x,'A'+str(rr)).find(T('v')).text=f'{j+1:02}  {NAV[j][1]}'
   for ref in ['N3:O3','P3:R3','S3:T3','D46:H46','I46:N46','O46:T46']:addmerge(x,ref)
   next(q for q in x.find(T('sheetData')) if q.attrib['r']=='46').set('ht','23')
   addmerge(x,'A34:C37');settext(paint(x,'A34','subbrand'),'INTEGRATED FINANCIAL\nCONTROL MODEL\n\nPraia · Cabo Verde')
   addmerge(x,'A40:C42');settext(paint(x,'A40','subbrand'),'200 hotel rooms · MICE\n94 residential units\n180-month financial model')
   addmerge(x,'A44:C46');settext(paint(x,'A44','model'),'PT / EN  |  GLOBAL LANGUAGE')
   for j in range(8):
    co=4+(j%4)*4;rr=6+(j//4)*5
    band(x,rr,rr+3,co,co+3,'note');paint(x,CL(co)+str(rr),'label');paint(x,CL(co)+str(rr+2),'value')
    formula=cell(x,CL(co)+str(rr+2)).findtext(T('f'),'');match=re.search(r"V05 KPI'!D(\d+)",formula)
    if match:
     key=next(k for k,v in entries.items() if v['row']==int(match[1]));info=entries[key];rd=READ.get(key,(info['name'],'Read the linked source and scenario assumptions.','Simulation; validate external conditions.'));tip='\n'.join([info['name'].upper(),rd[0],'HOW TO READ: '+rd[1],'REFERENCE: '+rd[2],'SOURCE: '+info['source'],'See KPI Dictionary / V05.1 KPI Guide.'])
     hyperlink(x,CL(co)+str(rr),f"'{GUIDE}'!A{gr[key]}",tip[:250]);tips[(sn,CL(co)+str(rr+2))]=tip
   if sn=='EXEC V05':
    for j,key in enumerate(['peak','equity','vat_peak','project_npv']):
     co=4+j*4;st=CL(co);en_=CL(co+3);info=entries[key];band(x,16,19,co,co+3,'note');addmerge(x,f'{st}16:{en_}17');addmerge(x,f'{st}18:{en_}19')
     translated(x,st+'16','V051_CARD_'+key,info['pt'],info['name']);paint(x,st+'16','label');num=cell(x,st+'18');num.set('s',str(style(info['style'],'value')));setformula(num,f"'V05 KPI'!D{info['row']}",info['value'],info['type']);hyperlink(x,st+'16',f"'{GUIDE}'!A{gr[key]}",READ[key][0]);tips[(sn,st+'18')]='\n'.join([info['name'].upper(),*READ[key],'SOURCE: '+info['source'],'See KPI Dictionary / V05.1 KPI Guide.'])
   else:
    # Replace the unused strip above the chart with a compact English reading panel.
    addmerge(x,'D16:T19');message={1:'INVESTMENT CONTROL\nReview the net construction budget alongside VAT funding, contingency, historical sunk costs and financing charges. Chapter controls remain linked to the existing monthly engine.',2:'TAX & INSURANCE | STUDY ASSUMPTIONS\nGeneral taxation is the reference. Proposed incentives are not granted benefits. VAT recovery depends on eligibility and timing; insurance amounts are provisions, not quotations.',3:'CONSOLIDATED LIQUIDITY\nCash must cover protected reserves and future commitments. A positive cash balance alone does not establish distributable liquidity. Check both funding and reserve shortfalls.',4:'COMMERCIAL VIEW\nThe filters below change the display only. Gross sales value, contracted receipts and development profit are different measures. Open a KPI label for definitions and sources.',5:'OWNER ECONOMICS\nResidential operating distributions are separate from Hotel + MICE shareholder cash flows. Target yield is not a guarantee; owner tax and contract terms require external validation.',6:'HOTEL & MICE OPERATIONS\nRead EBITDA together with operator charges, tax, maintenance and replacement CAPEX. CFADS ratios use the existing consolidated cash-flow definition; voluntary debt sweep is excluded from DSCR.',7:'OWNERSHIP & FUNDING\nThe approved 15-block structure is preserved. Planned primary capital finances KK; secondary proceeds do not. Economic participation, forecast distributions and actual payments are distinct.',8:'EQUITY RETURNS & EXIT\nIRR and MOIC include the selected estimated exit. Exit equity is allocated by approved ownership without restoring the old waterfall. Simulated dividends are not legally approved payments.'}[index]
    settext(paint(x,'D16','note'),message)
   addmerge(x,'D20:T20');settext(paint(x,'D20','section'),'MONTHLY OUTLOOK  /  Linked to the existing calculation engines')
   if sn=='EXEC V05':
    addmerge(x,'D35:T35');paint(x,'D35','note')
    formula='"EXECUTIVE READING | "&IF(\'V05 KPI\'!D{irr}<Pressupostos!B{discount},"Investor IRR below required return. ","Investor IRR meets selected required return. ")&IF(\'V05 KPI\'!D{div54}<SUMPRODUCT(\'V05 Config\'!B20:B22,\'V05 Config\'!C20:C22,\'V05 Config\'!E20:E22),"M54 distribution below minimum objective. ","M54 distribution covers minimum objective. ")&IF(MAX(\'V05 Sensibilidades\'!J5:J52)>0.01,"Sensitivity variants show reserve shortfalls.","No reserve shortfall in the displayed sensitivity grid.")'.format(discount=PR["equity_discount"],irr=entries["irr"]["row"],div54=entries["div54"]["row"])
    setformula(cell(x,'D35'),formula,'EXECUTIVE READING | Investor IRR below required return. M54 distribution below minimum objective. Sensitivity variants show reserve shortfalls.','str')
    next(q for q in x.find(T('sheetData')) if q.attrib['r']=='35').set('ht','32')
   hyperlink(x,'D46',f"'{GUIDE}'!A1",'Definitions, interpretation, sources and links to the full KPI Dictionary')
   # Preserve all existing display formulas; add an explicit guide action in the open margin.
   settext(paint(x,'T6','help'),'i');hyperlink(x,'T6',f"'{GUIDE}'!A1",'See KPI Dictionary and reading guide')
   views=x.find(T('sheetViews'))
   for v in views:
    v.set('showGridLines','0');v.set('zoomScale','80');v.set('zoomScaleNormal','80')
    pane=v.find(T('pane'))
    if pane is not None:pane.attrib.update({'xSplit':'3','ySplit':'5','topLeftCell':'D6','activePane':'bottomRight','state':'frozen'})
   setup=x.find(T('pageSetup'))
   if setup is not None:setup.attrib.update({'orientation':'landscape','paperSize':'8','fitToWidth':'1','fitToHeight':'1'})
   # Improve the lower tables while preserving blue editable controls and all validations.
   for a,c in list(cells(x).items()):
    rr=int(re.search(r'\d+',a)[0]);cc=CI(re.match('[A-Z]+',a)[0])
    if rr>=49 and cc>=4:
     oldxf=xfs[int(c.attrib.get('s','0'))];protection=oldxf.find(T('protection'))
     if protection is not None and protection.attrib.get('locked')=='0':continue
     if c.find(T('f')) is not None or sheet_value(c):paint(x,a,'section' if rr in [49,53,56,62,66] else 'table')
   addmerge(x,'D49:T49');next(q for q in x.find(T('sheetData')) if q.attrib['r']=='49').attrib.update({'ht':'27','customHeight':'1'})
   if index in [0,1,2,3,7,8]:
    for rr in ([51,52,53,54] if index in [1,2] else [51,52,53] if index in [7,8] else [51]):addmerge(x,f'D{rr}:T{rr}')
   if index in [0,3]:
    for rr in range(53,57):
     for a,b in [('D','F'),('G','J'),('K','N'),('O','T')]:addmerge(x,f'{a}{rr}:{b}{rr}')
   if index in [4,5]:
    for rr in [54,55,56,57,59,60]:
     addmerge(x,f'D{rr}:G{rr}');addmerge(x,f'H{rr}:K{rr}')
    for rr in range(66,97):
     for a,b in [('D','F'),('G','I'),('J','L'),('M','O'),('P','T')]:addmerge(x,f'{a}{rr}:{b}{rr}')
   if index==6:
    for rr in [51,52,53]:addmerge(x,f'D{rr}:G{rr}')
    for rr in [55,58]:addmerge(x,f'D{rr}:T{rr}')
   if index in [7,8]:
    for rr in range(56,60):
     for a,b in [('D','F'),('G','H'),('I','J'),('K','L'),('M','T')]:addmerge(x,f'{a}{rr}:{b}{rr}')
    for rr in range(62,78):
     for a,b in [('D','F'),('G','I'),('J','L'),('M','T')]:addmerge(x,f'{a}{rr}:{b}{rr}')
   # Anchors, sizes and line colours change; chart references and cached data stay intact.
   relpath=posixpath.dirname(ps[sn])+'/_rels/'+posixpath.basename(ps[sn])+'.rels';rels=E.fromstring(z.read(relpath))
   for rel in rels:
    target=rel.attrib['Target'];resolved=target.lstrip('/') if target.startswith('/') else posixpath.normpath(posixpath.join(posixpath.dirname(ps[sn]),target))
    if rel.attrib['Type'].endswith('/drawing'):
     drawing=E.fromstring(z.read(resolved))
     for anchor in drawing:
      start=anchor.find('{'+DRAW+'}from')
      if start is not None:start.find('{'+DRAW+'}row').text='20'
      ext=anchor.find('{'+DRAW+'}ext')
      if ext is not None:ext.attrib.update({'cx':'9650000','cy':'2850000'})
     dr=posixpath.dirname(resolved)+'/_rels/'+posixpath.basename(resolved)+'.rels'
     drawingrels=E.fromstring(z.read(dr))
     for relationship in list(drawingrels):
      t=relationship.attrib['Target'];chartfiles.append(t.lstrip('/') if t.startswith('/') else posixpath.normpath(posixpath.join(posixpath.dirname(resolved),t)))
     for j,(target,_,label) in enumerate(NAV+[('CONFIG_LANGUAGE','','Global PT / EN language')]):
      anchor=E.SubElement(drawing,'{'+DRAW+'}oneCellAnchor');start=E.SubElement(anchor,'{'+DRAW+'}from')
      for tag,txt in [('col','0'),('colOff','0'),('row',str(5+j*3 if j<9 else 43)),('rowOff','0')]:E.SubElement(start,'{'+DRAW+'}'+tag).text=txt
      E.SubElement(anchor,'{'+DRAW+'}ext',{'cx':'2750000','cy':'457200'});shape=E.SubElement(anchor,'{'+DRAW+'}sp');nv=E.SubElement(shape,'{'+DRAW+'}nvSpPr');pr=E.SubElement(nv,'{'+DRAW+'}cNvPr',{'id':str(100+j),'name':'Navigation '+str(j+1),'descr':'Open '+label});E.SubElement(pr,'{'+A+'}hlinkClick',{RID:'rIdNav'+str(j+1),'tooltip':'Open '+label});E.SubElement(nv,'{'+DRAW+'}cNvSpPr');sp=E.SubElement(shape,'{'+DRAW+'}spPr');geom=E.SubElement(sp,'{'+A+'}prstGeom',{'prst':'rect'});E.SubElement(geom,'{'+A+'}avLst');E.SubElement(sp,'{'+A+'}noFill');E.SubElement(E.SubElement(sp,'{'+A+'}ln'),'{'+A+'}noFill');E.SubElement(anchor,'{'+DRAW+'}clientData')
      E.SubElement(drawingrels,'{'+REL+'}Relationship',{'Id':'rIdNav'+str(j+1),'Type':'http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink','Target':"#'"+target+"'!A1",'TargetMode':'External'})
     changes[resolved]=E.tostring(drawing);changes[dr]=E.tostring(drawingrels)
   changes[ps[sn]]=E.tostring(x)
  for chartpath in chartfiles:
   chart=E.fromstring(z.read(chartpath))
   for fmt in chart.iter('{'+C+'}numFmt'):
    code=fmt.attrib.get('formatCode','')
    if code and '[$-' not in code:fmt.set('formatCode','[$-0816]'+code)
   for j,ser in enumerate(chart.iter('{'+C+'}ser')):
    sp=ser.find('{'+C+'}spPr')
    if sp is None:sp=E.SubElement(ser,'{'+C+'}spPr')
    line=sp.find('{'+A+'}ln')
    if line is None:line=E.SubElement(sp,'{'+A+'}ln')
    line.set('w','26000')
    for q in list(line):
     if q.tag in ['{'+A+'}solidFill','{'+A+'}noFill']:line.remove(q)
    E.SubElement(E.SubElement(line,'{'+A+'}solidFill'),'{'+A+'}srgbClr',{'val':[palette['teal'],palette['gold'],palette['muted']][j%3]})
   changes[chartpath]=E.tostring(chart)
  # Rich English notes on dashboard values and central KPI cells. Classic Excel Notes
  # have limited styling; the visible guide provides the formatted long explanations.
  comments_updated=0
  for sn in [s[0] for s in NAV]+['V05 KPI']:
   rp=posixpath.dirname(ps[sn])+'/_rels/'+posixpath.basename(ps[sn])+'.rels'
   for rel in E.fromstring(z.read(rp)):
    if not rel.attrib['Type'].endswith('/comments'):continue
    t=rel.attrib['Target'];cp=t.lstrip('/') if t.startswith('/') else posixpath.normpath(posixpath.join(posixpath.dirname(ps[sn]),t));tree=E.fromstring(z.read(cp));cl=tree.find(T('commentList'))
    for (ss,addr),tip in tips.items():
     if ss!=sn:continue
     comment=next((q for q in cl if q.attrib['ref']==addr),None)
     if comment is None:continue  # Existing VML note shapes remain valid; new cards use guide/tooltips.
     for q in list(comment):comment.remove(q)
     text=E.SubElement(comment,T('text'));E.SubElement(text,T('t')).text=tip;comments_updated+=1
    if sn=='V05 KPI':
     for key,info in entries.items():
      comment=next((q for q in cl if q.attrib['ref']==f'D{info["row"]}'),None)
      if comment is not None:
       for q in list(comment):comment.remove(q)
       rd=READ.get(key,(info['name'],'Read the linked guide.','Study assumptions require validation.'));E.SubElement(E.SubElement(comment,T('text')),T('t')).text='\n'.join([info['name'].upper(),*rd,'SOURCE: '+info['source'],'See V05.1 KPI Guide and full KPI Dictionary.']);comments_updated+=1
    changes[cp]=E.tostring(tree)
  # Extend all *new* editable-input notes with an explicit reading instruction.
  input_notes=0
  for f in z.namelist():
   if not f.startswith('xl/comments/v05_') or f in changes:continue
   tree=E.fromstring(z.read(f))
   for comment in tree.iter(T('comment')):
    text=comment.find(T('text'));original=''.join(text.itertext())
    if 'EDITABLE SCENARIO INPUT' in original:continue
    text.clear();E.SubElement(text,T('t')).text=original+'\n\nSCENARIO INPUT | Blue cells are editable. Change the source assumption, then recalculate. Validate units, timing and supporting documents; review linked cash, reserve and return effects. A forecast is not an approved contract or payment.';input_notes+=1
   changes[f]=E.tostring(tree)
  dic.find(T('dimension')).set('ref',f'A1:D{nextrow}')
  changes[ps['DIC_TRANSLATIONS']]=E.tostring(dic);changes[ps['V05 KPI']]=E.tostring(kp);changes['xl/styles.xml']=E.tostring(sty)
  # Append guide sheet, with print and filter names optional (no formulas added to engines).
  wb=E.fromstring(z.read('xl/workbook.xml'));sheets=wb.find(T('sheets'));sheetid=max(int(s.attrib['sheetId']) for s in sheets)+1
  E.SubElement(sheets,T('sheet'),{'name':GUIDE,'sheetId':str(sheetid),RID:'rIdV051Guide'})
  for view in wb.find(T('bookViews')):view.set('activeTab',str(list(ps).index('EXEC V05')))
  wr=E.fromstring(z.read('xl/_rels/workbook.xml.rels'));E.SubElement(wr,'{'+REL+'}Relationship',{'Id':'rIdV051Guide','Type':'http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet','Target':'worksheets/v051_guide.xml'})
  ct=E.fromstring(z.read('[Content_Types].xml'));E.SubElement(ct,'{http://schemas.openxmlformats.org/package/2006/content-types}Override',{'PartName':'/xl/worksheets/v051_guide.xml','ContentType':'application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml'})
  changes.update({'xl/workbook.xml':E.tostring(wb),'xl/_rels/workbook.xml.rels':E.tostring(wr),'[Content_Types].xml':E.tostring(ct)})
  with zipfile.ZipFile(OUT,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as dst:
   for it in z.infolist():dst.writestr(it,changes.get(it.filename,z.read(it.filename)))
   for name,raw in newparts.items():dst.writestr(name,raw)
  stats={'source_sha256':hashlib.sha256(BASE.read_bytes()).hexdigest(),'output_sha256':hashlib.sha256(OUT.read_bytes()).hexdigest(),'dashboards':9,'guide_entries':len(entries),'dashboard_and_dictionary_notes':comments_updated,'new_input_notes_extended':input_notes,'changed_parts':list(changes),'new_parts':list(newparts),'language':'PT/EN navigation, KPI labels, existing formula-driven notes; detailed reading panels, guide and enhanced notes in English','no_financial_changes_intended':True}
 (ROOT/'entrega/Registo_Refinamento_Visual_V05_1.json').write_text(json.dumps(stats,ensure_ascii=False,indent=2));print(json.dumps(stats,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
