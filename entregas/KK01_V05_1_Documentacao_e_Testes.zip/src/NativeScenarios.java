import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import com.sun.star.uno.*;
import com.sun.star.comp.helper.Bootstrap;
import com.sun.star.bridge.XUnoUrlResolver;
import com.sun.star.frame.*;
import com.sun.star.beans.*;
import com.sun.star.sheet.*;
import com.sun.star.table.*;
import com.sun.star.container.*;
import com.sun.star.lang.*;

// External test driver. No macros are inserted into or executed from the model.
public class NativeScenarios {
 static PropertyValue prop(String n,Object v){PropertyValue p=new PropertyValue();p.Name=n;p.Value=v;return p;}
 static String quote(String s){return "\""+s.replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n").replace("\r","\\r").replace("\t","\\t")+"\"";}
 static String b64(String s){return new String(Base64.getDecoder().decode(s),StandardCharsets.UTF_8);}
 static XSpreadsheet sheet(XSpreadsheets ss,String name)throws java.lang.Exception{return UnoRuntime.queryInterface(XSpreadsheet.class,ss.getByName(name));}
 static String col(int n){String s="";for(n++;n>0;n=(n-1)/26)s=(char)('A'+(n-1)%26)+s;return s;}
 static String[][] RANGES={
  {"Fluxo 180M","A1:DH185"},{"V04 Retornos","A1:Q145"},{"V04 Politica","A1:B18"},{"KPI","A1:B50"},
  {"V05 Fluxos Blocos","A1:S185"},{"V05 Blocos","A1:M22"},{"V05 Retornos","A1:B33"},
  {"EXEC V05","A1:T46"},{"DIC_TRANSLATIONS","A1:D300"},{"V05.1 KPI Guide","A1:G45"},{"DASH 02","A1:T46"},{"DASH 04A V05","A1:T96"},{"V05 KPI","A1:I48"},
  {"CalcF01","A1:DH185"},
  {"CalcF02","A1:DH185"},
  {"CalcF03","A1:DH185"},
  {"CalcF04","A1:DH185"},
  {"CalcF05","A1:DH185"},
  {"CalcF06","A1:DH185"},
  {"CalcF07","A1:DH185"},
  {"CalcF08","A1:DH185"},
  {"CalcF09","A1:DH185"},
  {"CalcF10","A1:DH185"},
  {"CalcF11","A1:DH185"},
  {"CalcF12","A1:DH185"},
  {"CalcF13","A1:DH185"},
  {"CalcF14","A1:DH185"},
  {"CalcF15","A1:DH185"},
  {"CalcF16","A1:DH185"},
  {"CalcF17","A1:DH185"},
  {"CalcF18","A1:DH185"},
  {"CalcF19","A1:DH185"},
  {"CalcF20","A1:DH185"},
  {"CalcF21","A1:DH185"},
  {"CalcF22","A1:DH185"},
  {"CalcF23","A1:DH185"},
  {"CalcF24","A1:DH185"},
  {"CalcF25","A1:DH185"},
  {"CalcF26","A1:DH185"},
  {"CalcF27","A1:DH185"},
  {"CalcF28","A1:DH185"},
  {"CalcF29","A1:DH185"},
  {"CalcF30","A1:DH185"},
  {"CalcF31","A1:DH185"},
  {"CalcF32","A1:DH185"},
  {"CalcF33","A1:DH185"},
  {"CalcF34","A1:DH185"},
  {"CalcF35","A1:DH185"},
  {"CalcF36","A1:DH185"},
  {"CalcF37","A1:DH185"},
  {"CalcF38","A1:DH185"},
  {"CalcF39","A1:DH185"},
  {"CalcF40","A1:DH185"},
  {"CalcF41","A1:DH185"},
  {"CalcF42","A1:DH185"},
  {"CalcF43","A1:DH185"},
  {"CalcF44","A1:DH185"},
  {"CalcF45","A1:DH185"},
  {"CalcF46","A1:DH185"},
  {"CalcF47","A1:DH185"},
  {"CalcF48","A1:DH185"},
  {"Fluxo 180M","A1:DH185"},
  {"V04 R01Fluxo","A1:DH185"},
  {"V04 R02Fluxo","A1:DH185"},
  {"V04 R03Fluxo","A1:DH185"},
  {"V04 R04Fluxo","A1:DH185"},
  {"V04 R05Fluxo","A1:DH185"},
  {"V04 R06Fluxo","A1:DH185"},
  {"V04 R07Fluxo","A1:DH185"},
  {"V04 R08Fluxo","A1:DH185"},
  {"V04 R09Fluxo","A1:DH185"},
  {"V04 R10Fluxo","A1:DH185"},
  {"V04 R11Fluxo","A1:DH185"},
  {"V04 R12Fluxo","A1:DH185"},
  {"V04 R13Fluxo","A1:DH185"}
 };
 static void snapshot(XSpreadsheets ss,Path path)throws java.lang.Exception{
  try(PrintWriter out=new PrintWriter(Files.newBufferedWriter(path,StandardCharsets.UTF_8))){
   out.print("{\"sheets\":{");boolean first=true;
   for(String[] range:RANGES){
    if(!first)out.print(",");first=false;out.print(quote(range[0])+":");XCellRangeData rd=UnoRuntime.queryInterface(XCellRangeData.class,sheet(ss,range[0]).getCellRangeByName(range[1]));Object[][] data=rd.getDataArray();out.print("[");
    for(int r=0;r<data.length;r++){if(r>0)out.print(",");out.print("[");for(int c=0;c<data[r].length;c++){if(c>0)out.print(",");Object value=data[r][c];out.print(value instanceof Number?value.toString():quote(value==null?"":value.toString()));}out.print("]");}out.print("]");
   }
   out.print("},\"errors\":[");first=true;
   for(String name:ss.getElementNames()){
    XSpreadsheet sh=sheet(ss,name);XSheetCellCursor cursor=sh.createCursor();UnoRuntime.queryInterface(XUsedAreaCursor.class,cursor).gotoEndOfUsedArea(true);CellRangeAddress bounds=UnoRuntime.queryInterface(XCellRangeAddressable.class,cursor).getRangeAddress();
    XCellRangesQuery query=UnoRuntime.queryInterface(XCellRangesQuery.class,sh.getCellRangeByPosition(0,0,bounds.EndColumn,bounds.EndRow));XSheetCellRanges errs=query.queryFormulaCells((short)FormulaResult.ERROR);
    for(CellRangeAddress a:errs.getRangeAddresses()){
     if(!first)out.print(",");first=false;String addr=col(a.StartColumn)+(a.StartRow+1);out.print("["+quote(name)+","+quote(addr)+","+sh.getCellByPosition(a.StartColumn,a.StartRow).getError()+"]");
    }
   }
   out.print("]}");
  }
 }
 public static void main(String[] args)throws java.lang.Exception{
  XComponentContext local=Bootstrap.createInitialComponentContext(null);
  XUnoUrlResolver resolver=UnoRuntime.queryInterface(XUnoUrlResolver.class,local.getServiceManager().createInstanceWithContext("com.sun.star.bridge.UnoUrlResolver",local));
  String port=args.length>3?args[3]:"20105";
  Object remote=resolver.resolve("uno:socket,host=127.0.0.1,port="+port+";urp;StarOffice.ComponentContext");XComponentContext ctx=UnoRuntime.queryInterface(XComponentContext.class,remote);
  XComponentLoader loader=UnoRuntime.queryInterface(XComponentLoader.class,ctx.getServiceManager().createInstanceWithContext("com.sun.star.frame.Desktop",ctx));
  XComponent doc=loader.loadComponentFromURL(Paths.get(args[0]).toUri().toString(),"_blank",0,new PropertyValue[]{prop("Hidden",true),prop("ReadOnly",false),prop("MacroExecutionMode",(short)0)});
  XSpreadsheetDocument calc=UnoRuntime.queryInterface(XSpreadsheetDocument.class,doc);XSpreadsheets ss=calc.getSheets();XCalculatable calculation=UnoRuntime.queryInterface(XCalculatable.class,doc);calculation.enableAutomaticCalculation(false);
  Path directory=Paths.get(args[2]);Files.createDirectories(directory);Map<String,String> restore=new LinkedHashMap<>();String name="";long started=0;
  for(String line:Files.readAllLines(Paths.get(args[1]),StandardCharsets.UTF_8)){
   String[] f=line.split("\t",-1);
   if(f[0].equals("CASE")){
    for(Map.Entry<String,String> old:restore.entrySet()){String[] address=old.getKey().split("\t");sheet(ss,address[0]).getCellRangeByName(address[1]).getCellByPosition(0,0).setFormula(old.getValue());}restore.clear();name=f[1];started=System.currentTimeMillis();System.out.println("BEGIN "+name);System.out.flush();
   }else if(f[0].equals("SET")){
    String sn=b64(f[1]),addr=f[2],key=sn+"\t"+addr;XCell cell=sheet(ss,sn).getCellRangeByName(addr).getCellByPosition(0,0);restore.putIfAbsent(key,cell.getFormula());
    if(f[3].equals("n"))cell.setValue(Double.parseDouble(f[4]));else UnoRuntime.queryInterface(com.sun.star.text.XText.class,cell).setString(b64(f[4]));
   }else if(f[0].equals("RUN")){
    calculation.calculateAll();snapshot(ss,directory.resolve(name+".json"));
    System.out.println("DONE "+name+" "+(System.currentTimeMillis()-started)+"ms");System.out.flush();
   }
  }
  doc.dispose();System.exit(0);
 }
}
