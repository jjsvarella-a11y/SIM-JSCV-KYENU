from refine import *
from validate import check
def main():
 folder=ROOT/'validacao/NativeFinal/out';results=[]
 for name in ['Base','PT_EN','Filtro_ID201']:
  r=check(folder/(name+'.json'),{});d=json.loads((folder/(name+'.json')).read_text());x=d['sheets']['EXEC V05'];k=d['sheets']['V05 KPI'];km={row[0]:row for row in k if row and isinstance(row[0],str)}
  ui=[]
  for addr,key in [('D18','peak'),('H18','equity'),('L18','vat_peak'),('P18','project_npv')]:
   row=int(re.search(r'\d+',addr)[0]);col=CI(re.match('[A-Z]+',addr)[0]);ui.append(abs(x[row-1][col-1]-km[key][3])<.01)
  ui.append('EXECUTIVE READING' in x[34][3])
  if name=='PT_EN':ui.extend([x[0][3]=='Executive Overview',x[5][0].startswith('01  Executive Overview'),'Peak debt'==x[15][3]])
  if name=='Filtro_ID201':ui.append(abs(d['sheets']['DASH 04A V05'][53][7]-552000)<.01)
  r.update(case=name,visual_display_checks=ui);r['ok']=r['ok'] and all(ui);results.append(r);print(name,r['ok'],r['failure_count'],r['error_count'],ui,flush=True)
 full=check(folder/'Base.json',{},risks=True);full['case']='Reconciliacao_62_motores';results.append(full);print('62 engines',full['ok'],full['comparisons'],flush=True)
 output={'ok':all(x['ok'] for x in results),'selector_cases':3,'engines_reconciled':62,'comparisons':sum(x['comparisons'] for x in results),'financial_failures':sum(x['failure_count'] for x in results),'unexpected_errors':sum(x['error_count'] for x in results),'cases':results,'note':'Native calculation in LibreOffice; Excel Desktop unavailable. All 35 V05 financial cases were not repeated for this presentation-only update.'}
 (ROOT/'entrega/KK01_V05_1_Testes_Nativos.json').write_text(json.dumps(output,ensure_ascii=False,indent=2));assert output['ok']
if __name__=='__main__':main()
