from refine import *
import shutil
from pypdf import PdfReader
def main():
 output=ROOT/'entrega'
 for name in ['Prova_Integridade_Motor_V05_1.json','KK01_V05_1_Testes_Nativos.json']:
  d=json.loads((output/name).read_text());assert d['ok'],name
  if 'final_presentation_math_matches_native_input' in d:assert d['final_presentation_math_matches_native_input']
 with zipfile.ZipFile(OUT) as z:
  assert z.testzip() is None
  ps=paths(z);assert len(ps)==348
  # Resolve package relationships and all navigation button targets.
  navbuttons=0
  for f in z.namelist():
   if not f.endswith('.rels'):continue
   source='' if f=='_rels/.rels' else f.split('/_rels/')[0]+'/'+f.split('/_rels/')[1][:-5]
   for rel in E.fromstring(z.read(f)):
    t=rel.attrib['Target']
    if t.startswith('#'):
     if '!' in t:assert t[1:].split('!')[0].strip("'") in ps,(f,t)
     if rel.attrib['Id'].startswith('rIdNav'):navbuttons+=1
    elif rel.attrib.get('TargetMode')!='External':
     p=t.lstrip('/') if t.startswith('/') else posixpath.normpath(posixpath.join(posixpath.dirname(source),t));assert p in z.namelist(),(f,p)
  assert navbuttons==90,navbuttons
 assert OUT.stat().st_size<40000000
 (output/'KK01_V05_1_Validacao_Estrutural.json').write_text(json.dumps({'ok':True,'zip_integrity':True,'worksheets':348,'navigation_click_areas':navbuttons,'package_relationships_resolved':True,'source_v05_preserved':hashlib.sha256(BASE.read_bytes()).hexdigest()=='432fdb6040316056c0f0e1125125f356660df5003719172de368123026452ed5','model_bytes':OUT.stat().st_size,'note':'OOXML inspection and native Calc checks do not certify Excel Desktop.'},ensure_ascii=False,indent=2))
 for p in output.glob('*.pdf'):
  pages=PdfReader(p).pages;assert pages and all(q.extract_text().strip() for q in pages)
 with zipfile.ZipFile(output/'KK01_V05_1_Documentacao_e_Testes.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as dst:
  for p in sorted(output.glob('*')):
   if p.is_file() and p.suffix not in ['.xlsx','.zip']:dst.write(p,p.name)
  for directory in ['src']:
   for p in sorted((ROOT/directory).glob('*')):
    if p.is_file():dst.write(p,p.relative_to(ROOT))
  dst.write(ROOT/'README_Fontes.md','README_Fontes.md')
  for directory in ['src','reference/src']:
   for p in sorted((Path('/workspace/kk01/v05_final')/directory).glob('*')):
    if p.is_file():dst.write(p,'financial_reference/'+directory+'/'+p.name)
 names=[p.name for p in sorted(output.glob('*')) if p.is_file() and p.name!='KK01_V05_1_Manifesto_SHA256.json']
 manifest={'date':'2026-10-21','original_v05_sha256':hashlib.sha256(BASE.read_bytes()).hexdigest(),'files':{name:{'bytes':(output/name).stat().st_size,'sha256':hashlib.sha256((output/name).read_bytes()).hexdigest()} for name in names}}
 assert manifest['original_v05_sha256']=='432fdb6040316056c0f0e1125125f356660df5003719172de368123026452ed5'
 (output/'KK01_V05_1_Manifesto_SHA256.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
 for destination in [Path('/workspace/kk01/entrega'),Path('/workspace/SIM-JSCV-KYENU/entregas')]:
  for p in output.iterdir():
   if p.is_file():
    target=destination/p.name
    if target.exists():assert hashlib.sha256(target.read_bytes()).hexdigest()==hashlib.sha256(p.read_bytes()).hexdigest(),'Refuse to overwrite different published file '+str(target)
    shutil.copy2(p,target)
 print('Packaged',len(names)+1,'files;',navbuttons,'native navigation buttons; model bytes',OUT.stat().st_size)
if __name__=='__main__':main()
