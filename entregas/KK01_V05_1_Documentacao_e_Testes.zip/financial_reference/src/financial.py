from common import *
ON=f'{P("active")}=1'
def ledger(fs,hs,rs,opening):
 q=lambda col,r:f"'{fs}'!{col}{r}"
 benefits=f'AND({P("convention")}<>"Geral",OR({P("convention")}="Pretendida",AND({P("proof")}=1,{P("application")}="Aprovada",LEN(\'V05 Parametros\'!$E${ROWS["proof"]})>0)))'
 relief=lambda k:f'IF({benefits},{P(k)},0)'
 updates={}
 for r in range(5,185):
  m=r-4;y=(m-1)//12;start=y*12+5;end=start+11;prior=start-1
  v=lambda k,rr=r:f'{HC[k]}{rr}'
  yr=lambda k:f'SUM({HC[k]}{start}:{HC[k]}{r})'
  prev=lambda k:'0' if r==5 else v(k,r-1)
  ratio=f'IF({P("vat_mode")}="Parcial",{P("vat_recovery")},1)'
  lag=f'IF({P("vat_mode")}="Diferido",{P("vat_deferred")},{P("vat_lag")})'
  recover=f'IF(A{r}>{lag},INDEX(${HC["vat_paid"]}$5:${HC["vat_paid"]}$184,MAX(1,A{r}-{lag}))*{ratio},0)'
  prices=f"SUMIFS('{rs}'!$AC$5:$AC$98,'{rs}'!$AB$5:$AB$98,A{r},'{rs}'!$AA$5:$AA$98,\"<=\"&{PV('sales_stop')})"
  unsold=f"MAX(0,SUM('{rs}'!$AC$5:$AC$98)-SUMIFS('{rs}'!$AC$5:$AC$98,'{rs}'!$AB$5:$AB$98,\"<=\"&A{r},'{rs}'!$AA$5:$AA$98,\"<=\"&{PV('sales_stop')}))"
  extra_cap=f'SUM(${HC["construction_ins"]}$5:${HC["construction_ins"]}$184)+SUM(${HC["vat_nonrecoverable"]}$5:${HC["vat_nonrecoverable"]}$184)'
  # Amounts are KK-only. Owner taxes remain outside its cash flow.
  f={
   'vat_paid':f'(H{r}+I{r})*{P("vat_rate")}',
   'vat_offset':f'MIN(\'V05 IVA Comp\'!B{r},MAX(0,IF(A{r}>{lag},SUM(${HC["vat_paid"]}$5:INDEX(${HC["vat_paid"]}$5:${HC["vat_paid"]}$184,MAX(1,A{r}-{lag})))*{ratio}*{P("vat_comp")},0)-'+('0' if r==5 else f'SUM(${HC["vat_offset"]}$5:{v("vat_offset",r-1)})')+'))',
   'vat_refund':f'({recover})*(1-{P("vat_comp")})',
   'vat_pending':f'{prev("vat_pending")}+{v("vat_paid")}*{ratio}-{v("vat_offset")}-{v("vat_refund")}',
   'vat_nonrecoverable':f'{v("vat_paid")}*(1-{ratio})',
   'vat_net':f'{v("vat_paid")}-{v("vat_offset")}-{v("vat_refund")}',
   'construction_ins':f'H{r}*{P("construction_ins_rate")}*(1-{P("construction_ins_included")})*{P("insurance_factor")}*(1+{P("stamp_ins")}*(1-{relief("stamp_relief")}))',
   'deeds':f"SUMIFS('V05 Escrituras'!$K$5:$K$98,'{rs}'!$AB$5:$AB$98,A{r},'{rs}'!$AA$5:$AA$98,\"<=\"&{PV('sales_stop')})+SUMIF('V05 Escrituras'!$D$99:$D$101,A{r},'V05 Escrituras'!$K$99:$K$101)+IF(A{r}={P('ph_month')},{P('ph')},0)",
   'property_other':f'(IF(A{r}<{opening},{P("land_taxbase")},0)+{unsold}*{P("unsold_tax_factor")})*{P("ipi")}/12*(1-{relief("ipi_relief")})',
   'customs':f'IF(A{r}={P("customs_month")},{P("customs_base")}*{P("customs_rate")}*(1-{relief("customs_relief")}),0)',
   'cash_cost':f'{v("vat_net")}+{v("construction_ins")}+{v("deeds")}+{v("property_other")}+{v("customs")}+{v("tax_paid")}',
   'sales_profit':f'{prices}*(1-{PV("res_capex_share")}*(SUM($H$5:$J$184)+{extra_cap})/SUM(\'{rs}\'!$AC$5:$AC$98)-{PV("marketing")}-{PV("kyenu")}-{P("iti")}*{P("iti_kk")}*(1-{relief("iti_relief")}))',
   'operating_ebt':f"'{hs}'!T{r}+M{r}-{v('depreciation')}-Y{r}-SUM(T{r}:V{r})-AV{r}-AY{r}",
   'other_expense':f'{v("deeds")}+{v("property_other")}+{v("customs")}',
   'ebt':f'{v("sales_profit")}+{v("operating_ebt")}-{v("other_expense")}',
   'ytd_ebt':yr('ebt'),
   'loss_open':'0' if prior<5 else f'MAX(0,{v("loss_open",prior)}-{v("ytd_ebt",prior)})',
   'taxable':f'MAX(0,{v("ytd_ebt")}-{v("loss_open")})',
   'eligible':f'MIN({v("taxable")},MAX(0,{yr("operating_ebt")}))',
   'tax_general':f'{v("taxable")}*{P("irpc")}',
   'tax_selected':f'MAX(0,{v("tax_general")}-IF({benefits},{v("eligible")}*MAX(0,{P("irpc")}-IF(AND(A{r}>={opening},INT((A{r}-1)/12)-INT((({opening})-1)/12)<{P("holiday")}),0,{P("reduced_rate")})),0))',
   'tax_accrual':f'{v("tax_selected")}-'+('0' if r==start else v('tax_selected',r-1)),
   'tax_paid':f'IF(AND(A{r}>{P("tax_lag")},MOD(A{r}-{P("tax_lag")},12)=0),INDEX(${HC["tax_selected"]}$5:${HC["tax_selected"]}$184,MAX(1,A{r}-{P("tax_lag")})),0)',
   'tax_liability':f'SUM(${HC["tax_accrual"]}$5:{v("tax_accrual")})-SUM(${HC["tax_paid"]}$5:{v("tax_paid")})',
   'profit_cum':f'SUM(${HC["ebt"]}$5:{v("ebt")})-SUM(${HC["tax_accrual"]}$5:{v("tax_accrual")})',
   'profit_capacity':f'MAX(0,{v("profit_cum")}*(1-{P("legal_reserve")}))',
   'cfads':f'L{r}+M{r}-{v("tax_paid")}-{v("property_other")}',
   'future_cost':f'{v("vat_net")}-IF({P("budget_gross")}=1,{v("vat_paid")},0)+{v("construction_ins")}+{v("deeds")}+{v("customs")}',
   'unlevered_ebt':f'{v("sales_profit")}+\'{hs}\'!T{r}+M{r}-{v("depreciation")}-{v("other_expense")}',
   'unlevered_ytd':yr('unlevered_ebt'),
   'unlevered_loss':'0' if prior<5 else f'MAX(0,{v("unlevered_loss",prior)}-{v("unlevered_ytd",prior)})',
   'unlevered_tax':f'MAX(0,{v("unlevered_ytd")}-{v("unlevered_loss")})*{P("irpc")}-IF({benefits},MIN(MAX(0,{v("unlevered_ytd")}-{v("unlevered_loss")}),MAX(0,{yr("operating_ebt")}+SUM(Y{start}:Y{r})+SUM(T{start}:V{r})+SUM(AV{start}:AV{r})+SUM(AY{start}:AY{r})))*MAX(0,{P("irpc")}-IF(AND(A{r}>={opening},INT((A{r}-1)/12)-INT((({opening})-1)/12)<{P("holiday")}),0,{P("reduced_rate")})),0)',
   'unlevered_paid':f'IF(AND(A{r}>{P("tax_lag")},MOD(A{r}-{P("tax_lag")},12)=0),INDEX(${HC["unlevered_tax"]}$5:${HC["unlevered_tax"]}$184,MAX(1,A{r}-{P("tax_lag")})),0)',
   'construction_economic':f'SUM(H{r}:J{r})+{v("construction_ins")}+{v("vat_nonrecoverable")}',
   'insurance_operating':f'IF(A{r}>={opening},({P("insured_basis")}*{P("property_ins_rate")}/12+AO{r}*({P("bi_rate")}+{P("liability_rate")})+{P("insurance_extra")}/12)*(1-{P("operating_ins_included")})*{P("insurance_factor")}*(1+{P("stamp_ins")}*(1-{relief("stamp_relief")})),0)',
   'ipi_operating':f'IF(A{r}>={opening},{P("property_taxbase")}*{P("ipi")}/12*(1-{relief("ipi_relief")}),0)',
   'depreciation':f'IF(AND(A{r}>={opening},A{r}<{opening}+{P("depreciation_years")}*12),{P("depreciable")}/{P("depreciation_years")}/12,0)',
   'tax_saving':f'{v("tax_general")}-{v("tax_selected")}',
   'extra_reserve':f'MAX(0,{prev("tax_liability")}-{v("tax_paid")},IF(AND({P("fund_current_tax")}=1,A{r}={PV("draw_end")}),{v("tax_prudential")},0))',
   'unlevered_general':f'MAX(0,{v("unlevered_ytd")}-{v("unlevered_loss")})*{P("irpc")}',
   'tax_prudential':f'MAX(0,SUM('+','.join([v('unlevered_general',j) for j in range(16,start,12)]+[v('unlevered_general')])+f')-SUM(${HC["tax_paid"]}$5:{v("tax_paid")}))',
  }
  for key,formula in f.items():updates[v(key)]='='+formula
 for k,col in HC.items():updates[col+'4']=k
 return updates,benefits
