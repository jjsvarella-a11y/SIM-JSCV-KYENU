from common import *
import model as e
import unittest,math
class FinancialRegression(unittest.TestCase):
 def test_disabled_parity(self):
  a=e.run(e.config(active=0,use_capital=0));b=e.old.run(e.old.config())
  for x,y in zip(a['flow'],b['flow']):
   for k in META['flow_columns']:
    if isinstance(y.get(k),(int,float)):
     with self.subTest(month=x['m'],field=k):self.assertAlmostEqual(x[k],y[k],delta=max(.001,abs(y[k])*1e-10))
 def test_fiscal_conservation_and_dividends(self):
  for params in [{},{'vat_mode':'Parcial'},{'vat_mode':'Diferido'},{'budget_gross':1},{'convention':'Pretendida','holiday':5},{'div_basis':'Acumulados','div_tier':'Máximo'},{'capital_delay':6,'commercial_delay':6,'cost_overrun':.1,'vat_mode':'Diferido'}]:
   r=e.run(e.config(**params));p=r['p'];prevvat=prevtax=0
   for x in r['flow']:
    t=x['fiscal']
    with self.subTest(params=params,month=x['m']):
     self.assertAlmostEqual(x['cash_check'],0,delta=.001);self.assertAlmostEqual(x['debt_check'],0,delta=.001)
     self.assertAlmostEqual(t['vat_pending'],prevvat+t['vat_paid']-t['vat_nonrecoverable']-t['vat_offset']-t['vat_refund'],delta=.001)
     self.assertAlmostEqual(t['tax_liability'],prevtax+t['tax_accrual']-t['tax_paid'],delta=.001)
     self.assertLessEqual(x['cumulative'],p['limit']+.001)
     if x['dividend']>0:
      self.assertIn(x['m'],range(54,175,12));self.assertLessEqual(x['dividend'],x['div_metrics']['free']+.001);self.assertLessEqual(x['dividend'],x['legal_headroom']+.001)
      self.assertGreaterEqual(x['cash'],x['reserve']-.001)
     if x['dividend']>0 and p['div_basis']=='Geração 12M':self.assertGreaterEqual(x['div_metrics']['coverage_ratio'],1.2-1e-8)
    prevvat=t['vat_pending'];prevtax=t['tax_liability']
 def test_approval_gate(self):
  a=e.run(e.config());b=e.run(e.config(convention='Aprovada',proof=1,application='Aprovada'))
  for x,y in zip(a['flow'],b['flow']):self.assertEqual(x['cash'],y['cash'])
 def test_insurance_inclusion(self):
  r=e.run(e.config(construction_ins_included=1,operating_ins_included=1))
  self.assertEqual(sum(x['fiscal']['construction_ins']+x['fiscal']['insurance_operating'] for x in r['flow']),0)
 def test_capital_and_secondary(self):
  a=e.run(e.config());b=e.run(e.config(primary=[.8]*8));self.assertAlmostEqual(sum(x['equity'] for x in a['flow']),25e6);self.assertAlmostEqual(sum(x['equity'] for x in b['flow']),20e6)
  self.assertEqual(sum(e.investor_outlay(b['p'],m) for m in range(1,181)),25e6)
 def test_no_undocumented_distribution(self):
  r=e.run(e.config(payout_basis='Documentado'));self.assertEqual(sum(x['dividend'] for x in r['flow']),0)
 def test_expected_tax_base(self):
  r=e.run(e.config());self.assertAlmostEqual(sum(x['fiscal']['vat_paid'] for x in r['flow']),8629200,places=2);self.assertAlmostEqual(sum(x['fiscal']['construction_ins'] for x in r['flow']),197400,places=2)
 def test_vat_offset_requires_same_entity_capacity(self):
  a=e.run(e.config(vat_comp=1));self.assertEqual(sum(x['fiscal']['vat_offset']+x['fiscal']['vat_refund'] for x in a['flow']),0);self.assertAlmostEqual(a['flow'][-1]['fiscal']['vat_pending'],8629200,places=2)
  b=e.run(e.config(vat_comp=.5,vat_output_capacity=[0.]*30+[100000.]*150))
  for x in b['flow']:self.assertLessEqual(x['fiscal']['vat_offset'],100000+.001)
 def test_historic_is_not_future_cash(self):
  a=e.run(e.config());b=e.run(e.config(historic=0))
  for x,y in zip(a['flow'],b['flow']):self.assertAlmostEqual(x['cash'],y['cash'],places=6)
 def test_terminal_bridge_cash_once(self):
  r=e.run(e.config());out=e.results(r);x=r['flow'][-1];p=r['p'];expected=out['ev']*(1-p['exit_cost'])+x['cash']-x['debt']-x['shareloan']-x['hothold']-x['conthold']-x['fiscal']['tax_liability']
  self.assertAlmostEqual(out['exit_equity'],max(0,expected),places=6)
if __name__=='__main__':unittest.main(verbosity=2)
