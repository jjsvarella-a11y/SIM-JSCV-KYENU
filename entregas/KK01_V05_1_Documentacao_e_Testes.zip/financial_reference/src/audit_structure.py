from common import *
import hashlib,posixpath
def audit(file):
 checks=[]
 def add(name,ok,detail=None):checks.append(dict(check=name,ok=bool(ok),detail=detail))
 add('Original V04 Fixed preservado',hashlib.sha256(ORIGINAL.read_bytes()).hexdigest()=='be8288ced2494ef31c2dbe1d31d77b8277a0753a1209a8df0a83c3a5d86dcdc0')
 with zipfile.ZipFile(BASE) as b,zipfile.ZipFile(file) as z:
  add('ZIP íntegro',z.testzip() is None);bp=paths(b);p=paths(z)
  add('Todas as folhas anteriores preservadas',set(bp)<=set(p),{'anteriores':len(bp),'atuais':len(p)})
  nav=['EXEC V05','DASH 01 V05','DASH 02','DASH 03 V05','DASH 04A V05','DASH 04B V05','DASH 05 V05','DASH 06 V05','DASH 07 V05']
  add('Nove ecrãs existentes',all(n in p for n in nav))
  charts=sum(bool(re.fullmatch(r'xl/charts/[^/]+\.xml',f)) for f in z.namelist());add('Gráficos anteriores e nove novos',charts>=26,charts)
  def chart_design(raw):
   x=E.fromstring(raw)
   for parent in x.iter():
    for c in list(parent):
     if c.tag.split('}')[-1] in ['numCache','strCache']:parent.remove(c)
   return E.tostring(x)
  add('Desenho e referências dos gráficos anteriores preservados',all(chart_design(z.read(f))==chart_design(b.read(f)) for f in b.namelist() if re.fullmatch(r'xl/charts/chart\d+\.xml',f)))
  add('Imagens e comentários anteriores preservados',all(z.read(f)==b.read(f) for f in b.namelist() if f.startswith('xl/media/') or re.fullmatch(r'xl/comments\d+\.xml',f)))
  add('Sem VBA nem workbook externo novo',not any('vbaProject' in f or f.startswith('xl/externalLinks/') for f in z.namelist()))
  bn=E.fromstring(b.read('xl/workbook.xml')).find(T('definedNames'));wn=E.fromstring(z.read('xl/workbook.xml')).find(T('definedNames'));names={(x.attrib.get('name'),x.attrib.get('localSheetId')):x.text for x in wn}
  add('Nomes definidos anteriores preservados',all(names.get((x.attrib.get('name'),x.attrib.get('localSheetId')))==x.text for x in bn))
  invalidrefs=[];errors=[];formcount=0;fns=set();validationlen=[]
  for sn,path in p.items():
   raw=z.read(path).decode();fs=formulas(raw);formcount+=len(fs)
   for a,formula in fs.items():
    if '#REF!' in formula:invalidrefs.append([sn,a,formula[:120]])
   for m in re.finditer(r'<(?:\w+:)?c\b[^>]*\bt="e"[^>]*>.*?</(?:\w+:)?c>',raw,re.S):errors.append([sn,m[0][:150]])
   if sn in nav:
    add('PT/EN ligado: '+sn,'DIC_TRANSLATIONS' in raw)
    add('Navegação: '+sn,len(list(E.fromstring(raw).iter(T('hyperlink'))))>=12)
   if path.startswith('xl/worksheets/v05_'):
    x=E.fromstring(raw)
    for dv in x.iter(T('dataValidation')):
     f=dv.find(T('formula1'))
     if f is not None and f.text and f.text.startswith('"') and len(f.text)>257:validationlen.append([sn,f.text[:70]])
  add('Sem #REF! nas fórmulas',not invalidrefs,invalidrefs[:10]);add('Sem erros armazenados',not errors,errors[:10]);add('Validações lista compatíveis com limite Excel',not validationlen,validationlen)
  add('Fórmulas dinâmicas preservadas e ampliadas',formcount>1657732,formcount)
  # Every package relationship target resolves to an actual part (except external URLs).
  broken=[]
  for f in z.namelist():
   if not f.endswith('.rels'):continue
   root=E.fromstring(z.read(f));source='' if f=='_rels/.rels' else f.split('/_rels/')[0]+'/'+f.split('/_rels/')[1][:-5]
   for rel in root:
    if rel.attrib.get('TargetMode')=='External':continue
    target=rel.attrib['Target']
    if target.startswith('#'):continue
    resolved=target.lstrip('/') if target.startswith('/') else posixpath.normpath(posixpath.join(posixpath.dirname(source),target))
    if resolved not in z.namelist():broken.append([f,target,resolved])
  add('Relações OOXML resolvidas',not broken,broken[:10])
 return {'ok':all(x['ok'] for x in checks),'checks':checks,'file':str(file)}
if __name__=='__main__':
 out=audit(OUTPUT);(ROOT/'entrega/Testes_Estruturais.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print(json.dumps(out,ensure_ascii=False,indent=2));raise SystemExit(not out['ok'])
