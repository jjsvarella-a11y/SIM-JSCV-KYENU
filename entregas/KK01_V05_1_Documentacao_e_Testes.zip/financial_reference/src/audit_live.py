from common import *
from validate import CASES,check
import hashlib,shutil,math
def main():
 directory=ROOT/'validacao/NativeLive/out';results=[];canonical=(directory.parent/'canonical.sha256').read_text().strip()
 for name,params,changes in CASES:
  source=directory/(name+'.json')
  mode='LibreOffice UNO Java client; calculateAll after input changes; macros disabled'
  case_hash=canonical;native=None
  if source.exists():result=check(source,params);native=json.loads(source.read_text())
  else:
   source=ROOT/'validacao'/name/'out'/(name+'.xlsx')
   if not source.exists():raise RuntimeError('Cenário nativo ainda não produzido: '+name)
   result=check(source,params);mode='LibreOffice fresh private XLSX copy; full recalc on open; macros absent';meta=json.loads((source.parent.parent/'Resultado.json').read_text());case_hash=meta['canonical_input_sha256']
  ui_ok=True
  if name=='PT_EN':ui_ok=native['sheets']['EXEC V05'][0][3]=='Executive Overview' and native['sheets']['DASH 02'][0][3]=='Tax, Incentives & Insurance'
  if name=='Filtro_ID201':ui_ok=abs(native['sheets']['DASH 04A V05'][53][7]-552000)<.01
  result.update(case=name,params=params,selector_changes=changes,interface_check=ui_ok,canonical_input_sha256=case_hash,snapshot_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),native_mode=mode);result['ok']=result['ok'] and ui_ok;results.append(result)
  print(name,result['ok'],result['comparisons'],result['failure_count'],result['error_count'],result['failures'][:2],flush=True)
 # Independently reopen the saved native reference and compare every original auxiliary engine.
 base=directory/'Base.xlsx';full=check(base,{},risks=True);full['case']='Base_Reabertura_62_Motores';results.append(full)
 print('62 motores',full['ok'],full['comparisons'],full['failures'][:3],flush=True)
 dest=ROOT/'validacao/Base/out';dest.mkdir(parents=True,exist_ok=True);shutil.copy2(base,dest/'Base.xlsx')
 (ROOT/'entrega/Testes_Nativos_Completos.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
 summary={'ok':all(x['ok'] for x in results),'cases':len(CASES),'reopening_full_auxiliary_check':True,'comparisons':sum(x['comparisons'] for x in results),'failures':sum(x['failure_count'] for x in results),'unexpected_errors':sum(x['error_count'] for x in results),'canonical_input_sha256':canonical,'note':'Conformidade de cálculo não equivale a viabilidade financeira nem certificação fiscal ou de Excel Desktop.'}
 (ROOT/'entrega/Resumo_Testes_Nativos.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2));print(summary);return summary['ok']
if __name__=='__main__':raise SystemExit(not main())
