"""Reproducible live native regression: three isolated Calc sessions, private copies.
The delivered XLSX never contains or executes macros.
"""
from common import *
from validate import CASES
import subprocess,concurrent.futures,shutil,socket,time,base64,hashlib,urllib.request
PROFILE='<?xml version="1.0"?><oor:items xmlns:oor="http://openoffice.org/2001/registry"><item oor:path="/org.openoffice.Office.Calc/Formula/Load"><prop oor:name="OOXMLRecalcMode" oor:op="fuse"><value>0</value></prop></item><item oor:path="/org.openoffice.Office.Calc/Formula/Calculation"><prop oor:name="UseThreadedCalculationForFormulaGroups" oor:op="fuse"><value>false</value></prop><prop oor:name="UseOpenCL" oor:op="fuse"><value>false</value></prop></item></oor:items>'
def worker(part,cases,root=None):
 root=Path(root) if root else ROOT/'validacao/NativeLive';folder=root/('worker'+str(part));folder.mkdir(parents=True,exist_ok=True);port=20105+part;profile=folder/'profile';shutil.rmtree(profile,ignore_errors=True);(profile/'user').mkdir(parents=True);(profile/'user/registrymodifications.xcu').write_text(PROFILE)
 private=folder/'Input.xlsx';shutil.copy2(OUTPUT,private);assert hashlib.sha256(private.read_bytes()).hexdigest()==(root/'canonical.sha256').read_text()
 commands=[];b64=lambda s:base64.b64encode(str(s).encode()).decode()
 for name,params,changes in cases:
  commands.append('CASE\t'+name)
  for sn,items in changes.items():
   for address,value in items.items():commands.append('\t'.join(['SET',b64(sn),address,'s' if isinstance(value,str) else 'n',b64(value) if isinstance(value,str) else str(value)]))
  commands.append('RUN')
 (folder/'cases.tsv').write_text('\n'.join(commands),encoding='utf-8');serverlog=(folder/'Server.log').open('w');driverlog=(folder/'Driver.log').open('w')
 server=subprocess.Popen(['soffice','-env:UserInstallation='+profile.as_uri(),'--headless','--norestore','--nodefault','--nofirststartwizard','--accept=socket,host=127.0.0.1,port='+str(port)+';urp;StarOffice.ServiceManager'],stdout=serverlog,stderr=serverlog)
 try:
  for i in range(100):
   try:s=socket.create_connection(('127.0.0.1',port),timeout=.5);s.close();break
   except OSError:time.sleep(.2)
  driver=subprocess.Popen(['java','--class-path',str(ROOT/'validacao/java/libreoffice-26.2.2.jar'),str(ROOT/'src/NativeScenarios.java'),str(private),str(folder/'cases.tsv'),str(root/'out'),str(port)],stdout=driverlog,stderr=driverlog)
  (folder/'pids.json').write_text(json.dumps({'driver':driver.pid,'server':server.pid,'cases':[x[0] for x in cases]}))
  code=driver.wait(timeout=2400)
  if code:raise RuntimeError('Native driver failed: '+str(folder/'Driver.log'))
  print('Native worker',part,'completed',len(cases),'cases',flush=True)
 finally:
  import psutil
  try:
   proc=psutil.Process(server.pid)
   for child in proc.children(recursive=True):child.terminate()
   proc.terminate()
  except psutil.NoSuchProcess:pass
def main():
 root=ROOT/'validacao/NativeLive';(root/'out').mkdir(parents=True,exist_ok=True);(root/'canonical.sha256').write_text(hashlib.sha256(OUTPUT.read_bytes()).hexdigest())
 jar=ROOT/'validacao/java/libreoffice-26.2.2.jar';jar.parent.mkdir(exist_ok=True)
 if not jar.exists():jar.write_bytes(urllib.request.urlopen('https://repo.maven.apache.org/maven2/org/libreoffice/libreoffice/26.2.2/libreoffice-26.2.2.jar',timeout=30).read())
 live=[c for c in CASES if sum(len(items) for items in c[2].values())<=32];bulk=[c for c in CASES if c not in live]
 for name,_,_ in CASES:
  prior=root/'out'/(name+'.json')
  if prior.exists():prior.unlink()
 with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:list(pool.map(lambda i:worker(i,live[i::3]),range(3)))
 # Large input matrices are faster and more stable as one OOXML mutation and fresh recalc.
 # All final results are still calculated by LibreOffice, not by the mutation script.
 if bulk:
  from validate import worker as fresh_recalc
  with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:checks=list(pool.map(fresh_recalc,bulk))
  if not all(c['ok'] for c in checks):raise RuntimeError('Bulk-input native regression failed; inspect case Resultado.json')
 print('All native selector scenarios completed.',flush=True)
if __name__=='__main__':main()
