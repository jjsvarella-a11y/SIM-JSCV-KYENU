from common import *
import model as e
from validate import CASES
import csv,hashlib,gzip,shutil,platform,importlib.metadata,subprocess,math
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,Image,PageBreak
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
pdfmetrics.registerFont(TTFont("KKRegular","/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf"))
pdfmetrics.registerFont(TTFont("KKBold","/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf"))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

def fmt(x,unit='EUR'):
 if x is None:return 'Indisponível'
 if unit=='%':return f'{100*x:,.2f}%'.replace(',','X').replace('.',',').replace('X','.')
 if unit=='x':return f'{x:.2f}×'.replace('.',',')
 return f'{x:,.2f}'.replace(',','X').replace('.',',').replace('X','.')+(' €' if unit=='EUR' else '')
def table(head,rows):return '| '+' | '.join(head)+' |\n|'+ '|'.join(['---']*len(head))+'|\n'+''.join('| '+' | '.join(str(v) for v in row)+' |\n' for row in rows)
def save(name,text):
 # Improve prose spacing without touching cell references, filenames or hashes.
 text=re.sub(r'(?<=\d)(?=(?:anos|meses|folhas|fórmulas|gráficos|nomes|blocos|frações|trimestres|simulações|motores|fluxos|grupos)\b)', ' ', text)
 text=re.sub(r'(?<=\d)(?=M€)', ' ', text)
 text=re.sub(r'\b(a|de|em|os|dos|aos|pelos|por|com|sobre|contém|estrutura|base|geração|global|Mínimo|Máximo|Intermédio)(?=\d)', r'\1 ', text, flags=re.I)
 p=ROOT/'entrega'/name;p.with_suffix('.md').write_text(text,encoding='utf-8');pdf(text,p.with_suffix('.pdf'))
def pdf(text,path):
 styles=getSampleStyleSheet();styles['BodyText'].fontName='KKRegular';styles['BodyText'].fontSize=9;styles['BodyText'].leading=13
 styles['Heading1'].fontSize=16;styles['Heading2'].fontSize=12;styles['Heading1'].fontName='KKBold';styles['Heading2'].fontName='KKBold'
 story=[];lines=text.splitlines();i=0
 def paragraph(s,style=None):return Paragraph(html.escape(s.replace('**','').replace('`','')),style or styles['BodyText'])
 while i<len(lines):
  line=lines[i]
  if line.startswith('|'):
   rows=[]
   while i<len(lines) and lines[i].startswith('|'):
    cells=[c.strip() for c in lines[i].strip().strip('|').split('|')]
    if not all(re.fullmatch(r'[:\- ]+',c) for c in cells):rows.append([paragraph(c) for c in cells])
    i+=1
   cols=len(rows[0]);width=[190,333] if cols==2 else [175]+[(523-175)/(cols-1)]*(cols-1)
   t=Table(rows,colWidths=width,repeatRows=1,hAlign='LEFT');t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#E9EDF1')),('VALIGN',(0,0),(-1,-1),'TOP'),('BOTTOMPADDING',(0,0),(-1,-1),6),('TOPPADDING',(0,0),(-1,-1),6),('LINEBELOW',(0,0),(-1,0),.8,colors.HexColor('#A8202B')),('LINEBELOW',(0,1),(-1,-1),.2,colors.HexColor('#DDDDDD'))]));story+=[t,Spacer(1,10)];continue
  if line.startswith('![grafico]('):
   target=line.split('(',1)[1].rstrip(')');story+=[Image(str(ROOT/'entrega'/target),width=510,height=240),Spacer(1,8)]
  elif line.startswith('# '):story+=[paragraph(line[2:],styles['Heading1']),Spacer(1,8)]
  elif line.startswith('## '):story+=[paragraph(line[3:],styles['Heading2'])]
  elif line.strip():story+=[paragraph(line),Spacer(1,6)]
  else:story.append(Spacer(1,4))
  i+=1
 def footer(canvas,doc):
  canvas.setFillColor(colors.HexColor('#777777'));canvas.setFont('KKRegular',8);canvas.drawString(36,22,'KK-01 · V05 Executive ·21/10/2026 · Estudo financeiro; validação externa pendente');canvas.drawRightString(A4[0]-36,22,str(doc.page))
 SimpleDocTemplate(str(path),leftMargin=36,rightMargin=36,topMargin=34,bottomMargin=36).build(story,onFirstPage=footer,onLaterPages=footer)

def main():
 out=ROOT/'entrega';native=json.loads((out/'Resumo_Testes_Nativos.json').read_text());assert native['ok'],'Não emitir relatório conforme com falhas nativas'
 r=e.run(e.config());m=e.results(r);p=r['p'];f=r['flow'];scenarios=[]
 for name,params,_ in CASES:
  rr=e.run(e.config(**params));values=e.results(rr);scenarios.append(dict(case=name,**{k:v for k,v in values.items() if k not in ['block_cf','new_cf']}))
 (out/'Sensibilidades_Python.json').write_text(json.dumps(scenarios,ensure_ascii=False,indent=2));by={s['case']:s for s in scenarios}
 cols=['case','cash30','cash42','cash54','div54','peak','used','interest','reserve_gap','funding_gap','new_irr','new_moic','new_npv','exit_equity']
 with (out/'Sensibilidades_Resumo.csv').open('w',newline='') as stream:
  writer=csv.DictWriter(stream,fieldnames=cols,extrasaction='ignore');writer.writeheader();writer.writerows(scenarios)
 oldbridge=json.loads(Path('/workspace/kk01/v05/entrega/Ponte_Impactos_V04_V05.json').read_text());bridge=[oldbridge[0],oldbridge[-1]]
 baseline=dict(active=0,use_capital=1);steps=[('Calendário individual revisto',baseline)]
 study=dict(vat_rate=0,irpc=0,ipi=0,ph=0,construction_ins_included=1,operating_ins_included=1)
 steps.append(('Estrutura fiscal sem encargos: contrafactual diagnóstico',study.copy()))
 for label,changes in [('IRPC consolidado e proteção fiscal',{'irpc':.2}),('IVA integral com recuperação6M',{'vat_rate':.15}),('IPI de estudo',{'ipi':.001}),('Propriedade horizontal',{'ph':20000}),('Seguros incrementais',{'construction_ins_included':0,'operating_ins_included':0})]:study.update(changes);steps.append((label,study.copy()))
 keys=['cash30','cash42','cash54','div54','cash_end','dividends','ev','exit_equity','new_irr','new_moic','new_npv','peak','used','interest']
 for label,params in steps:
  mm=e.results(e.run(e.config(**params)));row={'stage':label,'basis':'Ponte sequencial de estudo; resultados dependem da ordem, não altera direitos','params':params,**{k:mm[k] for k in keys}};previous=bridge[-1];row['delta']={k:row[k]-previous[k] for k in keys if isinstance(previous.get(k),(int,float)) and isinstance(row[k],(int,float))};bridge.append(row)
 (out/'Ponte_Impactos_Modulos.json').write_text(json.dumps(bridge,ensure_ascii=False,indent=2))
 assert all(abs(bridge[-1][k]-m[k])<.01 for k in keys if isinstance(m[k],(int,float)))
 with (out/'Ponte_Impactos_Modulos.csv').open('w',newline='') as stream:
  writer=csv.DictWriter(stream,fieldnames=['stage']+keys,extrasaction='ignore');writer.writeheader();writer.writerows(bridge)
 with (out/'Fluxos_180M_Base.csv').open('w',newline='') as stream:
  colsflow=['m','cash','reserve','debt','draw','dividend','interest','reservegap','project_cf','profits'];writer=csv.writer(stream);writer.writerow(colsflow+HKEYS)
  for x in f:writer.writerow([x[k] for k in colsflow]+[x['fiscal'][k] for k in HKEYS])
 # Monthly bridge to the immutable original, without assuming the balances should be equal.
 import openpyxl
 w=openpyxl.load_workbook(ORIGINAL,read_only=True,data_only=True)
 with (out/'Reconciliacao_Mensal_V04_Final.csv').open('w',newline='') as stream:
  writer=csv.writer(stream);writer.writerow(['Mês','CaixaV04','CaixaFinal','DeltaCaixa','DivV04','DivFinal','DivDelta','DividaV04','DividaFinal','IVA_Caixa_Net','IRPC_Pago','Seguro_Obra','Seguro_Operacao','IPI_Total'])
  for row,x in zip(w['Fluxo 180M'].iter_rows(min_row=5,max_row=184,values_only=True),f):
   t=x['fiscal'];cv4=row[META['flow_columns']['cash']];dv4=row[META['flow_columns']['dividend']];writer.writerow([x['m'],cv4,x['cash'],x['cash']-cv4,dv4,x['dividend'],x['dividend']-dv4,row[META['flow_columns']['debt']],x['debt'],t['vat_net'],t['tax_paid'],t['construction_ins'],t['insurance_operating'],t['property_other']+t['ipi_operating']])
 w.close()
 figures=out/'Graficos';figures.mkdir(exist_ok=True)
 fig,ax=plt.subplots(figsize=(9,4));months=[x['m'] for x in f];ax.plot(months,[x['cash']/1e6 for x in f],color='#A8202B',label='Caixa final');ax.plot(months,[x['reserve']/1e6 for x in f],color='#454B55',label='Reserva protegida');ax.set(xlabel='Mês do projeto',ylabel='Milhões de euros');ax.yaxis.set_major_formatter(FuncFormatter(lambda v,_:f'{v:.1f}'.replace('.',',')));ax.legend(frameon=False);ax.grid(alpha=.15);fig.tight_layout();fig.savefig(figures/'Tesouraria_180M.png',dpi=170);plt.close(fig)
 rows=[('VGV',50656336.37),('CAPEX futuro base',63168000),('IVA suportado',m['vat_paid']),('Pico crédito IVA',m['vat_peak']),('Pico da dívida',m['peak']),('Utilização acumulada',m['used']),('Juros bancários',m['interest']),('Caixa M30',m['cash30']),('Caixa M42',m['cash42']),('Caixa M54 após distribuição',m['cash54']),('Dividendo simulado M54',m['div54']),('EBITDA Ano15',m['ebitda15']),('EV a12×',m['ev']),('Equity Value saída',m['exit_equity']),('Dividendos novos investidores',m['new_dividends']),('VPL novos investidores a12%',m['new_npv'])]
 investorrows=[]
 for i,code in enumerate(['P01','G01','G02','S01','S02','S03','S04','S05']):
  cf=m['block_cf'][code];paid=sum(x['planned_received'] for x in e.pipeline(p) if x['code']==code);received=sum(cf)+paid;investorrows.append([code,fmt(paid),fmt(e.v4.irr(cf),'%'),fmt(received/paid,'x')])
 promoterdiv=m['dividends']-m['new_dividends'];promoterexit=m['exit_equity']*.5;promotercf=[-p['historic']]+[x['dividend']-sum((x['dividend']*q)*([1/3,1,1/2][j]) for j,q in enumerate(x['div_metrics']['weights']))+(promoterexit if x['m']==180 else 0) for x in f]
 payback=max([x['m'] for x in f if x['project_cum']<0],default=0)+1;payback=payback if payback<=180 else None
 executive=f'''# KK-01 V05 Executive — Relatório executivo

21/10/2026. Estudo com Hotel Favorável, banco Limite aceitável6%, capital previsto25M€, IVA integral com recuperação de estudo6meses, regime fiscal geral e saída12×. Hipóteses não constituem compromissos ou benefícios concedidos.

## Conclusão financeira

O cenário de referência financia os180meses e conserva as reservas testadas, com défice de caixa e de reservas igual a zero. Depende da entrada integral e atempada do capital, das vendas previstas, da disponibilidade do banco e da recuperação do IVA. A folga mínima adicional à reserva é nula no M30; a cobertura base exige disciplina de execução.

A rentabilidade dos novos investidores é {fmt(m['new_irr'],'%')} de TIR e {fmt(m['new_moic'],'x')} de MOIC. O VPL a12% é {fmt(m['new_npv'])}. O retorno fica abaixo do custo de capital próprio de estudo12%; o modelo não demonstra atratividade a essa taxa exigida. Os cenários de stress devem ser avaliados antes de concluir bancabilidade.

O projeto futuro, em base incremental sem repetir o histórico, apresenta TIR com saída de {fmt(m['project_irr_exit'],'%')} e VPL a10% de {fmt(m['project_npv_exit'])}. São métricas dos fluxos do projeto, distintas da remuneração atribuída aos novos acionistas. Os retornos acionistas são anteriores à fiscalidade individual de cada investidor, ainda não documentada.

{table(['Indicador','Referência V05'],[(a,fmt(b)) for a,b in rows])}

## Construção, fiscalidade e liquidez

O orçamento base63,168M€ contém56,4M€ de construção e FF&E inicial,1,128M€ de fiscalização e5,64M€ de contingência. Histórico4,5M€ permanece fora das saídas futuras. O IVA de8,6292M€ é recuperável por hipótese, com financiamento temporário; não é duplicado no custo económico. A exposição de crédito IVA máxima é {fmt(m['vat_peak'])}.

A reserva no último mês de crédito protege também o imposto reconhecido nas escrituras finais. Sem essa proteção, o cenário comparativo apresenta insuficiência máxima de reserva de {fmt(by['Sem_Reserva_IRPC_Ultimo_Draw']['reserve_gap'])}. Com a proteção, o saldo de caixa M30 de {fmt(m['cash30'])} acompanha dívida de {fmt(f[29]['debt'])}. O aumento de caixa resulta do financiamento das obrigações previstas. A dívida é liquidada por cash sweep no M34, antes da carência contratualM42.

Os seguros de obra adicionais são197.400€ para30meses. O seguro anual incremental do primeiro ano completo de operação é {fmt(sum(x['fiscal']['insurance_operating'] for x in f[30:42]))}, calculado por bases e taxas sobre a receita V04, com entradas próprias para inclusão na empreitada ou no OPEX. Não foi imposto o total preliminar209.700€.

![grafico](Graficos/Tesouraria_180M.png)

## Distribuições e valorização

O M54 suporta distribuição parcial de {fmt(m['div54'])}, abaixo do mínimo global3M€ em {fmt(3e6-m['div54'])}, com cobertura1,20× pelos12meses anteriores. Após distribuição, caixa {fmt(m['cash54'])} e reserva {fmt(f[53]['reserve'])}. A análise independente de acumulados/Máximo suporta {fmt(by['Div_Maximo_Acumulados']['div54'])} no M54 e deve ser distinguida do teste prudencial12M. Nenhum destes montantes é dividendo legalmente aprovado nem pagamento efetivo.

O EBITDA Ano15 é {fmt(m['ebitda15'])}; o EV não inclui apartamentos vendidos. A saída deduz dívida, custos de2%, contingências protegidas e IRPC por pagar ({fmt(m['tax_liability'])}), somando a caixa uma única vez. É avaliação estimada, sem comprador ou preço contratado.

Os novos investidores recebem {fmt(m['new_dividends'])} de dividendos ordinários em15anos: {fmt(m['new_dividends']/25e6,'x')} do capital aplicado. A recuperação integral do investimento depende da saída simuladaM180. O payback futuro do projeto sem saída, definido pelo último saldo acumulado negativo, é {payback or 'não alcançado'} meses; não é o payback acionista.

{table(['Exit','TIR novos','MOIC novos','VPL a12%'],[[name,fmt(by[case]['new_irr'],'%'),fmt(by[case]['new_moic'],'x'),fmt(by[case]['new_npv'])] for name,case in [('Prudente10×','Exit10'),('Base12×','Base'),('Favorável15×','Exit15')]])}

Comparativo de liquidação alternativa: a saídaM120 usa o EBITDA dos meses109–120 e também deduz o IRPC pendente no respetivo marco. É uma alternativa de estudo à saídaM180, não duas vendas acumuláveis.

{table(['Horizonte / múltiplo12×','TIR novos','MOIC novos','Equity Value'],[['10anos — saída alternativaM120',fmt(m['new_irr10'],'%'),fmt(m['new_moic10'],'x'),fmt(m['exit_equity10'])],['15anos — saída-baseM180',fmt(m['new_irr'],'%'),fmt(m['new_moic'],'x'),fmt(m['exit_equity'])]])}

## Acionistas e blocos

Mantêm-se15blocos: JSCV2Platinum40%, JALS5Silver10%, novos1Platinum+2Gold+5Silver50%. Os tickets dos promotores são bases convencionais, sem entrada fictícia de30M€. Venda secundária é separada do dinheiro que entra na KK. Os oito calendários são planos de estudo, não compromissos.

{table(['Bloco novo','Capital de cenário','TIR mensal anualizada','MOIC'],investorrows)}

Os promotores, em conjunto, recebem {fmt(promoterdiv)} de dividendos de cenário e {fmt(promoterexit)} na saída. A proxy de grupo baseada exclusivamente em4,5M€ no M0 produziria TIR {fmt(e.v4.irr(promotercf),'%')} e MOIC {fmt((promoterdiv+promoterexit)/p['historic'],'x')}; esta é uma convenção comparativa, não o retorno histórico efetivo. Faltam custos e datas individuais de JSCV/JALS para determinar TIR histórica por promotor.

## Condições para o sucesso

Confirmar capital e datas dos oito blocos, contratos de venda, orçamento de execução, disponibilidade bancária e requisitos de draw. Validar bases fiscais, prazos de IVA e de IRPC e encargos já incluídos na obra/OPEX. Formalizar direitos societários, reservas e deliberações antes de distribuir. A Convenção permanece em preparação e sem benefícios aprovados ativos.

O stress combinado — atraso de capital e vendas6meses, IVA diferido18meses, seguros+50%, sobrecusto10% e juros8% — apresenta défice máximo de financiamento {fmt(by['Stress_Combinado']['funding_gap'])} e insuficiência de reserva {fmt(by['Stress_Combinado']['reserve_gap'])}. Retornos desse cenário são condicionais à resolução dos défices.

Excel Desktop indisponível: a compatibilidade não está certificada nesse motor. A conformidade de cálculo foi verificada em Python e LibreOffice; fiscalidade, contratos, incentivos e pagamentos requerem validação externa.
'''
 save('KK01_V05_Relatorio_Executivo',executive)
 audit=f'''# KK-01 V05 Executive — Relatório de auditoria

21/10/2026. Auditoria técnica e financeira de um modelo de estudo. Estados: Conforme nos testes executados / Alerta / Pendente de Validação Externa.

## Evidência e preservação

Base autoritativa: V04 Excel Fix, SHA-256 be8288ced2494ef31c2dbe1d31d77b8277a0753a1209a8df0a83c3a5d86dcdc0. A entrega financeira anterior foi reutilizada como camada rastreável de alterações sobre a V04; o modelo não foi reconstruído do zero. Os originais e os respetivos hashes foram preservados.

A auditoria Fase1 foi aproveitada:313folhas,1.485.103fórmulas,17gráficos e347nomes definidos na V04. A Fase2 anterior tinha319folhas; a versão atual acrescenta os módulos técnicos e os nove ecrãs, preservando as folhas antigas. As contagens atuais e o inventário de relações estão em Testes_Estruturais.json.

## Alterações controladas

Estrutura15blocos; oito calendários explícitos; separação de fundos primários e secundários; inventário94frações único; orçamento por capítulos e EAC/ETC de controlo;10trimestres derivados do mensal; IVA por saldo e prazo; IRPC por lucro tributável anual e calendário; ITI/IPI por responsabilidade/titularidade; atos/PH; seguros incrementais; cenários de incentivos; reservas antes do sweep e dos dividendos; lucros de estudo com retenção prudencial; saída e retornos; nove ecrãs com dicionárioPT/EN central.

O registo completo de fórmulas antes/depois está comprimido em Registo_Alteracoes_Formulas.json.gz; o resumo por folha está em Alteracoes_por_Folha.csv. O registo da Fase2 anterior é incluído separadamente. A rastreabilidade dos valores literais anteriores permanece nos ficheiros originais e nos manifests.

## Correções encontradas durante desenvolvimento

1. A nova proteção fiscal usava inicialmente o imposto do mês anterior no fecho de draw, deixando uma insuficiência de reserva na abertura. Foi acrescentado controlo prudencial do imposto conhecido no último mês de financiamento, sem escudo dos juros atuais, evitando circularidade. A linha continua não renovável e sem capital fictício.

2. Os cenários auxiliares de atraso de obra exigem a sua própria expressão de conclusão e abertura. O acréscimo fiscal às reservas foi ligado às expressões de cada motor, evitando transportar o M30 global para um cenário de obra prolongada.

3. A geração12M no primeiro mês com dívida passou a somar diretamente principal, juros e encargos obrigatórios. A versão de desenvolvimento mostrou um cache transitório que omitia juros nesse ponto; a expressão explícita passou na reconciliação.

4. As48simulações financeiras mantêm os respetivos montantes de capital; não recebem automaticamente os25M€ do cenário principal. A saída mantém os direitos fixos aprovados, sinalizando cenários de captação incompleta.

5. A compensação de IVA foi limitada ao crédito elegível e à capacidade de IVA liquidado da própria KK introduzida em V05 IVA Comp. Sem capacidade documentada/previsão, não há compensação automática. O crédito permanece pendente.

6. A base com IVA incluído extrai o imposto antes de apresentar custo económico e repõe o desembolso bruto, evitando adicionar novamente o IVA ao mesmo orçamento.

7. Os prémios operacionais são calculados pelas bases e taxas; a diferença do orçamento indicativo foi resolvida por cálculo dinâmico, sem total fixo. Direitos, taxas e coberturas não foram considerados contratados.

8. O comparativo de retorno a10anos passou a deduzir o IRPC por pagar emM120, de forma coerente com a saídaM180. Foram comparados o valor líquido, TIR, MOIC e os121fluxos da alternativa10anos, sem somar duas saídas no mesmo cenário.

9. Os consumidores antigos do imposto de transmissão foram ligados à mesma taxa efetiva suportada pela KK, incluindo custos por unidade, cash sweep e projeções futuras de caixa imobiliária. O antigo1,5% é apenas referência do modo legado desligado; os cenários de benefício ITI foram testados separadamente.

## Testes executados

{table(['Verificação','Resultado'],[['Cenários de seletores em LibreOffice',str(native['cases'])],['Comparações numéricas nativas/Python',str(native['comparisons'])],['Falhas numéricas inesperadas',str(native['failures'])],['Erros de fórmula inesperados',str(native['unexpected_errors'])],['Reabertura:62motores incluindo o principal','Conforme'],['Regressões Python','10grupos aprovados; inclui paridade com módulos desligados'],['Excel Desktop / Web / WPS','Não executado; sem certificação']])}

Os testes nativos alteraram seletores por cliente externo Java/UNO ou por alterações OOXML em cópias privadas, seguidas de recálculo nativo integral. Nenhuma macro foi adicionada ou executada. As simulações Aprovada_Prova_Sintetica e Atos_KK_Sintetico são exclusivamente testes; não representam documentos aprovados. O modelo final mantém regimeGeral, candidaturaEm preparação, prova0 e campos de pagamentos efetivos vazios.

As comparações cobrem os180meses: caixa, dívida, juros, draws, serviço obrigatório, sweep, lucros, dividendos, IVA, impostos, seguros e fluxos por bloco. Tolerâncias monetárias: máximo de0,01€ ou1e-9 relativo; rácios1e-7 absoluto/1e-8 relativo. Valores não finitos são rejeitados. Os snapshots nativos verificam erros de todas as folhas, além dos KPI principais. A alteraçãoPT/EN e o filtroID201 foram verificados no motor nativo.

## Reconciliação e resultados

{table(['Marco','Caixa V04','Caixa final','Dívida final'],[[f'M{month}',fmt(oldbridge[0]['cash'+str(month)]),fmt(m['cash'+str(month)]),fmt(f[month-1]['debt'])] for month in [30,42,54]])}

As diferenças não foram anuladas por valores fixos. Resultam do calendário de captação revisto, da substituição da fiscalidade simplificada, do IVA e do seu timing, de seguros, IPI/atos, juros, reservas e política acionista. A ponte incremental é sequencial e depende da ordem; inclui contrafactuais apenas para diagnóstico. O ficheiro CSV mensal identifica os movimentos e diferenças face à V04.

## Estados e pendências

{table(['Área','Estado / limite'],[['Integridade, reconciliação e propagação testadas','Conforme nos testes executados'],['Tesouraria base','Conforme sob hipóteses de cenário; depende de capital/vendas/linha e prazos fiscais'],['Rentabilidade investidores a12%','Alerta: VPL negativo'],['Stress combinado','Alerta: défices, quando indicados nas sensibilidades'],['Fiscalidade e Convenção','Pendente de Validação Externa; taxas do mandato, não parecer legal'],['Recuperação IVA6meses','Hipótese de estudo; não direito ou reembolso confirmado'],['IPI e depreciações','Proxies de bases tributáveis e vida útil; sem mapas fiscais certificados'],['Seguros','Provisões editáveis; inclusão e cotações pendentes'],['94frações e escrituras504/810','IDs/preços preservados; M29 dessas frações não contratualmente confirmado'],['Dividendos e pagamentos','Simulação; aprovação, contas e covenants pendentes'],['JSCV/JALS retorno histórico individual','Custos e datas individuais indisponíveis'],['Excel Desktop','Compatibilidade não certificada']])}

A IRPC da promoção usa uma alocação de CAPEX por área; a depreciação usa base40,1M€/30anos e deve ser substituída por classes fiscais validadas. Os anos fiscais do projeto e o prazo de pagamento3meses são convenções, não calendário legal certificado. Custos aduaneiros/selo não quantificados a zero são pendências, não isenções.

A inspeção textual da V04 não identificou uma rubrica explícita de seguros. Isso não prova ausência de inclusão em custos agregados; a inclusão na empreitada/forecast permanece por confirmar e pode ser parametrizada sem duplicar o custo. O reporte da promoção e da operação é exclusivo da KK; impostos da JSCV ou dos investidores não são automaticamente consolidados.

A fiscalidade dos proprietários permanece informativa; taxa zero por falta de parecer não constitui benefício. O rendimento por unidade é rateio de estudo do pool, não contrato individual. A conservação patrimonial mantém FF&E/reposição e respetivos fundos sem repetir FF&E inicial.

Não se conclui validação fiscal/jurídica nem viabilidade incondicional a partir destes testes. Os testes comprovam a execução e a reconciliação da lógica financeira explicitamente parametrizada.
'''
 save('KK01_V05_Relatorio_Auditoria',audit)
 guide='''# KK-01 V05 Executive — Guia de utilização

21/10/2026. Abrir KK01_Modelo_Integrado_V05_Executive.xlsx e iniciar em EXEC V05. Trabalhar numa cópia para simulações. O ficheiro mantém fórmulas nativas e não contém VBA.

## Navegação e idioma

A sidebar dos nove ecrãs abre qualquer painel; o rodapé permite regressar à Visão Executiva e consultar fontes. O nome técnico DASH02 identifica exclusivamente Fiscalidade, Incentivos e Seguros. Os painéis antigos continuam disponíveis, identificados como legado.

Selecionar PT ou EN em CONFIG_LANGUAGE!B5. É um único controlo global: menus, títulos, cartões, legendas e avisos consultam DIC_TRANSLATIONS. A mudança de idioma não modifica pressupostos ou resultados. Os nomes técnicos das folhas e códigos de cenários mantêm-se estáveis.

Clicar no título de um KPI para abrir V05 KPI. Consultar definição, unidade, fórmula da célula, fonte e limitações. O V04 Dicionario KPI foi preservado e está ligado pelo novo dicionário.

## Alterar cenários

Células editáveis estão assinaladas a azul com notas. As folhas novas protegem fórmulas sem password; os inputs azuis continuam desbloqueados. Para manutenção estrutural, retirar a proteção na opçãoRever/Desproteger folha e restaurá-la após a alteração. Não ordenar linhas das folhas de configuração, captação ou traduções: as referências são estáveis por endereço. V05 Parametros controla IVA, impostos, seguros, incentivos e hipóteses fiscais. Pressupostos mantém os parâmetros originais da operação, obra, banco e cenários. V05 Config controla dividendos e saída. Os botões da top bar levam às fontes; não existem nove cópias independentes dos inputs.

Com Usar calendário8blocos=1, editar compromisso/recebimento e parcela destinada à KK em V05 Captacao. Os meses próprios substituem o calendário legado. Para testar os antigos calendários Base/Acelerado/Prudente/V03, usar seletor0 e o controlo original em Pressupostos. A origem do capital deve distinguir primário, secundário ou empréstimo; não editar percentagens societárias para ajustar artificialmente o funding.

O calendário-base revisto recebe P01 noM1, G01 noM2, G02 noM3, S01 noM4, S02/S03 noM5 e S04/S05 noM6. G02 mantém cinco parcelas técnicas simultâneas de1M€, agregadas num único bloco5M€. É hipótese de estudo, não contrato.

IVA: Integral é100% recuperável com lag6meses de estudo; Parcial usa percentagem editável; Diferido usa18meses editáveis. Crédito não recuperável integra o custo económico; crédito pendente não é caixa. Compensação exige capacidade mensal da mesma entidade em V05 IVA Comp. Não transferir créditos de outras sociedades.

Convenção: Geral não tem benefícios; Pretendida simula propostas; Aprovada só pode ativar benefícios com estadoAprovada, prova1 e identificação do documento. O estado de candidatura isolado não altera impostos. Não confundir o ensaio sintético dos testes com aprovação efetiva.

Seguros: indicar fração incluída na empreitada/OPEX entre0e1. O modelo acrescenta apenas o remanescente. O fator1/1,25/1,50 testa prémios. Os seguros de obra197.400€ correspondem à obra inteira30meses, sem multiplicação por2,5anos.

## Construção, atos e titularidade

V05 Capitulos apresenta orçamento, contratado, realizado, ETC e EAC. Valores documentais não fornecidos ficam vazios. O ETC calculado pode ser revisto, mas a aplicação ao motor mantém o controlo central de ETC/EAC em Pressupostos/V04 EAC; não ativar duas revisões do mesmo custo. Confirmar coerência entre o mapa por capítulos e o override central antes de uma revisão de orçamento.

V05 Trimestres agrega o motor mensal; os primeiros dez trimestres correspondem aos30meses-base. Em atraso, custos adicionais podem ocorrer nos trimestres seguintes e não devem ser truncados para forçar reconciliação.

O inventário único e o calendário das94unidades continuam em Unidades. V05 Escrituras consulta esse calendário e permite definir quota de custos suportada pela KK, outros encargos e os três atos não residenciais potenciais. PH é provisão separada20.000€ noM27 de estudo. Não imputar custos dos compradores à KK por defeito.

## Filtros comerciais

Nos DASH04A/04B, os filtros de ID, tipologia, piso, mês e trimestre atuam no detalhe e no gráfico associado. Todos desativa a restrição. O ID aceita entrada manual como201. Os cartões globais de tesouraria continuam a representar o projeto. Estes filtros não alteram o pricing nem o calendário financeiro; para alterar o cenário editar a fonte em Unidades/Pressupostos.

## Dividendos, saída e retornos

Primeira data elegívelM54; seguintes cada12meses atéM174. M180 tem apenas saída, sem ordinário adicional implícito. A base usa caixa gerada nos12meses anteriores com cobertura1,20×, caixa protegida e lucro de estudo. Acumulados é uma análise independente; pode suportar um montante com cobertura12M inferior ao limite e deve ser lida como alternativa.

Quando o mínimo3M€ não é suportado, o cenário parcial distribui proporcionalmente aos objetivos mínimos das categorias. Não há prioridade adicional ou dívida automática por dividendos não pagos. V05 Controlo distingue valores documentados, aprovação e pagamentos efetivos; deixar vazio quando não houver prova. Os registos documentais não criam um segundo desembolso no forecast.

A saídaM180 usa EBITDA dos meses169–180 e múltiplo10/12/15×. Deduz custos, dívida e obrigações, incluindo IRPC por pagar; adiciona caixa elegível uma vez. Os proprietários dos apartamentos já vendidos não entram como ativos próprios no EV. JSCV/JALS/novos recebem40/10/50 da saída como hipótese-base de estudo.

As TIR mensais são anualizadas sobre fluxos de cenário. A XIRR utiliza datas convencionais editáveis, ancoradas em01/11/2026 como hipótese; não é TIR histórica efetiva sem datas reais. MOIC inclui saída hipotética. Os promotores não têm custo de entrada individual documentado; não interpretar os tickets convencionais como capital novo ou investimento histórico efetivo.

## Alertas e compatibilidade

Consultar défice de caixa, reserva, DSCR, cobertura dos dividendos e rácios do operador. O DSCR exclui sweep voluntário e apresenta a cobertura operacional do serviço obrigatório; durante a construção os encargos são analisados pelas fontes e usos. Rácios do operador usam CFADS consolidado KK após impostos pagos e antes de dívida, explicitando meses sem caixa positiva.

Não editar fórmulas ou valores de saída para apagar alertas. Um teste técnico aprovado não torna viável um cenário com funding ou reservas insuficientes. O Excel deve estar em cálculo automático; ao abrir efetuar recálculo integral se necessário. Não foram realizados testes em Excel Desktop/Web/WPS: LibreOffice e Python são os motores efetivamente utilizados.
'''
 save('KK01_V05_Guia_Utilizacao',guide)
 assumptions='# KK-01 V05 — Registo de pressupostos e pendências\n\n21/10/2026. Definido pelo mandato não significa contratado ou realizado.\n\n'
 assumptions+=table(['Grupo','Classificação','Referência'],[['15blocos/40-10-50/tickets','Definido para estudo; formalização pendente','3P,2G,10S; captação25M'],['Obra/Hotel/inventário','Referências preservadas','30meses;200quartos;MICE1.500;94unidades'],['Capital, banco e vendas','Projetado; compromissos por confirmar','Oito blocos/linha30M não renovável'],['Dividendos e exit','Política de simulação','M54–174;1,20×;10/12/15×'],['Fiscalidade','Hipóteses e parecer pendente','IVA15%;IRPC20%;ITI1%;IPI0,1%'],['Seguros','Provisões sem cotações','197.400€ obra; operação dinâmica'],['Convenção','Não concedida','RegimeGeral; candidaturaEm preparação; prova0'],['Datas para XIRR','Convencionais','Início01/11/2026; substituir por datas reais']])
 assumptions+='\n## Parâmetros centrais novos\n\n'+table(['Parâmetro PT/EN','Valor de referência','Unidade','Estado / limite'],[[label,str(value),unit,note] for key,label,value,unit,note in PARAMS])
 assumptions+='\n## Pendências materiais\n\nParecer fiscal com vigência e entidade; bases e depreciações; mapa de importações/selo/taxas; prazo de IVA; período fiscal e liquidação IRPC; contratos e inclusão dos seguros; responsabilidades em97atos potenciais; regime dos proprietários; escrituras504/810; formalização societária; datas/custos históricos dos promotores; compromissos efetivos de capital/banco/vendas; regras de venda e caixa normalizada na saída.\n\nZeros em impostos não quantificados, pagamentos ou documentos não demonstram isenções, ausência de obrigações ou realização de caixa.\n'
 save('KK01_V05_Registo_Pressupostos',assumptions)
 changes=json.loads((out/'Registo_Alteracoes_Formulas.json').read_text());counts=collections.Counter(x['sheet'] for x in changes)
 with (out/'Alteracoes_por_Folha.csv').open('w',newline='') as stream:writer=csv.writer(stream);writer.writerow(['Folha','Células de alteração registadas']);writer.writerows(sorted(counts.items()))
 with (out/'Registo_Alteracoes_Formulas.json').open('rb') as src,gzip.open(out/'Registo_Alteracoes_Formulas.json.gz','wb',compresslevel=6) as dst:shutil.copyfileobj(src,dst)
 with Path('/workspace/kk01/v05/entrega/Registo_Alteracoes_Fase2.json').open('rb') as src,gzip.open(out/'Registo_Fase2_Anterior.json.gz','wb') as dst:shutil.copyfileobj(src,dst)
 changelog=f'''# KK-01 V05 — Relatório de alterações

21/10/2026. Preservação do V04 Excel Fix e da entrega anterior. Alterações atuais sobre a camada financeira anterior: {len(changes)}células registadas em{len(counts)}folhas, incluindo fórmulas auxiliares e textos; não são{len(changes)}erros da V04.

## Módulos

Capital:8calendários próprios, separação caixa KK/secondary e propagação às48sensibilidades e13riscos. Financiamento: motor não renovável preservado; novas despesas e reservas fiscais ligadas à disponibilidade, draw, juros, serviço e sweep. IVA: pago/dedutível/reembolsado/compensado/pendente/não recuperável, com bases líquidas ou IVA incluído. IRPC: EBT, prejuízos, lucro tributável, incentivos elegíveis, acréscimo/pagamento e dívida fiscal. Atos/IPI: titularidade, pagador e calendário. Seguros: adicionais versus incluídos, taxas dinâmicas, CAPEX/OPEX.

Dividendos: lucros de estudo e retenção prudencial, proteção de impostos, cobertura12M ou acumulados, parcial e documentação separada. Exit: IRPC por pagar deduzido; projeto distingue impostos sem escudo financeiro. Interface: nove painéis, gráficos e filtros comerciais, dicionárioPT/EN, fontes e navegação. Histórico, capítulos/EAC/ETC, trimestres, fontes fiscais e análises anuais ficam em folhas técnicas.

## Evidências

Registo_Alteracoes_Formulas.json.gz contém folha/célula/fórmula anterior/nova e motivo. Alteracoes_por_Folha.csv sintetiza o volume. Registo_Fase2_Anterior.json.gz cobre o percurso da V04 à camada anterior. A atualização de caches apenas transfere valores recalculados e não substitui fórmulas. Reconciliacao_Caches_Final.json prova a identidade das fórmulas antes/depois dessa transferência.

As folhas e dashboards legados foram preservados com avisos de contexto; não devem ser lidos como uma segunda política financeira. Todos os novos painéis consultam o mesmo motor. As decisões externas continuam identificadas em V05 Parametros, fontes fiscais e registo de pressupostos.
'''
 save('KK01_V05_Relatorio_Alteracoes',changelog)
 tech='''# KK-01 V05 — Documentação técnica

21/10/2026. Workbook OOXML sem VBA,180meses e resumos anuais15anos. Construído por alterações controladas sobre a V04 Fixed, preservando os componentes originais e a camada financeira anterior.

## Fluxo de dados

Pressupostos/Cenarios/Unidades/Obra + V05 Captacao/V05 Parametros → recebimentos/CAPEX/operação/capital + auxiliares fiscais em cada motor → Fluxo180M e61alternativas → reservas/dividendos → V04Waterfall180/V04Retornos/V05Blocos → V05Anual/V05KPI/V05Dados → nove ecrãs. CONFIG_LANGUAGE/DIC_TRANSLATIONS alimentam apenas apresentação.

## Novas folhas

V05 Parametros: inputs fiscais/seguros e limites. V05 IVA Comp: capacidade KK por mês. V05 Captacao:8blocos e origens. V05 Escrituras:94frações e3atos potenciais. V05 Historico:4,5M separados da caixa futura. V05 Capitulos: contratado/realizado/ETC/EAC de controlo. V05 Trimestres: agregação mensal. V05 Anual:15anos. V05 Fontes Fiscais: entidade/incidência/estado. V05 Seguros: bases e prémios. V05 Proprietarios: rateio informativo. V05 Sensibilidades:48motores dinâmicos. V05 KPI: definições e fontes. V05 Dados/V05 RE A/B: fontes de gráficos, ocultas. CONFIG_LANGUAGE/DIC_TRANSLATIONS/V05 Listas: idioma e validações. Nove ecrãs: EXEC V05, DASH01V05, DASH02, DASH03V05, DASH04AV05, DASH04BV05, DASH05V05, DASH06V05, DASH07V05; os nomes efetivos incluem os espaços visíveis no Excel.

## Fórmulas críticas

IVA suportado=(construção+fiscalização líquidas)×taxa. Crédito pendente=saldo inicial+IVA dedutível−compensação−reembolso. Não recuperável integra custo, sem nova duplicação de caixa. Compensação limita-se à capacidade da mesma entidade e aos créditos temporalmente elegíveis.

Lucro da promoção=preço transmitido−quota de custo de construção/seguro/IVA não recuperável−custos comerciais/ITI KK. Quota de área é hipótese. Resultado operacional tributável=EBITDA Hotel+MICE+residualKK−depreciação−juros/encargos. EBT consolidado desconta atos/IPI/outros encargos modelados; compensa prejuízos de estudo. IRPC é anual, com efeito de incentivos limitado ao lucro elegível. Pagamento é separado da competência; o passivo fiscal final reduz o Equity Value.

A retenção prudencial de5% e a proxy de resultados não certificam lucros legalmente distribuíveis. Valores documentados usam caps e aprovação próprios. O serviço obrigatório inclui principal/juros/encargos mandatórios e exclui sweep. O CFADS consolidado inclui efeitos dos impostos pagos, explicitando que não é imposto autónomo exclusivo do Hotel.

O projeto usa impostos sem o escudo de financiamento na TIR/VPL de projeto, evitando mudar esse retorno apenas por alterar juros. Fluxos de equity incluem financiamento, dividendos e saída. A base histórica não é repetida no CF futuro; métricas de projeto futuro são incrementais. Payback é determinado após o último saldo acumulado negativo; o retorno acionista depende dos fluxos próprios.

EV=Múltiplo×EBITDA M169–180. Equity=EV−custos−dívida−crédito acionista+caixa−HOTUSA/contingência−reserva adicional−IRPC por pagar, limitado a zero. Reserva operacional protege a exploração e não é abatida automaticamente como perda na venda; confirmar normalização de fundo de maneio/caixa com comprador. Não reavaliar apartamentos vendidos. Saída40/10/50; ordinários por objetivos de categoria, sem preferências adicionais.

## Datas e limitações

Meses do projeto não são datas de contratos. Data inicial01/11/2026 e vetor uniforme365/12 são convenções editáveis para XIRR; sem dados individuais não há TIR histórica comprovada. As bases tributáveis/proprietários/incentivos/seguro são hipóteses não certificadas. Não há importação automática de extratos, contabilidade, apólices ou registos societários.

## Código e regressões

model.py reutiliza o corpo do motor mensal V04 e injeta cálculos fiscais sequenciais. financial.py gera fórmulas OOXML equivalentes. build.py preserva partes e junta folhas/estilos/desenhos/validações. interface.py constrói os nove ecrãs. test_model.py testa invariantes e paridade desligada. validate.py compara valores; NativeScenarios.java altera seletores via UNO e desativa macros. audit_live.py reconcilia cenários e reabre a referência com62motores. merge_caches.py atualiza apenas valores e caches dos gráficos, provando identidade das fórmulas. audit_structure.py verifica o pacote, relações, fórmulas, folhas, nomes, gráficos e validações.

O pacote de fontes inclui referências Python e metadados necessários. Para gerar o workbook são necessárias as duas bases Excel indicadas no README_Fontes, disponíveis nas entregas anteriores; não estão duplicadas no pacote. Testar futuras alterações com os mesmos casos e acrescentar casos para novos ramos lógicos. Os testes financeiros nativos não certificam Excel Desktop.
'''
 save('KK01_V05_Documentacao_Tecnica',tech)
 (out/'Verificacao_Originais.json').write_text(json.dumps({'V04_Fixed':{'file':str(ORIGINAL),'sha256':hashlib.sha256(ORIGINAL.read_bytes()).hexdigest()},'Fase2_anterior':{'file':str(BASE),'sha256':hashlib.sha256(BASE.read_bytes()).hexdigest()},'sem_escrita_nos_originais':True},ensure_ascii=False,indent=2))
 env={'python':platform.python_version(),'packages':{k:importlib.metadata.version(k) for k in ['openpyxl','numpy','scipy','reportlab','pypdf','matplotlib']},'libreoffice':subprocess.run(['soffice','--version'],capture_output=True,text=True).stdout.strip(),'Excel_Desktop':'Indisponível; compatibilidade não certificada','UNO_client_jar':'org.libreoffice:libreoffice:26.2.2','jar_sha256':hashlib.sha256((ROOT/'validacao/java/libreoffice-26.2.2.jar').read_bytes()).hexdigest()};(out/'Ambiente_Validacao.json').write_text(json.dumps(env,ensure_ascii=False,indent=2))
 shutil.copy2(ROOT/'Autorizacao_Integral.txt',out/'Autorizacao_Execucao_Integral.txt');shutil.copy2(ROOT/'validacao/Testes_Python.log',out/'Testes_Python.log')
 print('Relatórios, pontes, pressupostos e fontes de auditoria produzidos.')
if __name__=='__main__':main()
