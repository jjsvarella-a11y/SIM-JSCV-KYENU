from pathlib import Path
import json,zipfile,xml.etree.ElementTree as E,re,html,collections,os
from openpyxl.utils import get_column_letter as CL
ROOT=Path(__file__).resolve().parents[1]
BASE=Path(os.environ.get('KK01_BASE_PATH','/workspace/kk01/v05/entrega/KK01_Modelo_Integrado_V05_Executive.xlsx'))
ORIGINAL=Path(os.environ.get('KK01_ORIGINAL_PATH','/workspace/kk01/v05/original/KK01_Modelo_Integrado_V04_Excel_Fix.xlsx'))
OUTPUT=ROOT/'entrega/KK01_Modelo_Integrado_V05_Executive.xlsx'
N='http://schemas.openxmlformats.org/spreadsheetml/2006/main';T=lambda x:'{'+N+'}'+x
RID='{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id'
META=json.loads((ROOT/'reference/src/build_metadata.json').read_text());PR=META['param_rows'];PV=lambda k:f'Pressupostos!$B${PR[k]}'
# All are editable study assumptions unless documentary proof is supplied.
PARAMS=[
('active','Ativar módulos novos / Enable new modules',1,'0/1','Desligar permite ponte para Fase2 anterior.'),
('vat_rate','IVA construção/fiscalização / VAT rate',.15,'%','Mandato; taxa e dedutibilidade carecem parecer fiscal.'),
('vat_mode','Cenário IVA / VAT scenario','Integral','lista','Integral, Parcial, Diferido.'),
('vat_recovery','Recuperação parcial / Partial recovery',.75,'%','Hipótese de stress, não previsão fiscal.'),
('vat_lag','Prazo recuperação base / Base recovery lag',6,'meses','Hipótese de estudo editável; sem data de reembolso contratada.'),
('vat_deferred','Prazo cenário diferido / Deferred lag',18,'meses','Hipótese de stress.'),
('vat_comp','Parte por compensação / Offset share',0,'%','Só na mesma entidade KK; remanescente por reembolso.'),
('budget_gross','Orçamento construção inclui IVA / Budget VAT-inclusive',0,'0/1','0: base líquida;1: extrair IVA do orçamento, sem acrescentar imposto de novo.'),
('irpc','IRPC / Corporate income tax',.20,'%','Referência do mandato2026; fonte legal ainda por validar.'),
('tax_lag','Pagamento após fecho anual / Tax payment lag',3,'meses','Hipótese: pagamento três meses após fim do ano do projeto; calendário legal a validar.'),
('depreciable','Base depreciável Hotel+MICE / Depreciable basis',40100000,'EUR','Estimativa de estudo; confirmar custo fiscal, não valor de mercado nem capital seguro definitivo.'),
('depreciation_years','Vida útil fiscal / Tax useful life',30,'anos','Hipótese simplificada; substituir mapa por classes após parecer.'),
('legal_reserve','Retenção prudencial sobre lucro / Profit retention',.05,'%','Hipótese de retenção; não certifica montante da reserva legal.'),
('iti','ITI transmissão / Transfer tax',.01,'%','Referência geral do mandato; vigência, base e sujeito passivo a confirmar.'),
('iti_kk','ITI suportado KK / KK share of ITI',0,'%','Hipótese comprador100%; alterar se KK suportar contratualmente.'),
('ipi','IPI propriedade anual / Annual property tax',.001,'%','Hipótese geral; valores tributáveis reais pendentes.'),
('land_taxbase','Base IPI terreno / Land taxable base',1000000,'EUR','Proxy histórica até abertura; sem valor matricial confirmado.'),
('property_taxbase','Base IPI Hotel+MICE/restaurante / Operating taxable base',40100000,'EUR','Proxy conjunta, sem duplicar MICE/restaurante; substituir por matrizes reais.'),
('unsold_tax_factor','Base IPI não vendidos / Unsold taxable factor',1,'x preço','Proxy tributável do preço; não equivale a valor matricial.'),
('fx','CVE por EUR / CVE per EUR',110.265,'CVE/EUR','Referência central do mandato.'),
('deed_cve','Taxa escritura / Deed fee',24000,'CVE/ato','Valor convencional; sujeito e tabela legal pendentes.'),
('certificate_cve','Certidão matricial / Tax certificate',1500,'CVE/ato','Por apartamento.'),
('registry_cve','Certidão predial / Registry certificate',1500,'CVE/ato','Por apartamento.'),
('ph','Propriedade horizontal / Condominium constitution',20000,'EUR','Estimativa de gestão, não inclui atos adicionais automaticamente.'),
('ph_month','Mês PH / PH month',27,'mês','Hipótese editável, não contrato.'),
('construction_ins_rate','Seguro de obra total / Construction insurance rate',.0035,'%','0,30% CAR+0,05%RC para30meses; não multiplicar por2,5.'),
('construction_ins_included','Seguro obra já incluído / Included construction insurance',0,'%','0 prudente adicional;1 totalmente incluído; confirmar empreitada.'),
('insurance_factor','Multiplicador seguros / Insurance stress factor',1,'x','Sensibilidade1/1,25/1,50.'),
('insured_basis','Capital patrimonial indicativo / Indicative insured basis',40100000,'EUR','Confirmar reconstrução/reposição; não capital seguro certificado.'),
('property_ins_rate','Seguro patrimonial / Property insurance rate',.0035,'%','Provisão de estudo, não cotação.'),
('bi_rate','Interrupção atividade / Business interruption rate',.0015,'% receita','Sobre receita anualizada dinâmica.'),
('liability_rate','RC exploração / Operating liability rate',.0015,'% receita','Sobre receita anualizada dinâmica.'),
('insurance_extra','Coberturas complementares / Additional cover',15000,'EUR/ano','Sem sobrepor coberturas.'),
('operating_ins_included','Seguro operação incluído OPEX / Included operating insurance',0,'%','0 prudente adicional;1 já incluído; confirmar forecast.'),
('convention','Cenário Convenção / Convention scenario','Geral','lista','Geral; Pretendida; Aprovada. Aprovada não ativa sem prova.'),
('application','Estado candidatura / Application status','Em preparação','lista','Estado informativo; nunca ativa benefícios.'),
('proof','Benefícios documentados / Documentary approval',0,'0/1','Só ativar com documento válido identificado na colunaE.'),
('holiday','Anos isenção pretendida / Proposed exemption years',3,'anos','3/5; benefício apenas sobre lucro elegível Hotel+MICE como hipótese.'),
('reduced_rate','IRPC posterior pretendido / Proposed later rate',.10,'%','Hipótese de estudo; não benefício concedido.'),
('iti_relief','Redução ITI / ITI relief',0,'%','Dependente de norma e titular.'),
('ipi_relief','Redução IPI / IPI relief',0,'%','Não extensível automaticamente a proprietários.'),
('customs_base','Base importações elegíveis / Eligible import base',0,'EUR','Sem lista de importações: zero significa não quantificado.'),
('customs_rate','Direitos aduaneiros / Customs rate',0,'%','Sem classificação: zero significa pendente, não isenção.'),
('customs_relief','Redução direitos / Customs relief',0,'%','Cenário pretendido ou aprovado com prova.'),
('customs_month','Mês direitos / Customs month',18,'mês','Hipótese de calendário.'),
('stamp_fin','Selo financiamento / Financing stamp duty',0,'% linha','Base e taxa pendentes; despesa só no primeiro desembolso.'),
('stamp_ins','Selo seguros / Insurance stamp duty',0,'% prémio','Base e taxa pendentes.'),
('stamp_relief','Redução selo / Stamp relief',0,'%','Nunca ativo no regime geral.'),
('owner_tax','Taxa proprietário / Owner tax rate',0,'%','Não quantificado sem parecer; zero NÃO certifica isenção.'),
('owner_cost','Custos adicionais proprietário / Additional owner costs',0,'% rendimento','Só custos ainda não abatidos no pool.'),
('start_date','Data inicial de estudo / Study start date',46327,'data','01/11/2026: convenção editável, não cronograma contratual.'),
('use_capital','Usar calendário8blocos / Use8block schedule',1,'0/1','1: calendário próprio revisto de estudo;0: calendário anterior para reconciliação.'),
('fund_current_tax','Proteger imposto no último draw / Protect tax at last draw',1,'0/1','Reserva prudente sem escudo de juros no último mês de crédito; evita deixar obrigação conhecida sem funding na abertura.'),
]
ROWS={k:i+5 for i,(k,*_) in enumerate(PARAMS)}
P=lambda k:f"'V05 Parametros'!$B${ROWS[k]}"
HKEYS=['vat_paid','vat_offset','vat_refund','vat_pending','vat_nonrecoverable','vat_net','construction_ins','deeds','property_other','customs','cash_cost','sales_profit','operating_ebt','other_expense','ebt','ytd_ebt','loss_open','taxable','eligible','tax_general','tax_selected','tax_accrual','tax_paid','tax_liability','profit_cum','profit_capacity','cfads','future_cost','unlevered_ebt','unlevered_ytd','unlevered_loss','unlevered_tax','unlevered_paid','construction_economic','insurance_operating','ipi_operating','depreciation','tax_saving','extra_reserve','unlevered_general','tax_prudential']
HC={k:CL(72+i) for i,k in enumerate(HKEYS)} # BT onward
def paths(z):
 w=E.fromstring(z.read('xl/workbook.xml'));rels={r.attrib['Id']:r.attrib['Target'] for r in E.fromstring(z.read('xl/_rels/workbook.xml.rels'))}
 return {s.attrib['name']:(rels[s.attrib[RID]].lstrip('/') if rels[s.attrib[RID]].startswith('/') else 'xl/'+rels[s.attrib[RID]]) for s in w.find(T('sheets'))}
def formulas(raw):return {m[1]:html.unescape(m[2]) for m in re.finditer(r'<(?:\w+:)?c\b[^>]*\br="([A-Z]+\d+)"[^>]*>\s*<(?:\w+:)?f(?:\s[^>]*)?>(.*?)</(?:\w+:)?f>',raw,re.S)}
def patch(raw,updates):
 pending=updates.copy()
 def sub(m):
  prefix=m[1];a=m[2]
  if a not in pending:return m[0]
  v=pending.pop(a);style=re.search(r'\bs="(\d+)"',m[0]);st=f' s="{style[1]}"' if style else ''
  if isinstance(v,str) and v.startswith('='):return f'<{prefix}c r="{a}"{st}><{prefix}f>{html.escape(v[1:],quote=False)}</{prefix}f></{prefix}c>'
  if isinstance(v,(int,float)):return f'<{prefix}c r="{a}"{st}><{prefix}v>{v}</{prefix}v></{prefix}c>'
  if v is None:return f'<{prefix}c r="{a}"{st}/>'
  return f'<{prefix}c r="{a}"{st} t="inlineStr"><{prefix}is><{prefix}t>{html.escape(str(v))}</{prefix}t></{prefix}is></{prefix}c>'
 raw=re.sub(r'<((?:\w+:)?)c\b[^>]*\br="([A-Z]+\d+)"[^>]*(?:/>|>.*?</\1c>)',sub,raw,flags=re.S)
 if pending:
  prefix=re.search(r'<((?:\w+:)?)worksheet\b',raw)[1]
  by=collections.defaultdict(list)
  for a,v in pending.items():
   cell=subtype(a,v)
   if prefix:cell=re.sub(r'<(/?)(\w+)',lambda m:'<'+m[1]+prefix+m[2],cell)
   by[int(re.search(r'\d+',a)[0])].append(cell)
  def row(m):
   close='</'+m[1]+'row>';return m[0][:-len(close)]+''.join(by.pop(int(m[2]),[]))+close
  raw=re.sub(r'<((?:\w+:)?)row\b[^>]*\br="(\d+)"[^>]*>.*?</\1row>',row,raw,flags=re.S)
  if by:
   closing='</'+prefix+'sheetData>';raw=raw.replace(closing,''.join(f'<{prefix}row r="{r}">'+''.join(cs)+f'</{prefix}row>' for r,cs in sorted(by.items()))+closing)
 return raw
def subtype(a,v):
 if isinstance(v,str) and v.startswith('='):return f'<c r="{a}"><f>{html.escape(v[1:],quote=False)}</f></c>'
 if isinstance(v,(int,float)):return f'<c r="{a}"><v>{v}</v></c>'
 if v is None:return f'<c r="{a}"/>'
 return f'<c r="{a}" t="inlineStr"><is><t>{html.escape(str(v))}</t></is></c>'
