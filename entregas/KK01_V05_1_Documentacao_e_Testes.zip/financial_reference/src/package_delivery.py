"""Package only final evidence; keep the model and documentation below 40 MB each."""
from pathlib import Path
import json,hashlib,zipfile,shutil
from pypdf import PdfReader

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'entrega'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 for name in ['Resumo_Testes_Nativos.json','Teste_Final_Entregue.json','Testes_Estruturais.json','Prova_Formatacao_Sem_Alteracao_Financeira.json','Teste_Inputs_Interface.json']:
  assert json.loads((OUT/name).read_text())['ok'],name
 for p in OUT.glob('*.pdf'):
  reader=PdfReader(p);assert len(reader.pages)>0 and all(page.extract_text().strip() for page in reader.pages),p
 model=OUT/'KK01_Modelo_Integrado_V05_Executive.xlsx'
 with zipfile.ZipFile(model) as z:assert z.testzip() is None
 assert model.stat().st_size<40_000_000
 for p in (ROOT/'validacao').glob('*.log'):
  if p.name in ['Testes_Python.log','Audit_Live.log','Audit_UI.log','Merge_Caches.log','Final_Presentation.log','Audit_Structure.log']:
   shutil.copy2(p,OUT/p.name)
 source=OUT/'KK01_V05_Fontes_e_Testes.zip'
 with zipfile.ZipFile(source,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for directory in ['src','reference/src']:
   for p in sorted((ROOT/directory).glob('*')):
    if p.is_file():z.write(p,p.relative_to(ROOT))
  for name in ['README_Fontes.md','requirements.txt']:
   z.write(ROOT/name,name)
  z.write(ROOT/'Autorizacao_Integral.txt','mandatos/Autorizacao_Integral.txt')
  z.write(ROOT/'Mandato_Consolidado.txt','mandatos/Mandato_Consolidado.txt')
 files=[p for p in sorted(OUT.rglob('*')) if p.is_file() and not p.name.startswith('.') and p.name not in ['Registo_Alteracoes_Formulas.json','Manifesto_SHA256.json','KK01_V05_Documentacao_e_Testes.zip']]
 manifest={'date':'2026-10-21','original_v04_sha256':'be8288ced2494ef31c2dbe1d31d77b8277a0753a1209a8df0a83c3a5d86dcdc0','files':{str(p.relative_to(OUT)):{'bytes':p.stat().st_size,'sha256':digest(p)} for p in files}}
 (OUT/'Manifesto_SHA256.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
 package=OUT/'KK01_V05_Documentacao_e_Testes.zip'
 with zipfile.ZipFile(package,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for p in files+[OUT/'Manifesto_SHA256.json']:
   if p!=model:z.write(p,p.relative_to(OUT))
 assert package.stat().st_size<40_000_000
 with zipfile.ZipFile(package) as z:assert z.testzip() is None
 destination=Path('/workspace/SIM-JSCV-KYENU/entregas/V05_Executive_Final')
 destination.mkdir(parents=True,exist_ok=True)
 for p in files+[OUT/'Manifesto_SHA256.json',package]:
  target=destination/p.relative_to(OUT);target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)
 print(json.dumps({'model_bytes':model.stat().st_size,'documentation_bytes':package.stat().st_size,'model_sha256':digest(model),'published_directory':str(destination)},indent=2))
if __name__=='__main__':main()
