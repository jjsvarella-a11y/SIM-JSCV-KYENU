from common import *
import model as e
import openpyxl,subprocess,time,concurrent.futures,shutil,hashlib,csv,sys,math
class NativeCell:
 def __init__(self,value):self.value=value
class NativeSheet:
 def __init__(self,rows):self.rows=rows
 def cell(self,row,column):return NativeCell(self.rows[row-1][column-1] if row<=len(self.rows) and column<=len(self.rows[row-1]) else None)
 def __getitem__(self,addr):
  from openpyxl.utils.cell import coordinate_from_string,column_index_from_string
  col,row=coordinate_from_string(addr);return self.cell(row,column_index_from_string(col))
 def iter_rows(self,min_row=1,max_row=None,min_col=1,max_col=None,values_only=False):
  max_row=max_row or len(self.rows);max_col=max_col or max(len(row) for row in self.rows)
  for r in range(min_row,max_row+1):
   values=[self.cell(r,c).value for c in range(min_col,max_col+1)]
   yield tuple(values if values_only else [NativeCell(v) for v in values])
class NativeBook:
 def __init__(self,data):self.data=data
 def __getitem__(self,name):return NativeSheet(self.data['sheets'][name])
 def close(self):pass
CASES=[
 ('Base',{},{}),
 ('Ponte_Sem_Modulos',{'active':0,'use_capital':0},{'V05 Parametros':{'B5':0,'B'+str(ROWS['use_capital']):0}}),
 ('IVA_Parcial',{'vat_mode':'Parcial'},{'V05 Parametros':{'B'+str(ROWS['vat_mode']):'Parcial'}}),
 ('IVA_Diferido',{'vat_mode':'Diferido'},{'V05 Parametros':{'B'+str(ROWS['vat_mode']):'Diferido'}}),
 ('IVA_Orcamento_Bruto',{'budget_gross':1},{'V05 Parametros':{'B'+str(ROWS['budget_gross']):1}}),
 ('IRPC_3anos',{'convention':'Pretendida','holiday':3},{'V05 Parametros':{'B'+str(ROWS['convention']):'Pretendida','B'+str(ROWS['holiday']):3}}),
 ('IRPC_5anos',{'convention':'Pretendida','holiday':5},{'V05 Parametros':{'B'+str(ROWS['convention']):'Pretendida','B'+str(ROWS['holiday']):5}}),
 ('Aprovada_Sem_Prova',{'convention':'Aprovada'},{'V05 Parametros':{'B'+str(ROWS['convention']):'Aprovada'}}),
 ('Seguros_25',{'insurance_factor':1.25},{'V05 Parametros':{'B'+str(ROWS['insurance_factor']):1.25}}),
 ('Seguros_50',{'insurance_factor':1.5},{'V05 Parametros':{'B'+str(ROWS['insurance_factor']):1.5}}),
 ('Seguros_Incluidos',{'construction_ins_included':1,'operating_ins_included':1},{'V05 Parametros':{'B'+str(ROWS['construction_ins_included']):1,'B'+str(ROWS['operating_ins_included']):1}}),
 ('Operador_4_3_10',{'fee_mode':'Proposta simulada'},{'Pressupostos':{'B'+str(PR['fee_mode']):'Proposta simulada'}}),
 ('Div_Minimo',{'div_tier':'Mínimo'},{'V05 Config':{'B6':'Mínimo'}}),
 ('Div_Intermedio',{'div_tier':'Intermédio'},{'V05 Config':{'B6':'Intermédio'}}),
 ('Div_Maximo_Acumulados',{'div_tier':'Máximo','div_basis':'Acumulados'},{'V05 Config':{'B5':'Acumulados','B6':'Máximo'}}),
 ('Div_Suspenso',{'div_tier':'Suspenso'},{'V05 Config':{'B6':'Suspenso'}}),
 ('Div_Documentado_Sem_Teto',{'payout_basis':'Documentado'},{'Pressupostos':{'B'+str(PR['payout_basis']):'Documentado'}}),
 ('Exit10',{'exit_mult':10},{'V05 Config':{'B9':'Prudente'}}),
 ('Exit15',{'exit_mult':15},{'V05 Config':{'B9':'Favorável'}}),
 ('Juro8',{'bank':'Personalizado','rate_custom':.08},{'Pressupostos':{'B'+str(PR['bank']):'Personalizado','B'+str(PR['rate_custom']):.08}}),
 ('Carencia48',{'bank':'Objetivo'},{'Pressupostos':{'B'+str(PR['bank']):'Objetivo'}}),
 ('Capital_Atrasado',{'capital_delay':6},{'Pressupostos':{'B'+str(PR['capital_delay']):6}}),
 ('Vendas_Atrasadas',{'commercial_delay':6},{'Pressupostos':{'B'+str(PR['commercial_delay']):6}}),
 ('Sobrecusto10',{'cost_overrun':.10},{'Pressupostos':{'B'+str(PR['cost_overrun']):.10}}),
 ('Secundaria_20pct',{'primary':[.8]*8},{'V05 Captacao':{f'G{r}':.8 for r in range(5,13)}}),
 ('PT_EN',{}, {'CONFIG_LANGUAGE':{'B5':'EN'}}),
 ('Filtro_ID201',{}, {'DASH 04A V05':{'D52':'201'}}),
 ('Sem_Reserva_IRPC_Ultimo_Draw',{'fund_current_tax':0},{'V05 Parametros':{'B'+str(ROWS['fund_current_tax']):0}}),
 ('Aprovada_Prova_Sintetica',{'convention':'Aprovada','application':'Aprovada','proof':1,'proof_document':'TESTE SINTETICO - NAO E APROVACAO REAL'},{'V05 Parametros':{'B'+str(ROWS['convention']):'Aprovada','B'+str(ROWS['application']):'Aprovada','B'+str(ROWS['proof']):1,'E'+str(ROWS['proof']):'TESTE SINTETICO - NAO E APROVACAO REAL'}}),
 ('Atos_KK_Sintetico',{'iti_kk':1,'deed_kk':[1.]*94,'nonres_kk':[1.]*3},{'V05 Parametros':{'B'+str(ROWS['iti_kk']):1},'V05 Escrituras':{f'I{r}':1 for r in range(5,102)}}),
 ('ITI_Beneficio_Sintetico',{'iti_kk':1,'iti_relief':.5,'convention':'Pretendida'},{'V05 Parametros':{'B'+str(ROWS['iti_kk']):1,'B'+str(ROWS['iti_relief']):.5,'B'+str(ROWS['convention']):'Pretendida'}}),
 ('Selo_Aduaneiros_Sintetico',{'stamp_fin':.005,'stamp_ins':.01,'customs_base':2000000,'customs_rate':.1},{'V05 Parametros':{'B'+str(ROWS[k]):v for k,v in {'stamp_fin':.005,'stamp_ins':.01,'customs_base':2000000,'customs_rate':.1}.items()}}),
 ('IVA_Comp_Limitada',{'vat_comp':.5,'vat_output_capacity':[0.]*30+[100000.]*150},{'V05 Parametros':{'B'+str(ROWS['vat_comp']):.5},'V05 IVA Comp':{f'B{r}':100000 for r in range(35,185)}}),
 ('Continuidade',{'exit_enabled':0},{'V05 Config':{'B10':0}}),
 ('Stress_Combinado',{'vat_mode':'Diferido','insurance_factor':1.5,'capital_delay':6,'commercial_delay':6,'cost_overrun':.10,'bank':'Personalizado','rate_custom':.08},{'V05 Parametros':{'B'+str(ROWS['vat_mode']):'Diferido','B'+str(ROWS['insurance_factor']):1.5},'Pressupostos':{'B'+str(PR['capital_delay']):6,'B'+str(PR['commercial_delay']):6,'B'+str(PR['cost_overrun']):.10,'B'+str(PR['bank']):'Personalizado','B'+str(PR['rate_custom']):.08}}),
]
def mutate(dest,changes):
 with zipfile.ZipFile(OUTPUT) as zi,zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED,compresslevel=2) as zo:
  ps=paths(zi);mods={ps[s]:v for s,v in changes.items()}
  for it in zi.infolist():
   data=zi.read(it.filename)
   if it.filename in mods:data=patch(data.decode(),mods[it.filename]).encode()
   if it.filename.startswith('xl/worksheets/') and it.filename.endswith('.xml'):
    def invalidate(m):
     t=m[0]
     if re.search(r'<(?:\w+:)?f(?:\s|>)',t):t=re.sub(r'<(?:\w+:)?v(?:\s[^>]*)?>.*?</(?:\w+:)?v>|<(?:\w+:)?v\s*/>','',t,flags=re.S)
     return t
    data=re.sub(r'<((?:\w+:)?)c\b[^>]*(?<!/)>.*?</\1c>',invalidate,data.decode(),flags=re.S).encode()
   zo.writestr(it,data)
def check(path,params,risks=False):
 r=e.run(e.config(**params));mm=e.results(r);fails=[];count=0;native=json.loads(path.read_text()) if path.suffix=='.json' else None;w=NativeBook(native) if native else openpyxl.load_workbook(path,read_only=True,data_only=True)
 def eq(label,actual,expected,ratio=False):
  nonlocal count
  count+=1
  if expected is None:
   if isinstance(actual,(int,float)):fails.append([label,actual,expected])
  elif not isinstance(actual,(int,float)) or not math.isfinite(actual) or abs(actual-expected)> (max(1e-7,abs(expected)*1e-8) if ratio else max(.01,abs(expected)*1e-9)):fails.append([label,actual,expected])
 def flowcheck(name,ref):
  for row,x in zip(w[name].iter_rows(min_row=5,max_row=184,values_only=True),ref['flow']):
   for k,c in META['flow_columns'].items():
    if isinstance(x.get(k),(int,float)):eq(name+' M'+str(x['m'])+' '+k,row[c],x[k],k=='dscr')
   for k,cl in HC.items():eq(name+' M'+str(x['m'])+' '+k,row[__import__('openpyxl').utils.column_index_from_string(cl)-1],x['fiscal'][k])
   for k,c in [('generation12',56),('free',57),('capacity',60),('financial_dividend',64)]:eq(name+' Div '+str(x['m'])+k,row[c],x['div_metrics'][k])
 flowcheck('Fluxo 180M',r)
 for a,k in [('B27','new_irr'),('B28','new_moic'),('B29','new_npv')]:eq('V04 Retornos!'+a,w['V04 Retornos'][a].value,mm[k],a!='B29')
 for a,k in [('B55','new_irr10'),('B56','new_moic10'),('M131','exit_equity10')]:eq('V04 Retornos10!'+a,w['V04 Retornos'][a].value,mm[k],a!='M131')
 eq('V04 Politica!B11',w['V04 Politica']['B11'].value,mm['exit_equity'])
 if params.get('vat_comp',0)>0:
  for x in r['flow']:eq('IVA comp M'+str(x['m']),w['Fluxo 180M'].cell(x['m']+4,73).value,x['fiscal']['vat_offset'])
 for key,a in [('project_npv_exit','B27'),('project_irr_exit','B29')]:eq('KPI!'+a,w['KPI'][a].value,mm[key],key=='project_irr_exit')
 for i,code in enumerate(['P01','G01','G02','S01','S02','S03','S04','S05']):
  for m,row in enumerate(w['V05 Fluxos Blocos'].iter_rows(min_row=5,max_row=185,min_col=i+2,max_col=i+2,values_only=True)):eq(code+' M'+str(m),row[0],mm['block_cf'][code][m])
 for month,row in enumerate(w['V04 Retornos'].iter_rows(min_row=5,max_row=125,min_col=17,max_col=17,values_only=True)):eq('Retorno10 M'+str(month),row[0],mm['new_cf'][month]+(mm['exit_equity10']*.5 if month==120 else 0))
 if risks:
  for item in json.loads((ROOT/'reference/src/v04_risk_metadata.json').read_text()):
   par=item['params'].copy()
   if 'res_adr_multiplier' in par:par['res_adr']=e.v4.DEFAULT['res_adr']*par.pop('res_adr_multiplier')
   rr=e.run(e.config(**par));flowcheck(item['flow'],rr)
  for j,item in enumerate(META['scenarios'],1):
   par={k:v for k,v in item.items() if k in ['equity','hotel','bank','equity_price','equity_stake'] and v is not None}
   for source,target in [('delay','commercial_delay'),('overrun','cost_overrun'),('rate','rate_custom')]:
    if source in item:par[target]=item[source]
   if 'fee_kind' in item:par['fee_mode']={'target':'Objetivo KK','offer':'Proposta simulada','limit':'Limites propostos','custom':'Personalizado'}[item['fee_kind']]
   flowcheck(f'CalcF{j:02}',e.run(e.config(**par)))
 w.close();errors=native['errors'] if native else []
 if native is None:
  with zipfile.ZipFile(path) as z:
   for it in z.infolist():
    if it.filename.startswith('xl/worksheets/') and it.filename.endswith('.xml'):
     errors.extend([it.filename,m[0][:150]] for m in re.finditer(r'<(?:\w+:)?c\b[^>]*\bt="e"[^>]*>.*?</(?:\w+:)?c>',z.read(it.filename).decode(),re.S))
 return dict(ok=not fails and not errors,comparisons=count,failures=fails[:50],failure_count=len(fails),errors=errors[:20],error_count=len(errors),metrics={k:v for k,v in mm.items() if k not in ['block_cf','new_cf']})
def worker(case):
 name,par,changes=case;d=ROOT/'validacao'/name;d.mkdir(exist_ok=True);(d/'out').mkdir(exist_ok=True);shutil.rmtree(d/'profile',ignore_errors=True);(d/'profile/user').mkdir(parents=True)
 (d/'profile/user/registrymodifications.xcu').write_text('<?xml version="1.0"?><oor:items xmlns:oor="http://openoffice.org/2001/registry"><item oor:path="/org.openoffice.Office.Calc/Formula/Load"><prop oor:name="OOXMLRecalcMode" oor:op="fuse"><value>0</value></prop></item><item oor:path="/org.openoffice.Office.Calc/Formula/Calculation"><prop oor:name="UseThreadedCalculationForFormulaGroups" oor:op="fuse"><value>false</value></prop><prop oor:name="UseOpenCL" oor:op="fuse"><value>false</value></prop></item></oor:items>')
 canonical_hash=hashlib.sha256(OUTPUT.read_bytes()).hexdigest();src=d/(name+'.xlsx');mutate(src,changes);input_hash=hashlib.sha256(src.read_bytes()).hexdigest();out=d/'out'/src.name
 if out.exists():out.unlink()
 start=time.time();proc=subprocess.run(['soffice','-env:UserInstallation='+str((d/'profile').as_uri()),'--headless','--convert-to','xlsx','--outdir',str(d/'out'),str(src)],capture_output=True,text=True,timeout=1200)
 (d/'Recalculo.log').write_text(proc.stdout+proc.stderr)
 result=check(out,par,risks=name=='Base') if out.exists() else dict(ok=False,errors=[proc.stdout+proc.stderr])
 if out.exists() and name in ['PT_EN','Filtro_ID201']:
  front=openpyxl.load_workbook(out,read_only=True,data_only=True)
  if name=='PT_EN':ui_ok=front['EXEC V05']['D1'].value=='Executive Overview' and front['DASH 02']['D1'].value=='Tax, Incentives & Insurance'
  else:ui_ok=abs(front['DASH 04A V05']['H54'].value-552000)<.01
  front.close();result['interface_check']=ui_ok;result['ok']=result['ok'] and ui_ok
 result.update(case=name,seconds=round(time.time()-start,2),params=par,canonical_input_sha256=canonical_hash,input_sha256=input_hash);(d/'Resultado.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(name,result['ok'],result.get('failure_count'),result.get('error_count'),result.get('failures',[])[:2],flush=True)
 return result
if __name__=='__main__':
 selected=set(sys.argv[1:]);cases=[c for c in CASES if not selected or c[0] in selected]
 with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:results=list(pool.map(worker,cases))
 (ROOT/'entrega'/('Testes_'+('_'.join(selected) if selected else 'Completos')+'.json')).write_text(json.dumps(results,ensure_ascii=False,indent=2))
 raise SystemExit(not all(r['ok'] for r in results))
