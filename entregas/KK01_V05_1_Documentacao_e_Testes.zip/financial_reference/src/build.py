from common import *
from financial import ledger
import hashlib,shutil
from openpyxl import Workbook
from openpyxl.styles import Font,PatternFill,Alignment,Border,Side
from openpyxl.comments import Comment
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.chart import BarChart,LineChart,Reference
from openpyxl.formatting.rule import CellIsRule
from openpyxl.workbook.defined_name import DefinedName
from copy import deepcopy

def main():
 ROOT.joinpath('validacao').mkdir(exist_ok=True)
 z=zipfile.ZipFile(BASE);paths0=paths(z);flowmeta={};hotels={};residentials={}
 for fs in json.loads((ROOT/'src/phase2_mapa_motor.json').read_text())['flows']:
  fm=formulas(z.read(paths0[fs]).decode());hs=re.match(r"(?:'([^']+)'|([^!]+))!",fm['AO5']);hs=hs[1] or hs[2];rs=re.match(r"(?:'([^']+)'|([^!]+))!",fm['M5']);rs=rs[1] or rs[2]
  hf=formulas(z.read(paths0[hs]).decode());opening=re.search(r'IF\(A5<(.*?),0,INT',hf['B5'])[1]
  endexpr=re.search(r'IF\(A5<=(.*?),SUMIFS',fm['Q5'])[1]
  flowmeta[fs]={'hotel':hs,'res':rs,'opening':opening,'end':endexpr};hotels.setdefault(hs,(fs,opening));residentials[rs]=True
 (ROOT/'src/flowmeta.json').write_text(json.dumps(flowmeta,indent=2))
 wb=Workbook();wb.remove(wb.active)
 def sheet(name,headers=None):
  ws=wb.create_sheet(name);ws.sheet_view.showGridLines=False;ws.freeze_panes='B5';ws.sheet_properties.pageSetUpPr.fitToPage=True;ws.page_setup.orientation='landscape';ws.page_setup.paperSize=ws.PAPERSIZE_A3;ws.page_setup.fitToWidth=1;ws.page_setup.fitToHeight=0
  if headers:
   ws.append([name]);ws.append(['Estudo / Study · Pressupostos editáveis a azul · Sem certificação fiscal/contratual']);ws.append(['Motor principal: Fluxo 180M']);ws.append(headers)
  for c in range(1,30):ws.column_dimensions[CL(c)].width=22
  ws.column_dimensions['A'].width=48
  return ws
 def comment(c,text):c.comment=Comment(text,'KK-01 · Auditoria')
 def input(c,text):c.font=Font(color='1565C0');c.fill=PatternFill('solid',fgColor='E8F2FF');c.protection=__import__('openpyxl').styles.Protection(locked=False);comment(c,text)
 def val(ws,cell,items):
  if len(','.join(items))>240:
   lists=wb['V05 Listas'] if 'V05 Listas' in wb.sheetnames else wb.create_sheet('V05 Listas');lists.sheet_state='hidden';column=lists.max_column+1
   for j,value in enumerate(items,1):lists.cell(j,column,value)
   name='V05Lista'+str(column);wb.defined_names.add(DefinedName(name,attr_text=f"'V05 Listas'!${CL(column)}$1:${CL(column)}${len(items)}"));formula=name
  else:formula='"'+','.join(items)+'"'
  d=DataValidation(type='list',formula1=formula);d.errorTitle='Seleção inválida';d.error='Escolha um valor da lista.';d.showErrorMessage=not (ws.title in ['DASH 04A V05','DASH 04B V05'] and cell=='D52');ws.add_data_validation(d);d.add(cell)
 def numberval(ws,cell,lo,hi,integer=False):
  d=DataValidation(type='whole' if integer else 'decimal',operator='between',formula1=lo,formula2=hi);d.showErrorMessage=True;d.error='Valor fora do intervalo permitido.';ws.add_data_validation(d);d.add(cell)
 ws=sheet('V05 Parametros',['Parâmetro PT/EN','Valor / Value','Unidade','Estado / Fonte','Documento de suporte'])
 for k,label,value,unit,note in PARAMS:
  r=ROWS[k];ws.append([label,value,unit,note,None]);input(ws[f'B{r}'],note);input(ws[f'E{r}'],'Identificar documento, data e entidade; necessário para benefícios aprovados.')
  if unit.startswith('%'):ws[f'B{r}'].number_format='0.00%';numberval(ws,f'B{r}',0,1)
  elif unit=='0/1':numberval(ws,f'B{r}',0,1,True)
  elif unit in ['meses','mês','anos']:numberval(ws,f'B{r}',1,180 if unit=='mês' else 60,True)
  elif unit=='EUR':ws[f'B{r}'].number_format='#,##0.00 "€"'
  elif unit=='data':ws[f'B{r}'].number_format='dd/mm/yyyy'
 for k,opts in [('vat_mode',['Integral','Parcial','Diferido']),('convention',['Geral','Pretendida','Aprovada']),('application',['Em preparação','Submetida','Em negociação','Aprovada','Não aprovada'])]:val(ws,f'B{ROWS[k]}',opts)
 ws.column_dimensions['D'].width=88;ws.column_dimensions['E'].width=40
 effective_iti="'V05 Parametros'!$B$90"
 benefits=f'AND({P("convention")}<>"Geral",OR({P("convention")}="Pretendida",AND({P("proof")}=1,{P("application")}="Aprovada",LEN(\'V05 Parametros\'!$E${ROWS["proof"]})>0)))'
 ws['A90']='Taxa efetiva suportada KK / Effective KK transfer tax';ws['B90']=f'=IF({P("active")}=1,{P("iti")}*{P("iti_kk")}*(1-IF({benefits},{P("iti_relief")},0)),{PV("tax_transfer")})';ws['B90'].number_format='0.00%';ws['D90']='Única taxa efetiva para consumidores legados; antigo1,5% apenas com módulos novos desligados.'
 vatcap=sheet('V05 IVA Comp',['Mês','IVA liquidado KK disponível para compensação','Documento','Estado'])
 for r in range(5,185):
  vatcap.append([r-4,0,None,'Não quantificado; sem compensação automática']);input(vatcap[f'B{r}'],'Limite de IVA liquidado pela MESMA entidade KK. Zero até previsão documentada; não compensar créditos alheios.');numberval(vatcap,f'B{r}',0,1e9)
 cap=sheet('V05 Captacao',['Bloco','Categoria','Ticket EUR','Participação','Mês compromisso','Mês recebimento','Parte entrada na KK','Estado','Documento','Data prevista estudo'])
 blocks=[('P01','Platinum',1e7,.20,1),('G01','Gold',5e6,.10,2),('G02','Gold',5e6,.10,3)]+[(f'S{i:02}','Silver',1e6,.02,m) for i,m in enumerate([4,5,5,6,6],1)]
 for r,(code,cat,ticket,share,month) in enumerate(blocks,5):
  cap.append([code,cat,ticket,share,max(1,month-1),month,1,'Previsto — hipótese de estudo',None,f'={P("start_date")}+(F{r}-1)*365/12'])
  for cl in ['E','F','G','H','I']:input(cap[f'{cl}{r}'],'Plano individual de estudo revisto; não prova compromisso nem recebimento. Parte1:100% entrada KK;0:venda secundária sem caixa KK.')
  numberval(cap,f'E{r}:F{r}',1,180,True);numberval(cap,f'G{r}',0,1);cap[f'D{r}'].number_format='0.0%';cap[f'C{r}'].number_format='#,##0 "€"';cap[f'J{r}'].number_format='dd/mm/yyyy'
 cap['A15']='Total novos investidores';cap['C15']='=SUM(C5:C12)';cap['D15']='=SUM(D5:D12)';cap['F15']='Montante entra KK';cap['G15']='=SUMPRODUCT(C5:C12,G5:G12)'
 cap['A17']='JSCV';cap['C17']=0;cap['D17']=.40;cap['B17']='2 Platinum históricos';cap['A18']='JALS';cap['C18']=0;cap['D18']=.10;cap['B18']='5 Silver históricos'
 cap['A20']='G02 passa a5M noM3: hipótese individual explícita, difere da ponte anterior3M M3+2M M4.'
 deeds=sheet('V05 Escrituras',['ID / imóvel','Tipo','Preço / valor transação','Mês transmissão (fonte)','Estado','Escritura EUR','Matricial EUR','Predial EUR','Parte KK','Outros EUR','Custo KK','Custo comprador','ITI informativo comprador','Base IPI proxy'])
 for i in range(94):
  r=i+5;deeds.append([f'=Unidades!A{r}',f'=Unidades!B{r}',f'=Unidades!H{r}',f'=Unidades!Z{r}','Prevista — não validada',f'={P("deed_cve")}/{P("fx")}',f'={P("certificate_cve")}/{P("fx")}',f'={P("registry_cve")}/{P("fx")}',0,0,f'=(SUM(F{r}:H{r})+J{r})*I{r}',f'=(SUM(F{r}:H{r})+J{r})*(1-I{r})',f'=C{r}*{P("iti")}*(1-{P("iti_kk")})',f'=C{r}*{P("unsold_tax_factor")}'])
  for cc in ['I','J','E']:input(deeds[f'{cc}{r}'],'Encargos por fração: responsabilidades de estudo; transmissão usa calendário único Unidades e cenários, não dados efetivos.')
  numberval(deeds,f'I{r}',0,1)
 for r,label in enumerate(['Hotel','MICE','Restaurante exterior'],99):
  deeds.append([label,'Ato potencial',0,30,'Hipótese jurídica',f'={P("deed_cve")}/{P("fx")}',0,0,0,0,f'=(F{r}+G{r}+H{r}+J{r})*I{r}',f'=(F{r}+G{r}+H{r}+J{r})*(1-I{r})',0,0])
  for cc in ['D','I','J']:input(deeds[f'{cc}{r}'],'Ato potencial; confirmar autonomia, pagador e data. ParteKK zero até definição; PH é rubrica separada.')
 deeds.auto_filter.ref='A4:N101'
 hist=sheet('V05 Historico',['Rubrica','Referência EUR','Documento','Estado','Saída futura EUR'])
 for label,amount in [('Terreno',1e6),('Projetos',1.5e6),('Viagens e desenvolvimento',1e6),('Outros estratégicos',1e6)]:hist.append([label,amount,None,'Pendente reconciliação documental',0])
 hist.append(['Total', '=SUM(B5:B8)',None,'Histórico ≠ disponibilidade financeira','=SUM(E5:E8)'])
 construction=sheet('V05 Capitulos',['Código','Descrição','Orçamento base','Peso','EUR/m²','Contratado','Realizado','ETC estudo','EAC','Desvio','Estado','Quota Hotel','Quota MICE','Quota residencial','Quota comuns'])
 for r in range(5,35):
  construction.append([f'=Obra!A{r}',f'=Obra!B{r}',f'=Obra!D{r}',f'=IF(SUM(Obra!$D$5:$D$34)>0,C{r}/SUM(Obra!$D$5:$D$34),0)',f'=C{r}/{PV("area")}',None,None,f'=MAX(0,C{r}-N(G{r}))',f'=N(G{r})+H{r}',f'=I{r}-C{r}','Não contratado/realizado sem documento',None,None,None,None])
  for cc in ['F','G','H','L','M','N','O']:input(construction[f'{cc}{r}'],'Input de controlo documental; ETC calculado pode ser substituído por previsão. EAC de capítulos é controlo de gestão; para propagar ao motor usar override EAC central, sem duplicação.')
 construction.auto_filter.ref='A4:O34';construction['A37']='EAC documental não altera motor sem ativação central V04 EAC';construction['A38']='Usar Pressupostos: status_month / etc_override / etc_amount; as quotas não preenchidas não são custos certificados.'
 quarterly=sheet('V05 Trimestres',['Trimestre','Construção económica','Fiscalização','Contingência','CAPEX base sem IVA','IVA suportado','Pagamentos brutos obra','IVA recuperado','Crédito IVA fim','Fontes capital KK','Desembolsos banco','Custo obra acumulado','Caixa final','Dívida final'])
 for q in range(1,61):
  r=q+4;a=(q-1)*3+5;b=a+2
  quarterly.append([q,f"=SUM('Fluxo 180M'!H{a}:H{b})",f"=SUM('Fluxo 180M'!I{a}:I{b})",f"=SUM('Fluxo 180M'!J{a}:J{b})",f'=SUM(B{r}:D{r})',f"=SUM('Fluxo 180M'!{HC['vat_paid']}{a}:{HC['vat_paid']}{b})",f'=E{r}+F{r}',f"=SUM('Fluxo 180M'!{HC['vat_offset']}{a}:{HC['vat_refund']}{b})",f"='Fluxo 180M'!{HC['vat_pending']}{b}",f"=SUM('Fluxo 180M'!C{a}:C{b})",f"=SUM('Fluxo 180M'!X{a}:X{b})",f'=SUM($G$5:G{r})',f"='Fluxo 180M'!AE{b}",f"='Fluxo 180M'!AB{b}"])
 quarterly.auto_filter.ref='A4:N64'
 annual=sheet('V05 Anual',['Ano projeto','Receitas Hotel','EBITDA Hotel','CFADS consolidado','IVA pago','IVA recuperado','IRPC contabilizado','IRPC pago','Seguros incrementais','ITI KK','IPI KK','Capital KK','Draws','Juros','Serviço obrigatório','Sweep','Dividendos','Caixa final','Dívida final','IRPC por pagar','Recebimentos RE','CAPEX+custos obra','Div JSCV','Div JALS','Div novos','DSCR'])
 for y in range(1,16):
  a=(y-1)*12+5;b=a+11;r=y+4
  S=lambda cl:f"SUM('Fluxo 180M'!{cl}{a}:{cl}{b})"
  annual.append([y,'='+S('AO'),'='+S('AN'),'='+S(HC['cfads']),'='+S(HC['vat_paid']),f'={S(HC["vat_offset"])}+{S(HC["vat_refund"])}','='+S(HC['tax_accrual']),'='+S(HC['tax_paid']),f'={S(HC["construction_ins"])}+{S(HC["insurance_operating"])}','='+S('E'),f'={S(HC["property_other"])}+{S(HC["ipi_operating"])}','='+S('C'),'='+S('X'),'='+S('Y'),'='+S('AH'),'='+S('AA'),'='+S('AD'),f"='Fluxo 180M'!AE{b}",f"='Fluxo 180M'!AB{b}",f"='Fluxo 180M'!{HC['tax_liability']}{b}",'='+S('D'),'='+S(HC['construction_economic']),f"=SUM('V04 Waterfall180'!W{a}:W{b})"+('-Retornos!C11*40%' if y==15 else ''),f"=SUM('V04 Waterfall180'!X{a}:X{b})"+('-Retornos!C11*10%' if y==15 else ''),f"=SUM('V04 Waterfall180'!T{a}:T{b})"+('-Retornos!C11*50%' if y==15 else ''),f'=IF(O{r}>0,D{r}/O{r},"")'])
  opservice=f'SUMIFS(\'Fluxo 180M\'!AH{a}:AH{b},\'Fluxo 180M\'!A{a}:A{b},">="&{PV("open")})'
  opcf=f'SUMIFS(\'Fluxo 180M\'!{HC["cfads"]}{a}:{HC["cfads"]}{b},\'Fluxo 180M\'!A{a}:A{b},">="&{PV("open")})'
  annual[f'Z{r}']=f'=IF({opservice}>0,{opcf}/{opservice},"")';annual[f'Z{r}'].number_format='0.00"×"'
 # Annexes for fiscal and insurance assumptions, sources and unquantified costs.
 annex=sheet('V05 Fontes Fiscais',['Encargo','Taxa/base editável','Fonte / estado','Entidade','Incidência / pagamento','Documento'])
 for label,k,entity,base in [('IVA','vat_rate','KK titular crédito a confirmar','Construção/fiscalização; não contingência sem fatura'),('IRPC','irpc','KK','Lucro tributável anual; não EBITDA'),('ITI','iti','Comprador por hipótese; quotaKK editável','Preço proxy; valor tributável a confirmar'),('IPI','ipi','Titular por mês','Valor matricial desconhecido: proxy explícita'),('Selo financiamento','stamp_fin','KK','Na primeira utilização; taxa pendente'),('Selo seguros','stamp_ins','KK','Prémios incrementais; taxa pendente'),('Aduaneiros','customs_rate','Importador a confirmar','Sem lista/classificação: não quantificado')]:annex.append([label,f'={P(k)}','Mandato2026 — validação legal externa pendente',entity,base,None])
 annex.append(['Convenção',f'={P("convention")}','Pretendida não significa concedida','KK','Cenário aprovado exige estadoAprovada+prova1+documento em parâmetros',None]);annex.append(['Lucros legais','Proxy após retenção de estudo','Contas/deliberação/covenants pendentes','KK','Não é dividendo aprovado/pago',None])
 insurance=sheet('V05 Seguros',['Cobertura','Base','Taxa','Provisão anual/total','Incluído %','Estado'])
 for row in [ ['CAR construção',f'={PV("area")}*{PV("cost")}',.003,'=B5*C5',f'={P("construction_ins_included")}','Total30meses; rateio pelo calendárioobra'],['RC construção','=B5',.0005,'=B6*C6',f'={P("construction_ins_included")}','Total30meses'],['Patrimonial operação',f'={P("insured_basis")}',f'={P("property_ins_rate")}','=B7*C7',f'={P("operating_ins_included")}','Capital de reconstrução pendente'],['Interrupção atividade',"=SUM(Hotel!K35:K46)",f'={P("bi_rate")}','=B8*C8',f'={P("operating_ins_included")}','Primeiros12mesesop conforme abertura-base; cálculo mensal usa receita dinâmica'],['RC exploração','=B8',f'={P("liability_rate")}','=B9*C9',f'={P("operating_ins_included")}','Sem cobertura contratada'],['Complementares',f'={P("insurance_extra")}',1,'=B10*C10',f'={P("operating_ins_included")}','Verificar sobreposições'] ]:insurance.append(row)
 insurance['A12']='Total anual indicativo operação';insurance['D12']='=SUM(D7:D10)';insurance['A14']='Aplicação mensal em cada motor e teste incluído/extra; proprietário fora do OPEX KK.'
 owners=sheet('V05 Proprietarios',['ID','Preço','Parte pool','Bruto atribuído (pool já após custos)','Custos adicionais','Imposto de estudo','Líquido','Yield líquido','Limitação fiscal'])
 for r in range(5,99):owners.append([f'=Unidades!A{r}',f'=Unidades!H{r}',f'=B{r}/SUM(Unidades!$H$5:$H$98)',f'=SUM(Residencial!$M$5:$M$184)*C{r}',f'=D{r}*{P("owner_cost")}',f'=MAX(0,D{r}-E{r})*{P("owner_tax")}',f'=D{r}-E{r}-F{r}',f'=IF(B{r}>0,G{r}/B{r}/(150/12),0)','Rateio informativo por preço; zero taxa não prova isenção; não é cashflow KK'])
 owners.auto_filter.ref='A4:I98'
 # Dedicated dashboard builder populates shared KPI tables and bilingual dictionaries.
 from interface import build_interface
 build_interface(wb,sheet,input,val,comment,flowmeta)
 for ws in wb:
  if ws.title.startswith('DASH ') or ws.title=='EXEC V05':continue
  for row in ws:
   for c in row:
    c.alignment=Alignment(vertical='top',wrap_text=True)
    if c.row in [1,4]:c.font=Font(color='FFFFFF',bold=True);c.fill=PatternFill('solid',fgColor='292B30')
    elif c.data_type=='f':
     c.font=Font(color='20252B')
     if c.number_format=='General':c.number_format='#,##0.00;[Red](#,##0.00);"–"'
  ws.row_dimensions[1].height=28;ws.row_dimensions[4].height=42
  ws.sheet_properties.tabColor='A8202B'
 mini=ROOT/'validacao/Novas_Folhas.xlsx';wb.save(mini)
 # Patch inherited engines; every financing scenario receives identical new logic.
 replacements={};changes=[]
 legs=[5,6]+[7]*5+list(range(8,13))
 for sn,path in paths0.items():
  raw=z.read(path).decode();fm=formulas(raw);u={}
  for addr,formula in fm.items():
   if PV('tax_transfer') in formula:u[addr]='='+formula.replace(PV('tax_transfer'),effective_iti)
  if sn in flowmeta:
   hs=flowmeta[sn]['hotel'];rs=flowmeta[sn]['res'];opening=flowmeta[sn]['opening'];endexpr=flowmeta[sn]['end'];extra,benefits=ledger(sn,hs,rs,opening);u.update(extra)
   relief=lambda k:f'IF({benefits},{P(k)},0)'
   for r in range(5,185):
    a=lambda k,rr=r:HC[k]+str(rr);m=r-4;lo=max(5,r-11)
    gate=lambda new,old:f'=IF({P("active")}=1,{new},{old})'
    delay=re.search(r'A'+str(r)+r'-(\d+)',fm['C'+str(r)]);delay=int(delay[1]) if delay else 0
    riskmatch=re.fullmatch(r'V04 (R\d+)Fluxo',sn);pipe=f'V04 {riskmatch[1]}Pipeline' if riskmatch else 'V04 Pipeline'
    scale='1'
    if re.fullmatch(r'CalcF\d+',sn):
     prefix=fm['C'+str(r)].split('*'+PV('treasury_ratio'))[0]
     scale=f'IF(({PV("equity")}-{PV("conversion")})>0,({prefix})/({PV("equity")}-{PV("conversion")}),0)'
    u['C'+str(r)]=f'=IF({P("use_capital")}=1,SUMIF(\'{pipe}\'!$J$5:$J$16,A{r}-{delay},\'{pipe}\'!$V$5:$V$16)*({scale}),{fm["C"+str(r)]})'
    # Gross budget conversion: same cash budget, extract economic VAT base.
    for cl in ['H','I']:u[cl+str(r)]=gate(f'({fm[cl+str(r)]})/IF({P("budget_gross")}=1,1+{P("vat_rate")},1)',fm[cl+str(r)])
    prices=f"SUMIFS('{rs}'!$AC$5:$AC$98,'{rs}'!$AB$5:$AB$98,A{r},'{rs}'!$AA$5:$AA$98,\"<=\"&{PV('sales_stop')})"
    u['E'+str(r)]=gate(f'{prices}*{P("iti")}*{P("iti_kk")}*(1-{relief("iti_relief")})',fm['E'+str(r)])
    u['V'+str(r)]=gate(f'({fm["V"+str(r)]})+S{r}*{PV("limit")}*{P("stamp_fin")}*(1-{relief("stamp_relief")})',fm['V'+str(r)])
    u['R'+str(r)]=gate(f'({fm["R"+str(r)]})-{a("cash_cost")}',fm['R'+str(r)])
    # Preserve work liquidity and unpaid taxes without circularity through current interest.
    nextend=min(184,r+3);nextstart=min(184,r+1)
    future=f'MAX(0,SUM({HC["future_cost"]}{nextstart}:{HC["future_cost"]}{nextend}))' if r<184 else '0'
    u['Q'+str(r)]=gate(f'({fm["Q"+str(r)]})+{a("extra_reserve")}+IF(A{r}<={endexpr},{future},0)',fm['Q'+str(r)])
    futureall=f'MAX(0,SUM({HC["future_cost"]}{nextstart}:{HC["future_cost"]}184))' if r<184 else '0'
    u['AR'+str(r)]=gate(f'({fm["AR"+str(r)]})+IF(A{r}<{endexpr},{futureall},0)',fm['AR'+str(r)])
    u['AJ'+str(r)]=gate(f'({fm["AJ"+str(r)]})-{a("cash_cost")}+{a("tax_paid")}-{a("unlevered_paid")}',fm['AJ'+str(r)])
    u['AL'+str(r)]=gate(f'({fm["AL"+str(r)]})+{a("cash_cost")}',fm['AL'+str(r)])
    u['AI'+str(r)]=gate(f'IF(AH{r}>0,{a("cfads")}/AH{r},"")',fm['AI'+str(r)])
    u['AZ'+str(r)]=gate(a('profit_capacity'),fm['AZ'+str(r)])
    prevdist='0' if r==5 else f'BB{r-1}'
    u['BA'+str(r)]=gate(f'IF({PV("payout_basis") }="Documentado",MIN(MAX(0,N({PV("legal_dividend_cap")})-{prevdist}),MAX(0,AZ{r}-{prevdist})),MAX(0,AZ{r}-{prevdist}))',fm['BA'+str(r)])
    explicit='('+ '+'.join(f'SUM({cl}{lo}:{cl}{r})' for cl in ['W','Y','AV','AW','AY'])+')'
    generated=fm['BE'+str(r)].replace(f'SUM(AH{lo}:AH{r})',explicit)
    u['BE'+str(r)]=gate(f'({generated})-SUM({HC["cash_cost"]}{lo}:{a("cash_cost")})+SUM({HC["vat_net"]}{lo}:{a("vat_net")})',fm['BE'+str(r)])
    u['BF'+str(r)]=gate(f'MAX(0,Z{r}-AA{r}-Q{r}-AR{r}-\'V05 Controlo\'!B{r}-MAX(0,{a("tax_liability")}-{a("extra_reserve")}))',fm['BF'+str(r)])
    # Requirement is actual KK inflow target; secondary proceeds cannot finance construction.
    u['BL'+str(r)]='='+fm['BL'+str(r)].replace(f'({PV("equity")}-{PV("conversion")})*{PV("treasury_ratio")}',f'IF({P("use_capital")}=1,\'V05 Captacao\'!$G$15*{PV("treasury_ratio")},({PV("equity")}-{PV("conversion")})*{PV("treasury_ratio")})')
  if sn in hotels:
   fs,opening=hotels[sn]
   for r in range(5,185):
    u['T'+str(r)]=f'=IF({P("active")}=1,({fm["T"+str(r)]})-\'{fs}\'!{HC["insurance_operating"]}{r}-\'{fs}\'!{HC["ipi_operating"]}{r},{fm["T"+str(r)]})'
    u['Y'+str(r)]=f'=IF({P("active")}=1,0,{fm["Y"+str(r)]})'
   u['Y4']='IRPC consolidado em Fluxo180M; proxy antiga apenas modo desligado'
  if sn in residentials:
   for r in range(5,185):u['T'+str(r)]=f'=IF({P("active")}=1,0,{fm["T"+str(r)]})'
  if sn=='V04 Pipeline':
   for i,r in enumerate(range(5,17)):
    cr=legs[i]
    for cl,target in [('I','E'),('J','F')]:u[cl+str(r)]=f'=IF({P("use_capital")}=1,\'V05 Captacao\'!{target}{cr}'+(f'+{PV("capital_delay")}' if cl=='J' else '')+f',{fm[cl+str(r)]})'
    u['V'+str(r)]=f'=T{r}*{PV("treasury_ratio")}*IF({P("use_capital")}=1,\'V05 Captacao\'!G{cr},1)';u['U'+str(r)]=f'=T{r}-V{r}'
   u['A2']='V05: calendário próprio8blocos; G02 cinco parcelas simultâneas de estudo; sem compromisso presumido.'
  if re.fullmatch(r'V04 R\d+Pipeline',sn):
   for i,r in enumerate(range(5,17)):u['V'+str(r)]=f'=T{r}*{PV("treasury_ratio")}*IF({P("use_capital")}=1,\'V05 Captacao\'!G{legs[i]},1)'
  if sn=='V04 Capital180':
   for r in range(5,185):u['F'+str(r)]=f'=SUMIF(\'V04 Pipeline\'!$J$5:$J$16,A{r},\'V04 Pipeline\'!$V$5:$V$16)';u['E'+str(r)]=f'=D{r}-F{r}'
  if sn in ['V04 Politica'] or re.fullmatch(r'V04 R\d+Politica',sn):
   # Each policy's exit uses its own financing scenario.
   match=re.search(r"'([^']+)'!AB184",fm.get('B11',''));fs=match[1] if match else 'Fluxo 180M'
   if fs not in flowmeta:fs='Fluxo 180M'
   for addr in ['B11','B16']:
    if addr in fm:u[addr]=f'=MAX(0,({fm[addr]})-IF({P("active")}=1,\'{fs}\'!{HC["tax_liability"]}184,0))'
  if sn=='Retornos':
   for cc,rr in [('B',124),('C',184)]:u[cc+'11']=f'=MAX(0,({fm[cc+"11"]})-IF({P("active")}=1,\'Fluxo 180M\'!{HC["tax_liability"]}{rr},0))'
  if sn=='V04 Retornos':u['M131']=f'=MAX(0,({fm["M131"]})-IF({P("active")}=1,\'Fluxo 180M\'!{HC["tax_liability"]}124,0))'
  if sn=='Fluxos Retorno':
   # Project terminal deducts unlevered taxes accrued but not yet paid.
   unlev_due=f"'Fluxo 180M'!{HC['unlevered_tax']}184"
   u['G185']=f'=({fm["G185"]})-IF({P("active")}=1,{unlev_due}*\'V05 Config\'!$B$10,0)'
  if sn=='V05 Fluxos Blocos':
   for m in range(181):u[f'S{m+5}']=f'={P("start_date")}+{m}*365/12'
  if sn=='EXEC KK01':u['A2']='V05 Executive completo: abrir EXEC V05. Painel legado preservado para rastreabilidade.'
  if sn=='Unidades':
   for r in range(5,99):u['S'+str(r)]=f'=H{r}*{effective_iti}'
   u['S4']='ITI KK estudo; comprador separado V05 Escrituras'
  if sn.startswith('DASH ') and sn not in wb.sheetnames:u['A2']='Painel legado preservado; interface atual: EXEC V05 e nove ecrãs. Consultar estados fiscais/documentais.'
  if u:
   for addr,value in u.items():changes.append({'sheet':sn,'cell':addr,'before':fm.get(addr),'after':value,'reason':'Mandato consolidado autorizado21/10/2026'})
   raw=patch(raw,u)
   if sn in flowmeta:raw=re.sub(r'<dimension ref="[^"]+"\s*/>',f'<dimension ref="A1:{CL(71+len(HKEYS))}185"/>',raw)
   replacements[path]=raw.encode()
 (ROOT/'entrega/Registo_Alteracoes_Formulas.json').write_text(json.dumps(changes,ensure_ascii=False,separators=(',',':')))
 merge_parts(z,mini,replacements,OUTPUT)
 print('Built',OUTPUT,'changes',len(changes),'new sheets',len(wb.sheetnames),'flows',len(flowmeta),flush=True)

def merge_parts(z,mini,replacements,out):
 """Merge a presentation/annex workbook into preserved original OOXML parts."""
 mz=zipfile.ZipFile(mini);wb=E.fromstring(z.read('xl/workbook.xml'));rels=E.fromstring(z.read('xl/_rels/workbook.xml.rels'));ct=E.fromstring(z.read('[Content_Types].xml'))
 # Merge styles and remap all local references.
 sty=E.fromstring(z.read('xl/styles.xml'));mst=E.fromstring(mz.read('xl/styles.xml'));offset={}
 for group in ['fonts','fills','borders','cellStyleXfs','cellXfs','dxfs']:
  dest=sty.find(T(group));src=mst.find(T(group))
  if dest is None:dest=E.SubElement(sty,T(group),{'count':'0'})
  offset[group]=len(dest)
  if src is None:continue
  for el in src:
   el=deepcopy(el)
   if group in ['cellStyleXfs','cellXfs']:
    for a,g in [('fontId','fonts'),('fillId','fills'),('borderId','borders'),('xfId','cellStyleXfs')]:
     if a in el.attrib:el.set(a,str(int(el.attrib[a])+offset[g]))
   dest.append(el)
  dest.set('count',str(len(dest)))
 # Custom numFmt IDs must not collide with inherited formats.
 nf=sty.find(T('numFmts'))
 if nf is None:nf=E.Element(T('numFmts'),{'count':'0'});sty.insert(0,nf)
 nextnf=max([163]+[int(x.attrib['numFmtId']) for x in nf])+1;num_map={}
 mn=mst.find(T('numFmts'))
 for el in [] if mn is None else mn:
  old=el.attrib['numFmtId'];el=deepcopy(el);num_map[old]=str(nextnf);el.set('numFmtId',str(nextnf));nextnf+=1;nf.append(el)
 nf.set('count',str(len(nf)))
 for el in list(sty.find(T('cellXfs')))[offset['cellXfs']:]:
  if el.attrib.get('numFmtId') in num_map:el.set('numFmtId',num_map[el.attrib['numFmtId']])
 # Remap every mini part path into a noncolliding namespace.
 mapping={}
 skip={'[Content_Types].xml','_rels/.rels','docProps/app.xml','docProps/core.xml','xl/workbook.xml','xl/_rels/workbook.xml.rels','xl/styles.xml','xl/theme/theme1.xml'}
 for f in mz.namelist():
  if f in skip:continue
  folder,base=f.rsplit('/',1);mapping[f]=folder+'/v05_'+base
 # Relationship parts must follow their renamed source base.
 for f in list(mapping):
  if '/_rels/' in f:
   folder,base=f.split('/_rels/');source=folder+'/'+base[:-5];mapping[f]=mapping.get(source,source).rsplit('/',1)[0]+'/_rels/'+mapping.get(source,source).rsplit('/',1)[1]+'.rels'
 import posixpath
 added={}
 for f,newpath in mapping.items():
  raw=mz.read(f)
  if f.endswith('.rels'):
   tree=E.fromstring(raw);source=f.split('/_rels/')[0]+'/'+f.split('/_rels/')[1][:-5];newsource=mapping.get(source,source)
   for rel in tree:
    if rel.attrib.get('TargetMode')=='External':continue
    target=rel.attrib['Target'];absolute=target.lstrip('/') if target.startswith('/') else posixpath.normpath(posixpath.join(posixpath.dirname(source),target));targetnew=mapping.get(absolute,absolute)
    rel.set('Target',posixpath.relpath(targetnew,posixpath.dirname(newsource)))
   raw=E.tostring(tree)
  elif f.startswith('xl/worksheets/') and f.endswith('.xml'):
   raw=re.sub(rb'\bs="(\d+)"',lambda m:b's="'+str(int(m[1])+offset['cellXfs']).encode()+b'"',raw)
   raw=re.sub(rb'\bdxfId="(\d+)"',lambda m:b'dxfId="'+str(int(m[1])+offset['dxfs']).encode()+b'"',raw)
  added[newpath]=raw
 # Names and charts/notes remain entirely native Excel OOXML.
 midpaths=paths(mz);sheets=wb.find(T('sheets'));existing=set(x.attrib['name'] for x in sheets);nextid=max(int(x.attrib['sheetId']) for x in sheets)+1
 for j,(name,path) in enumerate(midpaths.items(),1):
  assert name not in existing,name
  rid='rIdV05Final'+str(j);attrs={'name':name,'sheetId':str(nextid),'state':'visible',RID:rid};sheets.append(E.Element(T('sheet'),attrs));nextid+=1
  rels.append(E.Element('{http://schemas.openxmlformats.org/package/2006/relationships}Relationship',{'Id':rid,'Type':'http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet','Target':mapping[path][3:]}))
 miniwb=E.fromstring(mz.read('xl/workbook.xml'));names=wb.find(T('definedNames'))
 if names is None:names=E.SubElement(wb,T('definedNames'))
 for name in miniwb.find(T('definedNames')) or []:
  name=deepcopy(name)
  if 'localSheetId' in name.attrib:name.set('localSheetId',str(int(name.attrib['localSheetId'])+len(paths(z))))
  names.append(name)
 # Open on the new executive; technical names unchanged.
 views=wb.find(T('bookViews'))
 if views is not None:
  for view in views:view.set('activeTab',str(list(sheets).index(next(x for x in sheets if x.attrib['name']=='EXEC V05'))))
 current_parts={x.attrib.get('PartName') for x in ct};extensions={x.attrib.get('Extension') for x in ct}
 for el in E.fromstring(mz.read('[Content_Types].xml')):
  new=deepcopy(el)
  if 'PartName' in el.attrib:
   path=el.attrib['PartName'].lstrip('/')
   if path not in mapping:continue
   new.set('PartName','/'+mapping[path])
   if new.attrib['PartName'] not in current_parts:ct.append(new)
  elif el.attrib.get('Extension') not in extensions:ct.append(new);extensions.add(el.attrib.get('Extension'))
 replacements.update({'xl/workbook.xml':E.tostring(wb),'xl/_rels/workbook.xml.rels':E.tostring(rels),'[Content_Types].xml':E.tostring(ct),'xl/styles.xml':E.tostring(sty)})
 # Remove stale calculation chain, force a real recalculation on opening.
 with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as dest:
  for it in z.infolist():dest.writestr(it,replacements.get(it.filename,z.read(it.filename)))
  for f,raw in added.items():dest.writestr(f,raw)

if __name__=='__main__':main()
