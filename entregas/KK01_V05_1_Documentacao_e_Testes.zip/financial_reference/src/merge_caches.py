"""Transfer calculated values only; never replace preserved formulas or presentation."""
from common import *
import hashlib,os
Q=ROOT/'validacao/Base/out/Base.xlsx';C='{http://schemas.openxmlformats.org/drawingml/2006/chart}'
REF=re.compile(r"(?:'((?:[^']|'')+)'|([^!]+))!\$?([A-Z]+)\$?(\d+)(?::\$?([A-Z]+)\$?(\d+))?")
def coordinates(f):
 m=REF.fullmatch(f)
 if not m:return []
 from openpyxl.utils import column_index_from_string as CI
 sn=(m[1] or m[2]).replace("''", "'");a=CI(m[3]);b=CI(m[5] or m[3]);lo=int(m[4]);hi=int(m[6] or m[4]);return [(sn,CL(cc)+str(rr)) for rr in range(lo,hi+1) for cc in range(a,b+1)]
def merge():
 before=hashlib.sha256();after=hashlib.sha256();count=0;chartlog=[]
 with zipfile.ZipFile(OUTPUT) as zi,zipfile.ZipFile(Q) as zr,zipfile.ZipFile(OUTPUT.with_suffix('.cached'),'w',zipfile.ZIP_DEFLATED,compresslevel=6) as zo:
  pi=paths(zi);pr=paths(zr);names={v:k for k,v in pi.items()};ss=[];chartrefs=set();chartvals={}
  if 'xl/sharedStrings.xml' in zr.namelist():ss=[''.join(x.itertext()) for x in E.fromstring(zr.read('xl/sharedStrings.xml'))]
  for fn in zi.namelist():
   if re.fullmatch(r'xl/charts/[^/]+\.xml',fn):
    for f in E.fromstring(zi.read(fn)).iter(C+'f'):chartrefs.update(coordinates(f.text or ''))
  for it in zi.infolist():
   if re.fullmatch(r'xl/charts/[^/]+\.xml',it.filename):continue
   raw=zi.read(it.filename)
   if it.filename in names:
    sn=names[it.filename];x=E.fromstring(zr.read(pr[sn]));cache={}
    for c in x.iter(T('c')):
     a=c.attrib['r'];typ=c.attrib.get('t','n');v=c.find(T('v'));value=v.text if v is not None else None
     if typ=='s':typ='str';value=ss[int(value)] if value is not None else ''
     elif typ=='inlineStr':typ='str';value=''.join(c.find(T('is')).itertext())
     cache[a]=(typ,value,c.find(T('f')) is not None)
     if (sn,a) in chartrefs:chartvals[(sn,a)]=(typ,value)
    def sub(m):
     nonlocal count
     full=m[0];fm=re.search(r'<(?:\w+:)?f(?:\s[^>]*)?>.*?</(?:\w+:)?f>',full,re.S)
     if not fm:return full
     prefix=m[1];a=m[2];assert a in cache,(sn,a);typ,value,isf=cache[a];assert isf and typ!='e',(sn,a,typ,value)
     before.update((sn+'!'+a+'\0'+fm[0]).encode());count+=1
     full=re.sub(r'<(?:\w+:)?v(?:\s[^>]*)?>.*?</(?:\w+:)?v>|<(?:\w+:)?v\s*/>','',full,flags=re.S);start=full[:full.index('>')];start=re.sub(r'\s+t="[^"]*"','',start);start+=' t="'+typ+'"';full=start+full[full.index('>'):];closing='</'+prefix+'c>';full=full[:-len(closing)]+'<'+prefix+'v>'+html.escape(value or '',quote=False)+'</'+prefix+'v>'+closing
     after.update((sn+'!'+a+'\0'+re.search(r'<(?:\w+:)?f(?:\s[^>]*)?>.*?</(?:\w+:)?f>',full,re.S)[0]).encode());return full
    raw=re.sub(r'<((?:\w+:)?)c\b[^>]*\br="([A-Z]+\d+)"[^>]*(?<!/)>.*?</\1c>',sub,raw.decode(),flags=re.S).encode()
   zo.writestr(it,raw)
  for fn in zi.namelist():
   if not re.fullmatch(r'xl/charts/[^/]+\.xml',fn):continue
   chart=E.fromstring(zi.read(fn))
   for ref in list(chart.iter(C+'numRef'))+list(chart.iter(C+'strRef')):
    f=ref.find(C+'f');coords=coordinates(f.text or '')
    if not coords:continue
    tag='numCache' if ref.tag==C+'numRef' else 'strCache';old=ref.find(C+tag);fmt=old.find(C+'formatCode') if old is not None else None
    if old is not None:ref.remove(old)
    cache=E.SubElement(ref,C+tag)
    if fmt is not None:cache.append(fmt)
    E.SubElement(cache,C+'ptCount',{'val':str(len(coords))});points=0
    for i,coord in enumerate(coords):
     typ,value=chartvals.get(coord,('n',None))
     if value is None or value=='' or (tag=='numCache' and typ not in ['n','b']):continue
     E.SubElement(E.SubElement(cache,C+'pt',{'idx':str(i)}),C+'v').text=value;points+=1
    chartlog.append(dict(chart=fn,reference=f.text,points=points))
   zo.writestr(fn,E.tostring(chart,xml_declaration=True,encoding='UTF-8'))
 assert before.hexdigest()==after.hexdigest()
 os.replace(OUTPUT.with_suffix('.cached'),OUTPUT)
 result=dict(ok=True,formula_caches=count,formulas_unchanged=True,formula_sha256=before.hexdigest(),source=str(Q),chart_caches=chartlog,note='Valores recalculados transferidos; fórmulas, folhas e apresentação preservadas. Não certifica Excel Desktop.')
 (ROOT/'entrega/Reconciliacao_Caches_Final.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(count,'caches,',len(chartlog),'referências de gráficos')
if __name__=='__main__':merge()
