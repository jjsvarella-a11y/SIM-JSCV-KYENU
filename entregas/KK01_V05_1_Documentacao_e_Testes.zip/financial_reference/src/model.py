"""Independent sequential Python extension of the preserved V04 monthly engine.
Fiscal balances are calculated numerically, without evaluating spreadsheet formulas.
"""
from common import PARAMS,ROOT
import phase2_engine as old
import inspect,copy,math
v4=old.v4
OLD_PIPELINE=old.pipeline
DEFAULT={k:v for k,_,v,_,_ in PARAMS}
def config(**updates):
 p=old.config(**updates);p.update(DEFAULT);p.update(updates)
 p.setdefault('primary',[1.]*8);p.setdefault('capital_months',[1,2,3,4,5,5,6,6]);p.setdefault('commit_months',[1,1,2,3,4,4,5,5]);p.setdefault('deed_kk',[0.]*94);p.setdefault('nonres_kk',[0.]*3);p.setdefault('nonres_months',[30]*3);p.setdefault('extra_deeds',[0.]*97);p.setdefault('proof_document','');p.setdefault('vat_output_capacity',[0.]*180)
 return p
def enabled(p):return p['active']==1
def benefit(p):return p['convention']=='Pretendida' or (p['convention']=='Aprovada' and p['proof']==1 and p['application']=='Aprovada' and bool(p['proof_document']))
def rel(p,k):return p[k] if benefit(p) else 0
def pipeline(p):
 plans=OLD_PIPELINE(p);legs=[0,1]+[2]*5+list(range(3,8))
 if p['use_capital']:
  for x,b in zip(plans,legs):
   x['pay_month']=p['capital_months'][b]+p['capital_delay'];x['commit_month']=p['commit_months'][b]
   x['planned_received']=x['ticket']*p['received_ratio']*p['capital_fraction']*(1 if x.get('selected',True) and x['commit_month']<=p['capital_stop'] else 0)
   if p['equity_mode']!='Combinação tickets':x['planned_received']*=max(0,p['equity']-p['conversion'])/25e6
   x['transfer']=x['planned_received']*p['treasury_ratio']*p['primary'][b]
 return plans
def investor_outlay(p,m):return sum(x['planned_received'] for x in pipeline(p) if x['pay_month']==m)
def equity_in(p,m):return sum(x['transfer'] for x in pipeline(p) if x['pay_month']==m) if p['use_capital'] else old.investor_outlay(p,m)*p['treasury_ratio']
def receipts(p):
 if not enabled(p):return v4.receipts(p)
 p=p.copy();p['tax_transfer']=p['iti']*p['iti_kk']*(1-rel(p,'iti_relief'));return v4.receipts(p)
def construction(p):
 c=v4.construction(p)
 if enabled(p) and p['budget_gross']:
  for x in c:
   for k in ['base','supervision']:x[k]/=1+p['vat_rate']
   x['total']=x['base']+x['supervision']+x['cont']
 return c
def ins_operating(p,revenue,m):
 if m<p['open']:return 0
 return (p['insured_basis']*p['property_ins_rate']/12+revenue*(p['bi_rate']+p['liability_rate'])+p['insurance_extra']/12)*(1-p['operating_ins_included'])*p['insurance_factor']*(1+p['stamp_ins']*(1-rel(p,'stamp_relief')))
def ipi_operating(p,m):return p['property_taxbase']*p['ipi']/12*(1-rel(p,'ipi_relief')) if m>=p['open'] else 0
def hotel(p):
 h=old.hotel(p)
 if enabled(p):
  for x in h:
   extra=ins_operating(p,x['revenue'],x['m'])+ipi_operating(p,x['m']);x['ebitda']-=extra;x['cf']+=x['tax']-extra;x['tax']=0
 return h
def residential(p):
 r=v4.residential(p)
 if enabled(p):
  for x in r:x['kk']+=x['tax']*p['res_include'];x['tax']=0
 return r
def prepare(p,cap,res):
 out=[];pending=0;ratio=p['vat_recovery'] if p['vat_mode']=='Parcial' else 1;lag=p['vat_deferred'] if p['vat_mode']=='Diferido' else p['vat_lag'];units=v4.effective_units(p)
 for i,c in enumerate(cap):
  m=i+1;vat=(c['base']+c['supervision'])*p['vat_rate'];recover=out[i-lag]['vat_paid']*ratio if i>=lag else 0
  offset=min(p['vat_output_capacity'][i],max(0,sum(x['vat_paid'] for x in out[:max(0,i-lag+1)])*ratio*p['vat_comp']-sum(x['vat_offset'] for x in out)))
  refund=recover*(1-p['vat_comp']);pending+=vat*ratio-offset-refund
  insurance=c['base']*p['construction_ins_rate']*(1-p['construction_ins_included'])*p['insurance_factor']*(1+p['stamp_ins']*(1-rel(p,'stamp_relief')))
  eligible=[(j,u) for j,u in enumerate(units) if u['sale']+p['commercial_delay']<=p['sales_stop'] and v4.deed_month(p,u)==m]
  remaining=sum(u['price'] for u in units if not (u['sale']+p['commercial_delay']<=p['sales_stop'] and v4.deed_month(p,u)<=m))
  deed=sum(((p['deed_cve']+p['certificate_cve']+p['registry_cve'])/p['fx']+p['extra_deeds'][j])*p['deed_kk'][j] for j,u in eligible)
  deed+=sum((p['deed_cve']/p['fx']+p['extra_deeds'][j+94])*p['nonres_kk'][j] for j in range(3) if p['nonres_months'][j]==m)
  deed+=p['ph'] if m==p['ph_month'] else 0
  ipi=((p['land_taxbase'] if m<p['open'] else 0)+remaining*p['unsold_tax_factor'])*p['ipi']/12*(1-rel(p,'ipi_relief'))
  customs=p['customs_base']*p['customs_rate']*(1-rel(p,'customs_relief')) if m==p['customs_month'] else 0
  vatnet=vat-offset-refund;future=vatnet-(vat if p['budget_gross'] else 0)+insurance+deed+customs
  out.append(dict(vat_paid=vat,vat_offset=offset,vat_refund=refund,vat_pending=pending,vat_nonrecoverable=vat*(1-ratio),vat_net=vatnet,construction_ins=insurance,deeds=deed,property_other=ipi,customs=customs,future_cost=future,prices_deeded=sum(u['price'] for j,u in eligible)))
 return out
def tax_payment(p,previous,m,key='tax_selected'):
 return previous[m-p['tax_lag']-1][key] if m>p['tax_lag'] and (m-p['tax_lag'])%12==0 else 0
def fiscal_step(p,h,res,cap,pre,previous,m,interest,fees,loaninterest,commit):
 i=m-1;x=pre[i].copy();start=i//12*12;prior=start-1
 capital=sum(c['total'] for c in cap)+sum(a['construction_ins']+a['vat_nonrecoverable'] for a in pre)
 sales=x['prices_deeded']*(1-p['res_capex_share']*capital/sum(u['price'] for u in v4.effective_units(p))-p['marketing']-p['kyenu']-p['iti']*p['iti_kk']*(1-rel(p,'iti_relief')))
 dep=p['depreciable']/p['depreciation_years']/12 if p['open']<=m<p['open']+p['depreciation_years']*12 else 0
 finance=interest+fees+loaninterest+commit;op=h[i]['ebitda']+res[i]['kk']-dep-finance;extra=x['deeds']+x['property_other']+x['customs'];ebt=sales+op-extra
 loss=max(0,previous[prior]['loss_open']-previous[prior]['ytd_ebt']) if prior>=0 else 0;uloss=max(0,previous[prior]['unlevered_loss']-previous[prior]['unlevered_ytd']) if prior>=0 else 0
 ytd=sum(a['ebt'] for a in previous[start:])+ebt;uytd=sum(a['unlevered_ebt'] for a in previous[start:])+ebt+finance;opcum=sum(a['operating_ebt'] for a in previous[start:])+op;taxable=max(0,ytd-loss);eligible=min(taxable,max(0,opcum))
 holiday=m>=p['open'] and (m-1)//12-(p['open']-1)//12<p['holiday'];effective=0 if holiday else p['reduced_rate'];saving=eligible*max(0,p['irpc']-effective) if benefit(p) else 0;general=taxable*p['irpc'];selected=max(0,general-saving);accrued=selected-(previous[-1]['tax_selected'] if i>start else 0)
 ueligible=min(max(0,uytd-uloss),max(0,opcum+sum(a['finance'] for a in previous[start:])+finance));utax=max(0,uytd-uloss)*p['irpc']-(ueligible*max(0,p['irpc']-effective) if benefit(p) else 0)
 paid=tax_payment(p,previous,m);upaid=tax_payment(p,previous,m,'unlevered_tax');liability=(previous[-1]['tax_liability'] if previous else 0)+accrued-paid
 profit=(previous[-1]['profit_cum'] if previous else 0)+ebt-accrued
 x.update(sales_profit=sales,operating_ebt=op,other_expense=extra,ebt=ebt,ytd_ebt=ytd,loss_open=loss,taxable=taxable,eligible=eligible,tax_general=general,tax_selected=selected,tax_accrual=accrued,tax_paid=paid,tax_liability=liability,profit_cum=profit,profit_capacity=max(0,profit*(1-p['legal_reserve'])),cfads=h[i]['cf']+res[i]['kk']-paid-x['property_other'],unlevered_ebt=ebt+finance,unlevered_ytd=uytd,unlevered_loss=uloss,unlevered_tax=utax,unlevered_paid=upaid,construction_economic=cap[i]['total']+x['construction_ins']+x['vat_nonrecoverable'],insurance_operating=ins_operating(p,h[i]['revenue'],m),ipi_operating=ipi_operating(p,m),depreciation=dep,tax_saving=saving,extra_reserve=max(0,(previous[-1]['tax_liability'] if previous else 0)-paid),finance=finance)
 x['cash_cost']=x['vat_net']+x['construction_ins']+x['deeds']+x['property_other']+x['customs']+paid
 x['unlevered_general']=max(0,uytd-uloss)*p['irpc'];x['tax_prudential']=max(0,sum(previous[j]['unlevered_general'] for j in range(11,start,12))+x['unlevered_general']-sum(a['tax_paid'] for a in previous)-paid)
 if p['fund_current_tax'] and m==p['draw_end']:x['extra_reserve']=max(x['extra_reserve'],x['tax_prudential'])
 return x
def dividend_decision(p,previous,loc):
 if not enabled(p):return old.dividend_decision(p,previous,loc)
 m=loc['m'];start=max(0,m-12);gen=sum(x['hotel_cf']+x['res_cf']-x['service']-sum(x[k] for k in ['construction','supervision','contingency','hotpay','transfer','marketing','kyenu','openingfee','broker','mobil'])-x['fiscal']['cash_cost']+x['fiscal']['vat_net'] for x in previous[start:])
 gen+=loc['h'][m-1]['cf']+loc['res'][m-1]['kk']-loc['principal']-loc['interest']-loc['loan_interest']-loc['loan_principal']-loc['commitment']-loc['cap'][m-1]['total']-loc['hotpay']-loc['re']['tax'][m-1]-loc['re']['marketing'][m-1]-loc['re']['kyenu'][m-1]-loc['fees']-loc['_fcost']+loc['_tax']['vat_net']
 free=max(0,loc['post']-loc['sweep']-loc['reserve']-loc['forward']-p['extra_reserves'].get(m,0)-max(0,loc['_tax']['tax_liability']-loc['_tax']['extra_reserve']))
 profit=max(0,loc['profits']-loc['distributed']);legal=min(profit,max(0,(p['legal_dividend_cap'] or 0)-loc['distributed'])) if p['payout_basis']=='Documentado' else profit
 independent=min(free,legal);covcap=max(0,gen)/p['coverage'];capacity=min(independent,covcap) if p['div_basis']=='Geração 12M' else independent
 objectives=[sum(n*t*r for n,t,r in zip(old.COUNTS,old.TICKETS,rates)) for rates in old.RATES];tier={'Mínimo':0,'Intermédio':1,'Máximo':2}.get(p['div_tier'],2)
 while tier>0 and capacity<objectives[tier]:tier-=1
 target=objectives[tier];goal=sum(t*a for t,a in zip([1e7,5e6,5e6]+[1e6]*5,p['primary']))*p['treasury_ratio'] if p['use_capital'] else (p['equity']-p['conversion'])*p['treasury_ratio']
 full=sum(x['transfer'] for x in pipeline(p) if x['pay_month']<=m)>=goal-.005
 eligible=m>=54 and m>=p['open']+23 and (m-54)%12==0 and loc['debt']<.005 and loc['shareloan']<.005 and loc['fundgap_ever']<.005 and full and p['div_tier']!='Suspenso'
 div=min(capacity,target) if eligible and (p['partial'] or capacity>=target) else 0;tier=2 if div>=objectives[2]-.005 else 1 if div>=objectives[1]-.005 else 0;weights=[n*t*r/objectives[tier] for n,t,r in zip(old.COUNTS,old.TICKETS,old.RATES[tier])]
 approved=min(div,max(0,p['document_caps'].get(m,0))) if p['approvals'].get(m)==1 else 0
 return div,dict(generation12=gen,free=free,independent=independent,covcapacity=covcap,capacity=capacity,target=target,tier=tier,weights=weights,coverage_ratio=gen/div if div else None,financial_dividend=div,approved_documented=approved,actual_documented=p['actual_payments'].get(m),eligible=eligible)

# Reuse the original run body; additions are transparent named fiscal calculations.
src=inspect.getsource(v4.run)
src=src.replace(' for m in range(1,181):',' _budgetcap=v4.construction(p);_pre=prepare(p,cap,res);_history=[]\n for m in range(1,181):',1)
src=src.replace("equity=investor_outlay(p,m)*p['treasury_ratio']","equity=equity_in(p,m)").replace("cap_paid+=cap[i]['total']","cap_paid+=_budgetcap[i]['total']")
src=src.replace("buffer=sum(x['total'] for x in cap[","buffer=sum(x['total'] for x in _budgetcap[")
src=src.replace('  commitment=max(',"  _paid=tax_payment(p,_history,m) if enabled(p) else 0\n  _reserve=max(0,(_history[-1]['tax_liability'] if _history else 0)-_paid) if enabled(p) else 0\n  _future=max(0,sum(x['future_cost'] for x in _pre[m:m+3])) if enabled(p) and m<=p['end'] else 0\n  reserve+=_reserve+_future\n  _fcost=sum(_pre[i][k] for k in ['vat_net','construction_ins','deeds','property_other','customs'])+_paid if enabled(p) else 0\n  commitment=max(")
src=src.replace('  reserve+=_reserve+_future',"  if enabled(p) and p['fund_current_tax'] and m==p['draw_end']:_reserve=max(_reserve,fiscal_step(p,h,res,cap,_pre,_history,m,0,0,0,0)['tax_prudential'])\n  reserve+=_reserve+_future")
src=src.replace("-loan_principal-commitment\n","-loan_principal-commitment-_fcost\n",1)
src=src.replace("mobil=trigger*p['limit']*p['mobil']","mobil=trigger*p['limit']*(p['mobil']+(p['stamp_fin']*(1-rel(p,'stamp_relief')) if enabled(p) else 0))")
src=src.replace("futurecap=sum(x['total'] for x in cap[m:])","futurecap=sum(x['total'] for x in _budgetcap[m:])")
src=src.replace('  sweepcap=max(',"  if enabled(p) and m<p['end']:forward+=max(0,sum(x['future_cost'] for x in _pre[m:]))\n  sweepcap=max(")
src=src.replace('  ceiling=max(',"  _tax=fiscal_step(p,h,res,cap,_pre,_history,m,interest,fees,loan_interest,commitment)\n  _history.append(_tax)\n  if enabled(p):profits=_tax['profit_capacity']\n  ceiling=max(")
line="  dividend=min(ceiling,max(0,post-sweep-reserve)*p['payout']) if m>=p['open'] and m%int(p['dividend_frequency'])==0 and debt<.005 and shareloan<.005 and fundgap_ever<.005 else 0"
assert line in src;src=src.replace(line,line+"\n  dividend,_dm=dividend_decision(p,out,locals())")
src=src.replace("cap[i]['total'],hotpay])","cap[i]['total'],hotpay])-_fcost+(_tax['tax_paid']-_tax['unlevered_paid'] if enabled(p) else 0)")
src=src.replace('loan_principal,commitment]),debt_check','loan_principal,commitment,_fcost]),debt_check')
src=src.replace("dscr=h[i]['cf']/service if service>0 else None","dscr=(_tax['cfads'] if enabled(p) else h[i]['cf'])/service if service>0 else None")
src=src.replace(' return dict(p=p,re=re,cap=cap,hotel=h,res=res,flow=out)',"  out[-1]['div_metrics']=_dm;out[-1]['fiscal']=_tax\n return dict(p=p,re=re,cap=cap,hotel=h,res=res,flow=out)")
ns=dict(vars(v4));ns.update(globals());exec(src,ns);run=ns['run']
def results(r):
 # Reference aggregator reused with final tax obligations explicitly deducted.
 p=r['p'].copy();end=r['flow'][-1];liability=end['fiscal']['tax_liability'] if enabled(p) else 0
 p['extra_reserves']=p['extra_reserves'].copy();p['extra_reserves'][180]=p['extra_reserves'].get(180,0)+liability
 rr=r.copy();rr['p']=p
 import types
 aggregator=types.FunctionType(old.results.__code__,dict(old.results.__globals__,pipeline=pipeline,investor_outlay=investor_outlay))
 out=aggregator(rr)
 out.update(vat_paid=sum(x['fiscal']['vat_paid'] for x in r['flow']),vat_peak=max(x['fiscal']['vat_pending'] for x in r['flow']),irpc=sum(x['fiscal']['tax_accrual'] for x in r['flow']),irpc_paid=sum(x['fiscal']['tax_paid'] for x in r['flow']),tax_liability=liability,interest=sum(x['interest'] for x in r['flow']))
 # Project terminal uses unlevered rather than levered tax liability.
 if enabled(p):
  delta=liability-end['fiscal']['unlevered_tax'];out['project_npv_exit']+=delta*p['exit_enabled']/(1+p['discount'])**15
  pc=[0]+[x['project_cf'] for x in r['flow']];terminal=out['ev']*(1-p['exit_cost'])-end['hothold']-end['conthold']-end['fiscal']['unlevered_tax']-r['p']['extra_reserves'].get(180,0);pc[-1]+=terminal*p['exit_enabled'];out['project_irr_exit']=v4.irr(pc)
 x=r['flow'][119];eb10=sum(h['ebitda'] for h in r['hotel'][108:120]);exit10=max(0,eb10*p['exit_mult']*(1-p['exit_cost'])-x['debt']-x['shareloan']+x['cash']-x['hothold']-x['conthold']-r['p']['extra_reserves'].get(120,0)-(x['fiscal']['tax_liability'] if enabled(p) else 0))*p['exit_enabled']
 cf10=out['new_cf'][:121];cf10[-1]+=exit10*.5;paid10=sum(investor_outlay(p,m) for m in range(1,121));received10=sum(cf10)+paid10
 out.update(exit_equity10=exit10,new_irr10=v4.irr(cf10),new_moic10=received10/paid10 if paid10 else None,new_npv10=sum(v/(1+p['equity_discount'])**(m/12) for m,v in enumerate(cf10)))
 return out
if __name__=='__main__':
 import json
 r=run(config());out=results(r);print(json.dumps({k:v for k,v in out.items() if k not in ['block_cf','new_cf']},indent=2))
