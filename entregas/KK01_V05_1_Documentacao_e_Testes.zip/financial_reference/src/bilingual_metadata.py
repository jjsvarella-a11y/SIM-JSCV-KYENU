"""Complete language selection for new KPI definitions, limitations and states.
No financial formula or numeric input is modified.
"""
from common import *
import hashlib,os
LIMITS={
'vgv':'Forecast sales, not signed contracts','area':'Confirm areas against approved design','capex':'Initial FF&E already included; VAT and new costs shown separately','historic':'Documentary reconciliation pending; no future cash outflow','vat':'15% study assumption; contingency only when taxable work is invoiced','vat_peak':'Nonrecoverable VAT separate; no cross-entity offsets','irpc':'Project-year fiscal calendar and tax bases are study assumptions','irpc_paid':'Forecast cash payment, not evidence of payment','insurance':'Budget provisions, not insurer quotations','tax_saving':'Potential only; other savings follow their own taxable bases','cash30':'Cash balance is not automatically distributable','cash42':'Protected reserves apply','cash54':'Forecast, without evidence of receipt or payment','div54':'Not a legally approved dividend','reserve54':'Includes study reserves and assessed tax obligations','peak':'Different from cumulative drawdowns','used':'Nonrevolving facility','gap':'Reserves can be insufficient even with positive cash','fundgap':'No fictitious funding is inserted','ebitda15':'Project year15, not15 full operating years','ev':'Estimated value, not a contracted sale price','equity':'Cash counted once; sale terms are assumptions','irr':'Study timing; undefined if there is no unique root','moic':'Includes hypothetical terminal sale','npv':'Editable equity discount rate','dividends':'Targets are not guaranteed; legal approval is separate','capital':'Not evidence of actual capital received','price_m2':'Total unit area includes balconies as inventoried','owners':'No guaranteed rental return','owner_short':'Not a guarantee or an accrued debt','re_net':'Before construction costs and other transaction charges','re_margin':'Area-based allocation is not a certified cost budget','dscr':'Voluntary sweep excluded; no debt service means not applicable','ltv':'Hypothetical valuation, not a confirmed loan covenant','net_debt':'Prudential measure: protected cash and tax liabilities excluded','headroom':'A negative value indicates liquidity risk','interest':'Bank fees are reported separately','project_irr':'Incremental future model; historical costs excluded; estimated sale','project_npv':'Editable project discount rate10%; historical costs excluded','payback':'Not investor payback; historical costs excluded'}
def math_hash(z):
 h=hashlib.sha256()
 for sn,path in paths(z).items():
  if sn in ['DIC_TRANSLATIONS','CONFIG_LANGUAGE']:continue
  for a,f in formulas(z.read(path).decode()).items():
   if sn=='V05 KPI' and re.match(r'[EGHI]\d+$',a):continue
   h.update((sn+'!'+a+'\0'+f).encode())
 return h.hexdigest()
def main():
 with zipfile.ZipFile(OUTPUT) as z:
  before=math_hash(z);ps=paths(z);dic=E.fromstring(z.read(ps['DIC_TRANSLATIONS']));kp=E.fromstring(z.read(ps['V05 KPI']));data=dic.find(T('sheetData'));number=max(int(row.attrib['r']) for row in data);updates={};entries=[]
  def value(c):
   if c is None:return ''
   el=c.find(T('is'))
   return ''.join(el.itertext()) if el is not None else c.findtext(T('v'),'')
  def add(key,pt,en):
   nonlocal number
   number+=1;row=E.SubElement(data,T('row'),{'r':str(number)});entries.append([key,pt,en])
   for col,val in [('A',key),('B',pt),('C',en),('D',f'=IF(CONFIG_LANGUAGE!$B$5="PT",B{number},C{number})')]:
    cell=E.fromstring(subtype(col+str(number),val))
    for node in cell.iter():node.tag=T(node.tag)
    row.append(cell)
   return f"='DIC_TRANSLATIONS'!D{number}"
  state=add('KPI_STATE','Simulação; validação externa pendente','Simulation; external validation pending')
  for row in kp.find(T('sheetData')):
   r=int(row.attrib['r']);cells={re.match('[A-Z]+',c.attrib['r'])[0]:c for c in row};key=value(cells.get('A'))
   if key not in LIMITS:continue
   definition=value(cells.get('G'));pt,sep,en=definition.partition(' / ');en=en if sep else {'ev':'Hotel + MICE valuation; excludes sold apartments','equity':'Enterprise value less debt, costs and tax liabilities, plus eligible cash once','re_net':'Real estate receipts less KK transfer tax, marketing and Kyenu sales commission'}.get(key,pt)
   updates['G'+str(r)]=add('DEF_'+key,pt,en);updates['H'+str(r)]=add('LIMIT_'+key,value(cells.get('H')),LIMITS[key]);updates['I'+str(r)]=state
   if value(cells.get('E'))=='meses':updates['E'+str(r)]=add('UNIT_MONTHS','meses','months')
  dim=dic.find(T('dimension'))
  if dim is not None:dim.set('ref','A1:D'+str(number))
  display={}
  def selected(source,translations):
   result=source
   for pt,en in reversed(list(translations.items())):result=f'IF({source}="{pt}","{en}",{result})'
   return f'=IF($B$5="PT",{source},{result})'
  display['B6']=selected(PV('hotel'),{'Favorável':'Favourable','Conservador':'Conservative','Base':'Base'})
  display['B7']=selected(PV('bank'),{'Abertura':'Opening','Objetivo':'Target','Limite aceitável':'Acceptable limit','Personalizado':'Custom'})
  display['B8']=selected("'V05 Config'!B6",{'Mínimo':'Minimum','Intermédio':'Intermediate','Máximo':'Maximum','Automático':'Automatic','Suspenso':'Suspended'})
  display['B9']=selected(P('convention'),{'Geral':'General','Pretendida':'Proposed','Aprovada':'Approved'})
  for r,pt,en in [(6,'Cenário Hotel','Hotel scenario'),(7,'Cenário banco','Bank scenario'),(8,'Política dividendos','Dividend policy'),(9,'Convenção','Convention'),(10,'Moeda','Currency'),(11,'Versão','Version')]:display['A'+str(r)]=add('CONFIG_LABEL'+str(r),pt,en)
  if dim is not None:dim.set('ref','A1:D'+str(number))
  changed={ps['DIC_TRANSLATIONS']:E.tostring(dic),ps['V05 KPI']:patch(z.read(ps['V05 KPI']).decode(),updates).encode(),ps['CONFIG_LANGUAGE']:patch(z.read(ps['CONFIG_LANGUAGE']).decode(),display).encode()}
  with zipfile.ZipFile(OUTPUT.with_suffix('.bilingual'),'w',zipfile.ZIP_DEFLATED,compresslevel=6) as out:
   for item in z.infolist():out.writestr(item,changed.get(item.filename,z.read(item.filename)))
 with zipfile.ZipFile(OUTPUT.with_suffix('.bilingual')) as z:after=math_hash(z)
 assert before==after;os.replace(OUTPUT.with_suffix('.bilingual'),OUTPUT)
 (ROOT/'entrega/Prova_Traducao_Sem_Alteracao_Motor.json').write_text(json.dumps({'ok':True,'financial_and_auxiliary_formulas_unchanged':before==after,'engine_formula_hash':before,'changed_only':['DIC_TRANSLATIONS','V05 KPI text metadata G/H/I and textual month unit','CONFIG_LANGUAGE display labels and translated scenario names; financial inputs untouched'],'entries_added':len(entries),'note':'Recalcular e testarPT/EN antes da entrega; sem alterar definições originais do V04 Dicionario KPI.'},ensure_ascii=False,indent=2));print(len(entries),'translation entries added; engine formulas unchanged.')
if __name__=='__main__':main()
