"""Final visual formatting only. Proves all cell formulas/numeric values unchanged."""
from common import *
import hashlib,os
def fingerprint(z):
 fh=hashlib.sha256();nh=hashlib.sha256();count=0
 for sn,path in paths(z).items():
  x=E.fromstring(z.read(path))
  for c in x.iter(T('c')):
   f=c.find(T('f'));v=c.find(T('v'));a=c.attrib['r']
   if f is not None:fh.update((sn+'!'+a+'\0'+(f.text or '')).encode());count+=1
   if v is not None and c.attrib.get('t','n') in ['n','b']:nh.update((sn+'!'+a+'\0'+(v.text or '')).encode())
 return {'formulas':fh.hexdigest(),'numeric_values':nh.hexdigest(),'count':count}
def main():
 with zipfile.ZipFile(OUTPUT) as z:
  before=fingerprint(z);ps=paths(z);style=E.fromstring(z.read('xl/styles.xml'));dxfs=style.find(T('dxfs'))
  if dxfs is None:dxfs=E.SubElement(style,T('dxfs'),{'count':'0'})
  ids={}
  for key,fill,color in [('green','FFE8F5E9','FF176C3A'),('amber','FFFFF3CD','FF986400'),('red','FFFFE3DF','FFB3261E')]:
   ids[key]=len(dxfs);d=E.SubElement(dxfs,T('dxf'));font=E.SubElement(d,T('font'));E.SubElement(font,T('color'),{'rgb':color});pattern=E.SubElement(E.SubElement(d,T('fill')),T('patternFill'),{'patternType':'solid'});E.SubElement(pattern,T('fgColor'),{'rgb':fill});E.SubElement(pattern,T('bgColor'),{'indexed':'64'})
  dxfs.set('count',str(len(dxfs)));updates={'xl/styles.xml':E.tostring(style)};log=[]
  def format_sheet(name,rules):
   tree=E.fromstring(updates.get(ps[name],z.read(ps[name])));priority=max([0]+[int(c.attrib.get('priority','0')) for c in tree.iter(T('cfRule'))])
   for cell,formula,color in rules:
    priority+=1;cf=E.Element(T('conditionalFormatting'),{'sqref':cell});rule=E.SubElement(cf,T('cfRule'),{'type':'expression','dxfId':str(ids[color]),'priority':str(priority)});E.SubElement(rule,T('formula')).text=formula
    later={'dataValidations','hyperlinks','printOptions','pageMargins','pageSetup','headerFooter','drawing','legacyDrawing','legacyDrawingHF','picture','extLst'};index=next((i for i,c in enumerate(tree) if c.tag.split('}')[-1] in later),len(tree));tree.insert(index,cf);log.append([name,cell,formula,color])
   updates[ps[name]]=E.tostring(tree)
  irrs={'EXEC V05':'P8','DASH 06 V05':'L8','DASH 07 V05':'D8'}
  for name,cell in irrs.items():format_sheet(name,[(cell,f'AND(ISNUMBER({cell}),{cell}>=INDIRECT("Pressupostos!B{PR["equity_discount"]}"))','green'),(cell,f'AND(ISNUMBER({cell}),{cell}<INDIRECT("Pressupostos!B{PR["equity_discount"]}"))','red')])
  format_sheet('DASH 03 V05',[('P8','AND(ISNUMBER(P8),P8<=0.01)','green'),('D13','AND(ISNUMBER(D13),ABS(D13)<=0.01)','amber'),('D13','AND(ISNUMBER(D13),D13>0.01)','green'),('D13','AND(ISNUMBER(D13),D13< -0.01)','red'),('H13','AND(ISNUMBER(H13),H13>=0)','green'),('H13','AND(ISNUMBER(H13),H13<0)','red'),('L13',f'AND(ISNUMBER(L13),L13>=INDIRECT("Pressupostos!B{PR["discount"]}"))','green')])
  for name,cell in [('DASH 06 V05','D13'),('DASH 07 V05','L8')]:format_sheet(name,[(cell,f'AND(ISNUMBER({cell}),{cell}<0)','red'),(cell,f'AND(ISNUMBER({cell}),{cell}>=0)','green')])
  format_sheet('DASH 05 V05',[(f'H{r}',f'AND(ISNUMBER(H{r}),H{r}>0,H{r}<{limit})','green') for r,limit in [(51,.35),(52,.25),(53,.5)]])
  # Navigation glyphs are text-only, with PT/EN caches kept consistent.
  dic=E.fromstring(z.read(ps['DIC_TRANSLATIONS']));rows={int(row.attrib['r']):row for row in dic.iter(T('row'))};icons=0
  for r,row in rows.items():
   cells={re.match('[A-Z]+',c.attrib['r'])[0]:c for c in row}
   a=cells.get('A');text=''.join(a.itertext()) if a is not None else ''
   if not text.startswith('nav'):continue
   for col in ['B','C']:
    c=cells[col];t=c.find('.//'+T('t'))
    if t is not None and not (t.text or '').startswith('› '):t.text='› '+(t.text or '')
   cache=cells['D'].find(T('v'))
   if cache is not None and not (cache.text or '').startswith('› '):cache.text='› '+(cache.text or '')
   icons+=1
  updates[ps['DIC_TRANSLATIONS']]=E.tostring(dic)
  note={f'D{PR["tax_transfer"]}':'LEGADO:1,5% apenas com módulos novos desligados. No modo V05, taxa efetiva KK em V05 Parametros!B90; ITI comprador separado.',f'D{PR["tax"]}':'Proxy fiscal legada. O motor V05 calcula IRPC consolidado por lucro tributável e distingue imposto contabilizado/pago.',f'D{PR["capital_schedule"]}':'Com V05 Parametros / Usar calendário8blocos=1, usar V05 Captacao. Calendários originais ativos no modo legado0.'}
  updates[ps['Pressupostos']]=patch(z.read(ps['Pressupostos']).decode(),note).encode()
  # Protect new presentation/annex formulas while preserving explicitly unlocked blue inputs.
  # No password: maintainers can unprotect for structural edits; sorting of input structures is disabled.
  filter_ranges={'V05 Anual':'A4:Z19','V05 Blocos':'A4:M19','V05 Fontes Fiscais':'A4:F13','V05 Seguros':'A4:F10'}
  protected=[]
  for name,path in ps.items():
   if not path.startswith('xl/worksheets/v05_') and name!='V05 Blocos':continue
   tree=E.fromstring(updates.get(path,z.read(path)))
   if tree.find(T('sheetProtection')) is None:
    protection=E.Element(T('sheetProtection'),{'sheet':'1','objects':'1','scenarios':'1','sort':'1','autoFilter':'0','selectLockedCells':'0','selectUnlockedCells':'0'})
    index=next((i+1 for i,c in enumerate(tree) if c.tag==T('sheetData')),0);tree.insert(index,protection)
   if name in filter_ranges and tree.find(T('autoFilter')) is None:
    auto=E.Element(T('autoFilter'),{'ref':filter_ranges[name]});index=next((i for i,c in enumerate(tree) if c.tag.split('}')[-1] in ['mergeCells','conditionalFormatting','dataValidations','hyperlinks','pageMargins','pageSetup','drawing']),len(tree));tree.insert(index,auto)
   updates[path]=E.tostring(tree);protected.append(name)
  with zipfile.ZipFile(OUTPUT.with_suffix('.formatted'),'w',zipfile.ZIP_DEFLATED,compresslevel=6) as dest:
   for item in z.infolist():dest.writestr(item,updates.get(item.filename,z.read(item.filename)))
 with zipfile.ZipFile(OUTPUT.with_suffix('.formatted')) as z:after=fingerprint(z)
 assert before==after,(before,after)
 os.replace(OUTPUT.with_suffix('.formatted'),OUTPUT)
 result={'ok':True,'before':before,'after':after,'cell_formulas_and_numeric_values_unchanged':True,'navigation_icons':icons,'conditional_formatting':log,'protected_sheets':protected,'note':'Só formatos, ícones, filtros de detalhe, proteção sem password e notas de modo legado; sem alteração financeira. Inputs azuis mantêm desbloqueio explícito.'}
 (ROOT/'entrega/Prova_Formatacao_Sem_Alteracao_Financeira.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print('Presentation finalized:',icons,'navigation icons; all numeric values and formulas unchanged.')
if __name__=='__main__':main()
