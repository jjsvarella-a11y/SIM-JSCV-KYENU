from common import *
from openpyxl.styles import Font,PatternFill,Alignment
from openpyxl.chart import BarChart,LineChart,Reference
from openpyxl.chart.title import Title
from openpyxl.chart.text import Text
from openpyxl.chart.data_source import StrRef
from openpyxl.formatting.rule import CellIsRule
NAV=[('EXEC V05','Visão Executiva','Executive Overview'),('DASH 01 V05','Investimento e Construção','Investment & Construction'),('DASH 02','Fiscalidade, Incentivos e Seguros','Tax, Incentives & Insurance'),('DASH 03 V05','Análise Consolidada','Project Consolidated'),('DASH 04A V05','Promoção Imobiliária','Real Estate Development'),('DASH 04B V05','Residencial e Exploração','Residential Sell & Leaseback'),('DASH 05 V05','Hotel e Centro MICE','Hotel & MICE'),('DASH 06 V05','Acionistas e Blocos','Shareholder Structure & Blocks'),('DASH 07 V05','Retornos e Distribuições','Equity Returns & Waterfall')]
def build_interface(wb,sheet,input,val,comment,flowmeta):
 lang=sheet('CONFIG_LANGUAGE',['Controlo','Valor','Explicação']);lang.append(['Idioma / Language','PT','Única seleção global para os nove ecrãs.']);val(lang,'B5',['PT','EN']);input(lang['B5'],'Alterar PT/EN apenas muda a interface, nunca os resultados financeiros.')
 lang.append(['Cenário Hotel','=Pressupostos!B7','Alterar na fonte central Pressupostos']);lang.append(['Cenário banco','=Pressupostos!B6','Alterar na fonte central Pressupostos']);lang.append(['Política dividendos',"='V05 Config'!B6",'Alterar em V05Config']);lang.append(['Convenção',f'={P("convention")}','Alterar V05Parametros']);lang.append(['Moeda','EUR','Sem mistura com CVE']);lang.append(['Versão','V05 Executive','Simulação, sem aprovação contratual automática'])
 dic=sheet('DIC_TRANSLATIONS',['Text ID','Português','English','Selecionado / Selected'])
 count=4
 def tr(key,pt,en):
  nonlocal count
  count+=1;rr=count;dic.append([key,pt,en,f'=IF(CONFIG_LANGUAGE!$B$5="PT",B{rr},C{rr})']);return f"'DIC_TRANSLATIONS'!$D${rr}"
 trmap={}
 def tx(k,pt,en):
  if k not in trmap:trmap[k]=tr(k,pt,en)
  return '='+trmap[k]
 kpi=sheet('V05 KPI',['ID','Nome PT','Name EN','Valor dinâmico','Unidade','Fonte/fórmula','Definição / Definition','Limitação / Limitation','Estado'])
 items=[
 ('vgv','VGV','Gross sales value','=SUM(Unidades!H5:H98)','EUR','Unidades!H5:H98','Preço das94frações / Total94unit prices','Vendas previstas, não contratadas'),
 ('area','Área residencial','Residential area','=SUM(Unidades!D5:D98)','m²','Unidades!D5:D98','Soma áreas totais / Total unit areas','Confirmar áreas e projeto'),
 ('capex','CAPEX futuro base','Base future CAPEX',"=SUM('Fluxo 180M'!H5:J184)",'EUR','Fluxo180M!H:J','Construção+fiscalização+contingência líquidas / Net base future investment','FF&E inicial já incluído; IVA e custos novos separados'),
 ('historic','Investimento histórico','Historical investment',"='V05 Historico'!B9",'EUR','V05Historico','Custo afundado / Sunk cost','Pendente prova; não saída futura'),
 ('vat','IVA suportado','Input VAT',f"=SUM('Fluxo 180M'!{HC['vat_paid']}5:{HC['vat_paid']}184)",'EUR','Fluxo180M IVA','IVA construção/fiscalização / Construction VAT','Hipótese15%; contingência só faturada'),
 ('vat_peak','Exposição máxima IVA','Peak VAT financing exposure',f"=MAX('Fluxo 180M'!{HC['vat_pending']}5:{HC['vat_pending']}184)",'EUR','Ledger IVA','Maior crédito dedutível pendente / Peak outstanding deductible VAT','Não recuperável separado, sem compensação entre entidades'),
 ('irpc','IRPC contabilizado','Accrued corporate tax',f"=SUM('Fluxo 180M'!{HC['tax_accrual']}5:{HC['tax_accrual']}184)",'EUR','Ledger IRPC','Lucro tributável anual após prejuízos / Annual taxable profits after losses','Calendário anual de projeto e bases fiscais são hipóteses'),
 ('irpc_paid','IRPC pago previsto','Forecast corporate tax paid',f"=SUM('Fluxo 180M'!{HC['tax_paid']}5:{HC['tax_paid']}184)",'EUR','Ledger IRPC','Saída de caixa no calendário / Scheduled tax cash payment','Não é comprovativo de pagamento'),
 ('insurance','Seguros incrementais','Incremental insurance',f"=SUM('Fluxo 180M'!{HC['construction_ins']}5:{HC['construction_ins']}184)+SUM('Fluxo 180M'!{HC['insurance_operating']}5:{HC['insurance_operating']}184)",'EUR','V05 Seguros / Fluxo180M','Encargos ainda não incluídos / Costs not already included','Provisões, não cotações'),
 ('tax_saving','Poupança fiscal potencial','Potential tax savings',f"=SUM('Fluxo 180M'!{HC['tax_saving']}16,'Fluxo 180M'!{HC['tax_saving']}28,'Fluxo 180M'!{HC['tax_saving']}40,'Fluxo 180M'!{HC['tax_saving']}52,'Fluxo 180M'!{HC['tax_saving']}64,'Fluxo 180M'!{HC['tax_saving']}76,'Fluxo 180M'!{HC['tax_saving']}88,'Fluxo 180M'!{HC['tax_saving']}100,'Fluxo 180M'!{HC['tax_saving']}112,'Fluxo 180M'!{HC['tax_saving']}124,'Fluxo 180M'!{HC['tax_saving']}136,'Fluxo 180M'!{HC['tax_saving']}148,'Fluxo 180M'!{HC['tax_saving']}160,'Fluxo 180M'!{HC['tax_saving']}172,'Fluxo 180M'!{HC['tax_saving']}184)",'EUR','IRPC geral−selecionado','Diferença com mesmo lucro/base / Difference for same taxable basis','Potencial apenas; outras poupanças no ledger por base'),
 ('cash30','Caixa M30','Cash M30',"='Fluxo 180M'!AE34",'EUR','Fluxo180M!AE34','Saldo final do mês / Month end cash','Não equivalente a caixa distribuível'),
 ('cash42','Caixa M42','Cash M42',"='Fluxo 180M'!AE46",'EUR','Fluxo180M!AE46','Saldo final do mês / Month end cash','Sujeito a reservas'),
 ('cash54','Caixa M54','Cash M54',"='Fluxo 180M'!AE58",'EUR','Fluxo180M!AE58','Após dividendo de cenário / After simulated dividend','Sem prova de realização'),
 ('div54','Distribuição simulada M54','Simulated M54 distribution',"='Fluxo 180M'!AD58",'EUR','Fluxo180M!AD58','Limitada por caixa e lucro de estudo / Cash and study-profit constrained','Não dividendo legalmente aprovado'),
 ('reserve54','Reserva M54','Reserve M54',"='Fluxo 180M'!Q58",'EUR','Fluxo180M!Q58','Caixa protegida / Protected cash','Inclui reservas de estudo e impostos já apurados'),
 ('peak','Pico da dívida','Peak debt',"=MAX('Fluxo 180M'!BD5:BD184)",'EUR','Fluxo180M!BD','Antes de amortização intramês / Before monthly repayment','Não é utilização acumulada'),
 ('used','Utilização acumulada','Cumulative facility use',"='Fluxo 180M'!AC184",'EUR','Fluxo180M!AC184','Desembolsos acumulados / Cumulative drawdowns','Linha não renovável'),
 ('gap','Défice máximo de reservas','Maximum reserve shortfall',"=MAX('Fluxo 180M'!AG5:AG184)",'EUR','Fluxo180M!AG','Reserva menos caixa final se positiva / Positive reserve shortfall','Financiamento pode faltar mesmo com caixa positiva'),
 ('fundgap','Défice de financiamento','Funding shortfall',"=MAX('Fluxo 180M'!AF5:AF184)",'EUR','Fluxo180M!AF','Saldo negativo antes dividendos / Unfunded cash deficit','Não criado crédito fictício'),
 ('ebitda15','EBITDA Ano15','Year15 EBITDA','=SUM(Hotel!T173:T184)','EUR','Hotel!T173:T184','M169–180 / Project year15','Não décimo quinto ano completo de operação'),
 ('ev','Enterprise Value','Enterprise Value',"='V05 Retornos'!B18",'EUR','EBITDA15×múltiplo','Hotel+MICE; exclui apartamentos vendidos','Estimativa não preço contratual'),
 ('equity','Equity Value líquido','Net Equity Value',"='V04 Politica'!B11",'EUR','V04Politica!B11','EV−dívidas/custos+caixa elegível−impostos por pagar','Caixa uma vez; hipóteses de venda'),
 ('irr','TIR novos investidores','New investor IRR',"='V04 Retornos'!B27",'%','V04Retornos!B27','TIR mensal anualizada dos fluxos líquidos / Annualised monthly IRR','Datas de estudo; indisponível se sem raiz única'),
 ('moic','MOIC novos investidores','New investor MOIC',"='V04 Retornos'!B28",'x','V04Retornos!B28','Total recebido/capital investido / Proceeds divided by capital','Inclui saída hipotética'),
 ('npv','VPL novos investidores','New investor NPV',"='V04 Retornos'!B29",'EUR','V04Retornos!B29','Fluxos descontados pelo custo de capital / Discounted cash flows','Taxa de desconto editável'),
 ('dividends','Distribuições totais','Total distributions',"=SUM('Fluxo 180M'!AD5:AD184)",'EUR','Fluxo180M!AD','Somente ordinárias M54–174 / Ordinary distributions only','Objetivos sem garantia; aprovação separada'),
 ('capital','Capital previsto entra KK','Planned KK capital',"=SUM('Fluxo 180M'!C5:C184)",'EUR','Fluxo180M!C','Separado de venda secundária / Excludes secondary sales','Não capital recebido comprovado'),
 ('price_m2','Preço médio/m²','Average price per sqm','=SUM(Unidades!H5:H98)/SUM(Unidades!D5:D98)','EUR/m²','Unidades','Preço total/área total / Total price over total area','Área total inclui varandas conforme inventário'),
 ('owners','Rendimento proprietários','Owner distributions','=SUM(Residencial!M5:M184)','EUR','Residencial!M','Pool efetivamente suportado no cenário / Supported pool distributions','Não rendimento garantido'),
 ('owner_short','Défice yield alvo residencial','Residential target yield shortfall','=SUM(Residencial!N5:N184)','EUR','Residencial!N','Alvo menos caixa suportada / Target minus supported cash','Não garantia nem dívida'),
 ('re_net','Recebimentos RE líquidos','Net real estate receipts',"=SUM('Fluxo 180M'!D5:D184)-SUM('Fluxo 180M'!E5:G184)",'EUR','Fluxo180M!D:G','Recebimentos−ITI KK−marketing−Kyenu','Não deduz CAPEX nem outros atos'),
 ('re_margin','Margem promoção de estudo','Study development margin',f"=(SUM(Unidades!H5:H98)-SUM('Fluxo 180M'!E5:G184)-SUM('Fluxo 180M'!{HC['construction_economic']}5:{HC['construction_economic']}184)*{PV('res_capex_share')})/SUM(Unidades!H5:H98)",'%','Quota de CAPEX por área','Margem antes custos financeiros/fiscais / Before financing and corporate taxes','Quota por área não orçamento certificado'),
 ('dscr','DSCR mínimo anual','Minimum annual DSCR',"=IF(COUNT('V05 Anual'!Z5:Z19)>0,MIN('V05 Anual'!Z5:Z19),\"\")",'x','V05Anual!Z','CFADS/serviço obrigatório / CFADS divided by mandatory debt service','Sweep excluído; noDebt=indisponível'),
 ('ltv','LTV M180','LTV M180',"=IF('V05 Retornos'!B18>0,'Fluxo 180M'!AB184/'V05 Retornos'!B18,\"\")",'%','Dívida/EV','Dívida final/valor Hotel+MICE / Ending debt over EV','Valorização hipotética; não covenant avaliado'),
 ('net_debt','Dívida líquida caixa livre/EBITDA','Free-cash net debt/EBITDA',f"=IF(SUM(Hotel!T173:T184)>0,('Fluxo 180M'!AB184-MAX(0,'Fluxo 180M'!AE184-MAX('Fluxo 180M'!Q184,{PV('reserve')}+'Fluxo 180M'!AP184+'Fluxo 180M'!AQ184+'Fluxo 180M'!{HC['tax_liability']}184)-'V05 Controlo'!B184))/SUM(Hotel!T173:T184),\"\")",'x','Fluxo180M e Hotel','Dívida menos caixa após proteção / Debt minus cash after protected amounts','Métrica prudencial: reservas e impostos por pagar excluídos da caixa líquida'),
 ('headroom','Folga mínima de tesouraria','Minimum liquidity headroom',"=MIN('V05 Dados'!H5:H184)",'EUR','Caixa−reserva','Menor margem mensal após proteção / Minimum monthly cash less protected reserve','Negativo sinaliza risco'),
 ('interest','Juros bancários','Bank interest',"=SUM('Fluxo 180M'!Y5:Y184)",'EUR','Fluxo180M!Y','Sobre saldo utilizado / On drawn balance','Comissões separadas'),
 ('project_irr','TIR projeto futuro com saída','Future project IRR with exit','=KPI!B29','%','KPI!B29','Fluxos futuros sem financiamento / Unlevered future cash flows','Incremental: histórico excluído; saída estimada'),
 ('project_npv','VPL projeto futuro com saída','Future project NPV with exit','=KPI!B27','EUR','KPI!B27','Fluxos futuros descontados à taxa projeto / Discounted unlevered future cash flows','Taxa projeto10% editável; histórico excluído'),
 ('payback','Payback projeto futuro sem saída','Future project payback without exit','=KPI!B37','meses','KPI!B37','Após último saldo acumulado negativo / After last negative cumulative balance','Não é payback do investidor; histórico excluído'),
 ]
 km={}
 for i,(key,pt,en,formula,unit,source,definition,limit) in enumerate(items,5):
  kpi.append([key,pt,en,formula,unit,source,definition,limit,'Simulação; validação externa pendente']);km[key]=i
  kpi[f'D{i}'].number_format='0.00%' if unit=='%' else '0.00"×"' if unit=='x' else '#,##0.00 "€"' if unit=='EUR' else '#,##0.00'
  comment(kpi[f'D{i}'],definition+'\nFonte: '+source+'\nLimitação: '+limit)
  trmap['k_'+key]=tr('KPI_'+key,pt,en)
 kpi.auto_filter.ref=f'A4:I{kpi.max_row}'
 no_cash=tr('no_cash','Sem caixa positiva','No positive cash')
 data=sheet('V05 Dados',['Mês','Caixa','Dívida','Reserva','Dividendos','Recebimentos','Draws','Folga','IRPC pago','Crédito IVA','CFADS','Serviço obrigatório','EBITDA','Receita','Operador gestão/CF operacional','Sistemas/CF operacional','Total fees/CF operacional'])
 for r in range(5,185):
  d=HC['cfads'];data.append([r-4,f"='Fluxo 180M'!AE{r}",f"='Fluxo 180M'!AB{r}",f"='Fluxo 180M'!Q{r}",f"='Fluxo 180M'!AD{r}",f"='Fluxo 180M'!D{r}",f"='Fluxo 180M'!X{r}",f'=B{r}-D{r}',f"='Fluxo 180M'!{HC['tax_paid']}{r}",f"='Fluxo 180M'!{HC['vat_pending']}{r}",f"='Fluxo 180M'!{d}{r}",f"='Fluxo 180M'!AH{r}",f'=Hotel!T{r}',f'=Hotel!K{r}',f'=IF(K{r}>0,(Hotel!Q{r}+Hotel!S{r})/K{r},IF(SUM(Hotel!Q{r}:S{r})>0,{no_cash},""))',f'=IF(K{r}>0,Hotel!R{r}/K{r},IF(SUM(Hotel!Q{r}:S{r})>0,{no_cash},""))',f'=IF(ISNUMBER(O{r}),SUM(O{r}:P{r}),{no_cash})'])
 data.sheet_state='hidden'
 scenarios=sheet('V05 Sensibilidades',['Motor','Descrição histórica do teste','Capital KK','Caixa M30','Caixa M42','Caixa M54','Dividendos','Juros','Pico dívida','Défice reservas','EBITDA Ano15','Crédito IVA pico'])
 scenarios['A2']='Testes de capital não alteram direitos15blocos automaticamente; rótulos antigos preservados apenas como origem.'
 for j,s in enumerate(META['scenarios'],1):
  fs=f'CalcF{j:02}';r=j+4
  scenarios.append([fs,s['label'],f"=SUM('{fs}'!C5:C184)",f"='{fs}'!AE34",f"='{fs}'!AE46",f"='{fs}'!AE58",f"=SUM('{fs}'!AD5:AD184)",f"=SUM('{fs}'!Y5:Y184)",f"=MAX('{fs}'!BD5:BD184)",f"=MAX('{fs}'!AG5:AG184)",f"=SUM('{fs}'!AN173:AN184)",f"=MAX('{fs}'!{HC['vat_pending']}5:{HC['vat_pending']}184)"])
 scenarios.auto_filter.ref='A4:L52'
 commercial={}
 for target in ['DASH 04A V05','DASH 04B V05']:
  source=sheet('V05 RE '+('A' if '04A' in target else 'B'),['Mês','Sinal5%','Tranche20%','Prestações55%','Escritura20%','Recebimentos','Acumulado','Venda prevista','25% inicial'])
  masks=[f'IF(\'{target}\'!{sel}52="Todos",1,--((Unidades!${cl}$5:${cl}$98&"")=(\'{target}\'!{sel}52&"")))' for sel,cl in [('D','A'),('G','B'),('J','C'),('M','X'),('P','J')]];mask='*'.join(masks)+f'*--(Unidades!$X$5:$X$98<={PV("sales_stop")})'
  for r in range(5,185):
   m=r-4;cl=CL(m+1)
   source.append([m,f'=SUMPRODUCT(Unidades!$N$5:$N$98*--(Unidades!$X$5:$X$98=A{r})*{mask})',f'=SUMPRODUCT(Unidades!$O$5:$O$98*--(Unidades!$Y$5:$Y$98=A{r})*{mask})',f'=F{r}-SUM(B{r}:C{r})-E{r}',f'=SUMPRODUCT(Unidades!$Q$5:$Q$98*--(Unidades!$Z$5:$Z$98=A{r})*{mask})',f'=SUMPRODUCT(Recebimentos!${cl}$5:${cl}$98*{mask})',f'=SUM($F$5:F{r})',f'=SUMPRODUCT(Unidades!$H$5:$H$98*--(Unidades!$X$5:$X$98=A{r})*{mask})',f'=B{r}+C{r}'])
   if '04B' in target:
    source[f'J{r}']=f'=Residencial!M{r}*\'{target}\'!$H$54/SUM(Unidades!$H$5:$H$98)';source[f'K{r}']=f'=SUM($J$5:J{r})'
  if '04B' in target:source['J4']='Distribuição proprietário';source['K4']='Acumulado proprietário'
  commercial[target]=source;source.sheet_state='hidden'
 # Each dashboard is a linked executive report, with a shared sidebar and language cell.
 panels=[['vgv','capex','capital','irr','cash30','cash42','cash54','div54'],['capex','historic','vat','peak','price_m2','interest','used','gap'],['vat','vat_peak','irpc','tax_saving','insurance','irpc_paid','cash54','div54'],['peak','used','dscr','fundgap','headroom','project_npv','project_irr','payback'],['vgv','area','price_m2','re_margin','re_net','capital','cash30','gap'],['owners','owner_short','vgv','area','price_m2','re_net','cash54','div54'],['ebitda15','ev','dscr','insurance','irpc','interest','cash54','div54'],['capital','dividends','irr','moic','npv','equity','cash54','div54'],['irr','moic','npv','equity','dividends','div54','cash54','ev']]
 note=tx('note','Resultados simulados; não dividendos aprovados, benefícios concedidos ou pagamentos efetivos.','Simulated results; not approved dividends, granted incentives or actual payments.')
 alert=tx('fundalert','Alerta: financiamento ou reservas insuficientes','Warning: funding or reserves shortfall');covered=tx('covered','Coberto no cenário; confirmar fontes e contratos','Covered in scenario; confirm funding sources and contracts')
 for i,((sn,pt,en),keys) in enumerate(zip(NAV,panels)):
  ws=sheet(sn);ws.freeze_panes='D6';ws.print_options.horizontalCentered=True;ws.print_area='A1:T46';ws.page_setup.fitToHeight=1;ws.sheet_properties.tabColor='A8202B'
  for cc in range(1,4):ws.column_dimensions[CL(cc)].width=10
  for row in ws.iter_rows(min_row=1,max_row=46,min_col=1,max_col=3):
   for c in row:c.fill=PatternFill('solid',fgColor='292B30')
  for cc in range(4,21):ws.column_dimensions[CL(cc)].width=11
  ws.merge_cells('A1:C3');ws['A1']='JSCV\nKK-01';ws['A1'].font=Font(size=17,bold=True,color='FFFFFF');ws['A1'].fill=PatternFill('solid',fgColor='292B30');ws['A1'].alignment=Alignment(wrap_text=True,vertical='center')
  for j,(dest,lpt,len_) in enumerate(NAV,6):
   rr=(j-6)*3+6;ws.merge_cells(start_row=rr,start_column=1,end_row=rr+1,end_column=3);c=ws.cell(rr,1,tx('nav'+dest,lpt,len_));c.hyperlink=f"#'{dest}'!A1";c.font=Font(size=9,color='FFFFFF',bold=dest==sn);c.fill=PatternFill('solid',fgColor='A8202B' if dest==sn else '292B30');c.alignment=Alignment(wrap_text=True,vertical='center')
  ws.merge_cells('D1:T2');ws['D1']=tx('title'+sn,pt,en);ws['D1'].font=Font(size=23,color='292B30',bold=True)
  ws.merge_cells('D3:M3');ws['D3']=tx('subtitle','KK Hotel & Residences · Praia · 180 meses · EUR','KK Hotel & Residences · Praia · 180 months · EUR');ws['D3'].font=Font(size=11,color='777777')
  for addr,dest,label in [('N3','CONFIG_LANGUAGE','PT | EN'),('P3','Pressupostos','Cenários / Scenarios'),('S3','V05 Parametros','Inputs')]:ws[addr]=label;ws[addr].hyperlink=f"#'{dest}'!A1";ws[addr].font=Font(color='1565C0',underline='single',size=10)
  ws.merge_cells('D4:T4');ws['D4']='=CONFIG_LANGUAGE!B6&" | "&CONFIG_LANGUAGE!B7&" | "&CONFIG_LANGUAGE!B8&" | "&CONFIG_LANGUAGE!B9';ws['D4'].font=Font(size=10,color='62666E')
  for j,key in enumerate(keys):
   col=4+(j%4)*4;rr=6+(j//4)*5;start=CL(col);end=CL(col+3);ws.merge_cells(f'{start}{rr}:{end}{rr+1}');ws.merge_cells(f'{start}{rr+2}:{end}{rr+3}')
   c=ws.cell(rr,col,'='+trmap['k_'+key]);c.font=Font(size=10,color='62666E');c.alignment=Alignment(wrap_text=True,vertical='center');c.hyperlink=f"#'V05 KPI'!D{km[key]}"
   c=ws.cell(rr+2,col,f"='V05 KPI'!D{km[key]}");c.font=Font(size=22,color='292B30',bold=True);c.number_format=kpi[f'D{km[key]}'].number_format;comment(c,'Definição completa, fonte, fórmula e limitações: V05 KPI linha'+str(km[key])+'. O título abre o dicionário.');c.fill=PatternFill('solid',fgColor='F1F3F5')
   if key in ['gap','fundgap','owner_short']:ws.conditional_formatting.add(c.coordinate,CellIsRule(operator='greaterThan',formula=['0.01'],fill=PatternFill('solid',fgColor='FFE3DF'),font=Font(color='B3261E')))
  ws.merge_cells('D37:T38');ws['D37']=f'=IF(OR(\'V05 KPI\'!D{km["gap"]}>0.01,\'V05 KPI\'!D{km["fundgap"]}>0.01),{alert[1:]},{covered[1:]})';ws['D37'].font=Font(size=12,bold=True,color='A8202B');ws['D37'].alignment=Alignment(wrap_text=True)
  ws.merge_cells('D40:T41');ws['D40']=note;ws['D40'].alignment=Alignment(wrap_text=True);ws['D40'].font=Font(size=10,color='62666E')
  ws.merge_cells('D43:T44');ws['D43']=tx('footer','Fonte: motor mensal e V05 KPI · V05 Executive · 21/10/2026 · Hipóteses externas por validar','Source: monthly engine and V05 KPI · V05 Executive ·21/10/2026 · External assumptions pending validation');ws['D43'].font=Font(size=9,color='777777');ws['D43'].alignment=Alignment(wrap_text=True)
  ws['D46']=tx('sources','Fontes e definições','Sources and definitions');ws['D46'].hyperlink="#'V05 KPI'!A1";ws['I46']=tx('inputs','Pressupostos editáveis','Editable assumptions');ws['I46'].hyperlink="#'V05 Parametros'!A1";ws['O46']=tx('back','Visão executiva','Executive overview');ws['O46'].hyperlink="#'EXEC V05'!A1"
  ws.row_dimensions[2].height=25
  # Linked chart with native dynamic title from the global language dictionary.
  chart=LineChart();chart.height=10;chart.width=25
  chart.title=Title(tx=Text(strRef=StrRef(f=tr('chart'+sn,('Desembolsos trimestrais e curva S' if i==1 else 'Evolução mensal' if i!=2 else 'Fiscalidade e crédito IVA'),('Quarterly disbursement and S-curve' if i==1 else 'Monthly evolution' if i!=2 else 'Tax and VAT credit')))))
  chart.y_axis.numFmt='#,##0';chart.x_axis.title=None
  source=wb['V05 Trimestres'] if i==1 else commercial[sn] if i in [4,5] else data
  cols=[5,12] if i==1 else [9,10] if i==2 else [6,7] if i==4 else [10,11] if i==5 else [13,14] if i==6 else [5,2] if i in [7,8] else [2,3,4]
  for j,cc in enumerate(cols):
   maxrow=14 if i==1 else 34 if i==4 else 184
   chart.add_data(Reference(source,min_col=cc,max_col=cc,min_row=4,max_row=maxrow),titles_from_data=True)
   labels=[('Caixa','Cash'),('Dívida','Debt'),('Reserva','Reserve')] if len(cols)==3 else [('Desembolso','Disbursement'),('Acumulado','Cumulative')] if i==1 else [('IRPC pago','Tax paid'),('Crédito IVA','VAT credit')] if i==2 else [('Recebimentos','Receipts'),('Acumulado','Cumulative')] if i in [4,5] else [('EBITDA','EBITDA'),('Receita','Revenue')] if i==6 else [('Distribuições','Distributions'),('Caixa','Cash')]
   chart.series[-1].tx=__import__('openpyxl').chart.series.SeriesLabel(strRef=StrRef(f=tr('series'+sn+str(j),*labels[j])))
  chart.set_categories(Reference(source,min_col=1,min_row=5,max_row=maxrow));ws.add_chart(chart,'D17')
  chart.visible_cells_only=False
  # Operational details below the executive print area.
  ws['D49']=tx('detail','Detalhe e simuladores — editar apenas células azuis','Details and simulators — edit blue cells only');ws['D49'].font=Font(bold=True,size=13)
  if i==1:
   for j,(label,target) in enumerate([('Capítulos / Chapters','V05 Capitulos'),('ETC/EAC','V04 EAC'),('Trimestres / Quarters','V05 Trimestres'),('Histórico / History','V05 Historico')],51):ws[f'D{j}']=label;ws[f'D{j}'].hyperlink=f"#'{target}'!A1"
  if i==2:
   for j,(label,target) in enumerate([('IVA / Impostos / Tax','V05 Parametros'),('Seguros / Insurance','V05 Seguros'),('Escrituras / Deeds','V05 Escrituras'),('Fontes fiscais / Tax sources','V05 Fontes Fiscais')],51):ws[f'D{j}']=label;ws[f'D{j}'].hyperlink=f"#'{target}'!A1"
   ws.merge_cells('D57:T61');ws['D57']=tx('conventionnote','Convenção de Estabelecimento: incentivos pretendidos sujeitos a negociação, aprovação e formalização. Não são benefícios atualmente concedidos. IRPC3/5anos, reduções posteriores, aduaneiros, imobiliários e selo dependem de prova por benefício e entidade.','Tourism Investment Convention: proposed tax incentives remain subject to negotiation, approval and formalisation. They have not been granted.3/5year corporate tax exemptions, later reductions, customs, property and stamp benefits require evidence for each benefit and entity.');ws['D57'].alignment=Alignment(wrap_text=True,vertical='top')
  if i in [4,5]:
   for cc,pt,en,opts in [('D','ID','Unit ID',['Todos']+[str(u['id']) for u in json.loads((ROOT/'reference/src/source.json').read_text())['units']]),('G','Tipologia','Unit type',['Todos','T1','T2','T3','Penthouse']),('J','Piso','Floor',['Todos']+[str(j) for j in range(1,13)]),('M','Mês venda','Sale month',['Todos']+[str(j) for j in range(1,181)]),('P','Trimestre','Quarter',['Todos']+[str(j) for j in range(1,61)])]:
    ws[f'{cc}51']=tx('filter'+pt,pt,en);ws[f'{cc}52']='Todos';val(ws,f'{cc}52',opts if cc!='D' else ['Todos']);input(ws[f'{cc}52'],'Filtro de visualização; ID aceita entrada manual. Não altera pressupostos.');
   # SUMPRODUCT masks use text conversion for IDs/floors only; all amounts remain numeric.
   mask=[]
   for sel,cl in [('D','A'),('G','B'),('J','C'),('M','X'),('P','J')]:mask.append(f'IF({sel}52="Todos",1,--((Unidades!${cl}$5:${cl}$98&"")=({sel}52&"")))')
   filt='*'.join(mask)
   for rr,cl,pt,en in [(54,'H','VGV filtrado','Filtered gross sales'),(55,'D','Área filtrada','Filtered area'),(56,'T','Marketing filtrado','Filtered marketing'),(57,'U','Kyenu filtrado','Filtered Kyenu')]:ws[f'D{rr}']=tx('filtered'+cl,pt,en);ws[f'H{rr}']=f'=SUMPRODUCT(Unidades!${cl}$5:${cl}$98*{filt})';ws[f'H{rr}'].number_format='#,##0.00'
   ws['D59']=tx('filteredprice','Preço/m² filtrado','Filtered price/sqm');ws['H59']='=IF(H55>0,H54/H55,0)';ws['D60']=tx('filterediti','ITI informativo total filtrado','Filtered indicative transfer tax');ws['H60']=f'=H54*{P("iti")}'
   ws['D62']=tx('filterNote','Todos / All: filtros de visualização; ID manual. Dados únicos em Unidades; rendimento proprietário é rateio de estudo, não garantia.','Todos / All: display filters; manual unit ID. Single inventory in Unidades; owner income uses a study allocation, not a guarantee.');ws.merge_cells('D62:T64');ws['D62'].alignment=Alignment(wrap_text=True)
   for cc,pt,en in [('D','Mês','Month'),('G','25% inicial','Initial25%'),('J','55% prestações','55%instalments'),('M','20% escritura','20%deed'),('P','Total','Total')]:ws[f'{cc}66']=tx('re30'+cc,pt,en)
   for m in range(1,31):
    rr=m+66;sr=m+4;ss=commercial[sn].title;ws[f'D{rr}']=m
    for dest,col in [('G','I'),('J','D'),('M','E'),('P','F')]:ws[f'{dest}{rr}']=f"='{ss}'!{col}{sr}";ws[f'{dest}{rr}'].number_format='#,##0 "€"'
  if i==6:
   for rr,(pt,en,cc,limit) in enumerate([('Gestão / caixa','Management / cash','O',.35),('Sistemas / caixa','Systems / cash','P',.25),('Total fees / caixa','Total fees / cash','Q',.50)],51):
    ws[f'D{rr}']=tx('ratio'+cc,pt,en);ws[f'H{rr}']=f'=MAX(\'V05 Dados\'!{cc}5:{cc}184)';ws[f'H{rr}'].number_format='0.0%';ws[f'K{rr}']=limit;ws[f'K{rr}'].number_format='0.0%';ws.conditional_formatting.add(f'H{rr}',CellIsRule(operator='greaterThanOrEqual',formula=[str(limit)],fill=PatternFill('solid',fgColor='FFE3DF')))
   ws['D55']=tx('fees','Simulador de fees na fonte','Fee simulator at source');ws['D55'].hyperlink="#'Condicoes Operador'!A1"
   ws.merge_cells('D54:T54');ws['D54']=f'=IF(COUNTIF(\'V05 Dados\'!O5:O184,{no_cash})>0,{tr("fees_cash_alert","Alerta: fees em meses sem CFADS positivo da KK; consultar impostos e tesouraria.","Warning: fees in months without positive KK CFADS; review taxes and cash.")},{tr("fees_cash_ok","Rácios usam CFADS consolidado KK após impostos pagos, antes de dívida.","Ratios use consolidated KK CFADS after tax payments, before debt.")})';ws['D54'].font=Font(color='A8202B',size=10)
  if i in [7,8]:
   for rr,(pt,en,target) in enumerate([('Blocos e retornos','Blocks and returns','V05 Blocos'),('Calendário de captação','Capital schedule','V05 Captacao'),('Dividendos simulados/aprovados/pagos','Simulated/approved/paid dividends','V05 Dividendos')],51):ws[f'D{rr}']=tx('link'+target,pt,en);ws[f'D{rr}'].hyperlink=f"#'{target}'!A1"
   for cc,pt,en in [('D','Acionista','Shareholder'),('G','Platinum','Platinum'),('I','Gold','Gold'),('K','Silver','Silver'),('M','Participação','Ownership')]:ws[f'{cc}56']=tx('captable'+cc,pt,en)
   for rr,label,nums in [(57,'JSCV',[2,0,0,.4]),(58,'JALS',[0,0,5,.1]),(59,'Novos / New',[1,2,5,.5])]:
    ws[f'D{rr}']=label
    sourcerow=5 if label=='JSCV' else 6 if label=='JALS' else 7
    for cc,sourcecol in zip(['G','I','K'],['B','C','D']):ws[f'{cc}{rr}']=f"='Matriz Societaria V03'!{sourcecol}{sourcerow}"
    ws[f'M{rr}']=f'=(G{rr}*10000000+I{rr}*5000000+K{rr}*1000000)/50000000'
    ws[f'M{rr}'].number_format='0.0%'
   for j,(pt,en,cc) in enumerate([('Ano','Year','A'),('JSCV','JSCV','W'),('JALS','JALS','X'),('Novos','New','Y')]):ws.cell(62,4+j*3,tx('divtable'+cc,pt,en))
   for y in range(1,16):
    rr=y+62;ws[f'D{rr}']=y
    for dest,src in [('G','W'),('J','X'),('M','Y')]:ws[f'{dest}{rr}']=f"='V05 Anual'!{src}{y+4}";ws[f'{dest}{rr}'].number_format='#,##0 "€"'
  if i==6:
   ws['D58']=tx('sidebyside','Comparação simultânea de fees','Side-by-side fee comparison')
   for rr,fs,label in [(60,'CalcF37','3/3/6'),(61,'CalcF38','4/3/10')]:
    ws[f'D{rr}']=label;ws[f'G{rr}']=f"=SUM('{fs}'!AN173:AN184)";ws[f'K{rr}']=f"=SUM('{fs}'!AD5:AD184)";ws[f'O{rr}']=f"='{fs}'!AE58"
   ws['G59']=tx('e15','EBITDA Ano15','Year15 EBITDA');ws['K59']=tx('divs','Dividendos','Dividends');ws['O59']=tx('c54','Caixa M54','Cash M54')
  if i in [0,3]:
   ws['D51']=tx('sensitivity','Sensibilidades dinâmicas (48 motores)','Dynamic sensitivities (48 engines)');ws['D51'].hyperlink="#'V05 Sensibilidades'!A1"
   for rr,label,source in [(54,'M30',34),(55,'M42',46),(56,'M54',58)]:
    ws[f'D{rr}']=label;ws[f'G{rr}']=f"='Fluxo 180M'!AE{source}";ws[f'K{rr}']=f"='Fluxo 180M'!Q{source}";ws[f'O{rr}']=f'=G{rr}-K{rr}'
   ws['G53']=tx('cash','Caixa','Cash');ws['K53']=tx('res','Reserva','Reserve');ws['O53']=tx('head','Folga','Headroom')
 # Dictionary preserves old source as a linked annex; do not replace its definitions.
 kpi['A46']='Dicionário anterior preservado / Original dictionary preserved';kpi['A46'].hyperlink="#'V04 Dicionario KPI'!A1";kpi['A47']='Regressar / Return';kpi['A47'].hyperlink="#'EXEC V05'!A1"
