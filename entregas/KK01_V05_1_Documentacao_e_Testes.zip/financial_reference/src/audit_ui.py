from common import *
from validate import check
import shutil,hashlib
def main():
 root=ROOT/'validacao/NativeUI';results=[];canonical=(root/'canonical.sha256').read_text()
 for name in ['Base','PT_EN','Filtro_ID201']:
  source=root/'out'/(name+'.json');result=check(source,{});data=json.loads(source.read_text());ui=True
  if name=='PT_EN':
   ui=data['sheets']['EXEC V05'][0][3]=='Executive Overview' and 'Favourable' in data['sheets']['EXEC V05'][3][3] and data['sheets']['V05 KPI'][4][6]=='Total94unit prices' and data['sheets']['V05 KPI'][4][7]=='Forecast sales, not signed contracts'
  if name=='Base':ui='Preço' in data['sheets']['V05 KPI'][4][6]
  if name=='Filtro_ID201':ui=abs(data['sheets']['DASH 04A V05'][53][7]-552000)<.01
  result.update(case='Final_UI_'+name,interface_check=ui,canonical_input_sha256=canonical);result['ok']=result['ok'] and ui;results.append(result);print(name,result['ok'],result['failures'][:2],flush=True)
 full=check(root/'out/Base.xlsx',{},risks=True);full['case']='Final_UI_Base_Reabertura_62_Motores';results.append(full);print('Final_UI_62_motores',full['ok'],full['comparisons'],full['failures'][:3],flush=True)
 (ROOT/'entrega/Testes_Nativos_Final_UI.json').write_text(json.dumps(results,ensure_ascii=False,indent=2));assert all(r['ok'] for r in results)
 target=ROOT/'validacao/Base/out';target.mkdir(parents=True,exist_ok=True);shutil.copy2(root/'out/Base.xlsx',target/'Base.xlsx')
 summary=json.loads((ROOT/'entrega/Resumo_Testes_Nativos.json').read_text());summary['final_ui_verifications']=3;summary['comparisons']+=sum(r['comparisons'] for r in results);summary['failures']+=sum(r['failure_count'] for r in results);summary['unexpected_errors']+=sum(r['error_count'] for r in results);summary['final_ui_input_sha256']=canonical;summary['final_ui_reopening_full_auxiliary_check']=True
 (ROOT/'entrega/Resumo_Testes_Nativos.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2));print('Final bilingual interface and all engines reconciled.')
if __name__=='__main__':main()
