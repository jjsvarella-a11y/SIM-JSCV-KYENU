# KK-01 V02 — Utilização e mapa técnico

18/10/2026 | KK Hotelaria e Turismo, S.A. | V02

## Começar pelo Executive Control Center

Abrir EXEC KK01. Os12 cartões ligam ao motor; oito ícones abrem Investimento/CAPEX, Real Estate/Comercial, Financiamento/Liquidez, Hotel+MICE, Operador, Residencial, Acionistas e Riscos. Cada painel tem regresso ao início. Não são macros nem imagens estáticas dos KPI.

## Selecionar cenários

Em Pressupostos: capital0/5/10/15/20 M€, preço da ronda por40%15 ou20 M€, modo capital selecionado/combinação de tickets, parcela transferida à KK, cenário Hotel e banco. Personalizado ativa juros4,5–8%, carência e prazos. Para comparar15M/40 e20M/40 usar Comparativo15 20, sem alterar o cenário principal.

## Tickets e benefícios

Ronda Investidores mostra quantidades de tickets e montante. Platinum10M/20%, Gold5M/10%, SilverPlus2M/4%, Silver1M/2% na referência20M. Combinações não podem ultrapassar20M e40%. Selecionar Combinação tickets para que o total entre no motor; em Capital selecionado a combinação é uma proposta lateral. Blocos de benefícios da JSCV e JALS permanecem separados e dependentes de formalização.

## Equity e aquisição secundária

Saída do investidor é o preço líquido de conversão. Entrada na KK é esse preço multiplicado pela parcela de transferência. Rendimento da JALS inclui só o preço retido, não o valor transferido à sociedade. Referência assume100% à KK de forma irrevogável sem nova dívida; legal_confirmed=0 impede dar a formalização por comprovada. Não se pressupõe empréstimo sem modelar o passivo.

## Negociação Operador

Selecionar Objetivo KK, Proposta simulada, Limites propostos ou Personalizado. Campos vazios de limite significam não definidos; o cenário correspondente usa fallback ao objetivo identificado. Pressupostos centraliza valores; Condicoes Operador identifica estados e agenda. O seletor incentivo condicionado aplica limiares mensais anualizados sem circularidade; não certifica performance contratual.

## Stress comercial e obra

Desfasamento comercial desloca receitas e custos da venda sem deslocar a obra, preservando a cadência contratual na simulação. Datas originais continuam em Unidades, com colunas efetivas de cenário separadas. Sobrecusto adicional multiplica CAPEX incluindo fiscalização e contingência; não substitui a contingência10%. Os blocos CalcC/CalcR apenas transformam as fontes; CalcF reutiliza o mesmo algoritmo.

## Execução e dados reais

Execucao contém comprometido e realizado vazios, por mês. Em Pressupostos escolher mês de referência; só depois de dados documentados o painel apresenta totais realizados e por executar. Não preencher com previsões para completar gráficos. O orçamento base e estimativa à conclusão são sempre identificados como previsões.

## Mapa financeiro

Pressupostos/Cenarios → Unidades/Obra → Recebimentos/Imobiliario/CAPEX; Hotel e Residencial → Fluxo180M → Anual/KPI/Retornos/Investidores. A V02 acrescenta Ronda Investidores, Condicoes Operador, Resultados Cenarios, Vet Cenarios, Comparativo15 20, Execucao, Retorno Socios e painéis. Não elimina os módulos anteriores.

## Reprodução

Python3 com openpyxl, xlsxwriter, numpy, scipy, Pillow e reportlab. A partir da pasta v02 executar python src/engine.py e python src/build_model.py; recalcular integralmente o xlsx em LibreOffice/Excel; executar python src/test_model.py entrega/KK01_Modelo_Integrado_V02.xlsx e python src/test_selectors.py. Scripts upgrade_* documentam migração única: não repetir sobre ficheiros já migrados. Utilizar o workspace existente, sem criar worktree.

## Verificação e compatibilidade

Confirmar códigos de erro no ficheiro inteiro depois de hard recalc. As caches do gerador não validam o Excel. Valores numéricos, validações, gráficos e hiperligações nativos; sem macros. Em Excel com configuração regional portuguesa a vírgula decimal e separadores seguem a região. A aprovação externa continua necessária mesmo com regressões técnicas conformes.
