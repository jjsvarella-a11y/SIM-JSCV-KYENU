# KK-01 V02 — Auditoria da atualização

18/10/2026 | KK Hotelaria e Turismo, S.A. | V02

## Preservação e extensão

O Excel V01, o motor original, código e testes anteriores foram preservados em/workspace/kk01. A V02 é uma extensão em v02/, sem substituição do algoritmo de financiamento. O teste de regressão compara todos os180 meses da alternativa15 M€ com a fixtureV01 e verifica os hashes dos ficheiros anteriores. Não se colam resultados sobre fórmulas.

## Alterações autorizadas

Equity20 M€ e40%; alternativa15 M€ e40% preservada. Preço de ronda e montante transferido à KK separados. JSCV51% fixos, JALS49% menos ações cedidas, novos40% na referência. Tickets1–20 M€ e combinações Platinum/Gold/Silver Plus/Silver. Blocos de benefícios sem ligação económica automática.

Cenários de atraso comercial, sobrecusto e Hotel menos favorável acrescentados ao mesmo motor. Quatro modos de fees e incentivo condicionado. Dashboard inicial com12 cartões e8 ícones com hiperligações reais; os cinco dashboards antigos e filtros comerciais mantêm-se.

## Resultados executados

Testes principais V02: 29; falhas:0; erros:0; saltados:0. Mutações reais de seletores:11; conformes:11. Consultar resultados por teste, não interpretar ausência de teste como conformidade.

A V01 voltou a passar os20 testes originais antes da atualização. O recálculo da V02 deve ser integral, em perfil LibreOffice com OOXMLRecalcMode=0; confronta-se a saída com Python. Não foi executado Microsoft Excel desktop. Verificação de ficheiro inteiro: códigos de erro, macros/ligações externas, resultados mensais, cenários, KPI e navegação.

Na primeira passagem do motor externo foram detetadas caches incoerentes depois de alterar inputs: uma célula mostrava valor diferente da referência direta. O ensaio invalida agora todas as caches após mutação e força cálculo a frio. Os ensaios afetados foram repetidos e confrontados, mês a mês, sem substituir fórmulas por valores fixos. A primeira passagem está preservada no registo. O Excel final pede cálculo integral ao abrir; no Excel desktop pode usar Calcular Tudo após mudanças.

## Alertas não são defeitos de software

A formalização da entrada dos fundos, HMA, condições bancárias, fiscalidade e rights societários continuam pendentes. O yield residencial de arranque não coberto permanece visível. Cenários com défices ou reservas insuficientes não são tornados favoráveis por fontes fictícias ou valores fixos.

## Os510 erros da V45

A auditoria anterior fica preservada:510 caches de erro na V45;466 não se reproduziram no hard recalc,44 persistiram e17 outros surgiram, total61 códigos, um NA() intencional. Essa contagem não corresponde a510 causas independentes nem à quantidade de erros da V02. A nova versão volta a verificar todos os códigos de erro após recálculo.

## Rastreabilidade e limitações

Resultados Cenarios aponta a CalcH/CalcF; Vet Cenarios contém vetores de TIR/VPL. O comparativo15/20 e os painéis não substituem pressupostos por números armazenados. A saída é avaliação hipotética; a TIR promotores usa data histórica proxy. Previsto/realizado/desvio só surge como realizado após informação efetiva. Execucao fica vazia por defeito.
