# KK-01 V02 — Comparação 15 M€ / 20 M€

18/10/2026 | KK Hotelaria e Turismo, S.A. | V02

## Conclusão para o Board

Os 20 M€ reduzem o risco financeiro: o pico de dívida baixa de 25.423.784,44 € para 20.117.238,46 € e os juros baixam 848.784,86 €. A utilização acumulada da linha não renovável passa de 29.731.809,88 € para 24.423.415,74 €. O cenário selecionado pressupõe disponibilização efetiva do capital à KK, ainda sujeita a mecanismo jurídico.

Pelos mesmos 40%, os novos investidores pagam mais: a TIR estimada a15 anos desce de 8,73% para 7,06% e o MOIC desce de 3,03x para 2,39x. O VPL a12% permanece negativo (-8.307.581,96 € na referência20). Menor risco não significa maior retorno do comprador das ações.

| Indicador | 15 M€ / 40% | 20 M€ / 40% | Diferença |
|---|---|---|---|
| Preço aquisição | 15.000.000,00 € | 20.000.000,00 € | 5.000.000,00 € |
| Entrada na KK (condicional) | 15.000.000,00 € | 20.000.000,00 € | 5.000.000,00 € |
| Participação novos | 40,00% | 40,00% | 0,00 p.p. |
| Uso acumulado linha | 29.731.809,88 € | 24.423.415,74 € | -5.308.394,13 € |
| Capacidade não utilizada | 268.190,12 € | 5.576.584,26 € | 5.308.394,13 € |
| Pico de dívida | 25.423.784,44 € | 20.117.238,46 € | -5.306.545,98 € |
| Juros 180 meses | 1.858.076,72 € | 1.009.291,86 € | -848.784,86 € |
| Comissões/broker | 1.125.000,00 € | 1.125.000,00 € | 0,00 € |
| Caixa mínima construção | 3.633.802,73 € | 3.633.802,73 € | -0,00 € |
| Caixa mínima 180M | 3.000.000,00 € | 3.000.000,00 € | 0,00 € |
| Falta de reserva máxima | 0,00 € | 0,00 € | -0,00 € |
| Caixa mês 30 | 3.633.802,73 € | 3.633.802,73 € | 0,00 € |
| Reserva mês 30 | 3.633.802,73 € | 3.633.802,73 € | 0,00 € |
| Dívida início exploração | 5.771.735,94 € | 303.716,91 € | -5.468.019,03 € |
| DSCR ano 3 parcial | 1,01 | 1,82 | 0,81 |
| Dividendos totais 15A | 38.379.937,37 € | 44.227.020,93 € | 5.847.083,57 € |
| TIR investidores 15A | 8,73% | 7,06% | -1,67 p.p. |
| MOIC investidores 15A | 3,03 | 2,39 | -0,64 |
| VPL investidores (12%) | -4.686.835,26 € | -8.307.581,96 € | -3.620.746,71 € |
| Total promotores 15A | 68.157.861,91 € | 71.667.132,82 € | 3.509.270,91 € |
| MOIC promotores proxy | 15,15 | 15,93 | 0,78 |
| TIR promotores proxy | 23,83% | 26,93% | 3,10 p.p. |
| TIR investidores 10A | 8,25% | 6,02% | -2,22 p.p. |
| MOIC investidores 10A | 2,12 | 1,71 | -0,41 |

## Cobertura dos quatro primeiros trimestres

O Excel contém custos e recursos por trimestre, além da cobertura total dos quatro trimestres. Recursos do quadro são equity recebido mais cobranças, sem presumir crédito; o saldo inicial e o banco permanecem no motor mensal. Não confundir uma cobertura trimestral de fluxos inferior a1 com falta de caixa, nem cobertura superior a1 com fundos juridicamente confirmados.

## 15 M€ — cobertura de fluxos trimestrais

| Trimestre | Saídas previstas | Equity + vendas | Cobertura |
|---|---|---|---|
| 1 | 2.780.548,29 € | 17.032.938,89 € | 6,13x |
| 2 | 4.693.957,53 € | 1.174.359,24 € | 0,25x |
| 3 | 2.845.039,64 € | 2.469.440,82 € | 0,87x |
| 4 | 4.915.312,29 € | 1.978.211,83 € | 0,40x |

## 20 M€ — cobertura de fluxos trimestrais

| Trimestre | Saídas previstas | Equity + vendas | Cobertura |
|---|---|---|---|
| 1 | 2.780.548,29 € | 22.032.938,89 € | 7,92x |
| 2 | 4.693.957,53 € | 1.174.359,24 € | 0,25x |
| 3 | 2.845.039,64 € | 2.469.440,82 € | 0,87x |
| 4 | 3.779.539,50 € | 1.978.211,83 € | 0,52x |

## Sensibilidades recalculadas pelo motor existente

| Capital | Stress | Défice máximo | Falta de reserva |
|---|---|---|---|
| 15 M€ | Vendas +6 meses | 1.443.408,71 € | 7.112.012,98 € |
| 15 M€ | Obra +10% | 0,00 € | 4.440.135,98 € |
| 15 M€ | Hotel Base | 0,00 € | 0,00 € |
| 15 M€ | Hotel Conservador | 0,00 € | 0,00 € |
| 20 M€ | Vendas +6 meses | 0,00 € | 1.812.429,85 € |
| 20 M€ | Obra +10% | 0,00 € | 283.903,91 € |
| 20 M€ | Hotel Base | 0,00 € | 0,00 € |
| 20 M€ | Hotel Conservador | 0,00 € | 0,00 € |

O atraso comercial desloca cobranças, vendas e escritura em simulação pelo mesmo número de meses, mantendo os intervalos e os100% de preço; não desloca a obra nem aprova escrituras contratuais. A abertura e waterfall do pool mantêm-se no stress; efeitos de escritura tardia no leaseback carecem de validação contratual. Sobrecusto10% é adicional ao orçamento que já contém contingência10%. Os cenários Base e Conservador usam as premissas hoteleiras herdadas, não estimativas comprovadas por contrato.

## Compra de ações não é financiamento automático

Na ponte proposta, os investidores adquirem40.000 ações da JALS por20 M€; JSCV mantém51%, JALS9% e investidores40%. Uma segunda operação deve assegurar20 M€ na tesouraria da KK. O motor permite reduzir a parcela entregue à KK até0: nesse teste, o défice máximo não financiado é 5.913.096,33 €. A viabilidade não pode ser certificada só pela compra das ações.

A referência assume transferência irrevogável sem reembolso adicional. Se for suprimento ou empréstimo reembolsável, será necessário modelar a dívida e os direitos correspondentes antes de aprovação. Não se criou obrigação jurídica nem dupla entrada automática.

## Promotores e retorno de saída

A JSCV participa nos dividendos e no valor de saída em51%; a JALS em9%, acrescida apenas da parcela do preço efetivamente retida, se existir. Na referência com100% transferido à KK, essa retenção é zero. O retorno agregado dos promotores mantém a proxy histórica4,5 M€ no mês0; contribuições e datas individuais não foram fornecidas, pelo que não se inventa TIR individual de JSCV/JALS.

Saída: EBITDA Hotel dos últimos12 meses × múltiplo9x, custos de transação deduzidos, dívida deduzida e caixa somada uma vez, com reservas contingentes retidas. Apartamentos vendidos e fundos restritos não entram como ativos livres. A avaliação e a venda são estimadas, não contratualmente realizáveis.

## Alertas que permanecem

O yield residencial de arranque continua sem cobertura integral:164.946,24 € no mês31. O modelo paga só a renda suportável, sem garantia criada. DSCR é CFADS Hotel / serviço obrigatório; antecipações voluntárias estão fora. Com20 M€ a dívida pode desaparecer antes dos anos completos de operação, pelo que DSCR desses anos fica vazio, não999 nem zero. Fiscalidade, HMA, preços, calendário de vendas, escrituras504/810 e mecanismo societário permanecem por validar.
