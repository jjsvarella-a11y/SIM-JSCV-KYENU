# KK-01 V02 — Agenda de negociação do Operador Internacional

18/10/2026 | KK Hotelaria e Turismo, S.A. | V02

Nenhuma condição é contratual enquanto não houver HMA aprovado. Não existe proposta documentada na informação recebida. A coluna de proposta é uma simulação4% base +3% sistemas +10% incentivo; não é uma proposta efetiva atribuída ao Operador.

## Objetivos e limites

Objetivo KK:3% fee base,3% distribuição/marca/sistemas e6% incentivo sobre GOP após fees fixos. Limites de taxa não fornecidos ficam vazios; no modo Limites propostos o motor usa o objetivo como fallback até preencher cada limite. Esse fallback não equivale a aceite. O alerta interno total/CFADS é50%, gestão35% e sistemas25%; alertar ao atingir, não apenas ultrapassar.

| Condições simuladas | EBITDA15A | CFADS15A | TIR novos15A |
|---|---|---|---|
| Objetivo KK | 78.566.336,26 € | 46.553.922,59 € | 7,06% |
| Proposta simulada | 72.609.158,21 € | 41.788.180,16 € | 6,29% |
| Limites propostos | 78.566.336,26 € | 46.553.922,59 € | 7,06% |
| Personalizado | 78.566.336,26 € | 46.553.922,59 € | 7,06% |

Os quatro modos recalculam Hotel, financiamento, dividendos, DSCR e TIR. A seleção ativa está em Pressupostos; as comparações laterais usam os mesmos blocos de cálculo. Proposta, objetivo, limites e personalizado não são condições contratadas.

## Critérios de performance e proteção

Performance test, períodos de arranque, número de testes, limiares mínimos de GOP e EBITDA, orçamento, reporting/auditoria, distribuição/sistemas, FF&E, manutenção, rescisão e remédios ficam numa agenda editável. Não se inventam mínimos contratuais.

O seletor de incentivo condicionado usa GOP e resultado pré-incentivo anualizados para evitar circularidade. Zero nos limiares significa não definido. O teste numérico não substitui um performance test plurianual negociado; ativação é hipótese de cenário.

Exigir inventário dos encargos de marca e distribuição, separação de custos pass-through e prova de ausência de sobreposição. Definir titularidade e uso do fundo FF&E e aprovação de CAPEX extraordinário; manutenção corrente já faz parte dos custos de operação.

Os rácios do dashboard usam o mesmo CFADS anual de referência e incluem todos os fees uma única vez. O primeiro ano com fundo de maneio deve ser analisado à parte. O contrafactual sem operador permanece como hipótese, sem apresentar poupança de fees como prova de valor criado.
