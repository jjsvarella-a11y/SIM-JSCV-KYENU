# KK-01 V02 — Decisões e condições externas

18/10/2026 | KK Hotelaria e Turismo, S.A. | V02

| Decisão / condição | Estado | Consequência antes de aprovação |
|---|---|---|
| Transferência dos20 M€ à KK | Pendente | Definir instrumento, beneficiário, reembolso e fiscalidade; compra de ações não basta. |
| 40.000 ações JALS; JSCV51/JALS9/novos40 | Proposta | Formalizar transmissão, acordos, preço e condições precedentes. |
| 15 M€ /40% versus20 M€ /40% | Decisão Board | Separar preço de entrada, risco financeiro e retorno do investidor. |
| Blocos de benefícios promotores | Hipótese | Estatutos/Acordo: não atribuir ações, votos, dividendos ou garantias adicionais. |
| HMA e proposta Operador | Pendente | Objetivos e limites editáveis não são contrato; validar fees e performance. |
| Banco6%,42M,10A e fees | Pendente | Term sheet, janela, amortização e antecipação sem penalização. |
| Fiscalidade e IVA | Pendente | Impostos reais podem consumir disponibilidade de caixa e alterar rentabilidade. |
| Escrituras504/810 e calendário | Pendente | Mês29 permanece provisório; stress não aprova alteração contratual. |
| Realizado e comprometido | Indisponível | Introduzir só informação documentada; não converter previsão em execução. |
| Direito residual KK no residencial | Pendente | Validar waterfall e contratos; não garantir yield sem financiamento. |
| Valor de saída / comprador | Estimativa | Múltiplo9x não é garantia de liquidez ou de valor realizável. |
