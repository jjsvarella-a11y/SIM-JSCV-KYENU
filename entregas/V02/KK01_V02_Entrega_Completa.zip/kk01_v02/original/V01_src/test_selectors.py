"""Muta seletores reais no OOXML, força hard recalc externo e confronta com Python."""
from engine import *
from pathlib import PurePosixPath
import zipfile,xml.etree.ElementTree as ET,subprocess,openpyxl,concurrent.futures,shutil,copy,time
META=json.loads((ROOT/'src/build_metadata.json').read_text());P=ROOT/'entrega/KK01_Modelo_Integrado.xlsx';NS='http://schemas.openxmlformats.org/spreadsheetml/2006/main';REL='http://schemas.openxmlformats.org/officeDocument/2006/relationships'
CASES=[('Hotel_Conservador',dict(hotel='Conservador'),{}),('Capital_10M',dict(equity=10000000),{}),('Juro_8pct',dict(bank='Personalizado',rate_custom=.08),{}),('HOTUSA_pago',dict(hotpay=1),{}),('Filtro_ID_201',{}, {'DASH Comercial':{'B5':'201'}}),('Venda_201_M2',{}, {'Unidades':{'I5':2}})]
def mutate(dest,changes):
 with zipfile.ZipFile(P) as zi:
  w=ET.fromstring(zi.read('xl/workbook.xml'));rels=ET.fromstring(zi.read('xl/_rels/workbook.xml.rels'));paths={r.attrib['Id']:r.attrib['Target'] for r in rels}
  targets={}
  for s in w.find(f'{{{NS}}}sheets'):
   if s.attrib['name'] in changes:
    target=paths[s.attrib[f'{{{REL}}}id']];target=target.lstrip('/') if target.startswith('/') else 'xl/'+target
    targets[target]=changes[s.attrib['name']]
  with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED) as zo:
   for item in zi.infolist():
    data=zi.read(item.filename)
    if item.filename in targets:
     x=ET.fromstring(data)
     for addr,value in targets[item.filename].items():
      cell=x.find(f'.//{{{NS}}}c[@r="{addr}"]');assert cell is not None
      for child in list(cell):cell.remove(child)
      if isinstance(value,str):
       cell.set('t','inlineStr');node=ET.SubElement(cell,f'{{{NS}}}is');ET.SubElement(node,f'{{{NS}}}t').text=value
      else:
       cell.pop('t',None) if hasattr(cell,'pop') else cell.attrib.pop('t',None)
       ET.SubElement(cell,f'{{{NS}}}v').text=str(value)
     data=ET.tostring(x,encoding='utf-8',xml_declaration=True)
    zo.writestr(item,data)

def worker(case):
 name,params,extras=case;folder=ROOT/'validacao'/name;folder.mkdir(parents=True,exist_ok=True);(folder/'out').mkdir(exist_ok=True);profile=folder/'profile/user';profile.mkdir(parents=True,exist_ok=True)
 (profile/'registrymodifications.xcu').write_text('''<?xml version="1.0"?><oor:items xmlns:oor="http://openoffice.org/2001/registry"><item oor:path="/org.openoffice.Office.Calc/Formula/Load"><prop oor:name="OOXMLRecalcMode" oor:op="fuse"><value>0</value></prop></item></oor:items>''')
 changes=copy.deepcopy(extras)
 for k,v in params.items():changes.setdefault('Pressupostos',{})['B'+str(META['param_rows'][k])]=v
 dest=folder/(name+'.xlsx');mutate(dest,changes)
 cmd=['soffice','-env:UserInstallation='+str((folder/'profile').as_uri()),'--headless','--convert-to','xlsx','--outdir',str(folder/'out'),str(dest)]
 proc=subprocess.run(cmd,capture_output=True,text=True,timeout=240)
 output=folder/'out'/dest.name
 if proc.returncode or not output.exists():return dict(case=name,ok=False,error=proc.stdout+proc.stderr)
 # sale variant only changes input201; use a temporary process-local copy of UNITS to avoid parallel mutation.
 if name=='Venda_201_M2':
  code="import sys,json;sys.path.insert(0,"+repr(str(ROOT/'src'))+");import engine;engine.UNITS[0]['sale']=2;print(json.dumps(engine.run()['flow']))"
  expected=json.loads(subprocess.check_output(['python','-c',code],text=True))
 else:expected=run(config(**params))['flow']
 w=openpyxl.load_workbook(output,data_only=True,read_only=True);fail=[];count=0
 for row,e in zip(w['Fluxo 180M'].iter_rows(min_row=5,max_row=184,values_only=True),expected):
  for k,c in META['flow_columns'].items():
   if e[k] is None:continue
   if isinstance(e[k],(int,float)):
    count+=1
    if not isinstance(row[c],(int,float)) or abs(row[c]-e[k])>max(.01,abs(e[k])*1e-9):fail.append(f'm{e["m"]} {k}: {row[c]} != {e[k]}')
 if name=='Filtro_ID_201':
  s=w['DASH Comercial'];count+=2
  if s['B11'].value!=1:fail.append('Filtro não selecionou uma fração')
  if abs(s['B12'].value-UNITS[0]['price'])>.01:fail.append('VGV filtrado errado')
  for row,e in zip(s.iter_rows(min_row=151,max_row=330,values_only=True),receipts(config())['units'][0]):
   count+=1
   if abs(row[5]-e)>.01:fail.append('Recebimento filtrado errado')
 errs=[]
 for s in w:
  for row in s:
   for c in row:
    if c.data_type=='e':errs.append((s.title,c.coordinate,c.value))
 w.close()
 return dict(case=name,ok=not fail and not errs,comparisons=count,failures=fail[:12],formula_errors=errs[:12],params=params,output=str(output))
if __name__=='__main__':
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
  results=[]
  for res in pool.map(worker,CASES):results.append(res);print(json.dumps(res,ensure_ascii=False),flush=True)
 (ROOT/'entrega/Testes_Seletores.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
 raise SystemExit(0 if all(r['ok'] for r in results) else 1)
