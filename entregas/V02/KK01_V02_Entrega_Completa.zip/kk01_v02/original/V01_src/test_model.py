"""Regressão independente e confronto com fórmulas Excel recalculadas.
Uso: python test_model.py [caminho/modelo.xlsx]
"""
from engine import *
import unittest,openpyxl,sys,hashlib,zipfile,collections
FILE=Path(sys.argv[1]) if len(sys.argv)>1 else ROOT/'entrega/KK01_Modelo_Integrado.xlsx'
sys.argv=sys.argv[:1]
META=json.loads((ROOT/'src/build_metadata.json').read_text())
class ModelTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.r=run();cls.w=openpyxl.load_workbook(FILE,data_only=True,read_only=True);cls.f=openpyxl.load_workbook(FILE,data_only=False,read_only=True)
 @classmethod
 def tearDownClass(cls):cls.w.close();cls.f.close()
 def test_01_source_integrity(self):self.assertEqual(hashlib.sha256((ROOT/'original/V45_original.xlsx').read_bytes()).hexdigest(),SOURCE['source_sha256'])
 def test_02_units_vgv_area(self):
  self.assertEqual(len(UNITS),94);self.assertEqual(len(set(u['id'] for u in UNITS)),94);self.assertAlmostEqual(sum(u['price'] for u in UNITS),50656336.37,2)
  for u in UNITS:self.assertAlmostEqual(u['area'],u['interior']+u['varanda'],8)
 def test_03_receipts_each_fraction(self):
  for u,rows in zip(UNITS,self.r['re']['units']):self.assertAlmostEqual(sum(rows),u['price'],2);self.assertTrue(all(v>=0 for v in rows));self.assertEqual(sum(v!=0 for v in rows),2+(u['deed']-u['sale']-1)//6)
 def test_04_chapters(self):
  self.assertAlmostEqual(sum(c['share'] for c in CHAPTERS),1,10)
  for c in CHAPTERS:self.assertAlmostEqual(sum(c['weights']),1,10)
  self.assertAlmostEqual(sum(x['total'] for x in self.r['cap']),63168000,2)
 def test_05_identities_and_bank(self):
  for x in self.r['flow']:
   self.assertAlmostEqual(x['cash_check'],0,6);self.assertAlmostEqual(x['debt_check'],0,6);self.assertLessEqual(x['cumulative'],DEFAULT['limit']+.001)
   self.assertGreaterEqual(x['debt'],-.001)
   if x['m']<=42:self.assertEqual(x['principal'],0)
   if x['m']>30:self.assertEqual(x['draw'],0)
   self.assertAlmostEqual(x['service'],x['interest']+x['principal'],8)
 def test_06_liquidity_and_distributions(self):
  self.assertLess(max(x['reservegap'] for x in self.r['flow']),.01)
  for x in self.r['flow']:
   if x['dividend']>.005:self.assertEqual(x['m']%12,0);self.assertLess(x['debt'],.005);self.assertGreaterEqual(x['cash'],x['reserve']-.005)
 def test_07_no_historical_duplicate(self):
  changed=run(config(historic=9000000))
  for a,b in zip(self.r['flow'],changed['flow']):self.assertEqual(a,b)
 def test_08_hotusa_reserve_not_payment(self):
  self.assertEqual(sum(x['hotpay'] for x in self.r['flow']),0);self.assertTrue(all(x['hothold']==1000000 for x in self.r['flow']))
  paid=run(config(hotpay=1))
  self.assertEqual(sum(x['hotpay'] for x in paid['flow']),1000000);self.assertEqual(paid['flow'][29]['hothold'],0)
 def test_09_contingency_reserve(self):
  c=run(config(cont_used=0));self.assertEqual(sum(x['contingency'] for x in c['flow']),0);self.assertTrue(all(abs(x['conthold']-5640000)<.005 for x in c['flow']))
 def test_10_hotel_residential_separate(self):
  first=self.r['hotel'][30];self.assertLess(first['cf'],0);self.assertEqual(sum(x['revenue'] for x in self.r['hotel'][:30]),0)
  n=run(config(res_include=0));self.assertTrue(all(x['res_cf']==0 for x in n['flow']));self.assertEqual(n['hotel'],self.r['hotel'])
 def test_11_fees_only_on_first_draw(self):
  self.assertEqual(sum(x['trigger'] for x in self.r['flow']),1);self.assertAlmostEqual(sum(x['openingfee']+x['broker']+x['mobil'] for x in self.r['flow']),1125000,2)
  n=run(config(equity=100000000));self.assertEqual(sum(x['broker'] for x in n['flow']),0)
 def test_12_selectors_and_stress(self):
  a=run(config(equity=0));self.assertGreater(max(x['gap'] for x in a['flow']),0)
  for hn in HOTELS:
   a=run(config(hotel=hn));self.assertEqual(len(a['flow']),180)
  self.assertGreater(run(config(bank='Personalizado',rate_custom=.08))['flow'][29]['debt'],run(config(bank='Personalizado',rate_custom=.045))['flow'][29]['debt'])
  for term in [5,10,15,20]:
   a=run(config(bank='Personalizado',term_custom=term,sweep=0));self.assertGreater(a['flow'][42]['principal'],0)
   if term==5:self.assertLess(a['flow'][101]['debt'],.01)
 def test_13_receipts_conversion_and_lag(self):
  for lag in [0]:
   p=config(lag=lag);rr=receipts(p)
   for u,v in zip(UNITS,rr['units']):self.assertAlmostEqual(sum(v),u['price'],2)
  invalid=receipts(config(lag=1));self.assertLess(sum(invalid['units'][next(i for i,u in enumerate(UNITS) if u['id']=='504')]),next(u['price'] for u in UNITS if u['id']=='504'))
  rr=run(config(conversion=100000));self.assertAlmostEqual(sum(rr['re']['total']),50656336.37-100000,2);self.assertEqual(rr['flow'][0]['equity'],14900000)
 def test_14_valuation_no_double_cash(self):
  s=summary(self.r);last=self.r['flow'][-1];self.assertAlmostEqual(s['exit_equity'],s['ev']*.98-last['debt']+last['cash']-last['hothold']-last['conthold'],6)
  self.assertTrue(.08<s['equity_irr']<.10)
 def test_15_source_preserved_in_excel(self):
  rows=list(self.w['Unidades'].iter_rows(min_row=5,max_row=98,values_only=True))
  for u,row in zip(UNITS,rows):
   self.assertEqual(str(row[0]),u['id']);self.assertEqual(row[1],u['tipo']);self.assertEqual(str(row[2]),u['piso']);self.assertAlmostEqual(row[6],u['price_source'],6);self.assertAlmostEqual(row[7],u['price'],2);self.assertEqual(row[11],u['deed'])
 def test_16_recalculated_excel_matches_independent_engine(self):
  for sn,section,mapping in [('Fluxo 180M','flow',META['flow_columns']),('Hotel','hotel',META['hotel_columns']),('Residencial','res',META['res_columns'])]:
   rows=self.w[sn].iter_rows(min_row=5,max_row=184,values_only=True)
   for actual,expected in zip(rows,self.r[section]):
    for k,c in mapping.items():
     v=expected[k];a=actual[c]
     if v is None:self.assertIn(a,[None,'']);continue
     if isinstance(v,(int,float)):
      self.assertIsInstance(a,(int,float),msg=f'{sn} {expected["m"]} {k}: {a}')
      self.assertAlmostEqual(a,v,delta=max(.005,abs(v)*1e-9),msg=f'{sn} m{expected["m"]} {k}: Excel={a}; Python={v}')
 def test_17_all_23_scenarios_match(self):
  for i,sc in enumerate(META['scenarios']):
   p=config(equity=DEFAULT['equity'] if sc['equity'] is None else sc['equity'],hotel=DEFAULT['hotel'] if sc['hotel'] is None else sc['hotel'],bank=DEFAULT['bank'] if sc['bank'] is None else sc['bank'])
   if 'rate' in sc:p=config(**{**{k:p[k] for k in DEFAULT},'rate_custom':sc['rate']})
   expected=run(p)
   for row,e in zip(self.w[f'CalcF{i+1:02d}'].iter_rows(min_row=5,max_row=184,values_only=True),expected['flow']):
    for k in ['cash','debt','draw','interest','principal','sweep','dividend','reserve','gap']:
     self.assertAlmostEqual(row[META['flow_columns'][k]],e[k],delta=.01,msg=f'Cenário {i+1} m{e["m"]} {k}')
 def test_18_no_formula_errors_or_external_macros(self):
  errors=[]
  for s in self.w:
   for row in s:
    for c in row:
     if c.data_type=='e':errors.append((s.title,c.coordinate,c.value))
  self.assertEqual(errors,[])
  with zipfile.ZipFile(FILE) as z:self.assertFalse(any('externalLink' in n or n.endswith('vbaProject.bin') for n in z.namelist()))
 def test_19_dashboard_and_filters(self):
  for sn in ['DASH Real Estate','DASH Comercial','DASH Hotel MICE','DASH Acionistas','DASH Consolidado']:self.assertIn(sn,self.w.sheetnames)
  s=self.w['DASH Comercial'];self.assertEqual(s['B11'].value,94);self.assertAlmostEqual(s['B12'].value,50656336.37,2)
  # 30-month filtered schedule equals whole source with Todos selected.
  for row,e in zip(s.iter_rows(min_row=151,max_row=180,values_only=True),self.r['re']['total']):self.assertAlmostEqual(row[5],e,2)
 def test_20_return_vectors_and_kpi(self):
  s=summary(self.r);k=self.w['KPI'];rows=META['kpi_rows']
  for key,expected in [('vgv',50656336.37),('peak',s['peak']),('npv',s['npv_project']),('equityirr',s['equity_irr']),('equitymoic',s['moic'])]:self.assertAlmostEqual(k.cell(rows[key],2).value,expected,delta=.01)
  self.assertAlmostEqual(k.cell(rows['projectirr'],2).value,irr([0]+[x['project_cf'] for x in self.r['flow']]),delta=1e-6)

if __name__=='__main__':
 import io
 stream=io.StringIO();suite=unittest.defaultTestLoader.loadTestsFromTestCase(ModelTests);result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
 report=stream.getvalue();print(report);(ROOT/'entrega/Resultados_Testes.txt').write_text(report)
 (ROOT/'entrega/Resultados_Testes.json').write_text(json.dumps({'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped),'ok':result.wasSuccessful(),'file':str(FILE)},indent=2))
 sys.exit(0 if result.wasSuccessful() else 1)
