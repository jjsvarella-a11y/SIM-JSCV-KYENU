# KK-01 — V02 | 20 M€ por 40%

O ficheiro principal está em `entrega/KK01_Modelo_Integrado_V02.xlsx`. Abrir em Excel e começar em `EXEC KK01`. Os 12 cartões e 8 ícones estão ligados às folhas do modelo.

Referência: 20 M€ disponíveis na KK por hipótese, novos investidores40%, JSCV51%, JALS9%, Hotel Favorável, banco Limite aceitável6%/42meses/10anos. Compra secundária de ações da JALS NÃO constitui entrada automática na sociedade. Ver `KK01_Decisoes_Pendentes_V02.pdf` antes de aprovar a operação.

A alternativa15 M€ por40% é recalculada em `Comparativo 15 20`; maior capital reduz financiamento, mas pode reduzir TIR da mesma participação.

## Conteúdo

`entrega/`: modelo, comparativo, agenda do Operador, painel em PDF, auditoria, documentação e testes. `src/`: extensão do motor existente e testes. `original/`: V45, V01, snapshot do códigoV01, fixture e manifesto de integridade. Nenhum ficheiroV01 foi substituído.

## Reprodução

Utilizar o workspace existente, sem criar worktree. Instalar dependências de `requirements.txt` num ambiente próprio. Executar `python src/engine.py` e `python src/build_model.py`. Forçar cálculo integral no Excel/LibreOffice e guardar em `recalc/KK01_Modelo_Integrado_V02.xlsx`; `python src/finalize_v02.py` aplica validações e legenda dinâmica sem alterar o motor. Depois executar `python src/test_model.py entrega/KK01_Modelo_Integrado_V02.xlsx` e `python src/test_selectors.py`.

Os scripts `upgrade_*` são registo de migração única: não voltar a aplicá-los aos ficheiros já migrados. `finalize_v02.py` exige a versão integralmente recalculada em `recalc/`.

Os testes de seletores invalidam caches após alterar inputs e forçam recálculo completo em perfil isolado. A primeira passagem com caches antigas está preservada para rastreio. Não existe macro no Excel. Microsoft Excel desktop não foi executado neste ambiente; o recálculo externo foi confrontado com Python.

## Condições do Operador

Selecionar Objetivo KK, Proposta simulada, Limites propostos ou Personalizado. Valores em branco dos limites não são condições aceites: usa-se fallback ao objetivo explicitamente identificado. Nenhum modo corresponde a HMA aprovado. A agenda inclui performance, FF&E, manutenção, orçamento, reporting, auditoria e rescisão.

## Dados reais

Comprometido e realizado ficam vazios por defeito. Não copiar previsões para simular execução. Fundos, direitos societários, fiscalidade, HMA, bancos, vendas e saída permanecem sujeitos a confirmação externa.
