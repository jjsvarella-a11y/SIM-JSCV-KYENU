# KK-01 | Construção,EAC e abertura V04

18/10/2026 | KK Hotelaria e Turismo, S.A. | V04

Orçamento inicial:47.000m²×1.200€/m²=56, 4 M€, fiscalização 2%=1, 128 M€e contingência 10%=5, 64 M€; total 63, 168 M€. Custos comerciais, financiamento, HOTUSA e operação são separados. FF&E inicial incluído na construção não se repete como investimento inicial Hotel.

| Indicador | Situação |
|---|---|
| BAC inicial | 63.168.000,00 € |
| Orçamento aprovado | Indisponível |
| Actual Cost | Indisponível |
| Committed Cost | Indisponível |
| EAC com Actual Cost | Indisponível |
| Forecast de caixa de referência | 63.168.000,00 € |
| Conclusão física prevista | M30 |
| Abertura comercial prevista | M31 |

ETC revisto aplica-se apenas aos meses futuros após o mês de controlo e redistribui os pesos de CAPEX remanescente. Não inventa realizado anterior. EAC=Actual Cost documentado+ETC; VAC=BAC−EAC; sem Actual Cost não existe desvio executado certificado. Comprometido não é somado novamente ao realizado.

Atraso de obra insere pausa no calendário preservando os pesos por capítulo e pode gerar custo de imobilização editável. Abertura operacional tem atraso próprio. A janela bancária não é prorrogada automaticamente: cabe negociar extensão. Alterações atualizam juros, reserva, CFADS, dividendos e TIR.

## Hotel Opening Readiness

13 requisitos: HMA, licenças, FF&E, RH, formação, sistemas, distribuição, reservas/marketing, comissionamento, testes, aceitação, soft opening eabertura oficial. Datas/progresso/aprovação/documento próprios. Sem evidência não há percentagem de prontidão certificada. Conclusão física não equivale a autorização de abertura.

Ações prioritárias: validar medições e contratos por capítulo, atualizar compromissos e pagamentos, reconciliar extratos, aprovar orçamento e ETC, aferir avanço físico e atualizar previsão de conclusão mensalmente. O cenário CAPEX+10%/obra+6 Mmostra insuficiência de reservas, apesar de TIR positiva.
