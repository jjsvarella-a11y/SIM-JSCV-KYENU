# KK-01 | Documentação técnica V04

18/10/2026 | KK Hotelaria e Turismo, S.A. | V04

Fluxo: pressupostos + inventário/calendários → recebimentos, CAPEX e exploração separados → fluxo 180M/banco/tesouraria → lucro/reservas/dividendos → waterfall/saída/retornos → dashboards, KPI e relatórios. Riscos usam os mesmos geradores de fórmulas em blocos próprios; não motores financeiros divergentes.

| Módulo | Local / instrução |
|---|---|
| Entradas | Pressupostos;células azuis;listas e notas;validar unidades |
| Estrutura e capital | Matriz Societaria V03atualizada;V04 Pipeline/Calendarios/Capital180 |
| Imobiliário | Unidades/Recebimentos/Imobiliario/V04 Pricing/Comercial/Metas RE |
| Construção | Capítulos/CAPEX/V04 EAC;realizado vazio até evidência |
| Operação | Hotel/Residencial/Condicoes Operador/Opening Readiness |
| Financiamento | Fluxo180M/Bancabilidade/Completion;CPelegibilidade editáveis |
| Retornos | Politica/Waterfall180/Vet Retorno/Retornos;10e15anos |
| Gestão | Master Workflow/Operacional/Impactos/Decisoes Board |
| Interface | EXEC KK01,dashboards nativos,Dicionario KPI,AUDITORIA |

## Como utilizar

1 Guardar cópia.2 Selecionar cenário e editar pressupostos documentados.3 Atualizar dados executados apenas com comprovativos.4 Recalcular integralmente Excel.5 Rever alertas de caixa, reservas, DSCR, recebimentos eCompletion antes das TIR.6 Rever diferenças de política e aprovação.7 Guardar versão e repetir regressões. Não editar fórmulas do motor ou folhas técnicas ocultas para forçar resultados.

## Fórmulas críticas

Recebimentos 5/20/55/20 com semestres e arredondamento por fração; saldoCaixa=abertura+entradas−saídas; dívida=abertura+draw−capital−sweep; utilização acumulada=soma drawssem reposição; DSCR=CFADS/serviço obrigatório; VPL desconto mensal efetivo; TIR anual=(1+IRRmensal)^12−1; MOIC=recebido/pago; saída=EBITDA 12 M×múltiplo−custos−dívida+caixa−restrições; crédito recuperável limitado aos ativos; CFCfontes/necessidades; EAC=AC+ETC.

## Reprodução e limites

Código Python e fontesJSONincluídos; requirements com versões; test_phase 1.py, test_phase 23.py, test_selectors.py, audit_risks.py, audit_returns_v04.py, test_structure_v04.py. O recálculo externo invalida caches antes de comparar para evitar falsos passes com resultados antigos. Dados auxiliares e metodologia noREADME. Não executar migrações V01/V02/V03 sobre V04.

313 folhas, incluindo blocos de cálculo ocultos para cenários. Folhas técnicas não significam entradas duplicadas: parâmetros centrais alimentam geradores comuns. Mapa completo e hashes no pacote. PDFdoExecutiveé snapshot de valores doExcelfinal; não substitui o ficheiro dinâmico. Numeração portuguesa nos relatórios; Excel usa formatos numéricos e locale do utilizador.

## Mapa de folhas

| Folha | Visibilidade |
|---|---|
| EXEC KK01 | visible |
| LEIA-ME | visible |
| Pressupostos | visible |
| DASH Consolidado | visible |
| DASH Real Estate | visible |
| DASH Comercial | visible |
| DASH Hotel MICE | visible |
| DASH Acionistas | visible |
| AUDITORIA | visible |
| Cenarios | visible |
| Unidades | visible |
| Recebimentos | visible |
| Obra | visible |
| CAPEX | visible |
| Imobiliario | visible |
| Hotel | visible |
| Residencial | visible |
| Fluxo 180M | visible |
| Anual | visible |
| Comparacao | visible |
| CalcH01 | hidden |
| CalcF01 | hidden |
| CalcH02 | hidden |
| CalcF02 | hidden |
| CalcH03 | hidden |
| CalcF03 | hidden |
| CalcH04 | hidden |
| CalcF04 | hidden |
| CalcH05 | hidden |
| CalcF05 | hidden |
| CalcH06 | hidden |
| CalcF06 | hidden |
| CalcH07 | hidden |
| CalcF07 | hidden |
| CalcH08 | hidden |
| CalcF08 | hidden |
| CalcH09 | hidden |
| CalcF09 | hidden |
| CalcH10 | hidden |
| CalcF10 | hidden |
| CalcH11 | hidden |
| CalcF11 | hidden |
| CalcH12 | hidden |
| CalcF12 | hidden |
| CalcH13 | hidden |
| CalcF13 | hidden |
| CalcH14 | hidden |
| CalcF14 | hidden |
| CalcH15 | hidden |
| CalcF15 | hidden |
| CalcH16 | hidden |
| CalcF16 | hidden |
| CalcH17 | hidden |
| CalcF17 | hidden |
| CalcH18 | hidden |
| CalcF18 | hidden |
| CalcH19 | hidden |
| CalcF19 | hidden |
| CalcH20 | hidden |
| CalcF20 | hidden |
| CalcH21 | hidden |
| CalcF21 | hidden |
| CalcH22 | hidden |
| CalcF22 | hidden |
| CalcH23 | hidden |
| CalcF23 | hidden |
| CalcH24 | hidden |
| CalcF24 | hidden |
| CalcH25 | hidden |
| CalcF25 | hidden |
| CalcH26 | hidden |
| CalcF26 | hidden |
| CalcH27 | hidden |
| CalcF27 | hidden |
| CalcH28 | hidden |
| CalcF28 | hidden |
| CalcH29 | hidden |
| CalcF29 | hidden |
| CalcR29 | hidden |
| CalcA29 | hidden |
| CalcH30 | hidden |
| CalcF30 | hidden |
| CalcC30 | hidden |
| CalcH31 | hidden |
| CalcF31 | hidden |
| CalcH32 | hidden |
| CalcF32 | hidden |
| CalcH33 | hidden |
| CalcF33 | hidden |
| CalcR33 | hidden |
| CalcA33 | hidden |
| CalcH34 | hidden |
| CalcF34 | hidden |
| CalcC34 | hidden |
| CalcH35 | hidden |
| CalcF35 | hidden |
| CalcH36 | hidden |
| CalcF36 | hidden |
| CalcH37 | hidden |
| CalcF37 | hidden |
| CalcH38 | hidden |
| CalcF38 | hidden |
| CalcH39 | hidden |
| CalcF39 | hidden |
| CalcH40 | hidden |
| CalcF40 | hidden |
| CalcH41 | hidden |
| CalcF41 | hidden |
| CalcH42 | hidden |
| CalcF42 | hidden |
| CalcH43 | hidden |
| CalcF43 | hidden |
| CalcH44 | hidden |
| CalcF44 | hidden |
| CalcH45 | hidden |
| CalcF45 | hidden |
| CalcR45 | hidden |
| CalcA45 | hidden |
| CalcH46 | hidden |
| CalcF46 | hidden |
| CalcC46 | hidden |
| CalcH47 | hidden |
| CalcF47 | hidden |
| CalcH48 | hidden |
| CalcF48 | hidden |
| Retornos | visible |
| Fluxos Retorno | visible |
| Investidores | visible |
| Societario | visible |
| KPI | visible |
| Operador | visible |
| Sensibilidade | visible |
| Listas | hidden |
| Origem e Alteracoes | visible |
| Mapa V45 | visible |
| Ronda Investidores | visible |
| Condicoes Operador | visible |
| Resultados Cenarios | visible |
| Vet Cenarios | hidden |
| Comparativo 15 20 | visible |
| Execucao | visible |
| DASH Investimento | visible |
| DASH Residencial | visible |
| DASH Operador | visible |
| DASH Riscos | visible |
| Retorno Socios | visible |
| Capital V03 | visible |
| Blocos V03 | visible |
| Matriz Societaria V03 | visible |
| Governacao V03 | visible |
| Beneficios V03 | visible |
| Comparativo Capital V03 | visible |
| Retorno Categorias V03 | visible |
| Vet Categorias V03 | hidden |
| V04 Calendarios | visible |
| V04 Pipeline | visible |
| V04 Capital180 | hidden |
| V04 CAPEX Base | hidden |
| V04 Bancabilidade | visible |
| V04 Completion | visible |
| V04 Pricing | visible |
| V04 Politica | visible |
| V04 Waterfall180 | visible |
| V04 Retornos | visible |
| V04 Vet Retorno | hidden |
| V04 LEG28Unid | hidden |
| V04 LEG28Receb | hidden |
| V04 LEG32Unid | hidden |
| V04 LEG32Receb | hidden |
| V04 LEG44Unid | hidden |
| V04 LEG44Receb | hidden |
| V04 Comercial | visible |
| V04 Metas RE | visible |
| V04 EAC | visible |
| V04 Master Workflow | visible |
| V04 Operacional | visible |
| V04 Opening Readiness | visible |
| V04 Decisoes Board | visible |
| V04 R01Pipeline | hidden |
| V04 R01Capital | hidden |
| V04 R01Unid | hidden |
| V04 R01Receb | hidden |
| V04 R01RE | hidden |
| V04 R01Hotel | hidden |
| V04 R01Resid | hidden |
| V04 R01Fluxo | hidden |
| V04 R01Politica | hidden |
| V04 R01WF | hidden |
| V04 R02Pipeline | hidden |
| V04 R02Capital | hidden |
| V04 R02Unid | hidden |
| V04 R02Receb | hidden |
| V04 R02RE | hidden |
| V04 R02Hotel | hidden |
| V04 R02Resid | hidden |
| V04 R02Fluxo | hidden |
| V04 R02Politica | hidden |
| V04 R02WF | hidden |
| V04 R03Pipeline | hidden |
| V04 R03Capital | hidden |
| V04 R03Unid | hidden |
| V04 R03Receb | hidden |
| V04 R03RE | hidden |
| V04 R03Hotel | hidden |
| V04 R03Resid | hidden |
| V04 R03Fluxo | hidden |
| V04 R03Politica | hidden |
| V04 R03WF | hidden |
| V04 R04Pipeline | hidden |
| V04 R04Capital | hidden |
| V04 R04Unid | hidden |
| V04 R04Receb | hidden |
| V04 R04RE | hidden |
| V04 R04Hotel | hidden |
| V04 R04Resid | hidden |
| V04 R04Fluxo | hidden |
| V04 R04Politica | hidden |
| V04 R04WF | hidden |
| V04 R05Pipeline | hidden |
| V04 R05Capital | hidden |
| V04 R05Unid | hidden |
| V04 R05Receb | hidden |
| V04 R05RE | hidden |
| V04 R05Hotel | hidden |
| V04 R05Resid | hidden |
| V04 R05Fluxo | hidden |
| V04 R05Politica | hidden |
| V04 R05WF | hidden |
| V04 R06Pipeline | hidden |
| V04 R06Capital | hidden |
| V04 R06CB | hidden |
| V04 R06CAPEX | hidden |
| V04 R06Unid | hidden |
| V04 R06Receb | hidden |
| V04 R06RE | hidden |
| V04 R06Hotel | hidden |
| V04 R06Resid | hidden |
| V04 R06Fluxo | hidden |
| V04 R06Politica | hidden |
| V04 R06WF | hidden |
| V04 R07Pipeline | hidden |
| V04 R07Capital | hidden |
| V04 R07Unid | hidden |
| V04 R07Receb | hidden |
| V04 R07RE | hidden |
| V04 R07Hotel | hidden |
| V04 R07Resid | hidden |
| V04 R07Fluxo | hidden |
| V04 R07Politica | hidden |
| V04 R07WF | hidden |
| V04 R08Pipeline | hidden |
| V04 R08Capital | hidden |
| V04 R08Unid | hidden |
| V04 R08Receb | hidden |
| V04 R08RE | hidden |
| V04 R08Hotel | hidden |
| V04 R08Resid | hidden |
| V04 R08Fluxo | hidden |
| V04 R08Politica | hidden |
| V04 R08WF | hidden |
| V04 R09Pipeline | hidden |
| V04 R09Capital | hidden |
| V04 R09Unid | hidden |
| V04 R09Receb | hidden |
| V04 R09RE | hidden |
| V04 R09Hotel | hidden |
| V04 R09Resid | hidden |
| V04 R09Fluxo | hidden |
| V04 R09Politica | hidden |
| V04 R09WF | hidden |
| V04 R10Pipeline | hidden |
| V04 R10Capital | hidden |
| V04 R10Unid | hidden |
| V04 R10Receb | hidden |
| V04 R10RE | hidden |
| V04 R10Hotel | hidden |
| V04 R10Resid | hidden |
| V04 R10Fluxo | hidden |
| V04 R10Politica | hidden |
| V04 R10WF | hidden |
| V04 R11Pipeline | hidden |
| V04 R11Capital | hidden |
| V04 R11Unid | hidden |
| V04 R11Receb | hidden |
| V04 R11RE | hidden |
| V04 R11Hotel | hidden |
| V04 R11Resid | hidden |
| V04 R11Fluxo | hidden |
| V04 R11Politica | hidden |
| V04 R11WF | hidden |
| V04 R12Pipeline | hidden |
| V04 R12Capital | hidden |
| V04 R12Unid | hidden |
| V04 R12Receb | hidden |
| V04 R12RE | hidden |
| V04 R12Hotel | hidden |
| V04 R12Resid | hidden |
| V04 R12Fluxo | hidden |
| V04 R12Politica | hidden |
| V04 R12WF | hidden |
| V04 R13Pipeline | hidden |
| V04 R13Capital | hidden |
| V04 R13Unid | hidden |
| V04 R13Receb | hidden |
| V04 R13RE | hidden |
| V04 R13Hotel | hidden |
| V04 R13Resid | hidden |
| V04 R13Fluxo | hidden |
| V04 R13Politica | hidden |
| V04 R13WF | hidden |
| V04 Riscos | visible |
| V04 Impactos | visible |
| V04 Dicionario KPI | visible |
