# KK-01 | Banco, bancabilidade e conclusão V04

18/10/2026 | KK Hotelaria e Turismo, S.A. | V04

Linha estratégica 30 M€, não renovável. A referência utiliza 6% anuais, 42 meses carência de capital e10 anos de amortização após carência. Seletor 20/25/30 M€e condições personalizadas propagam pelo mesmo motor. Não recomendar redução apenas pela referência.

| Indicador | Referência recalculada |
|---|---|
| Limite estratégico | 30.000.000,00 € |
| Utilizado acumulado | 19.187.648,01 € |
| Pico intramensal dívida | 14.883.293,59 € |
| Juros | 619.930,36 € |
| Caixa mínima | 3.633.802,73 € |
| Défice não financiado | 0,00 € |
| Insuficiência de reservas | 0,00 € |

## Completion Funding Coverage no M24

| Componente | Projetado | Documentado |
|---|---|---|
| CaixaM24 | 10.600.500,33 € | Indisponível |
| Recebimentos líquidos futuros | 24.205.419,36 € | Indisponível |
| Capital futuroKK | 0,00 € | Indisponível |
| Banco remanescente mobilizável | 11.746.200,03 € | Indisponível |
| Liquidez total | 46.552.119,72 € | Indisponível |
| Cost to complete | 10.962.806,40 € | — |
| Encargos até abertura | 242.667,14 € | — |
| Défices operacionais até abertura | 483.802,73 € | — |
| Reserva abertura | 3.000.000,00 € | — |
| Necessidade total | 14.689.276,27 € | — |
| Completion Funding Coverage | 3,17 x | Indisponível |
| Funding gap | 0,00 € | Indisponível |

A cobertura projetada resulta de caixa existente, recebimentos líquidos futuros, capital e capacidade bancária condicionada. Custos incluem CAPEX remanescente, encargos, défice operacional de abertura e reservas, sem duplicar a reserva como despesa. Crédito só entra se CP, janela, elegibilidade e pari passu simulados permitirem; amortização não recria capacidade.

Estado documental: Pendente — recursos não documentados. Uma razão projetada de 3, 17 x não prova recursos firmes, nem elimina insuficiências mensais. Cobertura assegurada exige extratos, contratos/CP, compromissos firmes e validação do custo e do calendário.

## M30, M42 e transição operacional

| Marco | Dívida bancária | Caixa | Reserva |
|---|---|---|---|
| M30 | 0,00 € | 8.717.152,56 € | 3.633.802,73 € |
| M42 | 0,00 € | 7.760.803,63 € | 3.000.000,00 € |

## Viabilidade económica e indicadores complementares

| Indicador | Valor de cenário |
|---|---|
| VPL projeto sem saída a10% | 7.071.194,36 € |
| VPL projeto com saída a10% | 23.218.268,63 € |
| TIR projeto sem saída | 16,36% |
| TIR projeto com saída | 21,87% |
| Payback projeto sem saída | 86meses |
| Payback novos por dividendos | Não recuperado |
| LTV indicativo fimAno4 | 0,00% |
| Dívida líquida/EBITDA fimAno4 | -1,26 x |

TIR de projeto usa fluxos incrementais sem financiamento e pode ter múltiplas raízes em fluxos não convencionais; analisar VPL. LTV usa valor económico estimado do Hotel, não avaliação aceite pelo banco. Dívida líquida negativa representa caixa líquida; não prova caixa livre distribuível. No ano de referência sem dívida, o DSCR operacional fica indefinido.

## Custos e reconhecimento do equity

Broker 1, 5%, abertura 1% e mobilização 1, 25% sobre facilidade no primeiro uso são hipóteses editáveis; não há estes fees sem draw. Juros sobre saldo usado; compromisso sobre parcela não usada enquanto a janela está aberta, taxa inicial 0 por falta de proposta. Confirmar base e sobreposição de fees. Suprimentos e dívida vendedores separados.

Os4, 5 M€históricos não são automaticamente equity elegível. O quadro Bancabilidade separa capital social, contribuições, suprimentos, venda secundária, transferências, compromissos e previsões. Valores contabilísticos, realizados e aceites pelo banco permanecem indisponíveis sem documentos.

Cash sweep respeita reserva operacional 2 M€, HOTUSA1 M€no prudente e buffer de obra/pré-abertura. HOTUSA é reserva de risco, não dívida certa. DSCR divide CFADS pelo serviço obrigatório, exclui sweep e fica indefinido quando não há serviço. Garantias, CP e disponibilidade não contratadas permanecem pendentes.
