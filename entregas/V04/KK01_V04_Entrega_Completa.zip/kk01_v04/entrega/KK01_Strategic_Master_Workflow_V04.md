# KK-01 | Strategic Master Workflow V04

18/10/2026 | KK Hotelaria e Turismo, S.A. | V04

Workflow nativo expansível com 9 eixos; linhas principais Strategic View, sublinhas Operational View e folha Impactos com consequências financeiras. Dependências expressas por código; atividades em paralelo não são artificialmente sequenciadas. Progresso e aprovações documentais não fornecidos permanecem indisponíveis.

## JUR | Estruturação societária e jurídica

1 • 3

## JUR01 | Estrutura 20 blocos

Matriz societária; transmissão 11.000 JSCV/39.000 JALS • 1 • 2 • Jurídico / Board • Mandato V04 • 15 M€ / 94 frações / 20 blocos conforme eixo • Ver V04 Impactos; depende do desvio

## JUR02 | Waterfall

Proporcional vs preferências; parecer e deliberação • 1 • 3 • Board / Jurídico • Estrutura societária • 15 M€ / 94 frações / 20 blocos conforme eixo • Ver V04 Impactos; depende do desvio

## JUR03 | Instrumento KK

Recebido/retido/transferido; reembolso/subordinação • 1 • 3 • DF / Jurídico • Em paralelo com captação e banco • 15 M€ / 94 frações / 20 blocos conforme eixo • Ver V04 Impactos; depende do desvio

## EQ | Captação investidores

1 • 18

## EQ01 | PlatinumGold

Objetivo 15 M€iniciais; prioridade comercial • 1 • 3 • CEO / Comercial • Pode avançar em paralelo com crédito • 15 M€ / 94 frações / 20 blocos conforme eixo • Ver V04 Impactos; depende do desvio

## EQ02 | Silver

Colocar 10 Silver adicionais • 1 • 18 • Comercial • Pipeline de 12 blocos • 15 M€ / 94 frações / 20 blocos conforme eixo • Ver V04 Impactos; depende do desvio

## EQ03 | Capitalização KK

Confirmar recebimento e transferência efetiva • 1 • 18 • DF / Jurídico • Cada pagamento, documentação • 15 M€ / 94 frações / 20 blocos conforme eixo • Ver V04 Impactos; depende do desvio

## BNK | Financiamento bancário

1 • 30

## BNK01 | TermSheet

Negociar 30 M€, 6%, 42M, 10A; limites 20/25/30 • 1 • 3 • CEO / DF • Em paralelo com investidores • 15 M€ / 94 frações / 20 blocos conforme eixo • Ver V04 Impactos; depende do desvio

## BNK02 | Condições precedentes

Equity elegível, garantias, CPe calendário • 1 • 6 • DF / Jurídico • Contrato e documentos, não promessa de captação • 15 M€ / 94 frações / 20 blocos conforme eixo • Ver V04 Impactos; depende do desvio

## BNK03 | Desembolsos

Avanço obra e opção pari passu • 1 • 30 • DF / Obra • Condições precedentes cumpridas • 15 M€ / 94 frações / 20 blocos conforme eixo • Ver V04 Impactos; depende do desvio

## RE | Comercialização imobiliária

1 • 30

## RE01 | Ano 1

Meta quantidade/tipologia/VGV do plano vigente • 1 • 12 • Comercial • Licenças comerciais/CPCV • 15 M€ / 94 frações / 20 blocos conforme eixo • Ver V04 Impactos; depende do desvio

## RE02 | Ano 2

Objetivo 100% contratos até M24 • 1 • 24 • Comercial • Canal comercial, pricing, absorção • 15 M€ / 94 frações / 20 blocos conforme eixo • Ver V04 Impactos; depende do desvio

## RE03 | Escrituras

Objetivo 94 escrituras até M30 • 1 • 30 • Jurídico / Comercial • Recebimentos e validações contratuais • 15 M€ / 94 frações / 20 blocos conforme eixo • Ver V04 Impactos; depende do desvio

## CAP | Construção e procurement

1 • 30

## CAP01 | Orçamento aprovado

BAC, contingência, procurement • 1 • 3 • Obra / DF • Projeto e contratação • 15 M€ / 94 frações / 20 blocos conforme eixo • Ver V04 Impactos; depende do desvio

## CAP02 | EAC mensal

AC, CC, ETC, EAC, VACe progresso físico • 1 • 24 • Obra / DF • Medições e compromissos documentados • 15 M€ / 94 frações / 20 blocos conforme eixo • Ver V04 Impactos; depende do desvio

## CAP03 | Financial Completion Readiness

Recursos firmes cobrem conclusão M24 • 1 • 24 • CEO / DF / Board • Funding documentado e custotocomplete validado • 15 M€ / 94 frações / 20 blocos conforme eixo • Ver V04 Impactos; depende do desvio

## CAP04 | Conclusão física

Receção técnica, comissionamento • 1 • 30 • Obra • Execução e licenças • 15 M€ / 94 frações / 20 blocos conforme eixo • Ver V04 Impactos; depende do desvio

## OP | Operador Internacional/HMA

1 • 30

## OP01 | Proposta documentada

Separar proposta real e hipóteses 3/3/6 • 1 • 6 • CEO / Jurídico • Negociação paralela • 15 M€ / 94 frações / 20 blocos conforme eixo • Ver V04 Impactos; depende do desvio

## OP02 | HMA

Performance, FF&E, CAPEX, reporting, auditoria, rescisão • 1 • 12 • Board / Jurídico • Condições comerciais e parecer • 15 M€ / 94 frações / 20 blocos conforme eixo • Ver V04 Impactos; depende do desvio

## OP03 | Performance test

Preparar reporting e métricas • 1 • 30 • Operador / DF • HMA e sistemas • 15 M€ / 94 frações / 20 blocos conforme eixo • Ver V04 Impactos; depende do desvio

## OPEN | Pré-abertura Hotel+MICE

18 • 31

## OPEN01 | Equipa e sistemas

RH, formação, tecnologia, reservas • 18 • 27 • Operador / CEO • Plano de pré-abertura • 15 M€ / 94 frações / 20 blocos conforme eixo • Ver V04 Impactos; depende do desvio

## OPEN02 | Licenças/FF&E

Comissionamento, aceitação, testes • 18 • 30 • Obra / Operador • Conclusão física e autorizações • 15 M€ / 94 frações / 20 blocos conforme eixo • Ver V04 Impactos; depende do desvio

## OPEN03 | Softopening e abertura

Distinguir abertura comercial de estabilização • 18 • 31 • CEO / Operador • Prontidão operacional não é conclusão física • 15 M€ / 94 frações / 20 blocos conforme eixo • Ver V04 Impactos; depende do desvio

## RES | Residencial/leaseback

12 • 31

## RES01 | Contratos leaseback

Definir custos, fees, waterfall e direitos KK • 12 • 24 • Jurídico / Operador • Não garantir yield sem cobertura • 15 M€ / 94 frações / 20 blocos conforme eixo • Ver V04 Impactos; depende do desvio

## RES02 | Entrega e integração

Fração disponível apenas após escritura no cenário • 12 • 30 • Obra / Comercial • Escrituras e aceitação • 15 M€ / 94 frações / 20 blocos conforme eixo • Ver V04 Impactos; depende do desvio

## RES03 | Operação residencial

Pool 94 autónomo do Hotel 200 • 12 • 31 • Operador / DF • Entrega e contratos • 15 M€ / 94 frações / 20 blocos conforme eixo • Ver V04 Impactos; depende do desvio

## BOARD | Auditoria, licenças e decisões

1 • 31

## BOARD01 | Registo decisões

Competência, data, alternativas, documentos • 1 • 3 • Secretaria / Board • Pode avançar em paralelo • 15 M€ / 94 frações / 20 blocos conforme eixo • Ver V04 Impactos; depende do desvio

## BOARD02 | Revisão M24

Completion, licenças e ações corretivas • 1 • 24 • Board / Auditoria • CP, custos e fontes documentadas • 15 M€ / 94 frações / 20 blocos conforme eixo • Ver V04 Impactos; depende do desvio

## BOARD03 | Go/NoGo abertura

Concluir requisitos operacionais e reservas • 1 • 31 • Board / CEO • Prontidão e conclusão técnica • 15 M€ / 94 frações / 20 blocos conforme eixo • Ver V04 Impactos; depende do desvio

## Prioridades transversais

M1–M3: estrutura/atos societários, Platinum+Gold e negociação de banco em paralelo. M24: fundingcompletion e100% contratos imobiliários projetados, com prova de recursos firmes. M30: conclusão física/escrituras; M31: abertura condicionada à prontidão. Atualizar responsáveis, documentos, datas efetivas e ações corretivas sem converter previsão em execução.
