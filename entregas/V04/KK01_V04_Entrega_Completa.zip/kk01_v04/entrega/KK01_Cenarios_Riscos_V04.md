# KK-01 | Cenários e riscos V04

18/10/2026 | KK Hotelaria e Turismo, S.A. | V04

Resultados condicionais de cenário, não previsão certificada, contrato assinado ou garantia. Campos documentados em branco permanecem indisponíveis. As metas convencionais dos promotores não representam novos aportes.

| Cenário | Funding gap | Falta reservas | Pico dívida |
|---|---|---|---|
| Referência | 0,00 € | 0,00 € | 14.883.293,59 € |
| Sem novos contratosRE apósM24 | 0,00 € | 0,00 € | 14.883.293,59 € |
| Sem novas subscrições apósM24 | 0,00 € | 0,00 € | 14.883.293,59 € |
| Investidores +12M | 0,00 € | 935.602,13 € | 17.759.211,85 € |
| Vendas e escrituras +6M | 0,00 € | 0,00 € | 26.519.380,35 € |
| Investidores+12M e vendas+6M | 0,00 € | 5.333.159,44 € | 22.453.475,42 € |
| CAPEX+10% e conclusão+6M | 0,00 € | 1.034.416,93 € | 15.594.716,70 € |
| Hotel Conservador e fees maiores | 0,00 € | 0,00 € | 14.631.386,25 € |
| Escrituras+6M eADRresidencial−10% | 0,00 € | 0,00 € | 18.601.338,90 € |
| Apenas60%crédito mobilizável | 0,00 € | 925.092,93 € | 14.629.493,62 € |
| Apenas75%captação prevista | 0,00 € | 0,00 € | 21.437.954,16 € |
| Linha20M€ | 0,00 € | 0,00 € | 14.437.177,18 € |
| Linha25M€ | 0,00 € | 0,00 € | 14.657.254,68 € |
| Linha30M€ | 0,00 € | 0,00 € | 14.883.293,59 € |

| Cenário | TIR novos | MOIC | DSCR mínimo |
|---|---|---|---|
| Referência | 7,85% | 2,48 x | 2,99 x |
| Sem novos contratosRE apósM24 | 7,85% | 2,48 x | 2,99 x |
| Sem novas subscrições apósM24 | 7,85% | 2,48 x | 2,99 x |
| Investidores +12M | 8,45% | 2,47 x | 2,88 x |
| Vendas e escrituras +6M | 7,67% | 2,46 x | 0,72 x |
| Investidores+12M e vendas+6M | 8,22% | 2,44 x | 0,73 x |
| CAPEX+10% e conclusão+6M | 6,32% | 2,20 x | 92,80 x |
| Hotel Conservador e fees maiores | 2,32% | 1,32 x | 1,46 x |
| Escrituras+6M eADRresidencial−10% | 7,63% | 2,45 x | 1,05 x |
| Apenas60%crédito mobilizável | 7,85% | 2,49 x | 3,19 x |
| Apenas75%captação prevista | 6,75% | 2,30 x | 1,54 x |
| Linha20M€ | 7,90% | 2,49 x | 3,14 x |
| Linha25M€ | 7,87% | 2,49 x | 3,06 x |
| Linha30M€ | 7,85% | 2,48 x | 2,99 x |

## Leitura para decisão

Investidores+12M e vendas+6M consomem integralmente a linha 30 M€e violam reservas. Atraso de investidores isolado, crédito 60% disponível e CAPEX+10%/obra+6 Mtambém mostram insuficiência de reservas. Hotel Conservador com fees 4/3/10 reduz fortemente o retorno. Uma caixa positiva pode coexistir com violação de reservas ou DSCR baixo.

Nenhum cenário é certificado como financeiramente assegurado sem CP, recursos firmes e custos/calendário documentados. A regra de estado funding aponta caixa/reservas; rever também DSCR, metas por categoria e direitos antes de decidir. A referência 30 M€mantém valor de back-up; comparar 20/25/30 isoladamente não substitui combinações de stress.

Cortes M24: recebimentos de contratos anteriores continuam; apenas novos contratos/compromissos são interrompidos. Na base a colocação termina antes M24, logo estes cortes não geram perda adicional. Para avaliar carteira ainda por colocar, deslocar calendários e repetir. Atrasos de vendas e construção podem ocorrer em paralelo.
