# KK-01 | Estrutura acionista e waterfall V04

18/10/2026 | KK Hotelaria e Turismo, S.A. | V04

Resultados condicionais de cenário, não previsão certificada, contrato assinado ou garantia. Campos documentados em branco permanecem indisponíveis. As metas convencionais dos promotores não representam novos aportes.

| Titular | Platinum / Gold / Silver | Ações ilustrativas | Participação |
|---|---|---|---|
| JSCV | 1 / 2 / 0 | 40.000 | 40% |
| JALS | 0 / 0 / 5 | 10.000 | 10% |
| Novos | 1 / 1 / 10 | 50.000 | 50% |
| TOTAL | 2 / 3 / 15 | 100.000 | 100% |

## Conclusão financeira da proposta

A waterfall nativa selecionada produz TIR convencionais de 10, 00%, 6, 00% e 5, 50%. Conserva 100% dos dividendos e da saída, sem alterar a caixa da KK. A referência usa dividendos anuais e bases convencionais no M1; não são direitos preferenciais já aprovados.

| Categoria | Peso dividendos | Peso saída | TIR convencional15A |
|---|---|---|---|
| Platinum | 38,57% | 64,43% | 10,00% |
| Gold | 30,76% | 18,95% | 6,00% |
| Silver | 30,67% | 16,63% | 5,50% |

## Comparação dos mecanismos e calendário

| Método LP | Metas mínimas simultâneas | Metas exatas | TIR P / G / S |
|---|---|---|---|
| Proporcional | Não | Não | 7,79% / 7,79% / 7,79% |
| Só dividendos | Sim | Não | 10,00% / 6,00% / 6,83% |
| Só saída | Sim | Não | 10,00% / 6,00% / 5,58% |
| Combinado | Sim | Sim | 10,00% / 6,00% / 5,50% |

A otimização LP pode variar a alocação em cada evento; é um diagnóstico independente. A solução nativa de pesos constantes reproduz as metas no cenário anual de referência. O algoritmo simples de preferência acumulada não equivale ao ótimo LP e pode deixar excedentes/desvios. Na distribuição mensal o LP também encontra metas exatas, mas o método de pesos constantes pode ser inviável; nesse caso o Excel usa a preferência combinada e assinala a limitação do método. Falha dos pesos constantes não demonstra impossibilidade geral.

## Retorno efetivo e promotores

| Indicador | 10anos | 15anos |
|---|---|---|
| TIR efetiva novos | 7,09% | 7,85% |
| MOIC novos | 1,80 x | 2,48 x |
| VPL novos a12% | -7.619.955,77 € | -8.358.003,30 € |
| Recebido promotores | 45.615.135,73 € | 62.715.570,53 € |

| Bloco novo | Pagamento previsto | TIR efetiva15A |
|---|---|---|
| P01 | 10.000.000,00 € | 10,00% |
| G01 | 5.000.000,00 € | 6,05% |
| S01 | 1.000.000,00 € | 5,59% |
| S02 | 1.000.000,00 € | 5,59% |
| S03 | 1.000.000,00 € | 5,59% |
| S04 | 1.000.000,00 € | 5,63% |
| S05 | 1.000.000,00 € | 5,63% |
| S06 | 1.000.000,00 € | 5,63% |
| S07 | 1.000.000,00 € | 5,68% |
| S08 | 1.000.000,00 € | 5,68% |
| S09 | 1.000.000,00 € | 5,72% |
| S10 | 1.000.000,00 € | 5,72% |

JSCV recebe 53.474.240, 44 € e JALS 9.241.330, 09 € no horizonte 15A, incluindo saída estimada. A TIR do Grupo de 28, 09% usa 4, 5 M€históricos convencionados no M0; faltam custos/datas individuais para afirmar TIR efetiva de cada promotor. No horizonte 10A aplica-se a política 15 Aselecionada, sem reotimizar as metas como se fossem metas 10A.

Tratamento por categoria uniforme: cada bloco da mesma classe recebe igual montante por ação/base, incluindo promotores. Datas diferentes dos pagamentos novos geram TIR efetivas distintas. A participação equivalente paga é um diagnóstico económico, não prova de titularidade jurídica. Até colocação/pagamento, o valor não colocado fica nos vendedores.

## Dividendos e legalidade

O seletor Proxy prudente limita distribuições pelo excedente e lucro acumulado aproximado, além da dívida e reservas; não é apuramento estatutário de lucros distribuíveis. O modo Documentado bloqueia dividendos enquanto faltar um teto aprovado. Não é possível certificar legalidade das distribuições sem contas, fiscalidade, reservas legais e deliberações. Não foram criados direitos jurídicos nem retornos garantidos.

## Dividendos anuais por bloco — mesma categoria, mesmos direitos

| Ano | Div.P por bloco | Div.G por bloco | Div.S por bloco |
|---|---|---|---|
| 1 | 0,00 € | 0,00 € | 0,00 € |
| 2 | 0,00 € | 0,00 € | 0,00 € |
| 3 | 626.178,15 € | 332.990,88 € | 66.398,14 € |
| 4 | 609.200,92 € | 323.962,68 € | 64.597,92 € |
| 5 | 617.553,13 € | 328.404,24 € | 65.483,57 € |
| 6 | 637.701,42 € | 339.118,75 € | 67.620,03 € |
| 7 | 662.111,57 € | 352.099,66 € | 70.208,42 € |
| 8 | 689.405,96 € | 366.614,35 € | 73.102,63 € |
| 9 | 718.924,18 € | 382.311,64 € | 76.232,66 € |
| 10 | 750.365,51 € | 399.031,60 € | 79.566,61 € |
| 11 | 783.610,09 € | 416.710,50 € | 83.091,77 € |
| 12 | 817.488,03 € | 434.726,21 € | 86.684,09 € |
| 13 | 850.706,04 € | 452.390,98 € | 90.206,43 € |
| 14 | 884.656,25 € | 470.445,13 € | 93.806,42 € |
| 15 | 919.515,69 € | 488.982,78 € | 97.502,81 € |

## Retorno convencional 10A, sem reotimização

| Categoria | MOIC10A | TIR10A | VPL10A |
|---|---|---|---|
| Platinum | 2,57 x | 10,98% | -766.867,13 € |
| Gold | 1,36 x | 3,74% | -2.293.462,04 € |
| Silver | 1,26 x | 2,84% | -490.962,85 € |

## Retorno convencional 15A

| Categoria | Dividendos/bloco | Saída/bloco | MOIC15A |
|---|---|---|---|
| Platinum | 9.567.416,95 € | 24.231.046,93 € | 3,38 x |
| Gold | 5.087.789,39 € | 4.750.098,89 € | 1,97 x |
| Silver | 1.014.501,50 € | 833.764,52 € | 1,85 x |
