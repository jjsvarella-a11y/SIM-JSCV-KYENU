# KK-01 | Hotel,MICE,Residencial e Operador V04

18/10/2026 | KK Hotelaria e Turismo, S.A. | V04

Hotel 200 quartos+MICE têm demonstração própria; o residencial 94 unidades tem exploração separada e apenas o residual da KK entra no consolidado. Não usar previsões agregadas 294 unidades como forecast do Hotel 200.

| Condição | ObjetivoKK | Proposta simulada |
|---|---|---|
| Fee base | 3% | 4% |
| Distribuição/sistemas | 3% | 3% |
| Incentivo | 6% | 10% |

Não foi recebida proposta vinculativa do Operador Internacional. A coluna 4/3/10é cenário interno e não oferta de uma marca. O incentivo incide no GOP positivo após fees fixos, com testes de performance editáveis. O módulo preserva agenda de orçamento, FF&E, CAPEX, reporting, auditoria, rescisão e testes de desempenho.

Receitas, GOP, EBITDA, FF&E, reposição, imposto simplificado, fundo de maneio e CFADS calculam-se mensalmente. Custos de benefícios aplicam-se aos 20 blocos globais após fee incentivo e antes do imposto. Cenários Conservador, Base, Favorável preservados, referência comercial Favorável.

| Indicador | Referência15A |
|---|---|
| Dividendos consolidados | 49.615.724,55 € |
| Saída económica do equity | 75.218.858,32 € |
| DSCR anual mínimo com serviço | 2,99 x |
| TIR novos efetiva | 7,85% |

Alertas internos: gestão/CFADS≥35%, distribuição e sistemas/CFADS≥25%, total≥50%. Não são covenants universais. Comparação com operação sem operador é contrafactual editável, não evidência de produtividade garantida.

## Exploração anual — Hotel+MICE

| Ano de projeto | ReceitaHotel | EBITDAHotel | CFADSHotel |
|---|---|---|---|
| 3 | 8.830.080,00 € | 2.388.634,75 € | 725.983,64 € |
| 4 | 18.095.593,32 € | 4.895.059,06 € | 2.939.287,35 € |
| 5 | 18.984.638,89 € | 5.135.555,76 € | 3.083.960,19 € |
| 10 | 24.014.974,23 € | 6.496.317,36 € | 3.902.616,48 € |
| 15 | 28.689.428,28 € | 7.760.809,12 € | 4.681.949,21 € |

## Residencial

ADR, ocupação, custos, fees, FF&E, fundo de maneio e participação residual são autónomos. Yield alvo não é garantia: pagamento ao proprietário limitado à caixa disponível, défice evidenciado. Sem escritura/disponibilidade no cenário não há rendimento de fração. Residual KK 45% antes de imposto é hipótese herdada por validar; testar também exclusão.

A saída usa apenas Hotel+MICE, EBITDA últimos 12 meses×múltiplo 9, custos 2%, menos dívida e reservas restritas, mais caixa uma vez. Apartamentos vendidos não são reavaliados. Crédito dos vendedores só é recuperável até aos ativos líquidos disponíveis, nunca automaticamente ao par.
