# KK-01 | Equity e Investor Pipeline V04

18/10/2026 | KK Hotelaria e Turismo, S.A. | V04

Potencial 25 M€por 50%, em 12 blocos novos:1 Platinum 10 M€, 1 Gold 5 M€, 10 Silver 1 M€. Capital previsto não é dinheiro recebido. Objetivo comercial: primeiros 15 M€cedo e colocação até M18, em paralelo à negociação do banco.

| Código | Categoria | Ticket | Pagamento plano |
|---|---|---|---|
| P01 | Platinum | 10.000.000,00 € | M1 |
| G01 | Gold | 5.000.000,00 € | M2 |
| S01 | Silver | 1.000.000,00 € | M3 |
| S02 | Silver | 1.000.000,00 € | M3 |
| S03 | Silver | 1.000.000,00 € | M3 |
| S04 | Silver | 1.000.000,00 € | M4 |
| S05 | Silver | 1.000.000,00 € | M4 |
| S06 | Silver | 1.000.000,00 € | M4 |
| S07 | Silver | 1.000.000,00 € | M5 |
| S08 | Silver | 1.000.000,00 € | M5 |
| S09 | Silver | 1.000.000,00 € | M6 |
| S10 | Silver | 1.000.000,00 € | M6 |

| Calendário | Período proposto | Primeiros15M€ |
|---|---|---|
| Acelerado | M1–M3 | M1 |
| Base selecionado | M1–M6 | M2 |
| Prudente | M1–M18 | M3 |

Calendários editáveis por bloco na folha V04 Calendarios. Atrasos e corte de novos compromissos alimentam recebimentos, participação paga equivalente, transferências, dívida, dividendos e TIR. Estados: Prospect, Qualified, Term Sheet, Signed, Paid, Capitalized.

## Executado versus previsto

Investidores, contratos, datas efetivas, comprovativos e montantes realizados não foram fornecidos; os campos documentados ficam vazios. Capital potencial, comprometido, contratado, pago, retido, transferido à KK e elegível banco são separados. Não se declara 25 M€realizados ou contratados.

Venda secundária gera receita dos vendedores. Só a parcela efetivamente transferida entra na KK, uma vez. Transferência não reembolsável é hipótese; empréstimo cria saldo, juros, serviço e dedução na saída. Elegibilidade bancária dos suprimentos não é presumida. A afetação de origem 11.000 ações JSCV/39.000 JALS aos novos investidores é proposta a formalizar, mantendo 40/10/50 quando totalmente colocada.

O valor proposto no CRM é comercial; tickets de referência e seletores aprovados para cenário alimentam o motor. Alterações de preço ou direitos exigem revisão económica e formalização antes de as tratar como contrato. A soma dos recebimentos e das transferências documentadas deve ser reconciliada com extratos e atos societários.
