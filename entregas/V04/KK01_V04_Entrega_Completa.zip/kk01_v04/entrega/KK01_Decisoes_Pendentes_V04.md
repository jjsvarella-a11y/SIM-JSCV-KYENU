# KK-01 | Decisões pendentes V04

18/10/2026 | KK Hotelaria e Turismo, S.A. | V04

Registo central de propostas e decisões. Responsável/órgão/datas abaixo são agenda a validar; não significam deliberação tomada. Nenhuma preferência societária, garantia ou contrato foi aprovado por este trabalho.

## D01 | Estrutura 20 blocos

JSCV 1P+2G / JALS 5S / novos 1P1G10S • 40%/10%/50%; 25 M€ • Board / Jurídico • Board / órgão legal competente • 2 • Proposta / pendente

## D02 | Waterfall

Proporcional / dividendos / saída / combinado / otimizado • Metas convencionadas 10/6/5, 5; recursos conservados • Board / Jurídico • Board / órgão legal competente • 3 • Proposta / pendente

## D03 | Transferência à KK

Irrevogável / capital / suprimento subordinado • Não duplicar preço recebido e capitalização • Board / DF • Board / órgão legal competente • 3 • Proposta / pendente

## D04 | Linha estratégica

20 M€ / 25 M€ / 30 M€ • 30 M€referência; disponibilidade eCPseparados • Board / Banco • Board / órgão legal competente • 3 • Proposta / pendente

## D05 | Pari passu / garantias

Condições a negociar • Limita desembolsos por custo elegível e equity • Banco / Jurídico • Board / órgão legal competente • 6 • Proposta / pendente

## D06 | Pricing e metasRE

Origem / fatores; metas por tipologia • VGV/recebimentos/dívida • CEO / Comercial • Board / órgão legal competente • 3 • Proposta / pendente

## D07 | Escrituras 504/810

Manter hipótese M29 / validar datas • Não alterar contrato por conveniência de caixa • Jurídico / Comercial • Board / órgão legal competente • 24 • Proposta / pendente

## D08 | EAC / contingências

Aprovar BAC e revisões ETC • Custo/prato afetam caixa e completion • Board / Obra • Board / órgão legal competente • 24 • Proposta / pendente

## D09 | HMA

Proposta real / objetivo 3/3/6 / limites • GOP/EBITDA/CFADS/TIR/saída • Board / Jurídico • Board / órgão legal competente • 12 • Proposta / pendente

## D10 | Direitos e benefícios

Votos, nomeações, matérias reservadas, hospitalidade • Custos de benefícios 2P+3G+15S; sem garantias • Board / Jurídico • Board / órgão legal competente • 3 • Proposta / pendente

## D11 | Financial Completion M24

Avançar / corrigir funding / reprogramar • Só cobertura com fontes firmes e custos validados • Board / DF • Board / órgão legal competente • 24 • Proposta / pendente

## D12 | Go/NoGo abertura

Adiar / softopening / abertura formal • Reservas, licenças e prontidão operacional • Board / CEO • Board / órgão legal competente • 30 • Proposta / pendente

## Condições necessárias para execução

Formalizar direitos e origem das ações; validar instrumento e destino do preço; obter compromissos e pagamentos; contratar crédito disponível comCPcumpridas; confirmar orçamento, contingências, fiscalidade e escrituras 504/810; contratar HMA eleaseback; licenciar, aceitar epreparar abertura. Aprovação jurídica da waterfall não dispensa lucro distribuível ou liquidez.
