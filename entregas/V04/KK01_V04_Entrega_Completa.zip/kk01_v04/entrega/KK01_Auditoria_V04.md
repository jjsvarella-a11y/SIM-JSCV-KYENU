# KK-01 | Relatório de auditoria V04

18/10/2026 | KK Hotelaria e Turismo, S.A. | V04

A V04 é evolução incremental da V03; originais V45, V01, V02, V03 preservados. Foram reconciliados inventário, capital, distribuições, caixa e dívida, com recálculo externo e referência Python. Conformidade técnica não equivale a aprovação económica, contabilística, jurídica ou bancária.

## Origem dos 510 registos

A auditoria inicial da V45 identificou 510 registos de erro em cache, 5 fórmulas IF(=...) e12 fórmulas rejeitadas pelo parser na matriz fees. São deteções técnicas, não 527 erros económicos independentes; algumas caches provinham de limitações do motor anterior. Inventário eCSVoriginais acompanham o pacote. A V04 reaudita fórmulas recalculadas, sem aceitar a contagem histórica como prova de novos erros.

## Testes executados

Testes_Fase 1.json — ver ficheiro integral de evidência no pacote.

Testes_Fases 23.json — ver ficheiro integral de evidência no pacote.

Testes_Seletores.json — ver ficheiro integral de evidência no pacote.

Testes_Riscos_Integrados.json — ver ficheiro integral de evidência no pacote.

Testes_Retornos_Completion.json — ver ficheiro integral de evidência no pacote.

Testes_Estruturais_V04.json — ver ficheiro integral de evidência no pacote.

| Verificação | Resultado |
|---|---|
| Fase1Python | 14testes;0falhas |
| Fases2/3Python | 20testes;0falhas |
| Seletores Excel/Python | 9casos; 87785comparações; 0falhas |
| Riscos integrados Excel/Python | 14casos; 166570comparações |
| Retornos10/15A eCompletion | 153comparações; 0falhas |
| Erros de fórmula após recálculo | 0 |
| Integridade estrutural | 29controlos; 0falhas |

## Correções e limites

A primeira reconciliação integral dos riscos identificou diferença no primeiro desembolso em dois blocos de atraso: a avaliação da soma de fees na expressão de draw não refletia todos os encargos no recálculo externo. Foram usadas referências explícitas aos três fees, economicamente equivalentes, e repetidos o recálculo completo e as comparações. O histórico da primeira passagem foi preservado; nenhum resultado foi fixado para ocultar diferença.

| Estado | Tema |
|---|---|
| Conforme | 20blocos;2P3G15S;JSCV40/JALS10/novos50%;100.000ações |
| Conforme | 94frações eVGV reconciliados;calendários,centavos e custos separados |
| Conforme | Linha não renovável,CP/pari passu/janela;juros e dívida reconciliados |
| Conforme | Distribuição100%;igualdade por categoria;pagamentos reais de cenário nasTIR |
| Conforme | Atrasos paralelos usamMAX;leaseback depende de disponibilidade |
| Conforme | Recuperação do crédito de vendedores limitada aos ativos disponíveis |
| Conforme | Retornos10Aaplicam política selecionada15A,sembenchmark proporcional confundido |
| Alerta | Stress de reservas,DSCR em atrasos,VPL investidores negativo a12% |
| Pendente de Validação Externa | Direitos preferenciais,atos societários,destino do preço e lucros legais |
| Pendente de Validação Externa | Recursos firmes,CP,banco,custos,actualcost,licenças,HMA eleaseback |

Recalculado com LibreOfficeDev 26.8 e confrontado com Python/SciPy. Excel Desktop não disponível e não testado. OOXML, notas clássicas, hiperligações, gráficos e validações inspecionados; reabertura pelo LibreOffice verificada. Não existe macros, ligações externas de workbook ou fórmulas substituídas por resultados fixos. O motor usa funções Excel compatíveis e caches recalculadas.

No modo de lucros Proxy prudente as distribuições são cenários, não lucros estatutários comprovados. O modo Documentado deve ser usado para autorizar dividendos mediante teto aprovado; sem teto não distribui. A cobertura M24 documentada permanece indisponível. Os relatórios não declaram o projeto validado apenas por produzir retornos positivos.
