# KK-01 | Comercialização dos94apartamentos V04

18/10/2026 | KK Hotelaria e Turismo, S.A. | V04

Inventário preservado:94 IDs, 13.290m²privativos e VGV 50.656.336, 37 €. Preços originais e dados individuais mantidos. O calendário de origem é plano, não prova de venda.

| Tipologia | Quantidade | MetaY1unidades | VGV metaY1 |
|---|---|---|---|
| Penthouse | 4 | 0 | 0,00 € |
| T1 | 36 | 20 | 6.244.197,70 € |
| T2 | 36 | 20 | 10.164.965,11 € |
| T3 | 18 | 10 | 6.962.491,18 € |
| TOTAL | 94 | 50 | 23.371.653,99 € |

| Tipologia | Contratos previstosM24 | Escrituras previstasM30 | CPCV documentados |
|---|---|---|---|
| Penthouse | 4 | 4 | Indisponível |
| T1 | 36 | 36 | Indisponível |
| T2 | 36 | 36 | Indisponível |
| T3 | 18 | 18 | Indisponível |
| TOTAL | 94 | 94 | Indisponível |

Meta M24:100% contratos; M25–M30 recebimentos e escrituras. Na referência o último contrato previsto ocorre antes M24; o teste sem novas vendas após M24 não muda o resultado por esse motivo, não por ausência de risco. Campos Reserva/CPCV/entradas/prestações/liquidação/escritura/integração documentados separados.

## Recebimentos e pricing

Por fração:5% sinal+20% primeira tranche+55% nas datas semestrais contratualmente disponíveis+20% final; última prestação absorve cêntimos. Sem semestre disponível, o modelo sinaliza diferença em vez de inventar pagamentos. Imposto 1, 5% na escritura, marketing 1% eKyenu 1, 5% no contrato; incidência fiscal por confirmar.

Pricing Origem preserva os preços reconciliados. Motor aplica preço/m²×área×fatores de piso, vista, posição, tipologia, prestígio, absorção e desconto. Alterações propagam a recebimentos, custos, banco e retornos. Não são automaticamente alteração de CPCV.

504/810: escrituras M29 provisórias herdadas e não validadas. Se houver atraso de construção, a disponibilidade física desloca a escritura efetiva de cenário pelo máximo entre conclusão e calendário comercial; atrasos paralelos não são somados como etapas falsas. Nenhum contrato foi alterado pelo modelo. A exploração residencial só usa frações disponíveis e escrituradas no cenário.
