# KK-01 | Dicionário de KPI V04

18/10/2026 | KK Hotelaria e Turismo, S.A. | V04

Fonte única: V04 Dicionario KPI no Excel. Fórmulas integrais permanecem na colunaH; notas hover apresentam definição executiva e método legível, com referência técnica no final. Os limites internos não são universais.

## Valor Global de Vendas

Definição: Soma dos preços das 94 frações, antes de custos comerciais.

Interpretação: Potencial comercial; não é caixa recebida nem contratos assinados.

Unidade: €. Referência: Comparar com recebimentos e custos comerciais.

AUDITORIA | Fonte: KPI!B5; DASH Real Estate!B5. Método: Cálculo descrito na definição; fórmula integral e dependências no DicionárioKPI, colunaH.

## Área privativa comercializada

Definição: Soma das áreas individuais do inventário.

Interpretação: Permite reconciliar quantidades e preço médio; não é área construída total.

Unidade: m². Referência: Conferir projeto e áreas comuns.

AUDITORIA | Fonte: KPI!B6; DASH Real Estate!B6. Método: Cálculo descrito na definição; fórmula integral e dependências no DicionárioKPI, colunaH.

## Preço médio por metro quadrado

Definição: VGV dividido pela área privativa total.

Interpretação: Média ponderada; não média simples dos preços unitários.

Unidade: €/m². Referência: Comparar por piso, tipologia e unidade.

AUDITORIA | Fonte: KPI!B7; DASH Real Estate!B7. Método: Cálculo descrito na definição; fórmula integral e dependências no DicionárioKPI, colunaH.

## Custos comerciais

Definição: Transmissão, marketing e comissãoKyenu separadamente calendarizados.

Interpretação: Diminuem o rendimento líquido das vendas; incidência fiscal por validar.

Unidade: €. Referência: Hipóteses 1, 5%/1%/1, 5%.

AUDITORIA | Fonte: KPI!B8; DASH Real Estate!B8. Método: Cálculo descrito na definição; fórmula integral e dependências no DicionárioKPI, colunaH.

## Rendimento líquido das vendas

Definição: VGV menos custos comerciais previstos.

Interpretação: Antes de construção, financiamento e eventual imposto da promoção.

Unidade: €. Referência: Não confundir com margem líquida final.

AUDITORIA | Fonte: KPI!B9; DASH Real Estate!B9. Método: Cálculo descrito na definição; fórmula integral e dependências no DicionárioKPI, colunaH.

## Investimento futuro na obra

Definição: Construção, FF&E inicial, fiscalização e contingência paga.

Interpretação: Histórico 4, 5 M€não é nova saída futura; atraso/ETC revisto alteram forecast.

Unidade: €. Referência: Orçamento aprovado por confirmar.

AUDITORIA | Fonte: KPI!B10; DASH Consolidado!B5. Método: Cálculo descrito na definição; fórmula integral e dependências no DicionárioKPI, colunaH.

## CAPEX imputado residencial

Definição: Quota do investimento atribuída às frações por área.

Interpretação: É proxy de segmentação; carece de orçamento por componente.

Unidade: €. Referência: Não é custo específico contratualmente aprovado.

AUDITORIA | Fonte: KPI!B11; DASH Real Estate!B10. Método: Cálculo descrito na definição; fórmula integral e dependências no DicionárioKPI, colunaH.

## Resultado da promoção — proxy

Definição: Vendas líquidas menos CAPEX imputado ao residencial.

Interpretação: Margem antes de custos financeiros e fiscalidade completa.

Unidade: €. Referência: Confirmar imputação e impostos.

AUDITORIA | Fonte: KPI!B12; DASH Real Estate!B11. Método: Cálculo descrito na definição; fórmula integral e dependências no DicionárioKPI, colunaH.

## Margem imobiliária — proxy

Definição: Resultado da promoção dividido pelo VGV.

Interpretação: Permite comparar preços e custo imputado; não representa lucro líquido auditado.

Unidade: %. Referência: Sem limiar universal.

AUDITORIA | Fonte: KPI!B13; DASH Real Estate!B12. Método: Cálculo descrito na definição; fórmula integral e dependências no DicionárioKPI, colunaH.

## Pico intramensal da dívida bancária

Definição: Maior saldo inicial acrescido do desembolso do mês.

Interpretação: Mede a exposição máxima; distinto da utilização acumulada da linha não renovável.

Unidade: €. Referência: Comparar com limite e capacidade mobilizável.

AUDITORIA | Fonte: KPI!B14; DASH Consolidado!B7; EXEC KK 01!I7. Método: Cálculo descrito na definição; fórmula integral e dependências no DicionárioKPI, colunaH.

## Dívida bancária no M30

Definição: Saldo bancário após pagamentos do mês 30.

Interpretação: Não inclui automaticamente empréstimos dos vendedores, mostrados separadamente.

Unidade: €. Referência: M30é referência; abertura pode atrasar.

AUDITORIA | Fonte: KPI!B15; DASH Consolidado!B8; EXEC KK 01!E12. Método: Cálculo descrito na definição; fórmula integral e dependências no DicionárioKPI, colunaH.

## Caixa no M30

Definição: Saldo de tesouraria após entradas, saídas e distribuições do M30.

Interpretação: Pode conter reservas protegidas; não é todo livre para dividendos.

Unidade: €. Referência: Comparar com reserva protegida.

AUDITORIA | Fonte: KPI!B16; DASH Consolidado!B9. Método: Cálculo descrito na definição; fórmula integral e dependências no DicionárioKPI, colunaH.

## Dívida bancária no M42

Definição: Saldo do banco no final do mês 42.

Interpretação: Permite testar transição da carência de capital.

Unidade: €. Referência: Carência 42 Mé hipótese de negociação.

AUDITORIA | Fonte: KPI!B17; DASH Consolidado!B10. Método: Cálculo descrito na definição; fórmula integral e dependências no DicionárioKPI, colunaH.

## Caixa no M42

Definição: Tesouraria final do mês 42.

Interpretação: Verificar reserva e serviço obrigatório na transição da carência.

Unidade: €. Referência: Não confundir com caixa livre.

AUDITORIA | Fonte: KPI!B18. Método: Cálculo descrito na definição; fórmula integral e dependências no DicionárioKPI, colunaH.

## Juros bancários acumulados

Definição: Soma dos juros sobre saldos bancários efetivamente usados no cenário.

Interpretação: Menor utilização/taxa pode reduzir custo; linha disponível é proteção, não recomendação de redução.

Unidade: €. Referência: Outros encargos e crédito de vendedores separados.

AUDITORIA | Fonte: KPI!B19; DASH Consolidado!B14; EXEC KK 01!I12. Método: Cálculo descrito na definição; fórmula integral e dependências no DicionárioKPI, colunaH.

## Comissões e success fee

Definição: Abertura, mobilização e broker condicionados à primeira utilização.

Interpretação: Taxas de referência não são contrato; verificar sobreposição.

Unidade: €. Referência: Custo de compromisso adicional editável.

AUDITORIA | Fonte: KPI!B20; DASH Consolidado!B15. Método: Cálculo descrito na definição; fórmula integral e dependências no DicionárioKPI, colunaH.

## Caixa mínima projetada

Definição: Menor saldo mensal do fluxo integrado.

Interpretação: Saldo positivo não prova cumprimento da reserva nem funding assegurado.

Unidade: €. Referência: Ver insuficiência de reservas e completionsecured.

AUDITORIA | Fonte: KPI!B21; DASH Consolidado!B11; EXEC KK 01!A12. Método: Cálculo descrito na definição; fórmula integral e dependências no DicionárioKPI, colunaH.

## Insuficiência máxima de reservas

Definição: Maior diferença positiva entre reserva exigida e caixa.

Interpretação: Mesmo sem caixa negativa, insuficiência viola a política de segurança financeira.

Unidade: €. Referência: 0é referência interna de cumprimento.

AUDITORIA | Fonte: KPI!B22; DASH Consolidado!B12; DASH Consolidado!B21; DASH Riscos!B8. Método: Cálculo descrito na definição; fórmula integral e dependências no DicionárioKPI, colunaH.

## Défice não financiado

Definição: Maior falta de caixa após financiamento contratualmente simulável.

Interpretação: TIR positiva não torna um cenário com défice viável.

Unidade: €. Referência: 0 necessário, mas não suficiente.

AUDITORIA | Fonte: KPI!B23; DASH Consolidado!B13; DASH Riscos!B7. Método: Cálculo descrito na definição; fórmula integral e dependências no DicionárioKPI, colunaH.

## Dívida bancária final

Definição: Saldo do crédito bancário no M180.

Interpretação: Empréstimos dos vendedores constam em coluna própria e são deduzidos na saída.

Unidade: €. Referência: Prazo contratual pode exceder horizonte.

AUDITORIA | Fonte: KPI!B24. Método: Cálculo descrito na definição; fórmula integral e dependências no DicionárioKPI, colunaH.

## Caixa final

Definição: Tesouraria no M180 antes da venda hipotética dos ativos.

Interpretação: Somada uma única vez na saída, com reservas restritas deduzidas.

Unidade: €. Referência: Não duplicar no valor terminal.

AUDITORIA | Fonte: KPI!B25. Método: Cálculo descrito na definição; fórmula integral e dependências no DicionárioKPI, colunaH.

## VPL do projeto sem saída

Definição: Valor presente dos fluxos futuros do projeto sem alienação terminal.

Interpretação: Positivo indica excedente acima da taxa de desconto adotada.

Unidade: €. Referência: Taxa de projeto editável; não valor de mercado.

AUDITORIA | Fonte: KPI!B26; DASH Consolidado!B16. Método: Desconto mensal pela taxa anual efetiva convertida; pagamentos e recebimentos identificados na fonte.

## VPL do projeto com saída

Definição: VPL dos fluxos futuros acrescido do valor terminal económico.

Interpretação: Depende de avaliação e liquidez não contratadas.

Unidade: €. Referência: Taxa de projeto editável; saída estimada.

AUDITORIA | Fonte: KPI!B27; DASH Consolidado!B18. Método: Desconto mensal pela taxa anual efetiva convertida; pagamentos e recebimentos identificados na fonte.

## TIR do projeto sem saída

Definição: Taxa anual efetiva dos fluxos incrementais do empreendimento.

Interpretação: Fluxos não convencionais podem admitir mais de uma raiz; avaliar também VPL.

Unidade: %. Referência: Não substitui análise de liquidez.

AUDITORIA | Fonte: KPI!B28; DASH Consolidado!B17. Método: (1+TIR mensal)^12−1; fluxos positivos e negativos em meses coerentes.

## TIR do projeto com saída

Definição: Retorno anualizado incluindo alienação estimada do Hotel.

Interpretação: Depende do múltiplo, EBITDA e custos da saída.

Unidade: %. Referência: Não retorno garantido.

AUDITORIA | Fonte: KPI!B29. Método: (1+TIR mensal)^12−1; fluxos positivos e negativos em meses coerentes.

## TIR efetiva dos novos investidores

Definição: Retorno dos pagamentos previstos dos investidores e recebimentos pela waterfall selecionada.

Interpretação: Diferente da TIR convencional dos blocos promotores; datas de pagamento importam.

Unidade: %. Referência: Comparar com retorno exigido e riscos.

AUDITORIA | Fonte: KPI!B30; DASH Acionistas!B8; DASH Acionistas!B9; DASH Consolidado!B19; EXEC KK 01!E17. Método: (1+TIR mensal)^12−1; fluxos positivos e negativos em meses coerentes.

## MOIC dos novos investidores

Definição: Total recebido dividido pelo capital efetivamente pago no cenário.

Interpretação: Não mede o tempo até aos recebimentos; usar com TIR.

Unidade: x. Referência: Não inclui capital meramente prometido.

AUDITORIA | Fonte: KPI!B31; DASH Acionistas!B10; DASH Acionistas!B11; EXEC KK 01!I17. Método: Total recebido / capital pago; sem efeito do prazo de recebimento.

## VPL dos novos investidores

Definição: Valor presente de recebimentos menos pagamentos pela política selecionada.

Interpretação: Negativo significa retorno inferior à taxa de desconto escolhida.

Unidade: €. Referência: 12% é hipótese editável, não limite universal.

AUDITORIA | Fonte: KPI!B32; DASH Acionistas!B16; EXEC KK 01!M17. Método: Desconto mensal pela taxa anual efetiva convertida; pagamentos e recebimentos identificados na fonte.

## DSCR do ano inicial parcial

Definição: CFADSHotel dividido pelo serviço obrigatório no ano de abertura parcial.

Interpretação: Pode incluir juros da construção; não comparar indiscriminadamente com ano estabilizado.

Unidade: x. Referência: Alerta 1, 3 xé interno, não covenant aprovado.

AUDITORIA | Fonte: KPI!B33; DASH Hotel MICE!B19; EXEC KK 01!M12. Método: CFADS / serviço obrigatório; amortização voluntária excluída; sem serviço o rácio é indefinido.

## DSCR dos anos operacionais completos

Definição: Menor cobertura anual com serviço obrigatório e operação completa.

Interpretação: Exclui amortização voluntária; sem serviço de dívida o rácio fica indefinido.

Unidade: x. Referência: Não usar 999 para ausência de dívida.

AUDITORIA | Fonte: KPI!B34; DASH Hotel MICE!B20. Método: CFADS / serviço obrigatório; amortização voluntária excluída; sem serviço o rácio é indefinido.

## Margem até ao limite de crédito

Definição: Diferença entre limite estratégico e exposição bancária máxima.

Interpretação: Não significa capacidade disponível para novo desembolso numa linha não renovável.

Unidade: €. Referência: Conferir utilizado acumulado eCP.

AUDITORIA | Fonte: KPI!B35. Método: Cálculo descrito na definição; fórmula integral e dependências no DicionárioKPI, colunaH.

## Margem de segurança de caixa

Definição: Folga de tesouraria face às reservas do cenário.

Interpretação: Folga projetada não é liquidez documentada nem garantia de conclusão.

Unidade: €. Referência: Política de reservas editável.

AUDITORIA | Fonte: KPI!B36. Método: Cálculo descrito na definição; fórmula integral e dependências no DicionárioKPI, colunaH.

## Payback do projeto

Definição: Mês de recuperação acumulada do investimento futuro sem saída.

Interpretação: Não inclui avaliações hipotéticas; pode não ocorrer no horizonte.

Unidade: meses. Referência: Usar com VPL e TIR.

AUDITORIA | Fonte: KPI!B37. Método: Cálculo descrito na definição; fórmula integral e dependências no DicionárioKPI, colunaH.

## Utilização acumulada da linha

Definição: Soma de todos os desembolsos bancários.

Interpretação: Amortizações não repõem capacidade de uma linha não renovável.

Unidade: €. Referência: Limite estratégico 30 M€na referência.

AUDITORIA | Fonte: KPI!B38; DASH Consolidado!B24; EXEC KK 01!M7. Método: Cálculo descrito na definição; fórmula integral e dependências no DicionárioKPI, colunaH.

## Linha não utilizada

Definição: Limite estratégico menos desembolsos acumulados.

Interpretação: Não equivale a crédito efetivamente mobilizável: depende deCP, calendário e contrato.

Unidade: €. Referência: Distinguir contratado/utilizado/mobilizável.

AUDITORIA | Fonte: KPI!B39; DASH Consolidado!B23. Método: Cálculo descrito na definição; fórmula integral e dependências no DicionárioKPI, colunaH.

## Payback por dividendos dos investidores

Definição: Mês em que dividendos acumulados cobrem o capital pago.

Interpretação: Exclui a saída estimada; retorno pode depender dessa saída.

Unidade: meses. Referência: Não promessa de recuperação.

AUDITORIA | Fonte: KPI!B40; DASH Acionistas!B20. Método: Cálculo descrito na definição; fórmula integral e dependências no DicionárioKPI, colunaH.

## Completion Funding Coverage projetada

Definição: Fontes projetadas no M24 divididas pelas necessidades para concluir e abrir.

Interpretação: Maior que 1 não prova financiamento firme; exige análise mensal e documentação.

Unidade: x. Referência: M24é marco estratégico antes da conclusão M30.

AUDITORIA | Fonte: V04 Completion!B17. Método: Fontes elegíveis / custos e reservas remanescentes; documentos e calendário de mobilização separados.

## Completion Funding Coverage assegurada

Definição: Recursos firmes documentados divididos por custo de conclusão validado.

Interpretação: Indisponível enquanto faltarem extratos, CP, compromissos e validação de custos/calendário.

Unidade: x. Referência: Não classificar como coberto sem evidência.

AUDITORIA | Fonte: V04 Completion!C17; EXEC KK 01!M51. Método: Fontes elegíveis / custos e reservas remanescentes; documentos e calendário de mobilização separados.

## Estimate at Completion

Definição: Actual Cost documentado mais previsão do custo remanescente.

Interpretação: Não apresentar plano como executado; semActual Cost documentado fica indisponível.

Unidade: €. Referência: Comparar com BAC aprovado.

AUDITORIA | Fonte: V04 EAC!B193; EXEC KK 01!A56. Método: Cálculo descrito na definição; fórmula integral e dependências no DicionárioKPI, colunaH.

## Cost to Complete

Definição: Custo remanescente previsto após o mês de controlo.

Interpretação: Revisão ETC altera CAPEX futuro e financiamento; não reescreve dados históricos desconhecidos.

Unidade: €. Referência: Validar medições e compromissos.

AUDITORIA | Fonte: V04 EAC!B192. Método: Cálculo descrito na definição; fórmula integral e dependências no DicionárioKPI, colunaH.

## Budget at Completion

Definição: Orçamento total de referência para a obra.

Interpretação: Distinguir orçamento inicial, aprovado e forecast.

Unidade: €. Referência: Aprovação documental separada.

AUDITORIA | Fonte: V04 EAC!B188. Método: Cálculo descrito na definição; fórmula integral e dependências no DicionárioKPI, colunaH.

## Variance at Completion

Definição: BAC menos EAC.

Interpretação: Negativo indica sobrecusto previsto; indisponível seActual Cost não comprovado.

Unidade: €. Referência: SemActual Cost não afirmar desvio executado.

AUDITORIA | Fonte: V04 EAC!B194. Método: Cálculo descrito na definição; fórmula integral e dependências no DicionárioKPI, colunaH.

## TIR convencional por bloco

Definição: Retorno sobre a base 10/5/1 M€referida ao M1, com direitos iguais dentro da categoria.

Interpretação: Para promotores é referência negocial, não investimento novo; não confundir com TIR histórica.

Unidade: %. Referência: Metas 10%/6%/5, 5% não garantidas nem aprovadas.

AUDITORIA | Fonte: V04 Retornos!D5; V04 Retornos!D6; V04 Retornos!D7; EXEC KK 01!A51; EXEC KK 01!E51; EXEC KK 01!I51. Método: (1+TIR mensal)^12−1; fluxos positivos e negativos em meses coerentes.

## Prontidão documental da abertura

Definição: Proporção dos 13 requisitos com progresso, aprovação e documento.

Interpretação: Não equivale a progresso físico; sem dados a prontidão é indisponível.

Unidade: %. Referência: Abertura 31 Mna referência; licenças e aceitação obrigatórias.

AUDITORIA | Fonte: V04 Opening Readiness!B20; EXEC KK 01!I56. Método: Cálculo descrito na definição; fórmula integral e dependências no DicionárioKPI, colunaH.

## ADR — Average Daily Rate

Definição: Receita média de alojamento por quarto ocupado.

Interpretação: Distinguir Hotel 200 quartos do pool 94 apartamentos.

Unidade: €/noite. Referência: Hipóteses por cenário e crescimento anual.

AUDITORIA | Fonte: DASH Hotel MICE!B6; DASH Residencial!B5. Método: Cálculo descrito na definição; fórmula integral e dependências no DicionárioKPI, colunaH.

## Taxa de ocupação

Definição: Noites ocupadas divididas pela capacidade disponível.

Interpretação: Quartos disponíveis dependem de abertura e, na residência, de escritura no cenário.

Unidade: %. Referência: Não é forecast contratualmente garantido.

AUDITORIA | Fonte: DASH Hotel MICE!B7; DASH Residencial!B6. Método: Cálculo descrito na definição; fórmula integral e dependências no DicionárioKPI, colunaH.

## GOP — resultado operacional bruto

Definição: Receitas menos custos departamentais e gastos gerais.

Interpretação: Base para avaliar gestão antes dos fees e custos subsequentes.

Unidade: €. Referência: Comparar cenário sem operador e remuneração.

AUDITORIA | Fonte: DASH Hotel MICE!B9; DASH Hotel MICE!B24; DASH Operador!B15. Método: Cálculo descrito na definição; fórmula integral e dependências no DicionárioKPI, colunaH.

## EBITDAHotel+MICE

Definição: GOP menos fees e custos de benefícios atribuídos.

Interpretação: Não é caixa distribuível; faltamFF&E, CAPEX, impostos, fundo de maneio e dívida.

Unidade: €. Referência: Hotel 200 quartos, sem duplicar 94 frações.

AUDITORIA | Fonte: DASH Hotel MICE!B10; DASH Hotel MICE!B25; EXEC KK 01!A17. Método: Cálculo descrito na definição; fórmula integral e dependências no DicionárioKPI, colunaH.

## CFADS — caixa disponível para dívida

Definição: Caixa operacional apósFF&E, reposição, imposto proxy e variação do fundo de maneio.

Interpretação: Base de cobertura do serviço obrigatório; não confundir com EBITDA.

Unidade: €. Referência: Modelo fiscal simplificado por validar.

AUDITORIA | Fonte: DASH Hotel MICE!B13; DASH Hotel MICE!B14; DASH Hotel MICE!B15; DASH Hotel MICE!B16; DASH Operador!B10; DASH Operador!B11; DASH Operador!B12. Método: Cálculo descrito na definição; fórmula integral e dependências no DicionárioKPI, colunaH.

## Encargos do Operador Internacional

Definição: Fees base, incentivo e distribuição/sistemas em relação ao CFADS.

Interpretação: Avaliar custo e valor produzido; ratios altos sinalizam pressão na caixa KK.

Unidade: % / €. Referência: Alertas internos 35% gestão, 25% sistemas, 50% total; não limites contratuais.

AUDITORIA | Fonte: DASH Hotel MICE!B11; DASH Hotel MICE!B12; DASH Operador!B6; DASH Operador!B7; DASH Operador!B8. Método: Cálculo descrito na definição; fórmula integral e dependências no DicionárioKPI, colunaH.

## Capital previsto para KK

Definição: Soma dos pagamentos de cenário efetivamente transferidos à sociedade.

Interpretação: Não confundir preço recebido pelos vendedores com entrada KK ou capital documentado.

Unidade: €. Referência: Transferência e instrumento jurídico por validar.

AUDITORIA | Fonte: EXEC KK 01!A7. Método: Cálculo descrito na definição; fórmula integral e dependências no DicionárioKPI, colunaH.

## Participação paga equivalente

Definição: Quota económica contratada multiplicada pela fração do preço paga no cenário.

Interpretação: Diagnóstico económico; não reconhece titularidade jurídica ou direitos antes da formalização.

Unidade: %. Referência: Quadros distinguem estrutura alvo e pagamento.

AUDITORIA | Fonte: EXEC KK 01!E7. Método: Cálculo descrito na definição; fórmula integral e dependências no DicionárioKPI, colunaH.
